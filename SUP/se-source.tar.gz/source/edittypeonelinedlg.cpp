#include "qdebug.h"
#include "qmessagebox.h"

#include "library.h"
#include "eventnode.h"
#include "edittypeonelinedlg.h"
#include "ui_edittypeonelinedlg.h"


// *****************************************
// Constructor function.
// *****************************************
EditTypeOneLineDlg::EditTypeOneLineDlg(QWidget *parent, hypocenter_ *HypoCenter) : QDialog(parent), ui(new Ui::EditTypeOneLineDlg)
{
   // Set up the user interface.
   ui->setupUi(this);

   // Save pointer to the hypocenter.
   Hyp = HypoCenter;

   // Connect signals from the check boxes.
   connect(ui->FixLocCheckBox, SIGNAL(stateChanged(int)), this, SLOT(FixLocChanged(int)));
   connect(ui->StartLocCheckBox, SIGNAL(stateChanged(int)), this, SLOT(StartLocChanged(int)));
   connect(ui->FixDepthCheckBox, SIGNAL(stateChanged(int)), this, SLOT(FixDepthChanged(int)));
   connect(ui->StartDepthCheckBox, SIGNAL(stateChanged(int)), this, SLOT(StartDepthChanged(int)));

   // Initialize the date widget.
   CreateDateStr(Hyp->time, &String);
   ui->DateEdit->setText(String);

   // Initialize the time widget.
   CreateTimeStr(Hyp->time, &String);
   ui->TimeEdit->setText(String);

   // Initialize the Distance index (DI) widget.
   if (Hyp->dist_id != 32) ui->DistIndEdit->setText(QChar(Hyp->dist_id));

   // Initialize the latitude/logitude widgets.
   if (Hyp->lat != -999) ui->LatEdit->setText(QString::number(Hyp->lat,'f',3));
   if (Hyp->lon != -999) ui->LonEdit->setText(QString::number(Hyp->lon,'f',3));

   // Initialize the depth widget.
   if (Hyp->depth != -999) ui->DepthEdit->setText(QString::number(Hyp->depth,'f',1));

   // Initialize the agency widget.
   ui->AgencyEdit->setText(QString(Hyp->agency));

   // Initialize the NSt widget.
   if (Hyp->nstat != -999) ui->NumStaEdit->setText(QString::number(Hyp->nstat));

   // Initialize the RMS widget.
   if (Hyp->rms != -999) ui->RmsEdit->setText(QString::number(Hyp->rms,'f',1));

   // Create a list of all hypcenter magnitudes.
   GetHypocenterMags();

   // Initialize the first set of magnitude widgets.
   if (MagList.size()) {
      ui->Mag1Edit->setText(QString::number(MagList.at(0).value,'f',1));
      ui->Type1Edit->setText(QChar(MagList.at(0).type));
      ui->Agency1Edit->setText(QString(MagList.at(0).agency));
   }

   // Initialize the second set of magnitude widgets.
   if (MagList.size() >= 2) {
      ui->Mag2Edit->setText(QString::number(MagList.at(1).value,'f',1));
      ui->Type2Edit->setText(QChar(MagList.at(1).type));
      ui->Agency2Edit->setText(QString(MagList.at(1).agency));
   }

   // Initialize the third set of magnitude widgets.
   if (MagList.size() >= 3) {
      ui->Mag3Edit->setText(QString::number(MagList.at(2).value,'f',1));
      ui->Type3Edit->setText(QChar(MagList.at(2).type));
      ui->Agency3Edit->setText(QString(MagList.at(2).agency));
   }

   // Initialize the model index (Mod) widget.
   if (Hyp->modl_id != 32) ui->ModEdit->setText(QChar(Hyp->modl_id));

   // Initialize the event indicator (EI) widget.
   if (Hyp->evnt_id != 32) ui->EventIndEdit->setText(QChar(Hyp->evnt_id));

   // Initialize the fix depth/start depth widgets.
   if (Hyp->depth_flag == 'F') ui->FixDepthCheckBox->setChecked(true);
   if (Hyp->depth_flag == 'S') ui->StartDepthCheckBox->setChecked(true);

   // Initialize the fix location/start location widgets.
   if (Hyp->epi_flag == 'F') ui->FixLocCheckBox->setChecked(true);
   if (Hyp->epi_flag == 'S') ui->StartLocCheckBox->setChecked(true);

   // Set input focus to the time widget.
   ui->TimeEdit->setFocus();
}




// *****************************************
// Destructor function.
// *****************************************
EditTypeOneLineDlg::~EditTypeOneLineDlg()
{
    delete ui;
}




// ***********************************
// User has pressed the 'OK' button.
// ***********************************
void EditTypeOneLineDlg::accept()
{
   bool ValueOK;
   int iValue, i;
   float fValue, Magnitude;
   QString strValue, Agency, Type;

   // Check the date. This value is mandatory.
   QDate Date = QDate::fromString(ui->DateEdit->text().simplified(), "yyyyMMdd");
   if (!Date.isValid()) {
      Date = QDate::fromString(ui->DateEdit->text(), "yyyy-MM-dd");
      if (!Date.isValid()) {
         QMessageBox::critical(NULL, "Add hypocenter line.", "Date is invalid or mising.");
         ui->DateEdit->selectAll(); ui->DateEdit->setFocus();
         return;
      }
   }

   // Check the time. This value is mandatory.
   QTime Time = QTime::fromString(ui->TimeEdit->text().simplified(), "hhmmss.z");
   if (!Time.isValid()) {
      Time = QTime::fromString(ui->TimeEdit->text(), "hh:mm:ss.z");
      if (!Time.isValid()) {
         QMessageBox::critical(NULL, "Add hypocenter line.", "Time is invalid or mising.");
         ui->TimeEdit->selectAll(); ui->TimeEdit->setFocus();
         return;
      }
   }


   // Check the distance indicator. This value is mandatory.
   strValue = ui->DistIndEdit->text().simplified().toUpper();
   if (strValue != "L" && strValue != "R" && strValue != "D") {
      QMessageBox::critical(NULL, "Add hypocenter line.", "Distance indicator is invalid or mising.");
      ui->DistIndEdit->selectAll(); ui->DistIndEdit->setFocus();
      return;
   }

   // Check the latitude value. This value is not mandatory.
   if (ui->LatEdit->text().simplified().size()) {
      fValue = ui->LatEdit->text().toFloat(&ValueOK);
      if (!ValueOK || fValue > 90.0 || fValue < -90.0) {
         QMessageBox::critical(this, "Add hypocenter line", "An invalid latitude value has been entered.");
         ui->LatEdit->selectAll(); ui->LatEdit->setFocus();
         return;
      }
   }

   // Check the longitude value. This value is not mandatory.
   if (ui->LonEdit->text().simplified().size()) {
      fValue = ui->LonEdit->text().toFloat(&ValueOK);
      if (!ValueOK || fValue > 180.0 || fValue < -180.0) {
         QMessageBox::critical(this, "Add hypocenter line", "An invalid longitude value has been entered.");
         ui->LonEdit->selectAll(); ui->LonEdit->setFocus();
         return;
      }
   }

   // Check the depth value. This value is not mandatory.
   if (ui->DepthEdit->text().simplified().size()) {
      ui->DepthEdit->text().toFloat(&ValueOK);
      if (!ValueOK) {
         QMessageBox::critical(this, "Add hypocenter line", "An invalid depth value has been entered.");
         ui->DepthEdit->selectAll(); ui->DepthEdit->setFocus();
         return;
      }
   }

   // Check the agency name. 1-3 chars. This value is not mandatory.
   if (ui->AgencyEdit->text().simplified().size()) {
      strValue = ui->AgencyEdit->text().toUpper();
      if (((strValue.size()>3) || !strValue.contains(QRegExp("^[a-zA-Z]+$")))) {
         QMessageBox::critical(this, "Add hypocenter line", "An invalid agency name has been entered.");
         ui->AgencyEdit->selectAll(); ui->AgencyEdit->setFocus();
         return;
      }
   }

   // Check number of stations. This value is not mandatory.
   if (ui->NumStaEdit->text().simplified().size()) {
      iValue = ui->NumStaEdit->text().toInt(&ValueOK);
      if (!ValueOK || iValue <= 0) {
         QMessageBox::critical(this, "Add hypocenter line", "An invalid number of stations been entered.");
         ui->NumStaEdit->selectAll(); ui->NumStaEdit->setFocus();
         return;
      }
   }

   // Check the RMS value. This value is not mandatory.
   if (ui->RmsEdit->text().simplified().size()) {
      fValue = ui->RmsEdit->text().toFloat(&ValueOK);
      if (!ValueOK || fValue < 0) {
         QMessageBox::critical(this, "Add hypocenter line", "An invalid RMS value has been entered.");
         ui->RmsEdit->selectAll(); ui->RmsEdit->setFocus();
         return;
      }
   }

   // Check the first magnitude. These values are not mandatory.
   bool Mag1ValueOK = false, Mag1TypeOK = false, Mag1AgencyOK = false;
   if (ui->Mag1Edit->text().simplified().size()) {
      fValue = ui->Mag1Edit->text().simplified().toFloat(&ValueOK);
      if (!ValueOK || fValue < -10 || fValue > 10) {
         QMessageBox::critical(this, "Add hypocenter line", "An invalid magnitude value has been entered.");
         ui->Mag1Edit->selectAll(); ui->Mag1Edit->setFocus();
         return;
      }
      Mag1ValueOK = true;
   }
   if (ui->Type1Edit->text().simplified().size()) {
      strValue = ui->Type1Edit->text();
      if (strValue != "W" && strValue != "L" && strValue != "N" && strValue != "C" &&
          strValue != "b" && strValue != "B" && strValue != "s" && strValue != "S") {
         QMessageBox::critical(NULL, "Add hypocenter line.", "An invalid magnitude type has been entered.");
         ui->Type1Edit->selectAll(); ui->Type1Edit->setFocus();
         return;
      }
      Mag1TypeOK = true;
   }
   if (ui->Agency1Edit->text().simplified().size()) {
      strValue = ui->Agency1Edit->text().simplified().toUpper();
      if (((strValue.size()>3) || !strValue.contains(QRegExp("^[a-zA-Z]+$")))) {
         QMessageBox::critical(this, "Add hypocenter line", "An invalid agency name has been entered.");
         ui->Agency1Edit->selectAll(); ui->Agency1Edit->setFocus();
         return;
      }
      Mag1AgencyOK = true;
   }

   // Check the second magnitude. These values are not mandatory.
   bool Mag2ValueOK = false, Mag2TypeOK = false, Mag2AgencyOK = false;
   if (ui->Mag2Edit->text().simplified().size()) {
      fValue = ui->Mag2Edit->text().simplified().toFloat(&ValueOK);
      if (!ValueOK || fValue < -10 || fValue > 10) {
         QMessageBox::critical(this, "Add hypocenter line", "An invalid magnitude value has been entered.");
         ui->Mag2Edit->selectAll(); ui->Mag2Edit->setFocus();
         return;
      }
      Mag2ValueOK = true;
   }
   if (ui->Type2Edit->text().simplified().size()) {
      strValue = ui->Type2Edit->text();
      if (strValue != "W" && strValue != "L" && strValue != "N" && strValue != "C" &&
          strValue != "b" && strValue != "B" && strValue != "s" && strValue != "S") {
         QMessageBox::critical(NULL, "Add hypocenter line.", "An invalid magnitude type has been entered.");
         ui->Type2Edit->selectAll(); ui->Type2Edit->setFocus();
         return;
      }
      Mag2TypeOK = true;
   }
   if (ui->Agency2Edit->text().simplified().size()) {
      strValue = ui->Agency2Edit->text().simplified().toUpper();
      if (((strValue.size()>3) || !strValue.contains(QRegExp("^[a-zA-Z]+$")))) {
         QMessageBox::critical(this, "Add hypocenter line", "An invalid agency name has been entered.");
         ui->Agency2Edit->selectAll(); ui->Agency2Edit->setFocus();
         return;
      }
      Mag2AgencyOK = true;
   }

   // Check the third magnitude. These values are not mandatory.
   bool Mag3ValueOK = false, Mag3TypeOK = false, Mag3AgencyOK = false;
   if (ui->Mag3Edit->text().simplified().size()) {
      fValue = ui->Mag3Edit->text().simplified().toFloat(&ValueOK);
      if (!ValueOK || fValue < -10 || fValue > 10) {
         QMessageBox::critical(this, "Add hypocenter line", "An invalid magnitude value has been entered.");
         ui->Mag3Edit->selectAll(); ui->Mag3Edit->setFocus();
         return;
      }
      Mag3ValueOK = true;
   }
   if (ui->Type3Edit->text().simplified().size()) {
      strValue = ui->Type3Edit->text();
      if (strValue != "W" && strValue != "L" && strValue != "N" && strValue != "C" &&
          strValue != "b" && strValue != "B" && strValue != "s" && strValue != "S") {
         QMessageBox::critical(NULL, "Add hypocenter line.", "An invalid magnitude type has been entered.");
         ui->Type3Edit->selectAll(); ui->Type3Edit->setFocus();
         return;
      }
      Mag3TypeOK = true;
   }
   if (ui->Agency3Edit->text().simplified().size()) {
      strValue = ui->Agency3Edit->text().simplified().toUpper();
      if (((strValue.size()>3) || !strValue.contains(QRegExp("^[a-zA-Z]+$")))) {
         QMessageBox::critical(this, "Add hypocenter line", "An invalid agency name has been entered.");
         ui->Agency3Edit->selectAll(); ui->Agency3Edit->setFocus();
         return;
      }
      Mag3AgencyOK = true;
   }

   // Check the model value. This value is not mandatory.
   if (ui->ModEdit->text().size()) {
      strValue = ui->ModEdit->text().simplified();
      if (strValue.size() != 1) {
         QMessageBox::critical(NULL, "Add hypocenter line.", "An invalid model indicator has been entered.");
         ui->ModEdit->selectAll(); ui->ModEdit->setFocus();
         return;
      }
   }

   // Check the event indicator value. This value is not mandatory.
   if (ui->EventIndEdit->text().trimmed().size()) {
      strValue = ui->EventIndEdit->text();
      if (strValue.size() != 1 || (strValue.size() && strValue != " " && !strValue.at(0).isLetter())) {
         QMessageBox::critical(NULL, "Add hypocenter line.", "An invalid event indicator has been entered.");
         ui->EventIndEdit->selectAll(); ui->EventIndEdit->setFocus();
         return;
      }
   }

   // Check that magnitde value is given if agency/type is given.
   if ((Mag1TypeOK || Mag1AgencyOK) && !Mag1ValueOK) {
      QMessageBox::critical(NULL, "Add hypocenter line.", "Magnitude value is invalid or missing for first magnitude.");
      ui->Mag1Edit->setFocus();
      return;
   }
   if ((Mag2TypeOK || Mag2AgencyOK) && !Mag2ValueOK) {
      QMessageBox::critical(NULL, "Add hypocenter line.", "Magnitude value is invalid or missing for second magnitude.");
      ui->Mag2Edit->setFocus();
      return;
   }
   if ((Mag3TypeOK || Mag3AgencyOK) && !Mag3ValueOK) {
      QMessageBox::critical(NULL, "Add hypocenter line.", "Magnitude value is invalid or missing for third magnitude.");
      ui->Mag3Edit->setFocus();
      return;
   }


   // ----------------------------------------------------------------------------------------------------
   // All checks passed. Return values.
   // ----------------------------------------------------------------------------------------------------

   // Clear/initialize the hypocenter structure.
   HypInitialize(Hyp);

   // Return date.
   Date = QDate::fromString(ui->DateEdit->text().simplified(), "yyyyMMdd");
   if (!Date.isValid()) Date = QDate::fromString(ui->DateEdit->text(), "yyyy-MM-dd");
   Hyp->time.year = Date.year(); Hyp->time.month = Date.month(); Hyp->time.day = Date.day();

   // Return time.
   Time = QTime::fromString(ui->TimeEdit->text().simplified(), "hhmmss.z");
   if (!Time.isValid()) Time = QTime::fromString(ui->TimeEdit->text(), "hh:mm:ss.z");
   Hyp->time.hour = Time.hour();  Hyp->time.minute = Time.minute(); Hyp->time.second = Time.second() + Time.msec()*0.001;

   // Return distance id.
   Hyp->dist_id = ui->DistIndEdit->text().simplified().at(0).toUpper().toLatin1();

   // Return latitude.
   if (ui->LatEdit->text().simplified().size()) Hyp->lat = ui->LatEdit->text().toFloat(&ValueOK);

   // Return longitude.
   if (ui->LonEdit->text().simplified().size()) Hyp->lon = ui->LonEdit->text().toFloat(&ValueOK);

   // Return depth.
   if (ui->DepthEdit->text().simplified().size()) Hyp->depth = ui->DepthEdit->text().toFloat(&ValueOK);

   // Return agency.
   if (ui->AgencyEdit->text().simplified().size()) strcpy(Hyp->agency, ui->AgencyEdit->text().toUpper().toLocal8Bit().data());

   // Return number of stations.
   if (ui->NumStaEdit->text().simplified().size()) Hyp->nstat = ui->NumStaEdit->text().toInt(&ValueOK);

   // Return RMS value.
   if (ui->RmsEdit->text().simplified().size())  Hyp->rms = ui->RmsEdit->text().toFloat(&ValueOK);

   // Return model indicator.
   if (ui->ModEdit->text().size()) Hyp->modl_id = ui->ModEdit->text().simplified().at(0).toLatin1();

   // Return event indicator.
   if (ui->EventIndEdit->text().size()) Hyp->evnt_id = ui->EventIndEdit->text().simplified().at(0).toUpper().toLatin1();

   // Return first magnitude to the hypocenter if given.
   if (Mag1ValueOK) {
      Type = ui->Type1Edit->text().simplified();
      Agency = ui->Agency1Edit->text().simplified();
      Magnitude = ui->Mag1Edit->text().simplified().toFloat(&ValueOK);
      if (Type == "W") { i = Hyp->magnitudes.MW.nmag; Hyp->magnitudes.MW.mag[i] = Magnitude; strcpy(Hyp->magnitudes.MW.mag_agency[i], Agency.toLatin1()); Hyp->magnitudes.MW.order[i] = 0; Hyp->magnitudes.MW.nmag++; }
      if (Type == "L") { i = Hyp->magnitudes.ML.nmag; Hyp->magnitudes.ML.mag[i] = Magnitude; strcpy(Hyp->magnitudes.ML.mag_agency[i], Agency.toLatin1()); Hyp->magnitudes.ML.order[i] = 0; Hyp->magnitudes.ML.nmag++; }
      if (Type == "N") { i = Hyp->magnitudes.MN.nmag; Hyp->magnitudes.MN.mag[i] = Magnitude; strcpy(Hyp->magnitudes.MN.mag_agency[i], Agency.toLatin1()); Hyp->magnitudes.MN.order[i] = 0; Hyp->magnitudes.MN.nmag++; }
      if (Type == "C") { i = Hyp->magnitudes.MC.nmag; Hyp->magnitudes.MC.mag[i] = Magnitude; strcpy(Hyp->magnitudes.MC.mag_agency[i], Agency.toLatin1()); Hyp->magnitudes.MC.order[i] = 0; Hyp->magnitudes.MC.nmag++; }
      if (Type == "b") { i = Hyp->magnitudes.Mb.nmag; Hyp->magnitudes.Mb.mag[i] = Magnitude; strcpy(Hyp->magnitudes.Mb.mag_agency[i], Agency.toLatin1()); Hyp->magnitudes.Mb.order[i] = 0; Hyp->magnitudes.Mb.nmag++; }
      if (Type == "B") { i = Hyp->magnitudes.MB.nmag; Hyp->magnitudes.MB.mag[i] = Magnitude; strcpy(Hyp->magnitudes.MB.mag_agency[i], Agency.toLatin1()); Hyp->magnitudes.MB.order[i] = 0; Hyp->magnitudes.MB.nmag++; }
      if (Type == "s") { i = Hyp->magnitudes.Ms.nmag; Hyp->magnitudes.Ms.mag[i] = Magnitude; strcpy(Hyp->magnitudes.Ms.mag_agency[i], Agency.toLatin1()); Hyp->magnitudes.Ms.order[i] = 0; Hyp->magnitudes.Ms.nmag++; }
      if (Type == "S") { i = Hyp->magnitudes.MS.nmag; Hyp->magnitudes.MS.mag[i] = Magnitude; strcpy(Hyp->magnitudes.MS.mag_agency[i], Agency.toLatin1()); Hyp->magnitudes.MS.order[i] = 0; Hyp->magnitudes.MS.nmag++; }
      if (Type == "")  { i = Hyp->magnitudes.MU.nmag; Hyp->magnitudes.MU.mag[i] = Magnitude; strcpy(Hyp->magnitudes.MU.mag_agency[i], Agency.toLatin1()); Hyp->magnitudes.MU.order[i] = 0; Hyp->magnitudes.MU.nmag++; }
   }

   // Return second magnitude to the hypocenter if given.
   if (Mag2ValueOK) {
      Type = ui->Type2Edit->text().simplified();
      Agency = ui->Agency2Edit->text().simplified();
      Magnitude = ui->Mag2Edit->text().simplified().toFloat(&ValueOK);
      if (Type == "W") { i = Hyp->magnitudes.MW.nmag; Hyp->magnitudes.MW.mag[i] = Magnitude; strcpy(Hyp->magnitudes.MW.mag_agency[i], Agency.toLatin1()); Hyp->magnitudes.MW.order[i] = 1; Hyp->magnitudes.MW.nmag++; }
      if (Type == "L") { i = Hyp->magnitudes.ML.nmag; Hyp->magnitudes.ML.mag[i] = Magnitude; strcpy(Hyp->magnitudes.ML.mag_agency[i], Agency.toLatin1()); Hyp->magnitudes.ML.order[i] = 1; Hyp->magnitudes.ML.nmag++; }
      if (Type == "N") { i = Hyp->magnitudes.MN.nmag; Hyp->magnitudes.MN.mag[i] = Magnitude; strcpy(Hyp->magnitudes.MN.mag_agency[i], Agency.toLatin1()); Hyp->magnitudes.MN.order[i] = 1; Hyp->magnitudes.MN.nmag++; }
      if (Type == "C") { i = Hyp->magnitudes.MC.nmag; Hyp->magnitudes.MC.mag[i] = Magnitude; strcpy(Hyp->magnitudes.MC.mag_agency[i], Agency.toLatin1()); Hyp->magnitudes.MC.order[i] = 1; Hyp->magnitudes.MC.nmag++; }
      if (Type == "b") { i = Hyp->magnitudes.Mb.nmag; Hyp->magnitudes.Mb.mag[i] = Magnitude; strcpy(Hyp->magnitudes.Mb.mag_agency[i], Agency.toLatin1()); Hyp->magnitudes.Mb.order[i] = 1; Hyp->magnitudes.Mb.nmag++; }
      if (Type == "B") { i = Hyp->magnitudes.MB.nmag; Hyp->magnitudes.MB.mag[i] = Magnitude; strcpy(Hyp->magnitudes.MB.mag_agency[i], Agency.toLatin1()); Hyp->magnitudes.MB.order[i] = 1; Hyp->magnitudes.MB.nmag++; }
      if (Type == "s") { i = Hyp->magnitudes.Ms.nmag; Hyp->magnitudes.Ms.mag[i] = Magnitude; strcpy(Hyp->magnitudes.Ms.mag_agency[i], Agency.toLatin1()); Hyp->magnitudes.Ms.order[i] = 1; Hyp->magnitudes.Ms.nmag++; }
      if (Type == "S") { i = Hyp->magnitudes.MS.nmag; Hyp->magnitudes.MS.mag[i] = Magnitude; strcpy(Hyp->magnitudes.MS.mag_agency[i], Agency.toLatin1()); Hyp->magnitudes.MS.order[i] = 1; Hyp->magnitudes.MS.nmag++; }
      if (Type == "")  { i = Hyp->magnitudes.MU.nmag; Hyp->magnitudes.MU.mag[i] = Magnitude; strcpy(Hyp->magnitudes.MU.mag_agency[i], Agency.toLatin1()); Hyp->magnitudes.MU.order[i] = 1; Hyp->magnitudes.MU.nmag++; }
   }

   // Return third magnitude to the hypocenter if given.
   if (Mag3ValueOK) {
      Type = ui->Type3Edit->text().simplified();
      Agency = ui->Agency3Edit->text().simplified();
      Magnitude = ui->Mag3Edit->text().simplified().toFloat(&ValueOK);
      if (Type == "W") { i = Hyp->magnitudes.MW.nmag; Hyp->magnitudes.MW.mag[i] = Magnitude; strcpy(Hyp->magnitudes.MW.mag_agency[i], Agency.toLatin1()); Hyp->magnitudes.MW.order[i] = 2; Hyp->magnitudes.MW.nmag++; }
      if (Type == "L") { i = Hyp->magnitudes.ML.nmag; Hyp->magnitudes.ML.mag[i] = Magnitude; strcpy(Hyp->magnitudes.ML.mag_agency[i], Agency.toLatin1()); Hyp->magnitudes.ML.order[i] = 2; Hyp->magnitudes.ML.nmag++; }
      if (Type == "N") { i = Hyp->magnitudes.MN.nmag; Hyp->magnitudes.MN.mag[i] = Magnitude; strcpy(Hyp->magnitudes.MN.mag_agency[i], Agency.toLatin1()); Hyp->magnitudes.MN.order[i] = 2; Hyp->magnitudes.MN.nmag++; }
      if (Type == "C") { i = Hyp->magnitudes.MC.nmag; Hyp->magnitudes.MC.mag[i] = Magnitude; strcpy(Hyp->magnitudes.MC.mag_agency[i], Agency.toLatin1()); Hyp->magnitudes.MC.order[i] = 2; Hyp->magnitudes.MC.nmag++; }
      if (Type == "b") { i = Hyp->magnitudes.Mb.nmag; Hyp->magnitudes.Mb.mag[i] = Magnitude; strcpy(Hyp->magnitudes.Mb.mag_agency[i], Agency.toLatin1()); Hyp->magnitudes.Mb.order[i] = 2; Hyp->magnitudes.Mb.nmag++; }
      if (Type == "B") { i = Hyp->magnitudes.MB.nmag; Hyp->magnitudes.MB.mag[i] = Magnitude; strcpy(Hyp->magnitudes.MB.mag_agency[i], Agency.toLatin1()); Hyp->magnitudes.MB.order[i] = 2; Hyp->magnitudes.MB.nmag++; }
      if (Type == "s") { i = Hyp->magnitudes.Ms.nmag; Hyp->magnitudes.Ms.mag[i] = Magnitude; strcpy(Hyp->magnitudes.Ms.mag_agency[i], Agency.toLatin1()); Hyp->magnitudes.Ms.order[i] = 2; Hyp->magnitudes.Ms.nmag++; }
      if (Type == "S") { i = Hyp->magnitudes.MS.nmag; Hyp->magnitudes.MS.mag[i] = Magnitude; strcpy(Hyp->magnitudes.MS.mag_agency[i], Agency.toLatin1()); Hyp->magnitudes.MS.order[i] = 2; Hyp->magnitudes.MS.nmag++; }
      if (Type == "")  { i = Hyp->magnitudes.MU.nmag; Hyp->magnitudes.MU.mag[i] = Magnitude; strcpy(Hyp->magnitudes.MU.mag_agency[i], Agency.toLatin1()); Hyp->magnitudes.MU.order[i] = 2; Hyp->magnitudes.MU.nmag++; }
   }

   // Return depth flag to hypocenter.
   if (ui->FixDepthCheckBox->isChecked()) Hyp->depth_flag = 'F';
   if (ui->StartDepthCheckBox->isChecked()) Hyp->depth_flag = 'S';

   // Return location flag to hypocenter.
   if (ui->FixLocCheckBox->isChecked()) Hyp->epi_flag = 'F';
   if (ui->StartLocCheckBox->isChecked()) Hyp->epi_flag = 'S';

   // Close the dialog and return 'Accepted' signal.
   QDialog::done(QDialog::Accepted);
}




// **************************************
// User has pressed the 'Cancel' button.
// **************************************
void EditTypeOneLineDlg::reject()
{
   // Close the dialog and return 'Rejected' signal.
   QDialog::done(QDialog::Rejected);
}




// ***********************************************************
// This function handles state changes for FixLocCheckBox.
// ***********************************************************
void EditTypeOneLineDlg::FixLocChanged(int state)
{
   if (state == Qt::Checked) ui->StartLocCheckBox->setChecked(false);
}




// ***********************************************************
// This function handles state changes for StartLocCheckBox.
// ***********************************************************
void EditTypeOneLineDlg::StartLocChanged(int state)
{
   if (state == Qt::Checked) ui->FixLocCheckBox->setChecked(false);
}




// ***********************************************************
// This function handles state changes for FixDepthCheckBox.
// ***********************************************************
void EditTypeOneLineDlg::FixDepthChanged(int state)
{
   if (state == Qt::Checked) ui->StartDepthCheckBox->setChecked(false);
}




// ***********************************************************
// This function handles state changes for StartDepthCheckBox.
// ***********************************************************
void EditTypeOneLineDlg::StartDepthChanged(int state)
{
   if (state == Qt::Checked) ui->FixDepthCheckBox->setChecked(false);
}




// **********************************************************************************************
// This function returns the hypocenter's magnitudes in the 'MagList' list.
// **********************************************************************************************
void EditTypeOneLineDlg::GetHypocenterMags()
{
   phase_mag mag;

   for (int i=0;i<Hyp->magnitudes.MW.nmag;i++) {
      mag.type = 'W';
      mag.agency = QString(Hyp->magnitudes.MW.mag_agency[i]).toUpper().trimmed();
      mag.value = Hyp->magnitudes.MW.mag[i];
      MagList.append(mag);
   }
   for (int i=0;i<Hyp->magnitudes.ML.nmag;i++) {
      mag.type = 'L';
      mag.agency = QString(Hyp->magnitudes.ML.mag_agency[i]).toUpper().trimmed();
      mag.value = Hyp->magnitudes.ML.mag[i];
      MagList.append(mag);
   }
   for (int i=0;i<Hyp->magnitudes.MN.nmag;i++) {
      mag.type = 'N';
      mag.agency = QString(Hyp->magnitudes.MN.mag_agency[i]).toUpper().trimmed();
      mag.value = Hyp->magnitudes.MN.mag[i];
      MagList.append(mag);
   }
   for (int i=0;i<Hyp->magnitudes.MC.nmag;i++) {
      mag.type = 'C';
      mag.agency = QString(Hyp->magnitudes.MC.mag_agency[i]).toUpper().trimmed();
      mag.value = Hyp->magnitudes.MC.mag[i];
      MagList.append(mag);
   }
   for (int i=0;i<Hyp->magnitudes.Mb.nmag;i++) {
      mag.type = 'b';
      mag.agency = QString(Hyp->magnitudes.Mb.mag_agency[i]).toUpper().trimmed();
      mag.value = Hyp->magnitudes.Mb.mag[i];
      MagList.append(mag);
   }
   for (int i=0;i<Hyp->magnitudes.MB.nmag;i++) {
      mag.type = 'B';
      mag.agency = QString(Hyp->magnitudes.MB.mag_agency[i]).toUpper().trimmed();
      mag.value = Hyp->magnitudes.MB.mag[i];
      MagList.append(mag);
   }
   for (int i=0;i<Hyp->magnitudes.Ms.nmag;i++) {
      mag.type = 's';
      mag.agency = QString(Hyp->magnitudes.Ms.mag_agency[i]).toUpper().trimmed();
      mag.value = Hyp->magnitudes.Ms.mag[i];
      MagList.append(mag);
   }
   for (int i=0;i<Hyp->magnitudes.MS.nmag;i++) {
      mag.type = 'S';
      mag.agency = QString(Hyp->magnitudes.MS.mag_agency[i]).toUpper().trimmed();
      mag.value = Hyp->magnitudes.MS.mag[i];
      MagList.append(mag);
   }
}
