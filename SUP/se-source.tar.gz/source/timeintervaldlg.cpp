#include <QDebug>
#include <QMessageBox>
#include "timeintervaldlg.h"
#include "ui_timeintervaldlg.h"


// *************************************
// Constructor function.
// *************************************
TimeIntervalDlg::TimeIntervalDlg(se_config *Config, QWidget *parent) : QDialog(parent), ui(new Ui::TimeIntervalDlg)
{
   // Set up the user interface.
   ui->setupUi(this);

   // Save pointer to config structure.
   this->Config = Config;

   // Save current start date and type of end date.
   StartDate = Config->TimeIntDates.StartDate;
   EndDateType = Config->TimeIntDates.EndDateType;

   // Get the application name.
   AppName = QCoreApplication::applicationName();

   // Find and save the end date.
   if (Config->TimeIntDates.EndDateType == 1) {
      // Set end date to current date.
      EndDate = QDate::currentDate();
      ui->CurrentDateRb->setChecked(true);
      ui->EndDateEdit->setDisabled(true);
   }
   if (Config->TimeIntDates.EndDateType == 2) {
      // Set end date to end of startmonth.
      EndDate = QDate(StartDate.year(), StartDate.month(), 1);
      EndDate = EndDate.addDays(StartDate.daysInMonth()-1);
      ui->EndOfMonthRb->setChecked(true);
      ui->EndDateEdit->setDisabled(true);
   }
   if (Config->TimeIntDates.EndDateType == 3) {
      // User-specified end date.
      EndDate = Config->TimeIntDates.EndDate;
      ui->UserSpecDateRb->setChecked(true);
   }

   // Set values for end date and start date widgets.
   ui->StartDateEdit->setText(StartDate.toString("yyyy.MM.dd"));
   ui->EndDateEdit->setText(EndDate.toString("yyyy.MM.dd"));

   // Move focus to Start date widget and select all text.
   ui->StartDateEdit->setFocus(Qt::OtherFocusReason);
   ui->StartDateEdit->selectAll();

}




// *************************************
// Destructor function.
// *************************************
TimeIntervalDlg::~TimeIntervalDlg()
{
   delete ui;
}




// ************************************************************
// Current date has been selected as end date.
// ************************************************************
void TimeIntervalDlg::currentdaterb_clicked(void)
{
   if (EndDateType != 1) {
      EndDateType = 1;
      EndDate = QDate::currentDate();
      ui->EndDateEdit->setText(EndDate.toString("yyyy.MM.dd"));
      ui->EndDateEdit->setDisabled(true);
   }
}


// ************************************************************
// End of month has been selected as end date.
// ************************************************************
void TimeIntervalDlg::endofmonthrb_clicked(void)
{
   if (EndDateType != 2) {
      EndDateType = 2;
      ui->EndDateEdit->setDisabled(true);
   }
}


// ************************************************************
// User-specified date has been set as end date.
// ************************************************************
void TimeIntervalDlg::userspecrb_clicked(void)
{
   if (EndDateType != 3) {
      EndDateType = 3;
      ui->EndDateEdit->setDisabled(false);
      ui->EndDateEdit->selectAll();
      ui->EndDateEdit->setFocus(Qt::OtherFocusReason);
   }
}




// ************************************************************
// User have pressed the 'OK' button.
// ************************************************************
void TimeIntervalDlg::OkButton()
{
   // Check that the start date is valid.
   StartDate = QDate::fromString(ui->StartDateEdit->text(), "yyyyMMdd");
   if (!StartDate.isValid()) {
      StartDate = QDate::fromString(ui->StartDateEdit->text(), "yyyy.MM.dd");
      if (!StartDate.isValid()) {
         QMessageBox::critical(NULL, AppName, "An invalid start date has been entered.");
         ui->StartDateEdit->selectAll();
         ui->StartDateEdit->setFocus(Qt::OtherFocusReason);
         return;
      }
   }

   // Set end date to current date.
   if (EndDateType == 1) {
      EndDate = QDate::currentDate();
      ui->EndDateEdit->setText(EndDate.toString("yyyy.MM.dd"));
      ui->EndDateEdit->setDisabled(true);
   }

   // Set end date to end of start month.
   if (EndDateType == 2) {
      EndDate = QDate(StartDate.year(), StartDate.month(), 1);
      EndDate = EndDate.addDays(StartDate.daysInMonth()-1);
      ui->EndDateEdit->setText(EndDate.toString("yyyy.MM.dd"));
      ui->EndDateEdit->setDisabled(true);
   }

   // If user has entered the end date, check that it is valid.
   if (EndDateType == 3) {
      EndDate = QDate::fromString(ui->EndDateEdit->text(), "yyyyMMdd");
      if (!EndDate.isValid()) {
         EndDate = QDate::fromString(ui->EndDateEdit->text(), "yyyy.MM.dd");
         if (!EndDate.isValid()) {
            QMessageBox::critical(NULL, AppName, "An invalid end date has been entered.");
            ui->EndDateEdit->selectAll();
            ui->EndDateEdit->setFocus(Qt::OtherFocusReason);
            return;
         }
      }
   }

   // Check that start date <= end date.
   if (StartDate > EndDate) {
      QMessageBox::critical(this, AppName,
      QString("'Start Date' must be older or equal to 'End Date'."));
      return;
   }

   // Return new dates.
   Config->TimeIntDates.StartDate = StartDate;
   Config->TimeIntDates.EndDate = EndDate;
   Config->TimeIntDates.EndDateType = EndDateType;

   // Close the dialog and return 'Accepted' signal.
   accept();
}


// ************************************************************
// User have pressed the 'Cancel' button.
// ************************************************************
void TimeIntervalDlg::CancelButton()
{
   // Close the dialog and return 'Reject' signal.
   reject();
}

