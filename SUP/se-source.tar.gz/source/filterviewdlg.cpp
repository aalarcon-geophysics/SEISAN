#include <QDebug>
#include <QFileDialog>
#include <QStringList>
#include <QMessageBox>
#include "filterviewdlg.h"
#include "ui_filterviewdlg.h"
#include "querybuilderdlg.h"
#include "filter.h"
#include "library.h"


// ************************************
// Constructor function for this class.
// ************************************
FilterViewDlg::FilterViewDlg(QWidget *parent) : QDialog(parent), ui(new Ui::FilterViewDlg)
{
   ui->setupUi(this);
}


// ************************************
// Destructor function for this class.
// ************************************
FilterViewDlg::~FilterViewDlg()
{
   delete ui;
}




// ****************************************************************
// Init function. Mainly used to save pointers to return variables.
// ****************************************************************
void FilterViewDlg::InitDialog(db_filter *Filter)
{
   filter = Filter;
   descr = filter->Description;
   iQuery = filter->InclQuery;
   eQuery = filter->ExclQuery;
   ui->DescrEdit->setPlainText(descr);
   ui->InclBrowser->setPlainText(iQuery);
   ui->ExclBrowser->setPlainText(eQuery);
   ui->InclEditBtn->setFocus(Qt::OtherFocusReason);
   AppName = QCoreApplication::applicationName();
}




// *******************************************************
// User has pressed the Edit button for the include query.
// *******************************************************
void FilterViewDlg::EditInclQuery()
{
   // Create, initialize and open the expression build dialog.
   QueryBuilderDlg *QueryDlg = new QueryBuilderDlg(this);
   QueryDlg->setAttribute(Qt::WA_DeleteOnClose, true);
   QueryDlg->InitDialog(&iQuery, 0);
   if (QueryDlg->exec() == QDialog::Accepted) {
      // User pressed the 'OK' button.
      // Copy query expression to edit box.
      ui->InclBrowser->setPlainText(iQuery);
   }
}




// *******************************************************
// User has pressed the Edit button for the exclude query.
// *******************************************************
void FilterViewDlg::EditExclQuery()
{
   // Create, initialize and open the expression build dialog.
   QueryBuilderDlg *QueryDlg = new QueryBuilderDlg(this);
   QueryDlg->setAttribute(Qt::WA_DeleteOnClose, true);
   QueryDlg->InitDialog(&eQuery, 1);
   if (QueryDlg->exec() == QDialog::Accepted) {
      // User pressed the 'OK' button.
      // Copy query expression to edit box.
      ui->ExclBrowser->setPlainText(eQuery);
   }
}




// ***********************************
// User has pressed the 'OK' button.
// ***********************************
void FilterViewDlg::accept()
{
   // Check the include expression for errors.
   if (iQuery.size()) {
      if (!TrimAndCheckInfix(&iQuery, &Message, 0)) {
         // Expression check failed. Show error message.
         Message = "Syntax error in include expression.";
         QMessageBox::critical(NULL, AppName, Message);
         return;
      }
   }

   // Check the exclude expression for errors.
   if (eQuery.size()) {
      if (!TrimAndCheckInfix(&eQuery, &Message, 1)) {
         // Expression check failed. Show error message.
         Message = "Syntax error in exclude expression.";
         QMessageBox::critical(NULL, AppName, Message);
         return;
      }
   }

   // If all events are included then an
   // exclude expression must be entered.
   if (iQuery.toUpper() == "INCLUDEALL" && !eQuery.size()) {
      Message = "Exclude expression is mandatory with 'IncludeAll'.";
      QMessageBox::critical(NULL, AppName, Message);
      return;
   }

   // Return query to caller.
   filter->Description = ui->DescrEdit->toPlainText();
   filter->InclQuery = iQuery;
   filter->ExclQuery = eQuery;

   // Close the dialog and return 'Accepted' signal.
   done(QDialog::Accepted);
}




// *************************************
// User has pressed the 'Cancel' button.
// *************************************
void FilterViewDlg::reject()
{
   // Close the dialog and return 'Rejected' signal.
   done(QDialog::Rejected);
}




// *************************************
// User has pressed the 'Clear' button.
// *************************************
void FilterViewDlg::clear()
{
   descr.clear(); ui->DescrEdit->setPlainText(descr);
   iQuery.clear(); ui->InclBrowser->setPlainText(iQuery);
   eQuery.clear(); ui->ExclBrowser->setPlainText(eQuery);
}




// *************************************
// User has pressed the 'Load' button.
// *************************************
void FilterViewDlg::load()
{
   QString FileName;
   int Status, lineNr;
   QStringList FileCont;

   // Bring up file selection dialog box. Return if user cancel
   // the operation. User must point to a filter file.
   Message = "Please select a filter file:";
   FileName = QFileDialog::getOpenFileName(this, Message, QString(), "Filters (*.flt)");
   if (!FileName.size()) return;

   // Read the file.
   if ((Status = ReadTextFile(FileName, &FileCont))) {
      // File was not sucessfully read.
      if (Status == 1) Message = "The file could not be found.";
      if (Status == 2) Message = "The file could not be opened.";
      QMessageBox::critical(NULL, AppName, Message);
      return;
   }

   // Trim all lines and then remove all empty lines.
   for (int i=0;i<FileCont.size();i++) FileCont[i] = FileCont.at(i).trimmed();
   for (int i=FileCont.size()-1;i>=0;i--) if (FileCont.at(i).isEmpty()) FileCont.removeAt(i);

   // Check that at least 3 lines is still
   // present after removal of empty lines.
   if (FileCont.size() < 3) {
      Message = "Invalid file format.";
      QMessageBox::critical(NULL, AppName, Message);
      return;
   }

   // Read the description line(s).
   if (!FileCont.at(0).startsWith("@DESC:", Qt::CaseInsensitive)) {
      Message = "Invalid file format (expected '@DESC:').";
      QMessageBox::critical(NULL, AppName, Message);
      return;
   } else {
      lineNr = 1;
      descr = FileCont.at(0); descr.remove(0,6);
      while (!FileCont.at(lineNr).startsWith("@")) {
         descr.append("\n" + FileCont.at(lineNr));
         if (++lineNr == FileCont.size()) {
            Message = "Invalid file format (unexpected end of file).";
            QMessageBox::critical(NULL, AppName, Message);
            return;
         }
      }
   }

   // Read the include expression line(s).
   if (!FileCont.at(lineNr).startsWith("@INCL:", Qt::CaseInsensitive)) {
      Message = "Invalid file format (expected '@INCL:').";
      QMessageBox::critical(NULL, AppName, Message);
      return;
   } else {
      iQuery = FileCont.at(lineNr++); iQuery.remove(0,6);
      while (!FileCont.at(lineNr).startsWith("@")) {
         iQuery.append("\n" + FileCont.at(lineNr));
         if (++lineNr == FileCont.size()) {
            Message = "Invalid file format (unexpected end of file).";
            QMessageBox::critical(NULL, AppName, Message);
            return;
         }
      }
   }

   // Read the exclude expression line(s).
   if (!FileCont.at(lineNr).startsWith("@EXCL:", Qt::CaseInsensitive)) {
      Message = "Invalid file format (expected '@EXCL:').";
      QMessageBox::critical(NULL, AppName, Message);
      return;
   } else {
      eQuery = FileCont.at(lineNr++); eQuery.remove(0,6);
      while (lineNr < FileCont.size()) eQuery.append("\n" + FileCont.at(lineNr++));
   }

   // Set new query expressions.
   if (iQuery.size()) {
      // Clean up the expressions.
      TrimInfix(&iQuery); TrimInfix(&eQuery);
      // Set description.
      ui->DescrEdit->setPlainText(descr);
      // Set include expression.
      ui->InclBrowser->setPlainText(iQuery);
      // Set exclude expression.
      ui->ExclBrowser->setPlainText(eQuery);
   } else {
      Message = "No include expression found.";
      QMessageBox::critical(NULL, AppName, Message);
   }
}




// *************************************
// User has pressed the 'Save' button.
// *************************************
void FilterViewDlg::save()
{
   QString FileName;
   QStringList FileCont;

   // Check that there exists an include criteria.
   if (!iQuery.size()) {
      Message = "Cannot save. No include expression has been entered.";
      QMessageBox::critical(NULL, AppName, Message);
      return;
   }

   // Bring up file selection dialog box. Return if user
   // cancels the operation. User must type a filename.
   Message = "Please enter a filename:";
   FileName = QFileDialog::getSaveFileName(this, Message, QString(),  "Filter files(*.flt)");
   if(!FileName.size()) return;

   // Write description and query expression(s) to file.
   FileCont.append("@DESC:" + ui->DescrEdit->toPlainText().trimmed());
   FileCont.append("@INCL:" + iQuery);
   FileCont.append("@EXCL:" + eQuery);
   if (!WriteTextFile(FileName, FileCont)) {
      Message = "Failed to write the file.";
      QMessageBox::critical(NULL, AppName, Message);
   }
}


