#include <QDir>
#include "math.h"
#include "google.h"
#include "library.h"


// *************************************************************
// Creates a primary KML file used with Google Earth.
// This file is needed for auto refresh in GE.
// *************************************************************
void CreatePriKmlFile()
{
   // Create full path to secondary KML file.
   // File is located in the work directory.
   QString SecKmlFile = QString(SEC_KML_FILE);
   SecKmlFile.prepend(QDir::currentPath() + "/");
   SecKmlFile = QDir::cleanPath(SecKmlFile);

   // Create primary KML file (in work drectory).
   // Any existing file will just be overwritten.
   QFile *PriKmlFile = new QFile(PRI_KML_FILE);
   if (PriKmlFile->open(QIODevice::WriteOnly | QIODevice::Truncate | QIODevice::Text)) {
      QTextStream out(PriKmlFile);
      out << "<?xml version='1.0' encoding='UTF-8'?>\n";
      out << "<kml xmlns = 'http://earth.google.com/kml/2.2'>\n";
      out << "<Folder>\n";
      out << "<open>1</open>\n";
      out << "<NetworkLink>\n";
      out << "<open>1</open>\n";
      out << "<name><B>Selected events</B></name>\n";
      out << "<Link>\n";
      out << "<href>file:///" << SecKmlFile << "</href>\n";
      out << "<refreshMode>onInterval</refreshMode>\n";
      out << "<refreshInterval>10</refreshInterval>\n";
      out << "</Link>\n";
      out << "</NetworkLink>\n";
      out << "</Folder>\n";
      out << "</kml>\n";
      PriKmlFile->close();
   }
}




// *************************************************************
// Creates header lines for secondary KML file.
// Use this function before first call to function 'WriteKml'.
// *************************************************************
void WriteKmlHeader(QFile *KmlFile)
{
   QTextStream out(KmlFile);
   out << "<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n";
   out << "<kml xmlns=\"http://earth.google.com/kml/2.2\">\n";
   out << "<Document>\n";
   out << "<open>0</open>\n";
   out << "<name>SEISAN</name>\n";
}




// ***********************************************************************
// Adds a single event to secondary KML file.
//
// 'text' is a character array with the content of the sfile.
// 'nr' a integer with the number of lines in the sfile.
// 'url' is a character array with the URL for the icon.
// 'visible' is a logical that if true hides the events.
// 'Color' is a string with the KML color string.
// 'mSize', 'xSize', and 'ySize' defines the size of the epicenter icon.
// ************************************************************************
void WriteKml(event_node_ *Node, QFile *KmlFile, QString IconUrl, QString Color,
              bool Visible, float mSize, float xSize, float ySize)
{
   float IconScale, Mag = 0.0;
   QString MagType, MagAgency, Time;

   // Get magnitude of event.
   bool HaveMag = false;
   if (Node->hypocenters.nmag) {
      HaveMag = true;
      Mag = Node->hypocenters.mag_all[0].mag;
      MagType = QString(Node->hypocenters.mag_all[0].type);
      MagAgency = QString(Node->hypocenters.mag_all[0].agency);
   }

   // Calculate the icon scale value.
   IconScale = Mag;
   if (IconScale < mSize) IconScale = mSize;
   IconScale = xSize * pow(IconScale, ySize);
   //if (Node->hypocenters.first->type != 32) IconScale = IconScale*2.0;

   // Create text stream for writing to the KML file.
   QTextStream out(KmlFile);

   // Write the event to the KML file.
   out << "<Placemark>\n";
   if ( Visible) out << "<visibility>1</visibility>\n";
   if (!Visible) out << "<visibility>0</visibility>\n";
   out << "<description>";
   if (HaveMag) {
      out << QString::number(Mag,'f',1) << " M";
      out << MagType <<  " " << MagAgency << " ";
   }
   CreateElvTimeStr(&Node->hypocenters.first->time, &Time);
   out << Time << " (Row " << QString::number(Node->metadata.pos_pindex+1) << ")";
   out << "</description>\n";
   CreateISO8601TimeStr(&Node->hypocenters.first->time, &Time);
   out << "<TimeStamp>\n";
   out << "<when>" << Time << "</when>\n";
   out << "</TimeStamp>\n";
   out << "<Style>\n";
   out << "<IconStyle>\n";
   out << "<color>" << Color << "</color>\n";
   out << "<colorMode>normal</colorMode>\n";
   out << "<scale>" << QString::number(IconScale,'f',1) << "</scale>\n";
   out << "<Icon>\n";
   out << "<href>\n";
   out << IconUrl << "\n";
   out << "</href>\n";
   out << "</Icon>\n";
   out << "</IconStyle>\n";
   out << "</Style>\n";
   out << "<Point>\n";
   out << "<coordinates>";
   out << QString::number(Node->hypocenters.first->lon,'f',4);
   out << ",";
   out << QString::number(Node->hypocenters.first->lat,'f',4);
   out << "</coordinates>\n";
   out << "</Point>\n";
   out << "</Placemark>\n";
}




// *************************************************************
// Creates tail lines for secondary KML file.
// Use this function after last call to function 'WriteKml'.
// *************************************************************
void WriteKmlTail(QFile *KmlFile)
{
   QTextStream out(KmlFile);
   out << "</Document>\n";
   out << "</kml>\n";
}
