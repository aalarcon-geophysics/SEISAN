#include <QFile>
#include <QDebug>
#include <QDateTime>
#include <QSettings>
#include <QCloseEvent>
#include <QResizeEvent>
#include <QMessageBox>
#include "mainwindow.h"
#include "library.h"
#include "eventnode.h"
#include "locatedlg.h"
#include "ui_locatedlg.h"
#include "debug.h"


// *****************************************
// Constructor for this class.
// *****************************************
LocateDlg::LocateDlg(OperatorId *Operator) : ui(new Ui::LocateDlg)
{
    QStringList StrList;

    // Set up the graphical user interface.
    ui->setupUi(this);

    // Restore/set the last used geometry of the dialog.
    restoreGeometry(settings.value("Geometry/Locator").toByteArray());

    // Initialize variables.
    SEDB = nullptr;
    CurRowNr = 0;
    Node = LocatedNode = nullptr;
    this->Operator = Operator;

    // Define colors used in tables.
    GrayTextColor = QColor(127, 127, 127);
    GreenCellColor = QColor(155, 255, 180);
    YellowCellColor = QColor(255, 255, 128);
    OrangeCellColor = QColor(255, 195, 70);
    RedCellColor = QColor(255, 145, 145);
    EditableCellColor = QColor(240, 240, 240);

    // Define colcors for the 'RMS' value.
    GreenColor = "background:rgb(155, 255, 180);";
    YellowColor = "background:rgb(255, 255, 128);";
    RedColor = "background:rgb(255, 145, 145);";

    // Set up an event filter for the dialog. See the 'eventFilter' function.
    installEventFilter(this);

    // Prepare the 'Magnitudes' table.
    ui->MagnitudesTable->setColumnCount(3);
    ui->MagnitudesTable->setSortingEnabled(false);
    ui->MagnitudesTable->setTabKeyNavigation(false);
    ui->MagnitudesTable->horizontalHeader()->setStretchLastSection(true);
    StrList = QString("Value;Type;Agency").split(";");
    ui->MagnitudesTable->setHorizontalHeaderLabels(StrList);
    ui->MagnitudesTable->verticalHeader()->setSectionResizeMode(QHeaderView::ResizeToContents);

    // Prepare the 'Settings' table.
    ui->SettingsTable->setColumnCount(2);
    ui->SettingsTable->setRowCount(7);
    ui->SettingsTable->setSortingEnabled(false);
    ui->SettingsTable->setTabKeyNavigation(false);
    ui->SettingsTable->setHorizontalHeaderLabels(QString("Setting;Value").split(";"));
    ui->SettingsTable->horizontalHeader()->setStretchLastSection(true);
    ui->SettingsTable->verticalHeader()->setSectionResizeMode(QHeaderView::ResizeToContents);

    // Populate the 'Settings' table.
    Item = new QTableWidgetItem("Model indicator");
    Item->setFlags(Item->flags() & ~Qt::ItemIsEditable & ~Qt::ItemIsSelectable);
    ui->SettingsTable->setItem(SET_MODIND_ROW,0,Item);
    Item = new QTableWidgetItem(QString());
    Item->setFlags(Item->flags() & ~Qt::ItemIsSelectable);
    ui->SettingsTable->setItem(SET_MODIND_ROW,1, Item);
    Item = new QTableWidgetItem("Fix origin time");
    Item->setFlags(Item->flags() & ~Qt::ItemIsEditable & ~Qt::ItemIsSelectable);
    ui->SettingsTable->setItem(SET_FIXORT_ROW,0,Item);
    Item = new QTableWidgetItem(QString());
    Item->setFlags(Item->flags() & ~Qt::ItemIsSelectable);
    ui->SettingsTable->setItem(SET_FIXORT_ROW,1, Item);
    Item = new QTableWidgetItem("Epicenter flag");
    Item->setFlags(Item->flags() & ~Qt::ItemIsEditable & ~Qt::ItemIsSelectable);
    ui->SettingsTable->setItem(SET_EPIFLAG_ROW,0,Item);
    Item = new QTableWidgetItem(QString());
    Item->setFlags(Item->flags() & ~Qt::ItemIsSelectable);
    ui->SettingsTable->setItem(SET_EPIFLAG_ROW,1, Item);
    Item = new QTableWidgetItem("Depth flag");
    Item->setFlags(Item->flags() & ~Qt::ItemIsEditable & ~Qt::ItemIsSelectable);
    ui->SettingsTable->setItem(SET_DEPTHFLAG_ROW,0,Item);
    Item = new QTableWidgetItem(QString());
    Item->setFlags(Item->flags() & ~Qt::ItemIsSelectable);
    ui->SettingsTable->setItem(SET_DEPTHFLAG_ROW,1, Item);
    // These settings will be saved as a comment line only.
    Item = new QTableWidgetItem("XNEAR");
    Item->setFlags(Item->flags() & ~Qt::ItemIsEditable & ~Qt::ItemIsSelectable);
    ui->SettingsTable->setItem(SET_XNEAR_ROW,0,Item);
    Item = new QTableWidgetItem(QString());
    Item->setFlags(Item->flags() & ~Qt::ItemIsSelectable);
    ui->SettingsTable->setItem(SET_XNEAR_ROW,1, Item);
    Item = new QTableWidgetItem("XFAR");
    Item->setFlags(Item->flags() & ~Qt::ItemIsEditable & ~Qt::ItemIsSelectable);
    ui->SettingsTable->setItem(SET_XFAR_ROW,0,Item);
    Item = new QTableWidgetItem(QString());
    Item->setFlags(Item->flags() & ~Qt::ItemIsSelectable);
    ui->SettingsTable->setItem(SET_XFAR_ROW,1, Item);
    Item = new QTableWidgetItem("Start depth");
    Item->setFlags(Item->flags() & ~Qt::ItemIsEditable & ~Qt::ItemIsSelectable);
    ui->SettingsTable->setItem(SET_SDEP_ROW,0,Item);
    Item = new QTableWidgetItem(QString());
    Item->setFlags(Item->flags() & ~Qt::ItemIsSelectable);
    ui->SettingsTable->setItem(SET_SDEP_ROW,1, Item);

    // Prepare the 'Phase' table.
    ui->PhaseTable->setColumnCount(18);
    ui->PhaseTable->setSortingEnabled(true);
    ui->PhaseTable->setTabKeyNavigation(false);
    StrList = QString("#;Stat;Com;Nt;Lo;Date/Time;Dist;Azm;O;PhObs;WtObs").split(";");
    StrList.append(QString("T-Obs;PhCal;Ain;WtCal;T-Cal;Res;Imp").split(";"));
    ui->PhaseTable->setHorizontalHeaderLabels(StrList);
    ui->PhaseTable->resizeColumnsToContents();
    ui->PhaseTable->verticalHeader()->setSectionResizeMode(QHeaderView::ResizeToContents);
    ui->PhaseTable->installEventFilter(this);

    // Prepare the 'Azimuth' table.
    ui->AzimuthTable->setColumnCount(16);
    ui->AzimuthTable->setSortingEnabled(true);
    ui->AzimuthTable->setTabKeyNavigation(false);
    StrList = QString("#;Stat;Com;Nt;Lo;Date/Time;Dist;O;PhObs;BazObs").split(";");
    StrList.append(QString("AppVel;WtObs;BazCal;WtCal;Res;Imp").split(";"));
    ui->AzimuthTable->setHorizontalHeaderLabels(StrList);
    ui->AzimuthTable->verticalHeader()->setSectionResizeMode(QHeaderView::ResizeToContents);
    ui->AzimuthTable->resizeColumnsToContents();

    // Prepare the 'Magnitude' table.
    ui->MagnitudeTable->setColumnCount(16);
    ui->MagnitudeTable->setSortingEnabled(true);
    ui->MagnitudeTable->setTabKeyNavigation(false);
    StrList = QString("#;Stat;Com;Nt;Lo;Date/Time;Dist;Azm").split(";");
    StrList.append(QString("PhObs;MagType;Amp;Per;Coda;Moment;Mag;Res").split(";"));
    ui->MagnitudeTable->setHorizontalHeaderLabels(StrList);
    ui->MagnitudeTable->verticalHeader()->setSectionResizeMode(QHeaderView::ResizeToContents);
    ui->MagnitudeTable->resizeColumnsToContents();
    ui->MagnitudeTable->installEventFilter(this);

    // Connect 'state changed' signal from the check boxes.
    connect(ui->EpicFlag, SIGNAL(stateChanged(int)), this, SLOT(EpicFlagChanged(int)));
    connect(ui->DepthFlag, SIGNAL(stateChanged(int)), this, SLOT(DepthFlagChanged(int)));

    // Connect 'item changed' signal from the 'Settings' table.
    connect(ui->SettingsTable, SIGNAL(itemChanged(QTableWidgetItem*)), this, SLOT(SettingsTableChanged(QTableWidgetItem*)));

    // Set input focus to the Locate button.
    ui->LocateButton->setFocus();
}




// *****************************************
// Destructor for this class.
// *****************************************
LocateDlg::~LocateDlg()
{
   // Free the 'LocatedNode' if allocated.
   if (LocatedNode) FreeNode(LocatedNode);

   // Save the geometry of the dialog.
   settings.setValue(QString("Geometry/Locator"), saveGeometry());

   // Delete the user interface.
   delete ui;
}




// *****************************************
// User has pressed the 'Locate' button.
// *****************************************
void LocateDlg::LocateButton()
{
   event_node_ *WorkNode;
   QStringList Messages;

   // Return if pointer to database is zero.
   if (!SEDB) return;

   // Return if database is not open.
   if (SEDB->DbStatus != db::open) return;

   // Return if no row has been set.
   if (!Node) return;

   // Validate the distance indicator.
   if (!ValidateUserInput(true)) return;

   // If we already have located the node, then
   // keep working with the located node.
   if (LocatedNode) {
       // Node is already located. Work with the located node.
      WorkNode = LocatedNode;
   } else {
      // No location done. Work on a copy of the database node.
      if (!(WorkNode = CopyNode(Node))) {
         ui->LogList->addItem("Error: Out of memory. Unable to locate.");
         ui->TabWidget2->setCurrentIndex(3);
         return;
      }
   }

   // Apply all settings from the dialog to 'WorkNode'.
   CopyBasicValuesToNode(WorkNode);
   CopySettingsTableValuesToNode(WorkNode);

   // Apply all phases from the 'Phases' list to the node.
   NodeSetPhases(WorkNode, &Phases);

   // Locate the node.
   QApplication::setOverrideCursor(QCursor(Qt::WaitCursor));
   LocatedNode = NodeLocate(WorkNode, &Messages);
   QApplication::restoreOverrideCursor();

   // Free the copied node.
   FreeNode(WorkNode);

   // Handle outcome of location attempt.
   if (LocatedNode) {
      // Event location suceeded. Copy metadata
      // from original node to the located node.
      LocatedNode->metadata = Node->metadata;
      // Save the phases from the located node.
      NodeGetPhases(LocatedNode, &Phases);
      // Update widgets.
      PopulateWidgets(LocatedNode);
   }

   // Update the log list view.
   if (Messages.size()) {
      ui->LogList->addItems(Messages);
      ui->TabWidget2->setTabText(3, "Log (!)");
   }
}




// ************************************************************
// This function writes the current settings to an S-file.
// If 'RenameByHypo' is 'true' then the time/date of the first
// hypocenter will be used to name the S-file. The ID line
// will also be updated accordingly.
// ************************************************************
void LocateDlg::SaveSfile(bool RenameByHypo)
{
   // Return if pointer to database is zero.
   if (!SEDB) return;

   // Create and use a new pointer to the database.
   // This pointer will be unaffected by any call to
   // RowChanged() while this function is executing.
   SEBASE *sedb = SEDB;

   // Return if no row has been set, or database is not open.
   if (!Node || sedb->DbStatus != db::open) return;

   // Get database information.
   db_info DbInfo = sedb->DbInfo;

   // Check if database is an index file.
   if (DbInfo.Type == index_file) {
      Message = "Cannot save to an index file.";
      QMessageBox::information(nullptr, QCoreApplication::applicationName(), Message);
      return;
   }

   // Validate all user input.
   if (!ValidateUserInput()) return;

   // Save full path to existing S-file.
   QString OldFile = QString(Node->metadata.sfile);

   // Save the database index for the S-file.
   int DbIndex = sedb->DB->IndexByFile(OldFile);

   // Make a copy of the node to be saved.
   // Return if node could not be copied.
   event_node_ *NewNode = nullptr;
   if (!LocatedNode) NewNode = CopyNode(Node);
   if ( LocatedNode) NewNode = CopyNode(LocatedNode);
   if (!NewNode) {
      Message = "Locate: Unable to save. Out of memory.";
      QMessageBox::critical(nullptr, QCoreApplication::applicationName(), Message);
      return;
   }

   // Modify the ID line if locate has been done.
   // Modifications: action, update time, operator
   if (LocatedNode) {
      // Save the current ID line as a new comment line.
      // Note: In comment, 'ACTION' string will be renamed to 'OLDACT'.
      NodeAddComment(NewNode, QString(NewNode->id_line).replace(1, 6, "OLDACT"));
      // Update the the ID line.
      NodeSetIdlineAction(NewNode, "LOC");
      NodeSetIdlineUpdatetime(NewNode);
      NodeSetIdlineOperator(NewNode, Operator->GetConfirmedId());
   }

   // Apply all user defined values from the dialog box to the node.
   // Event file may be renamed here if distance indicator has changed.
   CopyBasicValuesToNode(NewNode);
   CopySettingsTableValuesToNode(NewNode);
   NodeSetPhases(NewNode, &Phases);

   // If requested, rename the file using Date, Time and
   // distance indicator from the primary hypocenter.
   // Changes being made to the node: File name and ID line.
   // ID line modifications: ID (date and time).
   if (RenameByHypo) NodeSetFileNameFromHypo(NewNode);

   // Get full path to new file from NewNode.
   QString NewFile = QString(NewNode->metadata.sfile);

   // Check if file will be renamed.
   bool Renamed = (NewFile != OldFile);

   // If S-file will be renamed:
   // 1. A file with the same name and different ID already exists.
   //    If so, then the S-file must be renamed again.
   // 2. A file with the same name and identical ID exists.
   //    If so, then the existing S-file will be replaced.
   if (Renamed) {
      // Delete and unload the old file.
      sedb->UnloadEvent(DbIndex);
      DeleteSfileFromDisk(OldFile, DbInfo);

      // Check if the new file already exists.
      if (QFile::exists(NewFile)) {
         // An S-file with the new name already exists.
         // Check if ID of existing file is equal to ID of new file.
         QString ExistFileID = GetSfileID(NewNode->metadata.sfile);
         QString NewID = NodeGetIdlineID(NewNode);
         if (NewID != ExistFileID) {
            // The ID's are different. The existing file will not be
            // replaced or unloaded from SE. The new S-file must be
            // renamed so it do not conflict with the existing file.
            NodeSetUniqueFileName(NewNode);
            NewFile = QString(NewNode->metadata.sfile);
         } else {
            // The ID lines are identical. The existing file will
            // be replaced. Unload and delete the existing file.
            int Index = sedb->DB->IndexByFile(NewFile);
            if (Index != -1) sedb->UnloadEvent(Index);
            DeleteSfileFromDisk(NewFile, DbInfo);
         }
      }
   } else {
      // File has not been renamed. Existing file will be deleted.
      // The new file will be reloaded after it has been written.
      DeleteSfileFromDisk(OldFile, DbInfo);
   }

   // Write S-file to disk. The file name is taken from 'metadata.sfile'.
   char Error;
   if (!WriteSfile(NewNode, &Error)) {
      // Could not write S-file to disk. Abort here.
      ui->LogList->clear();
      Message = "Locate: Failed to save new event file. ";
      if (Error == 1) Message.append("Function 'rea_event_out' returned an error. ");
      if (Error == 2) Message.append("Cannot open event file for writing. ");
      if (Error == 3) Message.append("Cannot write to event file. ");
      if (Renamed) Message.append("Old event has been moved to the DELET database.");
      ui->LogList->addItem(Message);
      ui->TabWidget2->setCurrentIndex(3);
      FreeNode(NewNode);
      return;
   }

   // Load new event file from disk.
   if (Renamed) {
      // Load the renamed S-file into SE and select it.
      int iStat = sedb->LoadEvent(NewFile);
      // If the new event file failes to load, write error message to the log.
      if (iStat == -1) {
         ui->LogList->clear();
         Message = QString("Locate: Unable to reload event file '") + NewFile + "'.";
         ui->LogList->addItem(Message); ui->TabWidget2->setCurrentIndex(3);
      }
   } else {
      // File is not renamed, and has not been unloaded.
      // Reload the updated S-file from disk and select it.
      sedb->ReloadEvent(DbIndex);
   }

   // Free the allocated node.
   FreeNode(NewNode);
}




// *****************************************
// User has pressed the 'Save' button.
// *****************************************
void LocateDlg::SaveButton()
{
   SaveSfile(false);
}




// ***********************************************
// User has pressed 'File|Save and Rename' menu.
// ***********************************************
void LocateDlg::SaveAndRename()
{
   SaveSfile(true);
}




// *********************************************************
// User has pressed 'Edit|Copy Coordinates' menu.
// *********************************************************
void LocateDlg::CopyCoordinates()
{
   CopyTextToClipboard(ui->Latitude->text() + " " + ui->Longitude->text());
}




// *****************************************
// User has pressed the 'Prev event' button.
// Jump to previous event in event list.
// *****************************************
void LocateDlg::PrevEventButton()
{
   if (!SEDB) return;
   if (SEDB->DbStatus != db::open) return;
   SEDB->NavigateUp();
}




// *****************************************
// User has pressed the 'Next event' button.
// Jump to next event in event list.
// *****************************************
void LocateDlg::NextEventButton()
{
   if (!SEDB) return;
   if (SEDB->DbStatus != db::open) return;
   SEDB->NavigateDown();
}




// *******************************************************************************
// This function is called whenever the current row in the event list is changed.
// The row number is the zero-based pointer into the database presentation index.
// The dialog will update its information when this function is called.
// *******************************************************************************
void LocateDlg::RowChanged(SEBASE *Db)
{
   // Get pointer to database.
   SEDB = Db; if (!SEDB) return;

   // Return if locate window is hidden.
   if (this->isHidden()) return;

   // Get status of database. Return if database is not opened.
   if (SEDB->DbStatus != db::open) {
      ui->LogList->clear();
      if (SEDB->DbStatus == db::closed) ui->LogList->addItem("Database is closed.");
      if (SEDB->DbStatus != db::closed) ui->LogList->addItem("Opening database, please wait...");
      ui->TabWidget2->setCurrentIndex(3);
      return;
   }

   // Get the current row.
   CurRowNr = SEDB->CurrentRow();

   // Return if there is no current row (database is empty).
   if (CurRowNr == -1) { Node = nullptr; return; }

   // Free the 'LocatedNode' node if allocated.
   if (LocatedNode) { FreeNode(LocatedNode); LocatedNode = nullptr; }

   // Save pointer to the event node for current row.
   Node = SEDB->DB->EventByIndex(CurRowNr); if (!Node) return;

   // Save the phases for this node.
   NodeGetPhases(Node, &Phases);

   // Save name of S-file.
   FileName = QString(Node->metadata.sfile);

   // Show node information in widgets.
   PopulateWidgets(Node);

   // Show the phase table.
   ui->TabWidget2->setCurrentIndex(0);
}




// *********************************************************************************
// This function will populate the dialog widgets. Data from the rea9 common block
// will be populaRegisterted by this function if locate has been done. All existing
// data in the widgets will be cleared.
// *********************************************************************************
void LocateDlg::PopulateWidgets(event_node_ *Node)
{
   int iValue;
   float fValue;
   hypocenter_ *Hypo;
   QString String, CmntLn;
   QStringList CommentList;

   // Set default title for the Log view widget.
   ui->TabWidget2->setTabText(3, "Log");

   // Get pointer to first hypocenter.
   Hypo = Node->hypocenters.first;

   // Set date.
   CreateDateStr(Hypo->time, &String);
   ui->Date->setText(String);

   // Set time.
   CreateTimeStr(Hypo->time, &String);
   ui->Time->setText(String);

   // Set time error.
   ui->TimeErrLabel->clear();
   fValue = Hypo->sec_err;
   if (fValue != -999) ui->TimeErrLabel->setText("+/- " + QString::number(fValue) + " s");

   // Set distance indicator.
   ui->DistInd->setText(QString(Hypo->dist_id).simplified());

   // Set event indicator.
   ui->EventInd->setText(QString(Hypo->evnt_id).simplified());

   // Set latitude.
   ui->Latitude->clear();
   fValue = Hypo->lat;
   if (fValue != -999) ui->Latitude->setText(QString().number(fValue, 'f', 4));

   // Set latitude error.
   ui->LatErrLabel->clear();
   fValue = Hypo->lat_err;
   if (fValue != -999) ui->LatErrLabel->setText("+/- " + QString::number(fValue) + " km");

   // Set longitude.
   ui->Longitude->clear();
   fValue = Hypo->lon;
   if (fValue != -999) ui->Longitude->setText(QString().number(fValue, 'f', 4));

   // Set longitude error.
   ui->LonErrLabel->clear();
   fValue = Hypo->lon_err;
   if (fValue != -999) ui->LonErrLabel->setText("+/- " + QString::number(fValue) + " km");

   // Set depth.
   ui->Depth->clear();
   fValue = Hypo->depth;
   if (fValue != -999) ui->Depth->setText(QString().number(fValue, 'f', 2));

   // Set depth error.
   ui->DepthErrLabel->clear();
   fValue = Hypo->depth_err;
   if (fValue != -999) ui->DepthErrLabel->setText("+/- " + QString::number(fValue) + " km");

   // Set the 'Fix depth' check box.
   if (Hypo->depth_flag == 'F') ui->DepthFlag->setCheckState(Qt::PartiallyChecked);
   if (Hypo->depth_flag == 'S') ui->DepthFlag->setCheckState(Qt::Checked);
   if (Hypo->depth_flag == 32) ui->DepthFlag->setCheckState(Qt::Unchecked);

   // Set the 'Fix epicenter' check box.
   if (Hypo->epi_flag == 'F') ui->EpicFlag->setCheckState(Qt::PartiallyChecked);
   if (Hypo->epi_flag == 'S') ui->EpicFlag->setCheckState(Qt::Checked);
   if (Hypo->epi_flag == 32) ui->EpicFlag->setCheckState(Qt::Unchecked);

   // Set locality.
   ui->Locality->setText(QString(Node->locality));

   // Set RMS. Color background will be used to clearify value.
   ui->RmsLabel->setText(" RMS:"); ui->RmsLabel->setStyleSheet("");
   fValue = Hypo->rms;
   if (fValue != -999) {
       ui->RmsLabel->setText(" RMS: " + QString().number(fValue, 'f', 2));
       fValue = fabs(fValue);
       if (fValue < 1.0) ui->RmsLabel->setStyleSheet(GreenColor);
       if (fValue >= 1.0 && fValue < 2.0) ui->RmsLabel->setStyleSheet(YellowColor);
       if (fValue >= 2.0) ui->RmsLabel->setStyleSheet(RedColor);
   }

   // Clear Dx,Dy,Dz and Dot values.
   ui->DxLabel->setText("Dx:"); ui->DyLabel->setText("Dy:"); ui->DzLabel->setText("Dz:"); ui->DotLabel->setText("Dot:");

   // Set Gap.
   ui->GapLabel->clear();
   fValue = Hypo->gap;
   if (fValue != -999) ui->GapLabel->setText("Gap: " + QString::number(fValue));

   // Set number of stations.
   ui->NStLabel->clear();
   iValue = Hypo->nstat;
   if (iValue != -999) ui->NStLabel->setText("NSt: " + QString::number(iValue));

   // Populate the 'Magnitudes' table.
   ui->MagnitudesTable->clearContents();
   ui->MagnitudesTable->setRowCount(Node->hypocenters.nmag);
   int row = 0;
   for (int i=0;i<Node->hypocenters.nmag;i++) {
      // Add all magnitues from the main agency.
      if (Node->hypocenters.mag_all[i].main_agency) {
         Item = new QTableWidgetItem(QString::number(Node->hypocenters.mag_all[i].mag, 'f', 1));
         Item->setTextAlignment(Qt::AlignRight | Qt::AlignVCenter);
         Item->setFlags(Qt::ItemIsEnabled);
         ui->MagnitudesTable->setItem(row, 0, Item);
         Item = new QTableWidgetItem(QString(Node->hypocenters.mag_all[i].type));
         Item->setTextAlignment(Qt::AlignHCenter | Qt::AlignVCenter);
         Item->setFlags(Qt::ItemIsEnabled);
         ui->MagnitudesTable->setItem(row, 1, Item);
         Item = new QTableWidgetItem(QString(Node->hypocenters.mag_all[i].agency));
         Item->setFlags(Qt::ItemIsEnabled);
         ui->MagnitudesTable->setItem(row, 2, Item);
         row++;
      }
   }
   for (int i=0;i<Node->hypocenters.nmag;i++) {
      // Add all magnitues from the secondary agency.
      if (!Node->hypocenters.mag_all[i].main_agency) {
         Item = new QTableWidgetItem(QString::number(Node->hypocenters.mag_all[i].mag, 'f', 1));
         Item->setTextColor(GrayTextColor);
         Item->setTextAlignment(Qt::AlignRight | Qt::AlignVCenter);
         Item->setFlags(Qt::ItemIsEnabled);
         ui->MagnitudesTable->setItem(row, 0, Item);
         Item = new QTableWidgetItem(QString(Node->hypocenters.mag_all[i].type));
         Item->setTextColor(GrayTextColor);
         Item->setTextAlignment(Qt::AlignHCenter | Qt::AlignVCenter);
         Item->setFlags(Qt::ItemIsEnabled);
         ui->MagnitudesTable->setItem(row, 1, Item);
         Item = new QTableWidgetItem(QString(Node->hypocenters.mag_all[i].agency));
         Item->setTextColor(GrayTextColor);
         Item->setFlags(Qt::ItemIsEnabled);
         ui->MagnitudesTable->setItem(row, 2, Item);
         row++;
      }
   }


   // Populate the 'Value' row in the 'Settings' table.
   Item = ui->SettingsTable->item(SET_MODIND_ROW, 1);
   Item->setBackgroundColor(EditableCellColor);
   Item->setText(QString(Hypo->modl_id).simplified());
   OrtFlagItem = ui->SettingsTable->item(SET_FIXORT_ROW, 1);
   OrtFlagItem->setBackgroundColor(EditableCellColor);
   OrtFlagItem->setText(QString(Hypo->fix_org).simplified());
   EpiFlagItem = ui->SettingsTable->item(SET_EPIFLAG_ROW, 1);
   EpiFlagItem->setBackgroundColor(EditableCellColor);
   EpiFlagItem->setText(QString(Hypo->epi_flag).simplified());
   DepthFlagItem = ui->SettingsTable->item(SET_DEPTHFLAG_ROW, 1);
   DepthFlagItem->setBackgroundColor(EditableCellColor);
   DepthFlagItem->setText(QString(Hypo->depth_flag).simplified());
   Item = ui->SettingsTable->item(SET_XFAR_ROW, 1);
   Item->setBackgroundColor(EditableCellColor);
   Item->setText(QString());
   Item = ui->SettingsTable->item(SET_XNEAR_ROW, 1);
   Item->setBackgroundColor(EditableCellColor);
   Item->setText(QString());
   Item = ui->SettingsTable->item(SET_SDEP_ROW, 1);
   Item->setBackgroundColor(EditableCellColor);
   Item->setText(QString());
   // If a comment line exist with XNEAR/XFAR/START DEPTH values, then show these values in the 'Settings' table.
   NodeGetComments(Node, &CommentList);
   // Look for a comment line of this type, and copy values if found.
   for (int i=0; i<CommentList.size(); i++) {
      CmntLn = CommentList.at(i).simplified().toUpper();
      if (CmntLn.contains("XNEAR") && CmntLn.contains("XFAR")) {
         // We have found a comment line with XNEAR/XFAR/START DEPTH
         // values. START DEPTH may be missing from the line.
         // Get a list of substrings from the comment line.
         QStringList SubStrList = CmntLn.split(" ");
         // Check that we have 4 or 6 substrings. If not then
         // there is a problem, and we skip this comment line.
         int NumSubStr = SubStrList.size();
         if (NumSubStr == 4 || NumSubStr == 6) {
            // Extract the values from SubStrList.
            QString Property, Value;
            for (int j=0; j<NumSubStr; j=j+2) {
               Property = SubStrList.at(j).toUpper();
               Value = SubStrList.at(j+1);
               Item = nullptr;
               if (Property == "XNEAR") Item = ui->SettingsTable->item(SET_XNEAR_ROW, 1);
               if (Property == "XFAR") Item = ui->SettingsTable->item(SET_XFAR_ROW, 1);
               if (Property == "SDEP") Item = ui->SettingsTable->item(SET_SDEP_ROW, 1);
               if (Item) Item->setText(Value);
            }
         }
         break;
      }
   }


   // Populate the 'TabWidget2' tables.
   PopulatePhaseTable((bool)LocatedNode);
   ui->PhaseTable->resizeColumnsToContents();
   PopulateAzimuthTable((bool)LocatedNode);
   ui->AzimuthTable->resizeColumnsToContents();
   PopulateMagnitudeTable((bool)LocatedNode);
   ui->MagnitudeTable->resizeColumnsToContents();

   // Update the Log list.
   ui->LogList->clear(); ui->LogList->addItems(HypMesg);

   // If locate has been done, Update Dx,Dy,Dz and Dot values.
   if (LocatedNode) {
      ui->DxLabel->setText(QString("Dx: ")   + QString::number(rea9_.hyp_dx, 'f', 1));
      ui->DyLabel->setText(QString("Dy: ")   + QString::number(rea9_.hyp_dy, 'f', 1));
      ui->DzLabel->setText(QString("Dz: ")   + QString::number(rea9_.hyp_dz, 'f', 1));
      ui->DotLabel->setText(QString("Dot: ") + QString::number(rea9_.hyp_do, 'f', 1));
   }
}




// *****************************************************************
// This function will populate the 'Phase' table widget with
// values from 'Node'. All existing information will be cleared.
// *****************************************************************
void LocateDlg::PopulatePhaseTable(bool LocateDone)
{
   char str8[9];
   float fvalue;
   phase_ Phase;
   int RowNum, PhaseNum;
   bool SkipPhase, ErrVal;

   // Clear the table.
   ui->PhaseTable->clearContents();
   ui->PhaseTable->setRowCount(0);
   ui->PhaseTable->sortByColumn(0, Qt::AscendingOrder);
   ui->TabWidget2->setTabText(0, "Phase");

   // Disconnect itemChanged signal to PhaseTableItemChanged() while the table is being populated.
   disconnect(ui->PhaseTable, SIGNAL(itemChanged(QTableWidgetItem*)), this, SLOT(PhaseTableItemChanged(QTableWidgetItem*)));

   // Populate the table.
   RowNum = 0;
   ErrVal = false;
   for (PhaseNum=0;PhaseNum<Phases.size();PhaseNum++) {
      Phase = Phases.at(PhaseNum);
      // Check if this phase should excluded from the table.
      SkipPhase = false;
      if (QString(Phase.phase).startsWith("A", Qt::CaseInsensitive)) SkipPhase = true;
      if (QString(Phase.phase).startsWith("IA", Qt::CaseInsensitive)) SkipPhase = true;
      if (QString(Phase.phase).startsWith("SPE", Qt::CaseInsensitive)) SkipPhase = true;
      if (QString(Phase.phase).startsWith("END", Qt::CaseInsensitive)) SkipPhase = true;
      if (QString(Phase.phase).startsWith("BAZ", Qt::CaseInsensitive)) SkipPhase = true;
      if (QString(Phase.phase).startsWith("E", Qt::CaseInsensitive) && Phase.amp != -999) SkipPhase = true;
      if (QString(Phase.phase).startsWith("I", Qt::CaseInsensitive) && Phase.amp != -999) SkipPhase = true;

      // Add this phase if it has not been skipped.
      if (!SkipPhase) {
         // Add a new row to the table.
         ui->PhaseTable->insertRow(RowNum);

         // First, set row number.
         Item = new QTableWidgetItem(QString());
         Item->setTextAlignment(Qt::AlignHCenter | Qt::AlignVCenter);
         Item->setData(Qt::DisplayRole, RowNum + 1);
         Item->setData(Qt::UserRole, QVariant(PhaseNum));
         Item->setFlags(Item->flags() & ~Qt::ItemIsEditable);
         ui->PhaseTable->setItem(RowNum, PHASE_NUM_COL, Item);

         // Set station/agency.
         Item = new QTableWidgetItem(QString(Phase.station));
         Item->setFlags(Item->flags() & ~Qt::ItemIsEditable);
         ui->PhaseTable->setItem(RowNum, PHASE_STAT_COL, Item);

         // Set component.
         Item = new QTableWidgetItem(QString(Phase.comp3));
         Item->setTextAlignment(Qt::AlignHCenter | Qt::AlignVCenter);
         Item->setFlags(Item->flags() & ~Qt::ItemIsEditable);
         ui->PhaseTable->setItem(RowNum, PHASE_COMP_COL, Item);

         // Set network.
         Item = new QTableWidgetItem(QString(Phase.network));
         Item->setTextAlignment(Qt::AlignHCenter | Qt::AlignVCenter);
         Item->setFlags(Item->flags() & ~Qt::ItemIsEditable);
         ui->PhaseTable->setItem(RowNum, PHASE_NETW_COL, Item);

         // Set location.
         Item = new QTableWidgetItem(QString(Phase.location));
         Item->setTextAlignment(Qt::AlignHCenter | Qt::AlignVCenter);
         Item->setFlags(Item->flags() & ~Qt::ItemIsEditable);
         ui->PhaseTable->setItem(RowNum, PHASE_LOC_COL, Item);

         // Set date and time.
         db_time time; QString TimeStr;
         time.year = Phase.year; time.month = Phase.month;
         time.day = Phase.day; time.hour = Phase.hour;
         time.minute = Phase.min; time.second = Phase.sec;
         CreateElvTimeStr(&time, &TimeStr);
         Item = new QTableWidgetItem(TimeStr);
         Item->setFlags(Item->flags() & ~Qt::ItemIsEditable);
         ui->PhaseTable->setItem(RowNum, PHASE_DATETIME_COL, Item);

         // Set distance.
         Item = new QTableWidgetItem(QString());
         Item->setTextAlignment(Qt::AlignRight | Qt::AlignVCenter);
         Item->setFlags(Item->flags() & ~Qt::ItemIsEditable);
         if (Phase.dist != -999) Item->setText(QString::number(Phase.dist, 'f', 1));
         ui->PhaseTable->setItem(RowNum, PHASE_DIST_COL, Item);

         // Set Azm.
         Item = new QTableWidgetItem(QString());
         Item->setTextAlignment(Qt::AlignRight | Qt::AlignVCenter);
         Item->setFlags(Item->flags() & ~Qt::ItemIsEditable);
         if (Phase.az != -999) Item->setText(QString::number(Phase.az, 'f', 1));
         ui->PhaseTable->setItem(RowNum, PHASE_AZM_COL, Item);

         // Set Onset.
         Item = new QTableWidgetItem(QString(QChar::fromLatin1(Phase.onset)));
         Item->setTextAlignment(Qt::AlignHCenter | Qt::AlignVCenter);
         Item->setFlags(Item->flags() & ~Qt::ItemIsEditable);
         ui->PhaseTable->setItem(RowNum, PHASE_O_COL, Item);

         // Set PhObs. This column is editable.
         Item = new QTableWidgetItem(QString(Phase.phase));
         Item->setBackgroundColor(EditableCellColor);
         ui->PhaseTable->setItem(RowNum, PHASE_PHOBS_COL, Item);

         // Set WtObs. This column is editable.
         Item = new QTableWidgetItem(QString(Phase.weight_in));
         Item->setTextAlignment(Qt::AlignRight | Qt::AlignVCenter);
         Item->setBackgroundColor(EditableCellColor);
         if (Phase.weight_in == 32) Item->setText(QString());
         ui->PhaseTable->setItem(RowNum, PHASE_WTOBS_COL, Item);

         // Set Ain.
         Item = new QTableWidgetItem(QString());
         Item->setTextAlignment(Qt::AlignRight | Qt::AlignVCenter);
         Item->setFlags(Item->flags() & ~Qt::ItemIsEditable);
         if (Phase.ain != -999) Item->setText(QString::number(Phase.ain));
         ui->PhaseTable->setItem(RowNum, PHASE_AIN_COL, Item);

         // Set Res.
         Item = new QTableWidgetItem(QString());
         Item->setTextAlignment(Qt::AlignRight | Qt::AlignVCenter);
         Item->setFlags(Item->flags() & ~Qt::ItemIsEditable & ~Qt::ItemIsSelectable);
         if (Phase.res != -999) {
            Item->setText(QString::number(Phase.res, 'f', 2));
            fvalue = fabs(Phase.res);
            if (fvalue <  PhaseColLimits[0]) Item->setBackgroundColor(GreenCellColor);
            if (fvalue >= PhaseColLimits[0] && fvalue < PhaseColLimits[1]) Item->setBackgroundColor(YellowCellColor);
            if (fvalue >= PhaseColLimits[1] && fvalue < PhaseColLimits[2]) Item->setBackgroundColor(OrangeCellColor);
            if (fvalue >= PhaseColLimits[2]) { Item->setBackgroundColor(RedCellColor); ErrVal = true; }
         }
         ui->PhaseTable->setItem(RowNum, PHASE_RES_COL, Item);

         // If locate has been done, show some values from the rea9 common block.
         // Set T-Obs.
         Item = new QTableWidgetItem(QString());
         Item->setTextAlignment(Qt::AlignRight | Qt::AlignVCenter);
         Item->setFlags(Item->flags() & ~Qt::ItemIsEditable);
         if (LocateDone) {
            if (rea9_.rea_time_obs[PhaseNum] != -999) {
                Item->setText(QString::number(rea9_.rea_time_obs[PhaseNum], 'f', 2));
            }
         }
         ui->PhaseTable->setItem(RowNum, PHASE_TOBS_COL, Item);

         // Set PhCal.
         Item = new QTableWidgetItem(QString());
         Item->setFlags(Item->flags() & ~Qt::ItemIsEditable);
         if (LocateDone) {
            fstr2char(str8, rea9_.rea_phase_cal[PhaseNum], 8);
            Item->setText(QString(str8));
         }
         ui->PhaseTable->setItem(RowNum, PHASE_PHCAL_COL, Item);

         // Set WtCal.
         Item = new QTableWidgetItem(QString());
         Item->setTextAlignment(Qt::AlignRight | Qt::AlignVCenter);
         Item->setFlags(Item->flags() & ~Qt::ItemIsEditable);
         if (LocateDone) {
            if (rea9_.rea_wt[PhaseNum] != -999) Item->setText(QString::number(rea9_.rea_wt[PhaseNum], 'f', 1));
         }
         ui->PhaseTable->setItem(RowNum, PHASE_WTCAL_COL, Item);

         // Set T-Cal.
         Item = new QTableWidgetItem(QString());
         Item->setTextAlignment(Qt::AlignRight | Qt::AlignVCenter);
         Item->setFlags(Item->flags() & ~Qt::ItemIsEditable);
         if (LocateDone) {
            if (rea9_.rea_time_cal[PhaseNum] != -999) Item->setText(QString::number(rea9_.rea_time_cal[PhaseNum], 'f', 2));
         }
         ui->PhaseTable->setItem(RowNum, PHASE_TCAL_COL, Item);

         // Set Imp.
         Item = new QTableWidgetItem(QString());
         Item->setTextAlignment(Qt::AlignRight | Qt::AlignVCenter);
         Item->setFlags(Item->flags() & ~Qt::ItemIsEditable);
         if (LocateDone) {
            if (rea9_.rea_di[PhaseNum] != -999) Item->setText(QString::number(rea9_.rea_di[PhaseNum]));
         }
         ui->PhaseTable->setItem(RowNum, PHASE_IMP_COL, Item);

         // Go to next row.
         RowNum++;
      }
   }

   // Add "(!)" to the tab title if one or more phases a bad residual.
   if (ErrVal) ui->TabWidget2->setTabText(0, "Phase (!)");

   // Connect itemChanged signal to PhaseTableItemChanged() so that we can save user changes in the table.
   connect(ui->PhaseTable, SIGNAL(itemChanged(QTableWidgetItem*)), this, SLOT(PhaseTableItemChanged(QTableWidgetItem*)));

   // Resize column widths.
   ui->PhaseTable->resizeColumnsToContents();
}




// ******************************************************************
// This function is signalled when user changes an item in the
// phase table. The change will be saved in the Phases list.
// ******************************************************************
void LocateDlg::PhaseTableItemChanged(QTableWidgetItem* item)
{
   Q_UNUSED(item)

   // Save changes to the Phases list.
   SavePhaseTableValues();

   // The azimuth table will have to be redrawn
   // since both tables share the WtObs column.
   PopulateAzimuthTable((bool)LocatedNode);
}




// ******************************************************************
// This function will populate the 'Azimuth' table widget with
// values from 'Node'. All existing information will be cleared.
// ******************************************************************
void LocateDlg::PopulateAzimuthTable(bool LocateDone)
{
   bool ErrVal;
   int RowNum, PhaseNum;
   phase_ Phase;

   // Clear the table.
   ui->AzimuthTable->clearContents();
   ui->AzimuthTable->setRowCount(0);
   ui->TabWidget2->setTabText(1, "Azimuth");

   // Disconnect itemChanged signal to AzimuthTableItemChanged() while the table is being populated.
   disconnect(ui->AzimuthTable, SIGNAL(itemChanged(QTableWidgetItem*)), this, SLOT(AzimuthTableItemChanged(QTableWidgetItem*)));

   // Populate the table.
   RowNum = 0;
   ErrVal = false;
   for (PhaseNum=0;PhaseNum<Phases.size();PhaseNum++) {
      Phase = Phases.at(PhaseNum);
      // Add this phase if BazObs has a value.
      if (Phase.baz_obs != -999) {
         // Add a new row to the table.
         ui->AzimuthTable->insertRow(RowNum);

         // Set row number.
         Item = new QTableWidgetItem(QString());
         Item->setTextAlignment(Qt::AlignHCenter | Qt::AlignVCenter);
         Item->setData(Qt::DisplayRole, RowNum + 1);
         Item->setData(Qt::UserRole, QVariant(PhaseNum));
         Item->setFlags(Item->flags() & ~Qt::ItemIsEditable & ~Qt::ItemIsSelectable);
         ui->AzimuthTable->setItem(RowNum, AZM_NUM_COL, Item);

         // Set station/agency.
         Item = new QTableWidgetItem(QString(Phase.station));
         Item->setFlags(Item->flags() & ~Qt::ItemIsEditable & ~Qt::ItemIsSelectable);
         ui->AzimuthTable->setItem(RowNum, AZM_STAT_COL, Item);

         // Set component.
         Item = new QTableWidgetItem(QString(Phase.comp3));
         Item->setTextAlignment(Qt::AlignHCenter | Qt::AlignVCenter);
         Item->setFlags(Item->flags() & ~Qt::ItemIsEditable);
         ui->AzimuthTable->setItem(RowNum, AZM_COMP_COL, Item);

         // Set network.
         Item = new QTableWidgetItem(QString(Phase.network));
         Item->setTextAlignment(Qt::AlignHCenter | Qt::AlignVCenter);
         Item->setFlags(Item->flags() & ~Qt::ItemIsEditable);
         ui->AzimuthTable->setItem(RowNum, AZM_NETW_COL, Item);

         // Set location.
         Item = new QTableWidgetItem(QString(Phase.location));
         Item->setTextAlignment(Qt::AlignHCenter | Qt::AlignVCenter);
         Item->setFlags(Item->flags() & ~Qt::ItemIsEditable);
         ui->AzimuthTable->setItem(RowNum, AZM_LOC_COL, Item);

         // Set date and time.
         db_time time; QString TimeStr;
         time.year = Phase.year; time.month = Phase.month;
         time.day = Phase.day; time.hour = Phase.hour;
         time.minute = Phase.min; time.second = Phase.sec;
         CreateElvTimeStr(&time, &TimeStr);
         Item = new QTableWidgetItem(TimeStr);
         Item->setFlags(Item->flags() & ~Qt::ItemIsEditable & ~Qt::ItemIsSelectable);
         ui->AzimuthTable->setItem(RowNum, AZM_DATETIME_COL, Item);

         // Set distance.
         Item = new QTableWidgetItem(QString());
         Item->setTextAlignment(Qt::AlignRight | Qt::AlignVCenter);
         Item->setFlags(Item->flags() & ~Qt::ItemIsEditable & ~Qt::ItemIsSelectable);
         if (Phase.dist != -999) Item->setText(QString::number(Phase.dist, 'f', 1));
         ui->AzimuthTable->setItem(RowNum, AZM_DIST_COL, Item);

         // Set Onset.
         Item = new QTableWidgetItem(QString(QChar::fromLatin1(Phase.onset)));
         Item->setTextAlignment(Qt::AlignHCenter | Qt::AlignVCenter);
         Item->setFlags(Item->flags() & ~Qt::ItemIsEditable & ~Qt::ItemIsSelectable);
         ui->AzimuthTable->setItem(RowNum, AZM_O_COL, Item);

         // Set PhObs. This columns is editable.
         Item = new QTableWidgetItem(QString(Phase.phase));
         Item->setFlags(Item->flags() & ~Qt::ItemIsEditable & ~Qt::ItemIsSelectable);
         ui->AzimuthTable->setItem(RowNum, AZM_PHOBS_COL, Item);

         // Set BazObs.
         Item = new QTableWidgetItem(QString());
         Item->setTextAlignment(Qt::AlignRight | Qt::AlignVCenter);
         Item->setFlags(Item->flags() & ~Qt::ItemIsEditable & ~Qt::ItemIsSelectable);
         Item->setText(QString::number(Phase.baz_obs, 'f', 1));
         ui->AzimuthTable->setItem(RowNum, AZM_BAZOBS_COL, Item);

         // Set AppVel.
         Item = new QTableWidgetItem(QString());
         Item->setTextAlignment(Qt::AlignRight | Qt::AlignVCenter);
         Item->setFlags(Item->flags() & ~Qt::ItemIsEditable & ~Qt::ItemIsSelectable);
         if (Phase.vel != -999) Item->setText(QString::number(Phase.vel, 'f', 1));
         ui->AzimuthTable->setItem(RowNum, AZM_APPVEL_COL, Item);

         // Set WtObs. This column is editable.
         Item = new QTableWidgetItem(QString(Phase.weight_in));
         Item->setTextAlignment(Qt::AlignRight | Qt::AlignVCenter);
         Item->setFlags(Item->flags() & ~Qt::ItemIsSelectable);
         Item->setBackgroundColor(EditableCellColor);
         if (Phase.weight_in == 32) Item->setText(QString());
         ui->AzimuthTable->setItem(RowNum, AZM_WTOBS_COL, Item);

         // Set BazCal.
         Item = new QTableWidgetItem(QString());
         Item->setTextAlignment(Qt::AlignRight | Qt::AlignVCenter);
         Item->setFlags(Item->flags() & ~Qt::ItemIsEditable & ~Qt::ItemIsSelectable);
         if (Phase.baz_cal != -999) Item->setText(QString::number(Phase.baz_cal, 'f', 1));
         ui->AzimuthTable->setItem(RowNum, AZM_BAZCAL_COL, Item);

         // Set Res.
         Item = new QTableWidgetItem(QString());
         Item->setTextAlignment(Qt::AlignRight | Qt::AlignVCenter);
         Item->setFlags(Item->flags() & ~Qt::ItemIsEditable & ~Qt::ItemIsSelectable);
         if (Phase.baz_res != -999) {
            Item->setText(QString::number(Phase.baz_res, 'f', 1));
            float fvalue = fabs(Phase.baz_res);
            if (fvalue <  AzimColLimits[0]) Item->setBackgroundColor(GreenCellColor);
            if (fvalue >= AzimColLimits[0] && fvalue < AzimColLimits[1]) Item->setBackgroundColor(YellowCellColor);
            if (fvalue >= AzimColLimits[1] && fvalue < AzimColLimits[2]) Item->setBackgroundColor(OrangeCellColor);
            if (fvalue >= AzimColLimits[2]) { Item->setBackgroundColor(RedCellColor); ErrVal = true; }
         }
         ui->AzimuthTable->setItem(RowNum, AZM_RES_COL, Item);

         // If locate has been done, show some values from the rea9 common block.
         // Set WtCal.
         Item = new QTableWidgetItem(QString());
         Item->setTextAlignment(Qt::AlignRight | Qt::AlignVCenter);
         Item->setFlags(Item->flags() & ~Qt::ItemIsEditable & ~Qt::ItemIsSelectable);
         if (LocateDone) {
            if (rea9_.rea_baz_wt[PhaseNum] != -999) Item->setText(QString::number(rea9_.rea_baz_wt[PhaseNum], 'f', 1));
         }
         ui->AzimuthTable->setItem(RowNum, AZM_WTCAL_COL, Item);

         // Set Imp.
         Item = new QTableWidgetItem(QString());
         Item->setTextAlignment(Qt::AlignRight | Qt::AlignVCenter);
         Item->setFlags(Item->flags() & ~Qt::ItemIsEditable & ~Qt::ItemIsSelectable);
         if (LocateDone) {
            if (rea9_.rea_baz_di[PhaseNum] != -999) Item->setText(QString::number(rea9_.rea_baz_di[PhaseNum]));
         }
         ui->AzimuthTable->setItem(RowNum, AZM_IMP_COL, Item);

         // Go to next row.
         RowNum++;
      }
   }

   // Add "(!)" to the tab title if one or more phases a bad residual.
   if (ErrVal) ui->TabWidget2->setTabText(1, "Azimuth (!)");

   // Connect itemChanged signal to AzimuthTableItemChanged() so that we can save user changes in the table.
   connect(ui->AzimuthTable, SIGNAL(itemChanged(QTableWidgetItem*)), this, SLOT(AzimuthTableItemChanged(QTableWidgetItem*)));

   // Resize column widths.
   ui->AzimuthTable->resizeColumnsToContents();
}




// ******************************************************************
// This function is signalled when user changes an item in the
// azimuth table. The change will be saved in the Phases list.
// ******************************************************************
void LocateDlg::AzimuthTableItemChanged(QTableWidgetItem* item)
{
   Q_UNUSED(item)

   // Save changes to the Phases list.
   SaveAzimuthTableValues();

   // The phase table will have to be redrawn
   // since both tables share the WtObs column.
   PopulatePhaseTable((bool)LocatedNode);
}




// ********************************************************************
// This function will populate the 'Magnitude' table widget with
// values from 'Node'. All existing information will be cleared.
// This table will only be populated if locate is done, and rea9
// contains valid values.
// ********************************************************************
void LocateDlg::PopulateMagnitudeTable(bool LocateDone)
{
   char str2[3];
   bool SkipPhase, ErrVal;
   int RowNum, PhaseNum;
   phase_ Phase;

   // Clear the table.
   ui->MagnitudeTable->clearContents();
   ui->MagnitudeTable->setRowCount(0);
   ui->TabWidget2->setTabText(2, "Magnitude");

   // Returne here if node has not been located.
   if (!LocateDone) return;

   // Populate the table.
   RowNum = 0;
   ErrVal = false;
   for (PhaseNum=0;PhaseNum<Phases.size();PhaseNum++) {
      Phase = Phases.at(PhaseNum);
      // Check if this phase should excluded from the table.
      SkipPhase = false;
      if (rea4_.rea_mag[PhaseNum] == -999) SkipPhase = true;

      // Add this phase if it has not been skipped.
      if (!SkipPhase) {
         // Add a new row to the table.
         ui->MagnitudeTable->insertRow(RowNum);

         // Set row number.
         Item = new QTableWidgetItem(QString());
         Item->setTextAlignment(Qt::AlignHCenter | Qt::AlignVCenter);
         Item->setData(Qt::DisplayRole, RowNum + 1);
         Item->setData(Qt::UserRole, QVariant(PhaseNum));
         Item->setFlags(Item->flags() & ~Qt::ItemIsEditable);
         ui->MagnitudeTable->setItem(RowNum, MAG_NUM_COL, Item);

         // Set station/agency.
         Item = new QTableWidgetItem(QString(Phase.station));
         Item->setFlags(Item->flags() & ~Qt::ItemIsEditable);
         ui->MagnitudeTable->setItem(RowNum, MAG_STAT_COL, Item);

         // Set component.
         Item = new QTableWidgetItem(QString(Phase.comp3));
         Item->setTextAlignment(Qt::AlignHCenter | Qt::AlignVCenter);
         Item->setFlags(Item->flags() & ~Qt::ItemIsEditable);
         ui->MagnitudeTable->setItem(RowNum, MAG_COMP_COL, Item);

         // Set network.
         Item = new QTableWidgetItem(QString(Phase.network));
         Item->setTextAlignment(Qt::AlignHCenter | Qt::AlignVCenter);
         Item->setFlags(Item->flags() & ~Qt::ItemIsEditable);
         ui->MagnitudeTable->setItem(RowNum, MAG_NETW_COL, Item);

         // Set location.
         Item = new QTableWidgetItem(QString(Phase.location));
         Item->setTextAlignment(Qt::AlignHCenter | Qt::AlignVCenter);
         Item->setFlags(Item->flags() & ~Qt::ItemIsEditable);
         ui->MagnitudeTable->setItem(RowNum, MAG_LOC_COL, Item);

         // Set date and time.
         db_time time; QString TimeStr;
         time.year = Phase.year; time.month = Phase.month;
         time.day = Phase.day; time.hour = Phase.hour;
         time.minute = Phase.min; time.second = Phase.sec;
         CreateElvTimeStr(&time, &TimeStr);
         Item = new QTableWidgetItem(TimeStr);
         Item->setFlags(Item->flags() & ~Qt::ItemIsEditable);
         ui->MagnitudeTable->setItem(RowNum, MAG_DATETIME_COL, Item);

         // Set distance.
         Item = new QTableWidgetItem(QString());
         Item->setTextAlignment(Qt::AlignRight | Qt::AlignVCenter);
         Item->setFlags(Item->flags() & ~Qt::ItemIsEditable);
         if (Phase.dist != -999) Item->setText(QString::number(Phase.dist, 'f', 1));
         ui->MagnitudeTable->setItem(RowNum, MAG_DIST_COL, Item);

         // Set Azm.
         Item = new QTableWidgetItem(QString());
         Item->setTextAlignment(Qt::AlignRight | Qt::AlignVCenter);
         Item->setFlags(Item->flags() & ~Qt::ItemIsEditable);
         if (Phase.az != -999) Item->setText(QString::number(Phase.az, 'f', 1));
         ui->MagnitudeTable->setItem(RowNum, MAG_AZM_COL, Item);

         // Set PhObs.
         Item = new QTableWidgetItem(QString(Phase.phase));
         Item->setFlags(Item->flags() & ~Qt::ItemIsEditable);
         ui->MagnitudeTable->setItem(RowNum, MAG_PHOBS_COL, Item);

         // Set Amp.
         Item = new QTableWidgetItem(QString());
         Item->setTextAlignment(Qt::AlignRight | Qt::AlignVCenter);
         Item->setFlags(Item->flags() & ~Qt::ItemIsEditable);
         if (Phase.amp != -999) Item->setText(QString::number(Phase.amp, 'f', 1));
         ui->MagnitudeTable->setItem(RowNum, MAG_AMP_COL, Item);

         // Set Per.
         Item = new QTableWidgetItem(QString());
         Item->setTextAlignment(Qt::AlignRight | Qt::AlignVCenter);
         Item->setFlags(Item->flags() & ~Qt::ItemIsEditable);
         if (Phase.per != -999) Item->setText(QString::number(Phase.per, 'f', 2));
         ui->MagnitudeTable->setItem(RowNum, MAG_PER_COL, Item);

         // Set Coda.
         Item = new QTableWidgetItem(QString());
         Item->setTextAlignment(Qt::AlignRight | Qt::AlignVCenter);
         Item->setFlags(Item->flags() & ~Qt::ItemIsEditable);
         if (Phase.coda != -999) Item->setText(QString::number(Phase.coda, 'f', 2));
         ui->MagnitudeTable->setItem(RowNum, MAG_CODA_COL, Item);

         // Set Moment.
         Item = new QTableWidgetItem(QString());
         Item->setTextAlignment(Qt::AlignRight | Qt::AlignVCenter);
         Item->setFlags(Item->flags() & ~Qt::ItemIsEditable);
         if (Phase.spectral.moment != -999) Item->setText(QString::number(Phase.spectral.moment, 'f', 2));
         ui->MagnitudeTable->setItem(RowNum, MAG_MOMENT_COL, Item);

         // Set Magtype.
         Item = new QTableWidgetItem(QString());
         Item->setFlags(Item->flags() & ~Qt::ItemIsEditable);
         fstr2char(str2, rea9_.rea_mag_type[PhaseNum], 2);
         Item->setText(str2);
         ui->MagnitudeTable->setItem(RowNum, MAG_MAGTYPE_COL, Item);

         // Set Mag.
         Item = new QTableWidgetItem(QString());
         Item->setTextAlignment(Qt::AlignRight | Qt::AlignVCenter);
         Item->setFlags(Item->flags() & ~Qt::ItemIsEditable);
         if (rea4_.rea_mag[PhaseNum] != -999) Item->setText(QString::number(rea4_.rea_mag[PhaseNum], 'f', 2));
         ui->MagnitudeTable->setItem(RowNum, MAG_MAG_COL, Item);

         // Set Res.
         Item = new QTableWidgetItem(QString());
         Item->setTextAlignment(Qt::AlignRight | Qt::AlignVCenter);
         Item->setFlags(Item->flags() & ~Qt::ItemIsEditable & ~Qt::ItemIsSelectable);
         if (rea9_.rea_mag_res[PhaseNum] != -999) {
            Item->setText(QString::number(rea9_.rea_mag_res[PhaseNum], 'f', 2));
            float fvalue = fabs(rea9_.rea_mag_res[PhaseNum]);
            if (fvalue <  MagnColLimits[0]) Item->setBackgroundColor(GreenCellColor);
            if (fvalue >= MagnColLimits[0] && fvalue < MagnColLimits[1]) Item->setBackgroundColor(YellowCellColor);
            if (fvalue >= MagnColLimits[1] && fvalue < MagnColLimits[2]) Item->setBackgroundColor(OrangeCellColor);
            if (fvalue >= MagnColLimits[2]) { Item->setBackgroundColor(RedCellColor); ErrVal = true; }
         }
         ui->MagnitudeTable->setItem(RowNum, MAG_RES_COL, Item);

         // Go to next row.
         RowNum++;
      }
   }

   // Add "(!)" to the tab title if one or more phases a bad residual.
   if (ErrVal) ui->TabWidget2->setTabText(2, "Magnitude (!)");

   // Resize column widths.
   ui->MagnitudeTable->resizeColumnsToContents();
}




// ****************************************************************************
// This function checks all user settable values before a Save.
// If 'LocateCheck' is true then only distance indicator is checked.
// ****************************************************************************
bool LocateDlg::ValidateUserInput(bool LocateCheck)
{
   float fValue;
   QString Value;
   QModelIndex index;
   bool ValueOK, HasDepth, HasLat, HasLon;
   bool xnear_empty, xfar_empty, sdep_empty;

   // Check the Distance Indicator value. Mandatory value.
   ValueOK = false;
   Value = ui->DistInd->text().toUpper();
   if (Value == "L" || Value == "R" || Value == "D") ValueOK = true;
   if (!ValueOK) {
      QMessageBox::critical(this, "Locator", "Invalid distance indicator.");
      ui->DistInd->setFocus();
      return false;
   }

   // Check the date.
   QDate Date = QDate::fromString(ui->Date->text().simplified(), "yyyyMMdd");
   if (!Date.isValid()) {
      Date = QDate::fromString(ui->Date->text(), "yyyy-MM-dd");
      if (!Date.isValid()) {
         QMessageBox::critical(nullptr, "Locate", "Invalid or missing date.");
         ui->Date->selectAll(); ui->Date->setFocus();
         return false;
      }
   }

   // Return here if only DI has to be chacked.
   if (LocateCheck) return true;

   // Check the time.
   QTime Time = QTime::fromString(ui->Time->text().simplified(), "hhmmss.z");
   if (!Time.isValid()) {
      Time = QTime::fromString(ui->Time->text(), "hh:mm:ss.z");
      if (!Time.isValid()) {
         QMessageBox::critical(nullptr, "Locate", "Invalid or missing time.");
         ui->Time->selectAll(); ui->Time->setFocus();
         return false;
      }
   }

   // Check the latitude value.
   if ((HasLat = ui->Latitude->text().trimmed().size())) {
      ui->Latitude->text().toFloat(&ValueOK);
      if (!ValueOK) {
         QMessageBox::critical(this, "Locator", "Invalid latitude.");
         ui->Latitude->setFocus(); ui->Latitude->selectAll();
         return false;
      }
   }

   // Check the longitude value.
   if ((HasLon = ui->Longitude->text().trimmed().size())) {
      ui->Longitude->text().toFloat(&ValueOK);
      if (!ValueOK) {
         QMessageBox::critical(this, "Locator", "Invalid longitude.");
         ui->Longitude->setFocus(); ui->Longitude->selectAll();
         return false;
      }
   }

   // Check the event indicator value. Not mandatory.
   ValueOK = false;
   Value = ui->EventInd->text().trimmed().toUpper();
   if (!Value.size() || Value == " ") ValueOK = true;
   if (Value.size() == 1 && Value.at(0).isLetter()) ValueOK = true;
   if (!ValueOK) {
      QMessageBox::critical(nullptr, "Locator", "Invalid event indicator.");
      ui->EventInd->selectAll(); ui->EventInd->setFocus();
      return false;
   }

   // Check the depth value. Must be present if lat/lon is given.
   if ((HasDepth = ui->Depth->text().trimmed().size())) {
      ui->Depth->text().toFloat(&ValueOK);
      if (!ValueOK) {
         QMessageBox::critical(this, "Locator", "Invalid depth.");
         ui->Depth->setFocus(); ui->Depth->selectAll();
         return false;
      }
   }

   // Check that depth is given if logitude/latitude is given.
   if (HasLat && HasLon && !HasDepth) {
      QMessageBox::critical(this, "Locator", "Missing value for depth.");
      ui->Depth->setFocus(); ui->Depth->selectAll();
      return false;
   }


   //
   // Check values in the Settings table.
   //
   // Check the Model Indicator value.
   ValueOK = false;
   Value = ui->SettingsTable->item(SET_MODIND_ROW, 1)->text();
   if (!Value.size() || Value == " ") ValueOK = true;
   if (Value.size() == 1 && Value.at(0).isLetter()) ValueOK = true;
   if (Value.size() == 1 && Value.at(0).isNumber()) ValueOK = true;
   if (!ValueOK) {
      QMessageBox::critical(this, "Locator", "Invalid value, please correct.");
      index = ui->SettingsTable->model()->index(SET_MODIND_ROW, 1);
      ui->SettingsTable->setCurrentIndex(index); ui->SettingsTable->edit(index);
      ui->TabWidget1->setCurrentIndex(1);
      return false;
   }

   // Check the Fix Ort value.
   ValueOK = false;
   Value = ui->SettingsTable->item(SET_FIXORT_ROW, 1)->text().toUpper();
   if (!Value.size() || Value == " " || Value == "F") ValueOK = true;
   if (!ValueOK) {
      QMessageBox::critical(this, "Locator", "Invalid value, please correct.");
      index = ui->SettingsTable->model()->index(SET_FIXORT_ROW, 1);
      ui->SettingsTable->setCurrentIndex(index); ui->SettingsTable->edit(index);
      ui->TabWidget1->setCurrentIndex(1);
      return false;
   }

   // Check the Epicenter Flag value.
   ValueOK = false;
   Value = ui->SettingsTable->item(SET_EPIFLAG_ROW, 1)->text().toUpper();
   if (!Value.size() || Value == " " || Value == "F" || Value == "S" || Value == "*") ValueOK = true;
   if (!ValueOK) {
      QMessageBox::critical(this, "Locator", "Invalid value, please correct.");
      index = ui->SettingsTable->model()->index(SET_EPIFLAG_ROW, 1);
      ui->SettingsTable->setCurrentIndex(index); ui->SettingsTable->edit(index);
      ui->TabWidget1->setCurrentIndex(1);
      return false;
   }

   // Check the Depth Flag value.
   ValueOK = false;
   Value = ui->SettingsTable->item(SET_DEPTHFLAG_ROW, 1)->text().toUpper();
   if (!Value.size() || Value == " " || Value == "F" || Value == "S") ValueOK = true;
   if (!ValueOK) {
      QMessageBox::critical(this, "Locator", "Invalid value, please correct.");
      index = ui->SettingsTable->model()->index(SET_DEPTHFLAG_ROW, 1);
      ui->SettingsTable->setCurrentIndex(index); ui->SettingsTable->edit(index);
      ui->TabWidget1->setCurrentIndex(1);
      return false;
   }

   // Check XFAR,XNEAR, and START DEPTH values.
   // First, get and check the XNEAR value.
   ValueOK = xnear_empty = false;
   Value = ui->SettingsTable->item(SET_XNEAR_ROW, 1)->text().trimmed();
   if (Value.isEmpty()) {
      xnear_empty = ValueOK = true;
   } else {
      fValue = Value.toFloat(&ValueOK);
      if (ValueOK) if (fValue < 0.0 || fValue > 9999.0) ValueOK = false;
   }
   if (!ValueOK) {
      QMessageBox::critical(this, "Locator", "Invalid value, or value out of range. Please correct.");
      index = ui->SettingsTable->model()->index(SET_XNEAR_ROW, 1);
      ui->SettingsTable->setCurrentIndex(index); ui->SettingsTable->edit(index);
      ui->TabWidget1->setCurrentIndex(1);
      return false;
   }

   // Get and check the XFAR value.
   ValueOK = xfar_empty = false;
   Value = ui->SettingsTable->item(SET_XFAR_ROW, 1)->text().trimmed();
   if (Value.isEmpty()) {
      xfar_empty = ValueOK = true;
   } else {
      fValue = Value.toFloat(&ValueOK);
      if (ValueOK) if (fValue < 0.0 || fValue > 9999.0) ValueOK = false;
   }
   if (!ValueOK) {
      QMessageBox::critical(this, "Locator", "Invalid value, or value out of range. Please correct.");
      index = ui->SettingsTable->model()->index(SET_XFAR_ROW, 1);
      ui->SettingsTable->setCurrentIndex(index); ui->SettingsTable->edit(index);
      ui->TabWidget1->setCurrentIndex(1);
      return false;
   }

   // Get and check the start depth value.
   ValueOK = sdep_empty = false;
   Value = ui->SettingsTable->item(SET_SDEP_ROW, 1)->text().trimmed();
   if (Value.isEmpty()) {
      ValueOK = sdep_empty = true;
   } else {
      fValue = Value.toFloat(&ValueOK);
      if (ValueOK) if (fValue < 0.0 || fValue > 999.0) ValueOK = false;
   }
   if (!ValueOK) {
      QMessageBox::critical(this, "Locator", "Invalid value, or value out of range. Please correct.");
      index = ui->SettingsTable->model()->index(SET_SDEP_ROW, 1);
      ui->SettingsTable->setCurrentIndex(index); ui->SettingsTable->edit(index);
      ui->TabWidget1->setCurrentIndex(1);
      return false;
   }

   // If one of XNEAR/XFAR is given, then both must be given.
   if (!xnear_empty || !xfar_empty) {
      if (xnear_empty || xfar_empty) {
         QMessageBox::critical(this, "Locator", "Required value missing, please correct.");
         if (xfar_empty) index = ui->SettingsTable->model()->index(SET_XFAR_ROW, 1);
         if (xnear_empty) index = ui->SettingsTable->model()->index(SET_XNEAR_ROW, 1);
         ui->SettingsTable->setCurrentIndex(index); ui->SettingsTable->edit(index);
         ui->TabWidget1->setCurrentIndex(1);
         return false;
      }
   }

   // Check that value of XNEAR is less than XFAR.
   if (!xnear_empty) {
      float fFar = ui->SettingsTable->item(SET_XFAR_ROW, 1)->text().toFloat(&ValueOK);
      float fNear = ui->SettingsTable->item(SET_XNEAR_ROW, 1)->text().toFloat(&ValueOK);
      if (fNear >= fFar) {
         QMessageBox::critical(this, "Locator", "Invalid values, XFAR needs to be larger then XNEAR. Please correct.");
         index = ui->SettingsTable->model()->index(SET_XNEAR_ROW, 1);
         ui->SettingsTable->setCurrentIndex(index); ui->SettingsTable->edit(index);
         ui->TabWidget1->setCurrentIndex(1);
         return false;
      }
   }

   // If START DEPTH if given, then XNEAR/XFAR must be given.
   if (!sdep_empty && xnear_empty) {
      QMessageBox::critical(this, "Locator", "Required value missing, please correct.");
      if (xfar_empty) index = ui->SettingsTable->model()->index(SET_XFAR_ROW, 1);
      if (xnear_empty) index = ui->SettingsTable->model()->index(SET_XNEAR_ROW, 1);
      ui->SettingsTable->setCurrentIndex(index); ui->SettingsTable->edit(index);
      ui->TabWidget1->setCurrentIndex(1);
      return false;
   }


   //
   // Check values in the 'Phase' table.
   //
   for (int Row=0;Row<ui->PhaseTable->rowCount();Row++) {
      // Check PhObs value. Must contain 0 to 8 letters.
      ValueOK = true;
      Value = ui->PhaseTable->item(Row, PHASE_PHOBS_COL)->text().simplified();
      if (Value.size()) ValueOK = ((Value.size()<9) && Value.contains(QRegExp("^[a-zA-Z]+$")));
      if (!ValueOK) {
         Message = "Invalid PhObs value in row " + QString::number(Row+1) + ".";
         QMessageBox::critical(this, "Locator", Message);
         ui->TabWidget2->setCurrentIndex(0);
         return false;
      }

      // Check WtObs value.
      ValueOK = true;
      Value = ui->PhaseTable->item(Row, PHASE_WTOBS_COL)->text().simplified();
      if (Value.size()) ValueOK = ((Value.size()==1) && Value.contains(QRegExp("[012349]")));
      if (!ValueOK) {
         Message = "Invalid WtObs value in row " + QString::number(Row+1) + ".";
         QMessageBox::critical(this, "Locator", Message);
         ui->TabWidget2->setCurrentIndex(0);
         return false;
      }
   }

   //
   // Check values in the 'Azimuth' table.
   //
   for (int Row=0;Row<ui->AzimuthTable->rowCount();Row++) {
      // Check WtObs value.
      ValueOK = true;
      Value = ui->AzimuthTable->item(Row, AZM_WTOBS_COL)->text().simplified();
      if (Value.size()) ValueOK = ((Value.size()==1) && Value.contains(QRegExp("[012349]")));
      if (!ValueOK) {
         Message = "Invalid WtObs value in row " + QString::number(Row+1) + ".";
         QMessageBox::critical(this, "Locator", Message);
         ui->TabWidget2->setCurrentIndex(1);
         return false;
      }
   }

   // No problems was found
   return true;
}




// ************************************************************************
// This function copies values from the dialog box into a node.
// ************************************************************************
void LocateDlg::CopyBasicValuesToNode(event_node_ *Node)
{
   bool ok;
   QString sValue;
   hypocenter_ *Hypo;

   // Get pointer to first hypocenter.
   Hypo = Node->hypocenters.first;

   // Copy date.
   QDate Date = QDate::fromString(ui->Date->text().simplified(), "yyyy-MM-dd");
   if (!Date.isValid()) Date = QDate::fromString(ui->Date->text(), "yyyyMMdd");
   Hypo->time.year = Date.year(); Hypo->time.month = Date.month(); Hypo->time.day = Date.day();

   // Copy time.
   QTime Time = QTime::fromString(ui->Time->text().simplified(), "hh:mm:ss.z");
   if (!Time.isValid()) Time = QTime::fromString(ui->Time->text(), "hhmmss.z");
   Hypo->time.hour = Time.hour();  Hypo->time.minute = Time.minute();
   Hypo->time.second = Time.second() + Time.msec()*0.001;

   // Copy the Distance indicator value. This value can
   // not be empty. File name will also changed if needed.
   sValue = ui->DistInd->text();
   NodeSetDistanceIndicator(Node, sValue.at(0));

   // Copy the Event indicator value.
   sValue = ui->EventInd->text();
   if (sValue.isEmpty()) NodeSetEventIndicator(Node, 32);
   if (!sValue.isEmpty()) NodeSetEventIndicator(Node, sValue.at(0));

   // Copy latitude.
   sValue = ui->Latitude->text().trimmed();
   Hypo->lat = -999.0;
   if (!sValue.isEmpty()) {
      Hypo->lat = sValue.toFloat(&ok);
      if (!ok) Hypo->lat = -999.0;
   }

   // Copy longitude.
   sValue = ui->Longitude->text().trimmed();
   Hypo->lon = -999.0;
   if (!sValue.isEmpty()) {
      Hypo->lon = sValue.toFloat(&ok);
      if (!ok) Hypo->lon = -999.0;
   }

   // Copy depth.
   sValue = ui->Depth->text().trimmed();
   Hypo->depth = -999.0;
   if (!sValue.isEmpty()) {
      Hypo->depth = sValue.toFloat(&ok);
      if (!ok) Hypo->depth = -999.0;
   }

   // Copy locality.
   sValue = ui->Locality->text().trimmed();
   strcpy(Node->locality, sValue.toLocal8Bit().data());
}




// ************************************************************************
// This function copies values from the 'Settings' table into a node.
// ************************************************************************
void LocateDlg::CopySettingsTableValuesToNode(event_node_ *Node)
{
   QString Value, CmntLn;
   QStringList CommentList;

   // Copy the Model Indicator value.
   Value = ui->SettingsTable->item(SET_MODIND_ROW, 1)->text();
   if (!Value.size()) Value = " ";
   Node->hypocenters.first->modl_id = Value.at(0).toLatin1();

   // Copy the Fix Ort value.
   Value = ui->SettingsTable->item(SET_FIXORT_ROW, 1)->text();
   if (!Value.size()) Value = " ";
   Node->hypocenters.first->fix_org = Value.at(0).toUpper().toLatin1();

   // Copy the Epicenter Flag value.
   Value = ui->SettingsTable->item(SET_EPIFLAG_ROW, 1)->text();
   if (!Value.size()) Value = " ";
   Node->hypocenters.first->epi_flag = Value.at(0).toUpper().toLatin1();

   // Copy the Depth Flag value.
   Value = ui->SettingsTable->item(SET_DEPTHFLAG_ROW, 1)->text();
   if (!Value.size()) Value = " ";
   Node->hypocenters.first->depth_flag = Value.at(0).toUpper().toLatin1();

   // Create a new comment line from START DEPTH/XNEAR/XFAR values if they exist.
   // Existing comment lines of this type will be removed. If XNEAR exists, then
   // XFAR is expected to exist as well. Value for START DEPTH may not exist.
   NodeGetComments(Node, &CommentList);
   // Remove all existing comments of this type.
   for (int i = CommentList.size()-1; i >= 0; i--) {
      CmntLn = CommentList.at(i);
      if (CmntLn.contains("XNEAR") && CmntLn.contains("XFAR")) CommentList.removeAt(i);
   }
   // Create a new comment line if a value exist for XNEAR.
   if (ui->SettingsTable->item(SET_XNEAR_ROW, 1)->text().size()) {
      // Create the new comment line.
      CmntLn = "XNEAR " + ui->SettingsTable->item(SET_XNEAR_ROW, 1)->text();
      CmntLn.append(" XFAR " + ui->SettingsTable->item(SET_XFAR_ROW, 1)->text());
      if (ui->SettingsTable->item(SET_SDEP_ROW, 1)->text().size()) {
         CmntLn.append(" SDEP " + ui->SettingsTable->item(SET_SDEP_ROW, 1)->text());
      }
      // Add the new comment line to comment list.
      CommentList.append(CmntLn);
   }
   // Set the new comment list.
   NodeSetComments(Node, CommentList);
}




// ***********************************************************************
// This function copies user settable values from the 'Phase' table into
// the Phases list. Only the two columns PhObs and WtObs will be copied.
// ***********************************************************************
void LocateDlg::SavePhaseTableValues()
{
   int PhaseNum;
   phase_ Phase;
   QString Value;

   for (int Row=0;Row<ui->PhaseTable->rowCount();Row++) {
      // Get phase number for this row from the table.
      PhaseNum = ui->PhaseTable->item(Row, PHASE_NUM_COL)->data(Qt::UserRole).toInt();

      // Get pointer to phase.
      Phase = Phases.at(PhaseNum);

      // Update PhObs value.
      Phase.phase[0] = 0;
      Value = ui->PhaseTable->item(Row, PHASE_PHOBS_COL)->text().simplified();
      if (Value.size()) strcpy(Phase.phase, Value.toLocal8Bit().data());

      // Update WtObs value.
      Phase.weight_in = 32;
      Value = ui->PhaseTable->item(Row, PHASE_WTOBS_COL)->text().simplified();
      if (Value.size()) Phase.weight_in = Value.at(0).toLatin1();

      // Save the phase.
      Phases.replace(PhaseNum, Phase);
   }
}




// ***********************************************************************
// This function copies user settable values from the 'Azimuth' table
// into the Phases list. Only the WtObs column will be copied.
// ***********************************************************************
void LocateDlg::SaveAzimuthTableValues()
{
   int PhaseNum;
   phase_ Phase;
   QString Value;

   for (int Row=0;Row<ui->AzimuthTable->rowCount();Row++) {
      // Get phase numer for this row from the table.
      PhaseNum = ui->AzimuthTable->item(Row, AZM_NUM_COL)->data(Qt::UserRole).toInt();

      // Get the phase.
      Phase = Phases.at(PhaseNum);

      // Update WtObs value.
      Phase.weight_in = 32;
      Value = ui->AzimuthTable->item(Row, AZM_WTOBS_COL)->text().simplified();
      if (Value.size()) Phase.weight_in = Value.at(0).toLatin1();

      // Save the phase.
      Phases.replace(PhaseNum, Phase);
   }
}




// ************************************************************************
// This function is called every time user shows the window.
// We will respond by showing the currently selected row.
// ************************************************************************
void LocateDlg::showEvent(QShowEvent*)
{
   RowChanged(SEDB);
}




// ***********************************************************************
// This function handles state changes for the 'Epicenter flag' check box.
// ***********************************************************************
void LocateDlg::EpicFlagChanged(int state)
{
   // Update value for 'Epicenter flag' in 'Settings' table.
   QTableWidgetItem *Item = ui->SettingsTable->item(SET_EPIFLAG_ROW, 1);
   disconnect(ui->SettingsTable, SIGNAL(itemChanged(QTableWidgetItem*)), this, SLOT(SettingsTableChanged(QTableWidgetItem*)));
   if (state == Qt::Unchecked) Item->setText(QString());
   if (state == Qt::PartiallyChecked) Item->setText(QString("F"));
   if (state == Qt::Checked) Item->setText(QString("S"));
   connect(ui->SettingsTable, SIGNAL(itemChanged(QTableWidgetItem*)), this, SLOT(SettingsTableChanged(QTableWidgetItem*)));
}




// ***********************************************************************
// This function handles state changes for the 'Depth flag' check box.
// ***********************************************************************
void LocateDlg::DepthFlagChanged(int state)
{
   // Update value for 'Depth flag' in 'Settings' table.
   QTableWidgetItem *Item = ui->SettingsTable->item(SET_DEPTHFLAG_ROW, 1);
   disconnect(ui->SettingsTable, SIGNAL(itemChanged(QTableWidgetItem*)), this, SLOT(SettingsTableChanged(QTableWidgetItem*)));
   if (state == Qt::Unchecked) Item->setText(QString());
   if (state == Qt::PartiallyChecked) Item->setText(QString("F"));
   if (state == Qt::Checked) Item->setText(QString("S"));
   connect(ui->SettingsTable, SIGNAL(itemChanged(QTableWidgetItem*)), this, SLOT(SettingsTableChanged(QTableWidgetItem*)));
}




// **********************************************************************
// This function handles changes in the 'Settings' table.
// **********************************************************************
void LocateDlg::SettingsTableChanged(QTableWidgetItem *Item)
{
   // Get the item string, and make sure string is uppercase.
   QString ItemStr = Item->text().simplified().toUpper();

   // Handle the orgin time flag. Set the value
   // again to make sure it is upper case.
   if (Item == OrtFlagItem) Item->setText(ItemStr);

   // Handle the epicenter flag.
   if (Item == EpiFlagItem) {
      // Set the value again to make sure it is upper case.
      Item->setText(ItemStr);
      // Set check state for the 'Epicenter flag' check box.
      ui->EpicFlag->setCheckState(Qt::Unchecked);
      if (ItemStr == "F") ui->EpicFlag->setCheckState(Qt::PartiallyChecked);
      if (ItemStr == "S") ui->EpicFlag->setCheckState(Qt::Checked);
   }

   // Handle the depth flag.
   if (Item == DepthFlagItem) {
      // Set the value again to make sure it is upper case.
      Item->setText(ItemStr);
      // Set check state for the 'Depth flag' check box.
      ui->DepthFlag->setCheckState(Qt::Unchecked);
      if (ItemStr == "F") ui->DepthFlag->setCheckState(Qt::PartiallyChecked);
      if (ItemStr == "S") ui->DepthFlag->setCheckState(Qt::Checked);
   }
}




// *****************************************************************************
// User has pressed the 'Delete' button from the PhaseTable widget.
// *****************************************************************************
void LocateDlg::DeletePhases()
{
   int Row, PhaseNum;

   // Get the selected rows.
   QModelIndexList IndexList = ui->PhaseTable->selectionModel()->selectedRows();

   // Return if no rows are selected.
   if (!IndexList.size()) return;

   // Delete the selected phases from the 'Phases' list.
   for (int i=IndexList.size()-1;i>=0;i--) {
       // Get the row number in the table.
       Row = IndexList.at(i).row();
       // Get the index for this phase in 'Phases' list.
       PhaseNum = ui->PhaseTable->item(Row, 0)->data(Qt::UserRole).toInt();
       // Delete the phase from the 'Phases' list.
       Phases.removeAt(PhaseNum);
   }

   // Update the three tables views.
   PopulatePhaseTable((bool)LocatedNode);
   PopulateAzimuthTable((bool)LocatedNode);
   PopulateMagnitudeTable((bool)LocatedNode);
}




// *****************************************************************************
// User has pressed the 'Delete' button from the MagnitudeTable widget.
// *****************************************************************************
void LocateDlg::DeleteMagnitudes()
{
   int Row, PhaseNum;

   // Get the selected rows.
   QModelIndexList IndexList = ui->MagnitudeTable->selectionModel()->selectedRows();

   // Return if no rows are selected.
   if (!IndexList.size()) return;

   // Delete the selected magnitudes from the 'Phases' list.
   for (int i=IndexList.size()-1;i>=0;i--) {
      // Get the row number in the table.
      Row = IndexList.at(i).row();
      // Get the index for this phase in 'Phases' list.
      PhaseNum = ui->MagnitudeTable->item(Row, 0)->data(Qt::UserRole).toInt();
      // Delete the phase from the 'Phases' list.
      Phases.removeAt(PhaseNum);
   }

   // Update the three tables views.
   PopulatePhaseTable((bool)LocatedNode);
   PopulateAzimuthTable((bool)LocatedNode);
   PopulateMagnitudeTable((bool)LocatedNode);
}




// ********************************************************
// This is the event filter for the dialog.
// ********************************************************
bool LocateDlg::eventFilter(QObject* object, QEvent* event)
{
   if (event->type()==QEvent::KeyPress) {
      // Transform QEvent into QKeyEvent.
      QKeyEvent* pKeyEvent=static_cast<QKeyEvent*>(event);

      // Handle pressed key.
      if (object == ui->PhaseTable) {
          // Handle key presses from the phase table.
          switch(pKeyEvent->key()) {
          case Qt::Key_Delete:
             if (pKeyEvent->modifiers() == Qt::NoModifier) { DeletePhases(); return true; }
             return false;
          }
      } else if (object == ui->MagnitudeTable) {
          // Handle key presses from the magnitude table.
          switch(pKeyEvent->key()) {
          case Qt::Key_Delete:
             if (pKeyEvent->modifiers() == Qt::NoModifier) { DeleteMagnitudes(); return true; }
             return false;
          }
      } else {
         // Handle other key presses from the dialog.
         switch(pKeyEvent->key()) {
         case Qt::Key_C:
            if (pKeyEvent->modifiers() == Qt::ControlModifier) { CopyCoordinates(); return true; }
            return false;

         case Qt::Key_L:
            if (pKeyEvent->modifiers() == Qt::ControlModifier) { LocateButton(); return true; }
            return false;

         case Qt::Key_S:
            if (pKeyEvent->modifiers() == Qt::ControlModifier) { SaveButton(); return true; }
            return false;

         case Qt::Key_P:
            if (pKeyEvent->modifiers() == Qt::ControlModifier) { PrevEventButton(); return true; }
            return false;

         case Qt::Key_N:
            if (pKeyEvent->modifiers() == Qt::ControlModifier) { NextEventButton(); return true; }
            return false;
         }
      }
   }
   return false;
}
