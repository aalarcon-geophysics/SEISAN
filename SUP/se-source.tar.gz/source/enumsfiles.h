#ifndef ENUMSFILES_H
#define ENUMSFILES_H

#include <QDate>
#include <QMutex>
#include <QThread>
#include <QStringList>
#include <types.h>


class enumsfiles : public QThread
{
   Q_OBJECT

public:
   void run();
   void Cancel();
   void SetDatabase(db_info, QDate, QDate, QStringList*);

signals:
   void EnumSfilesProgress(int);
   void EnumSfilesDone(char);

private:
   char dbname[40];
   char startdate[14];
   char stopdate[14];
   db_type dbtype;
   QString dbpath;
   QString date;
   QStringList *sfilelist;
   QMutex mtx_terminate;
   bool terminate;
};

#endif // ENUMSFILES_H
