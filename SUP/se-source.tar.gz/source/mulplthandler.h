#ifndef MULPLTHANDLER_H
#define MULPLTHANDLER_H

#include <QObject>
#include <QUdpSocket>
#include "logmodel.h"

class MulpltHandler : public QObject
{
   Q_OBJECT

public:
   explicit MulpltHandler(logmodel*, QObject *parent = 0);
   ~MulpltHandler();
   void SendMsg(QString);
   bool Start(QString, QStringList);
   void LoadFile(QString);
   void Close();
   QString SFile;                // S-file passed to mulplt at launch.
   bool Running;                 // This variable indicates if mulplt is running.

signals:
   void message_received(MulpltHandler*, QString, QString);

public slots:
   void GetUdpMessages();

private:
   logmodel *LogModel;           // Pointer to the logmodel class.
   QString Eev, Mulplt;          // Holds name of eev and mulplt executables.
   QString Shell, ShellPar;      // Holds name of shell and shell parameter used for execution of eev/mulplt.
   QString Message;              // For general use.

   // Objects related to network communication.
   QUdpSocket Socket;            // Socket for communication with mulplt.
   bool NetworkOk;               // Indicates if network where successfully initialised in constructor.
   quint16 MyPort;               // The UDP port we listen to.
   quint16 PeerPort;             // The UDP port mulplt listen to.

   // Private functions.
   bool InitNetwork();           // Initializes the network.
   void SendUdpMessage(QString); // Send a message to mulplt.
};

#endif // MULPLTHANDLER_H
