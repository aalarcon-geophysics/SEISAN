﻿#ifndef CONFIGUREDLG_H
#define CONFIGUREDLG_H

#include <QDialog>
#include "types.h"
#include "logmodel.h"


namespace Ui {
   class ConfigureDlg;
}

class ConfigureDlg : public QDialog
{
   Q_OBJECT

public:
   explicit ConfigureDlg(se_config*, QWidget *parent = 0);
   ~ConfigureDlg();

public slots:
   void accept();

private:
   Ui::ConfigureDlg *ui;
   se_config *Config;
};

#endif // CONFIGUREDLG_H
