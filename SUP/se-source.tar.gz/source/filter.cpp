#include <QList>
#include <QDebug>
#include <QPolygonF>
#include "filter.h"
#include "library.h"
#include "eventnode.h"


// *********************************************************************
// This function trimmes the infix expression and checks it for errors.
// If function returns 'true' then the expression is assumed to be OK.
// If an error is found then an error message is returned in 'ErrMsg'.
// An empty expression will be defined as being OK.
// ExprType: 0=Include expression, 1=Exclude expression.
// *********************************************************************
bool TrimAndCheckInfix(QString *infix, QString *ErrMsg, char ExprType)
{
   // Check the use of double quotes in expression.
   // Infix must contain an even number of quotes.
   if (infix->count(QChar('"'))%2 != 0) {
      *ErrMsg = "Invalid syntax: Odd number of double quotes found";
      return false;
   }

   // Clean up the whitespace in the expression.
   // Empty paranthesis are also being removed.
   // Spaces inside of strings will not be modified.
   TrimInfix(infix);

   // Check if expression is empty.
   if (!infix->size()) return true;

   // Check for 'IncludeAll' statement.
   if (infix->toUpper() == "INCLUDEALL") {
      if (!ExprType) return true;
      *ErrMsg = "Invalid statement: IncludeAll";
      return false;
   }

   // Check infix expression for errors.
   if (!CheckInfix(*infix, ErrMsg, false, false, false)) return false;

   return true;
}




// ************************************************************
// Cleans up whitespace in an infix expression. Also removes
// empty paranthesis. Spaces in strings are NOT being modified.
// ************************************************************
void TrimInfix(QString *infix)
{
   bool replace;

   // Protect spaces in strings by replacing
   // them with a control character (30).
   replace = false;
   for (int i=infix->size()-1;i>=0;i--) {
      if (infix->at(i) == '"') replace = !replace;
      if (replace) {
         if (infix->at(i) == ' ') infix->replace(i, 1, QChar(30));
         if (infix->at(i) == '\n') infix->remove(i, 1);
      }
   }

   // Make space around paranthesis.
   infix->replace("(", " ( ");
   infix->replace(")", " ) ");

   // Remove unneeded spaces between tokens.
   while (infix->contains("  ")) infix->replace("  ", " ");

   // Remove spaces around newlines.
   while (infix->contains(" \n")) infix->replace(" \n", "\n");
   while (infix->contains("\n ")) infix->replace("\n ", "\n");

   // Remove unneeded newlines.
   while (infix->contains("\n\n")) infix->replace("\n\n", "\n");

   // Remove spaces around commas.
   while (infix->contains(" ,")) infix->replace(" ,", ",");
   while (infix->contains(", ")) infix->replace(", ", ",");

   // Remove spaces around brackets.
   while (infix->contains(" ]")) infix->replace(" ]", "]");
   while (infix->contains(" [")) infix->replace(" [", "[");
   while (infix->contains("[ ")) infix->replace("[ ", "[");

   // Remove empty paranthesis from expression.
   while (infix->contains("( )")) {
      infix->remove("( )"); infix->replace("  ", " ");
   }

   // Remove whitespace from start and end.
   *infix = infix->trimmed();

   // Restore control characters in strings to spaces.
   replace = false;
   for (int i=0;i<infix->size();i++) {
      if (infix->at(i) == '"') replace = !replace;
      if (replace && infix->at(i) == 30) infix->replace(i, 1, ' ');
   }
}




// *******************************************************************
// Checks an infix expression for errors. If an error is found this
// funtion will return false + an error message and the error token.
// If 'HasStation' is true then the infix expression is intended for
// the 'HasStation' function.
// *******************************************************************
bool CheckInfix(QString infix, QString *ErrMsg, bool HasStation,
                bool HasMagnitude, bool HasFPS)
{
   int tokenType;
   QString token, lastToken;
   QString value1, value2, varType;
   QStringList iList, pList, stack;

   // Check number of right/left paranthesis in infix.
   if (infix.count("(") != infix.count(")")) {
      *ErrMsg = "Invalid syntax: Paranthesis mismatch.";
      return false;
   }

   // Check number of right/left brackets in infix.
   if (infix.count("[") != infix.count("]")) {
       *ErrMsg = "Invalid syntax: Brackets mismatch.";
      return false;
   }

   // Split the infix string into a list of tokens.
   // The split is based on spaces in the expression.
   // Spaces inside of strings will be ignored.
   // All newline cahracters are removed.
   Infix2TokenList(infix, &iList);

   // Tests related to the HasStation/HasMagnitude/HasFPS query expressions.
   if (HasStation || HasMagnitude || HasFPS) {
      // Only certain properties can be used with the these
      // functions. Check for invalid properties and functions.
      for (int i=0;i<iList.size();i++) {
         // Check for invalid properties.
         if (GetTokenType(iList.at(i)) == TTVARIABLE) {
            if (HasStation && !isValidHasStationProperty(iList.at(i))) {
               *ErrMsg = "Invalid property " + iList.at(i);
               return false;
            }
            if (HasMagnitude && !isValidHasMagnitudeProperty(iList.at(i))) {
               *ErrMsg = "Invalid property " + iList.at(i);
               return false;
            }
            if (HasFPS && !isValidHasFPSProperty(iList.at(i))) {
               *ErrMsg = "Invalid property " + iList.at(i);
               return false;
            }
         }
         // Functions are not allowed in the query expression.
         tokenType = GetTokenType(iList.at(i));
         if (tokenType == TTBFUNCTION || tokenType == TTVFUNCTION) {
            *ErrMsg = "Functions not allowed: " + iList.at(i);
            return false;
         }
      }
   }

   // The properties reserved for HasStation[], HasMagnitude[]
   // and HasFPS[] are not allowed in the normal expression.
   if (!HasStation && !HasMagnitude && !HasFPS) {
      for (int i=0;i<iList.size();i++) {
         if (GetTokenType(iList.at(i)) == TTVARIABLE) {
            if (isValidHasStationProperty(iList.at(i))) {
               *ErrMsg = "Invalid property " + iList.at(i);
               return false;
            }
            if (isReservedHasMagnitudeProperty(iList.at(i))) {
               *ErrMsg = "Invalid property " + iList.at(i);
               return false;
            }
            if (isReservedHasFPSProperty(iList.at(i))) {
               *ErrMsg = "Invalid property " + iList.at(i);
               return false;
            }
         }
      }
   }

   // Scan for unknown tokens.
   for (int i=0;i<iList.size();i++) {
      if (GetTokenType(iList.at(i)) == TTUNKNOWN) {
         *ErrMsg = "Unknown token: " + iList.at(i);
         return false;
      }
   }

   // Check for ")(" paranthesis combination.
   for (int i=0;i<iList.size()-1;i++) {
      if (iList.at(i) == ")" && iList.at(i+1) == "(") {
         *ErrMsg = "Invalid syntax: ) (";
         return false;
      }
   }

   // Check for adjacent operators.
   lastToken.clear();
   for (int i=0;i<iList.size();i++) {
      if (isOperator(iList.at(i)) && isOperator(lastToken)) {
         *ErrMsg = "Adjacent operators: " + lastToken + " " + iList.at(i);
         return false;
      }
      lastToken = iList.at(i);
   }

   // Check for adjacent operands.
   lastToken.clear();
   for (int i=0;i<iList.size();i++) {
      if (isOperand(iList.at(i)) && isOperand(lastToken)) {
         *ErrMsg = "Adjacent values: " + lastToken + " " + iList.at(i);
         return false;
      }
      lastToken = iList.at(i);
   }

   // Check that expression do not end with an operator.
   lastToken = iList.last();
   if (isOperator(lastToken)) {
      if (lastToken != ")") {
         *ErrMsg = "Expression ends with an operator.";
         return false;
      }
   }

   // Convert expression to postfix.
   if (!Infix2Postfix(infix, &pList, ErrMsg)) return false;

   // Parse postfix to detect errors in the expression.
   for (int i=0;i<pList.size();i++) {
      // Get token and token type.
      token = pList.at(i);
      tokenType = GetTokenType(token);

      // If token is a relational operator then
      // evaluate and put 'logical' back on stack.
      if (tokenType == TTRELATOPER) {
         if (stack.size() >= 2) {
            value1 = stack.takeFirst();
            value2 = stack.takeFirst();
            if (value1 == "logical" || value2 == "logical") {
               *ErrMsg = "Type mismatch in compare: " + value2 + " " + token + " " + value1;
               return false;
            }
            if (value1 != value2) {
               if (!(value1 == "integer" && value2 == "float")) {
                  *ErrMsg = "Type mismatch in compare: " + value2 + " " + token + " " + value1;
                  return false;
               }
            }
            stack.prepend("logical");
         } else {
            *ErrMsg = "Invalid syntax near '" + token + "'";
            return false;
         }
      }

      // If token is a logical operator then
      // evaluate and put 'logical' back on stack.
      if (tokenType == TTLOGICOPER) {
         if (stack.size() >= 2) {
            value1 = stack.takeFirst();
            value2 = stack.takeFirst();
            if (value1 == "logical" && value2 == "logical") {
               stack.prepend("logical");
            } else {
               *ErrMsg = "Type mismatch in compare: " + value2 + " " + token + " " + value1;
               return false;
            }
         } else {
            *ErrMsg = "Invalid syntax near '" + token + "'";
            return false;
         }
      }

      // If token is a variable, put it's type on the stack.
      if (tokenType == TTVARIABLE) {
         varType = GetVarType(token);
         stack.prepend(varType);
      }

      // If token is an integer, put "integer" on the stack.
      if (tokenType == TTINTEGER) stack.prepend("integer");

      // If token is a float, put "float" on the stack.
      if (tokenType == TTFLOAT) stack.prepend("float");

      // If token is a string, put "string" on the stack.
      if (tokenType == TTSTRING) stack.prepend("string");

      // If token is a boolean function, put "logical" on the stack.
      if (tokenType == TTBFUNCTION) {
         // Check function syntax and values.
         if (!CheckFunction(token, ErrMsg)) return false;
         stack.prepend("logical");
      }

      // If token is a value function, put "float" on the stack.
      if (tokenType == TTVFUNCTION) {
         // Check function syntax and values.
         if (!CheckFunction(token, ErrMsg)) return false;
         stack.prepend("float");
      }

   }

   // Analayse stack status. At this point the
   // stack should ONLY contain a logical value.
   if (stack.size() == 1 && stack.first() == "logical") return true;

   // Stack is out of order.
   *ErrMsg = "Invalid syntax";
   return false;
}




// **************************************************
// Builds a list of tokens from the infix expression.
// All newline characters in expression are removed.
// **************************************************
void Infix2TokenList(QString infix, QStringList *tokenList)
{
   QString token;
   bool replace;

   // Search infix expression for strings.
   // All space charaters inside strings will be replaced with ASCII value 30.
   // All newline characters inside strings will also be removed.
   replace = false;
   for (int i=infix.size()-1;i>=0;i--) {
      if (infix.at(i) == '"') replace = !replace;
      if (replace) {
         if (infix.at(i) == ' ') infix.replace(i, 1, QChar(30));
         if (infix.at(i) == '\n') infix.remove(i, 1);
      }
   }

   // Search infix expression for brackets. All space and newline
   // charaters inside brackets are replaced with ASCII value 31.
   replace = false;
   for (int i=infix.size()-1;i>=0;i--) {
      if (infix.at(i) == '[' || infix.at(i) == ']') replace = !replace;
      if (replace) {
         if (infix.at(i) == ' ') infix.replace(i, 1, QChar(31));
         if (infix.at(i) == '\n') infix.replace(i, 1, QChar(31));
      }
   }

   // Replace newlines with spaces.
   infix.replace('\n', ' ');

   // Split expression into tokens. A split is made
   // every time space is found in the expression.
   *tokenList = infix.split(QChar(32), QString::SkipEmptyParts);

   // Restore all space characters that was previously replaced in comments.
   for (int i=0;i<tokenList->size();i++) {
      token = tokenList->at(i);
      tokenList->replace(i, token.replace(QChar(30), ' '));
   }

   // Restore all space characters that was previously replaced in brackets.
   for (int i=0;i<tokenList->size();i++) {
      token = tokenList->at(i);
      tokenList->replace(i, token.replace(QChar(31), ' '));
   }

   return;
}




// *********************************************************************
// Transforms an infix expression into a postfix expression. The
// shunting-yard algorithm is used. Returns false if an error is found
// in the expression, and 'Error' holds an error message.
// *********************************************************************
bool Infix2Postfix(QString infix, QStringList *postfix, QString *ErrMsg)
{
   bool done;
   QString token, stack_token;
   QStringList tokenList, stack;

   // Check for statement 'IncludeAll' in expression.
   if (infix.toUpper() == "INCLUDEALL") {
      postfix->append(infix); return true;
   }

   // Split the infix string into a list of tokens.
   Infix2TokenList(infix, &tokenList);

   // Convert infix expression to postfix expression.
   postfix->clear();
   for (int i=0;i<tokenList.size();i++) {
      token = tokenList.at(i);
      if (isOperand(token)) postfix->append(token);
      if (token == "(") stack.append("(");
      if (token == ")") {
         done = false;
         while (!stack.isEmpty() && !done) {
            stack_token = stack.last();
            stack.removeLast();
            if (stack_token == "(") {
               done = true;
            } else {
               postfix->append(stack_token);
            }
         }
      }
      if (isOperator(token)) {
         if (stack.isEmpty()) {
            stack.append(token);
         } else {
            done = false;
            while (!stack.isEmpty() && !done) {
               stack_token = stack.last();
               if (OperCmp(stack_token, token)) {
                  stack.removeLast();
                  postfix->append(stack_token);
               } else {
                  done = true;
               }
            }
            stack.append(token);
         }
      }
   }
   while (!stack.isEmpty()) {
      stack_token = stack.last();
      stack.removeLast();
      postfix->append(stack_token);
   }

   // Check if postfix exression contains paranthesis.
   if (postfix->contains("(") || postfix->contains(")")) {
      *ErrMsg = "Invalid syntax: Paranthesis mismatch.";
      return false;
   }

   return true;
}




// ***********************************************
// Evaluates a postfix expression for a node.
// Returns true if node matches the expression.
// ***********************************************
bool EvaluatePostfix(QStringList postfix, event_node_ *node)
{
   int tokenType;
   QString token;
   QStringList argList;
   QList<stack_item> stack;
   bool OK, bValue = false;
   stack_item val1, val2, val3;

   // Return false if expression is empty.
   if (!postfix.size()) return false;

   // Check for 'IncludeAll' statement.
   if (postfix.at(0).toUpper() == "INCLUDEALL") return true;

   // Evaluates the postfix expression.
   for (int i=0;i<postfix.size();i++) {
      // Get token and token type.
      token = postfix.at(i);
      tokenType = GetTokenType(token);

      // Token is a relational operator. Compare
      // and put the logical result back on stack.
      if (tokenType == TTRELATOPER) {
         val1 = stack.takeFirst();
         val2 = stack.takeFirst();
         if (!val1.value.novalue && !val2.value.novalue) {
            // Both operands has values.
            if (val1.valueType == 0) {
               // Compare floats.
               if (token == "<=") bValue = (val2.value.number <= val1.value.number);
               if (token == "<") bValue = (val2.value.number < val1.value.number);
               if (token == ">=") bValue = (val2.value.number >= val1.value.number);
               if (token == ">") bValue = (val2.value.number > val1.value.number);
               if (token == "=") bValue = (val2.value.number == val1.value.number);
            } else {
               // Compare strings.
               if (token == "<=") bValue = (val2.value.string.toUpper() <= val1.value.string.toUpper());
               if (token == "<") bValue = (val2.value.string.toUpper() < val1.value.string.toUpper());
               if (token == ">=") bValue = (val2.value.string.toUpper() >= val1.value.string.toUpper());
               if (token == ">") bValue = (val2.value.string.toUpper() > val1.value.string.toUpper());
               if (token == "=") bValue = (val2.value.string.toUpper() == val1.value.string.toUpper());
            }
            val1.valueType = 2;
            val1.logicalValue = bValue;
            stack.prepend(val1);
         } else {
            // At least one operand has no value.
            val1.valueType = 2;
            val1.logicalValue = false;
            stack.prepend(val1);
         }
      }

      // Token is a logical operator. Evaluate and
      // put the logical result back on the stack.
      if (tokenType == TTLOGICOPER) {
         if (stack.size() >= 2) {
            val1 = stack.takeFirst();
            val2 = stack.takeFirst();
            val3.valueType = 2;
            if (token.toUpper() ==  "OR") val3.logicalValue = (val1.logicalValue || val2.logicalValue);
            if (token.toUpper() == "AND") val3.logicalValue = (val1.logicalValue && val2.logicalValue);
            stack.prepend(val3);
         }
      }

      // If token is a variable, put it's value on the stack.
      if (tokenType == TTVARIABLE) {
         NodeGetProperty(node, token.toUpper(), &val1.value);
         val1.valueType = val1.value.valueType;
         stack.prepend(val1);
      }

      // If token is an integer or float, put "number" on the stack.
      if (tokenType == TTINTEGER || tokenType == TTFLOAT) {
         val1.valueType = 0;
         val1.value.novalue = false;
         val1.value.number = token.toFloat(&OK);
         stack.prepend(val1);
      }

      // If token is a string, put the string on the stack.
      // All double quotes must be removed from the string.
      if (tokenType == TTSTRING) {
         val1.valueType = 2;
         val1.value.novalue = false;
         token.remove(0, 1).chop(1);
         val1.value.string = token;
         stack.prepend(val1);
      }

      // If token is a function then execute it and put the result on the stack.
      if (tokenType == TTBFUNCTION) {
         // Get the list of function arguments.
         GetFunctionArgs(token, &argList);
         // Execute the function.
         token.truncate(token.indexOf('['));
         val1.valueType = 2;
         val1.logicalValue = ExecuteBoolFunction(node, token.toUpper(), argList);
         // Put the logical result on the stack.
         stack.prepend(val1);
      }
      if (tokenType == TTVFUNCTION) {
         // Get the list of function arguments.
         GetFunctionArgs(token, &argList);
         // Execute the function.
         token.truncate(token.indexOf('['));
         val1.valueType = 0;
         val1.value.novalue = false;
         val1.value.number = ExecuteValueFunction(node, token.toUpper(), argList);
         // Put the float result on the stack.
         stack.prepend(val1);
      }

   }

   // Return the evaluation result.
   return stack.at(0).logicalValue;
}




// ***************************************************
// Inspects a function. Checks that parameters are OK.
// Returns 'false' if an error is found. Also returns
// a description of the error.
// ***************************************************
bool CheckFunction(QString function, QString *ErrMsg)
{
   bool ArgsOK;
   int NumArgs, NumExpectedArgs, tokenType;
   QStringList argList, ExpectedArgs;
   QString varType, Arguments, funcName, Msg, Arg;

   // Handle the 'HasStation' function.
   // This function need to be handled specially
   // since its parameter is an infix expression.
   if (function.toUpper().startsWith("HASSTATION")) {
      // Strip away the function name and brackets.
      function.chop(1); function.remove(0, function.indexOf("[", 0) + 1);
      // Check if infix expresion is empty.
      if (!function.size()) {
         *ErrMsg = "HasStation[]: Empty expression.";
         return false;
      }
      // Check the infix expression.
      if (!CheckInfix(function.toUpper(), &Msg, true, false, false)) {
         *ErrMsg = "HasStation[]: "; ErrMsg->append(Msg);
         return false;
      }
      return true;
   }


   // Handle the 'HasMagnitude' function.
   // This function need to be handled specially
   // since first parameter is an infix expression.
   if (function.toUpper().startsWith("HASMAGNITUDE")) {
      // Get the list of function arguments.
      GetFunctionArgs(function, &argList);
      // Check  number of arguments.
      if (argList.size() != 2) {
         *ErrMsg = "HasMagnitude[]: incorrect number of arguments.";
         return false;
      }
      // Check if infix expression is empty.
      if (!argList.at(0).size()) {
         *ErrMsg = "HasMagnitude[]: Empty expression.";
         return false;
      }
      // Check argument nr 2. Must be "PRIMARY" or "ALL".
      Arg = argList.at(1).toUpper();
      if (Arg != "PRIMARY" && Arg != "ALL") {
         *ErrMsg = "HasMagnitude[]: Second argument is invalid.";
         return false;
      }
      // Check the infix expression.
      if (!CheckInfix(argList.at(0).toUpper(), &Msg, false, true, false)) {
         *ErrMsg = "HasMagnitude[]: "; ErrMsg->append(Msg);
         return false;
      }
      return true;
   }


   // Handle the 'HasFPS' function.
   // This function need to be handled specially
   // since its parameter is an infix expression.
   // This function may have an empty argument list.
   if (function.toUpper().startsWith("HASFPS")) {
      // Get the list of function arguments.
      GetFunctionArgs(function, &argList);
      // Check the infix expression.
      if (argList.size()) {
         if (!CheckInfix(argList.at(0).toUpper(), &Msg, false, false, true)) {
            *ErrMsg = "HasFPS[]: "; ErrMsg->append(Msg);
            return false;
         }
      }
      return true;
   }


   // Handle the 'InPolygon' function.
   // This function need to be handled specially
   // since its parameter list has variable size.
   // This function must have at list 6 arguments.
   if (function.toUpper().startsWith("INPOLYGON")) {
      // Get the list of function arguments.
      GetFunctionArgs(function, &argList);
      // Check number of arguments.
      NumArgs = argList.size();
      if (NumArgs < 6 || NumArgs%2) {
         *ErrMsg = "InPolygon: Invalid number of arguments.";
         return false;
      }
      // Check the arguments. They must all be numbers.
      for (int i=0;i<argList.size();i++) {
         tokenType = GetTokenType(argList.at(i));
         if (tokenType != TTFLOAT && tokenType != TTINTEGER) {
            *ErrMsg = "InPolygon: Invalid argument type(s).";
            return false;
         }
      }
      return true;
   }


   // Handle the 'InRange' function.
   if (function.toUpper().startsWith("INRANGE")) {
      funcName = "INRANGE";
      NumExpectedArgs = 3;
      ExpectedArgs.append("$integerintegerinteger");
      ExpectedArgs.append("$integerfloatinteger");
      ExpectedArgs.append("$integerintegerfloat");
      ExpectedArgs.append("$integerfloatfloat");
      ExpectedArgs.append("$floatfloatfloat");
      ExpectedArgs.append("$floatintegerfloat");
      ExpectedArgs.append("$floatfloatinteger");
      ExpectedArgs.append("$floatintegerinteger");
   }


   // Handle the 'Contains' function.
   if (function.toUpper().startsWith("CONTAINS")) {
      funcName = "CONTAINS";
      NumExpectedArgs = 2;
      ExpectedArgs.append("$stringstring");
   }


   // Handle the 'IsFelt' function.
   if (function.toUpper().startsWith("ISFELT")) {
      funcName = "ISFELT";
      NumExpectedArgs = 0;
   }

   // Handle the 'WeekDay' function.
   if (function.toUpper().startsWith("WEEKDAY")) {
      funcName = "WEEKDAY";
      NumExpectedArgs = 0;
   }

   // Handle the 'Distance' function.
   if (function.toUpper().startsWith("DISTANCE")) {
      funcName = "DISTANCE";
      NumExpectedArgs = 2;
      ExpectedArgs.append("floatfloat");
      ExpectedArgs.append("integerinteger");
      ExpectedArgs.append("floatinteger");
      ExpectedArgs.append("integerfloat");
   }


   // Get the list of function arguments.
   GetFunctionArgs(function, &argList);

   // Check number of arguments.
   if (argList.size() != NumExpectedArgs) {
      *ErrMsg = funcName + "[]: Wrong number of arguments";
      return false;
   }

   // Check argument types.
   if (NumExpectedArgs) {
      for (int i=0;i<argList.size();i++) {
         tokenType = GetTokenType(argList.at(i));
         if (tokenType == TTVARIABLE) {
            varType = GetVarType(argList.at(i));
            if (varType == "integer") Arguments.append("$integer");
            if (varType == "float") Arguments.append("$float");
            if (varType == "string") Arguments.append("$string");
         }
         if (tokenType == TTINTEGER) Arguments.append("integer");
         if (tokenType == TTFLOAT) Arguments.append("float");
         if (tokenType == TTSTRING) Arguments.append("string");
      }
      ArgsOK = false;
      for (int index=0;index<ExpectedArgs.size();index++) {
         if (Arguments == ExpectedArgs.at(index)) { ArgsOK = true; break; }
      }
      if (!ArgsOK) {
         *ErrMsg = funcName + ": Invalid argument type(s).";
         return false;
      }
   }

   return true;
}




// ********************************************************************
// Executes a boolean function and returns the result as true or false.
// ********************************************************************
bool ExecuteBoolFunction(event_node_ *node, QString func, QStringList args)
{
   phase_ *phase;
   prop_value pValue;
   float fVal1, fVal2;
   bool ok, MissingVal;
   QString strVal1, token;
   QStringList tokenList, tList;
   QList<agency_fps> AgencyFPSList;
   QList<agency_mags> AgencyMagsList;

   // Handle the 'HasStation' function.
   // Arguments are: an infix expression.
   if (func == "HASSTATION") {
      // Return FALSE if there are no phase lines in the node.
      if (!node->phases.nphase) return false;
      // Convert to postfix notation.
      Infix2Postfix(args.first(), &tokenList, &strVal1);
      // For all stations, execute the expression.
      // If the expression evaluates to TRUE for
      // one of the stations, then this function
      // returns TRUE. Else it will return FALSE.
      phase = node->phases.first;
      for (int i=0;i<node->phases.nphase;i++) {
         // Work on a copy of the tokenlist.
         tList = tokenList;
         // Replace all variables in the token list
         // with actual values (numbers or strings).
         MissingVal = false;
         for (int j=0;j<tList.size()&&!MissingVal;j++) {
            if (tList.at(j).at(0) == '$') {
               // Token is a variable. Get variable's value.
               NodeGetStationProperty(phase, tList.at(j), &pValue);
               if (pValue.novalue) {
                  // No value was found for this variable. Skip to next station/phase.
                  MissingVal = true;
               } else {
                  // In token list, replace variablename with value.
                  if (pValue.valueType == 0) {
                     // This is a number value.
                     tList[j] = QString::number(pValue.number);
                  } else {
                     // This is a string value. String is made uppercase. Spaces are also
                     // removed from front/end, and string is enclosed in double quotes.
                     tList[j] = pValue.string.trimmed().toUpper().prepend("\"").append("\"");
                  }
               }
            }
         }
         // Evaluate the exression to TRUE or FALSE.
         if (!MissingVal) if (EvaluatePostfix(tList, node)) return true;
         // Move phase pointer to next phase/station.
         phase = phase->next;
      }
      return false;
   }


   // Handle the 'HasMagnitude' function.
   // Arguments are: infix expression, option.
   if (func == "HASMAGNITUDE") {
      // Convert expression to postfix notation.
      Infix2Postfix(args.at(0), &tokenList, &strVal1);
      // Get a list of all agencies and their magnitudes.
      if (args.at(1).toUpper() == "PRIMARY") NodeGetPriHypocenterMags(node, &AgencyMagsList);
      if (args.at(1).toUpper() == "ALL") NodeGetAllHypocenterMags(node, &AgencyMagsList);
      // For all agencies in AgencyMagsList, execute
      // the expression. If the expression evaluates
      // to TRUE for one of the agenciess, then this
      // function returns TRUE. Else it will return FALSE.
      for (int i=0;i<AgencyMagsList.size();i++) {
         // Work on a copy of the tokenlist.
         tList = tokenList;
         // Replace all variables in the token list
         // with actual values (numbers or strings).
         MissingVal = false;
         for (int j=0;j<tList.size()&&!MissingVal;j++) {
            if (tList.at(j).at(0) == '$') {
               // The token is a property. Create an uppercase token.
               token = tList.at(j).toUpper();
               // Get the property's value.
               pValue.valueType = 0;
               pValue.novalue = false;
               if (token == "$AGENCY") {
                   pValue.valueType = 1;
                   pValue.string = AgencyMagsList.at(i).agency;
               }
               if (token == "$MAG-W") pValue.number = AgencyMagsList.at(i).MW;
               if (token == "$MAG-L") pValue.number = AgencyMagsList.at(i).ML;
               if (token == "$MAG-N") pValue.number = AgencyMagsList.at(i).MN;
               if (token == "$MAG-C") pValue.number = AgencyMagsList.at(i).MC;
               if (token == "$MAG_B") pValue.number = AgencyMagsList.at(i).Mb;
               if (token == "$MAG-B") pValue.number = AgencyMagsList.at(i).MB;
               if (token == "$MAG_S") pValue.number = AgencyMagsList.at(i).Ms;
               if (token == "$MAG-S") pValue.number = AgencyMagsList.at(i).MS;
               if (pValue.novalue) {
                  // No value exists for this variable. Skip to next agency.
                  MissingVal = true;
               } else {
                  // In token list, replace variablename with value.
                  if (!pValue.valueType) {
                     // This is a number value.
                     tList[j] = QString::number(pValue.number);
                  } else {
                     // This is a string value. String is made uppercase. Spaces are also
                     // removed from front/end, and string is enclosed in double quotes.
                     tList[j] = AgencyMagsList[i].agency;
                     tList[j] = tList[j].trimmed().toUpper().prepend("\"").append("\"");
                  }
               }
            }
          }
          // Evaluate the expression.
          if (!MissingVal) if (EvaluatePostfix(tList, node)) return true;
      }
      return false;
   }


   // Handle the 'HasFPS' function.
   // Arguments are: an infix expression.
   if (func == "HASFPS") {
      // Get a list of all fault plane solutions
      // with their agencies and qualities.
      NodeGetAllFPS(node, &AgencyFPSList);
      if (args.size()) {
         // Function has an argument. Convert
         // the expression to postfix notation.
         Infix2Postfix(args.at(0), &tokenList, &strVal1);
         // For all agencies in AgencyMagsList, execute
         // the expression. If the expression evaluates
         // to TRUE for one of the agenciess, then this
         // function returns TRUE. Else it will return FALSE.
         for (int i=0;i<AgencyFPSList.size();i++) {
            // Work on a copy of the tokenlist.
            tList = tokenList;
            // Replace all variables in the token list
            // with actual values (numbers or strings).
            for (int j=0;j<tList.size();j++) {
               if (tList.at(j).at(0) == '$') {
                  // Token is a variable. Get variable's value.
                  token = tList.at(j).toUpper();
                  if (token == "$AGENCY") strVal1 = AgencyFPSList.at(i).agency;
                  if (token == "$QUALITY") strVal1 = AgencyFPSList.at(i).quality;
                  // In token list, replace variablename with value.
                  // Strings are enclosed in double quotes.
                  tList[j] = strVal1.prepend("\"").append("\"");
               }
             }
             // Evaluate the expression.
             if (EvaluatePostfix(tList, node)) return true;
         }
      } else {
         // Function do not have an argument. Return
         // 'true' if node has a fault plane solution.
         if (AgencyFPSList.size()) return true;
      }
      return false;
   }


   // Handle the 'InRange' function.
   // Arguments are: $number, number, number
   if (func == "INRANGE") {
      // Get the value for the $variable argument.
      // Return false if variable has no value.
      NodeGetProperty(node, args.at(0).toUpper(), &pValue);
      if (pValue.novalue) return false;
      // Get the rest of the arguments.
      fVal1 = args.at(1).toFloat(&ok);
      fVal2 = args.at(2).toFloat(&ok);
      // Execute function.
      return (pValue.number >= fVal1 && pValue.number < fVal2);
   }


   // Handle the 'Contains' function.
   // Arguments are: $string, string
   if (func == "CONTAINS") {
      // Get the value for the first argument.
      // Return false if variable has no value.
      NodeGetProperty(node, args.at(0).toUpper(), &pValue);
      if (pValue.novalue) return false;
      // Remove quotes from second agument.
      strVal1 = args.at(1); strVal1.remove(0, 1).chop(1);
      // Execute function.
      return pValue.string.contains(strVal1, Qt::CaseInsensitive);
   }


   // Handle the 'IsFelt' function.
   // Arguments are: none
   if (func == "ISFELT") {
      NodeGetProperty(node, "$NUMMACROS", &pValue);
      return pValue.number > 0;
   }


   // Handle the 'InPolygon' function.
   // Arguments are: A list of numbers.
   if (func == "INPOLYGON") {
      // Get the event location.
      QPointF EventLoc;
      NodeGetProperty(node, "$LON", &pValue); EventLoc.setX(pValue.number);
      NodeGetProperty(node, "$LAT", &pValue); EventLoc.setY(pValue.number);
      // Get the polygon coordinates.
      QPolygonF Pol; int NumVal = args.size();
      for (int i=0;i<NumVal;i+=2) Pol.append(QPointF(args[i+1].toDouble(), args[i].toDouble()));
      // Check if event is inside the polygon.
      return Pol.containsPoint(EventLoc, Qt::OddEvenFill);
   }

   // Unknown function, we should not reach this point.
   return false;
}




// ********************************************************************
// Executes a value-function and returns the result as a float.
// ********************************************************************
float ExecuteValueFunction(event_node_ *node, QString func, QStringList args)
{
   float fVal1, fVal2, fVal3, fVal4;
   struct hypocenter_ *Hypoc;

   // Handle the 'Distance' function.
   // Arguments are: A coordinate (lat,lon) in decimal degrees format.
   // Returns: Distance to epicenter in KM.
   if (func == "DISTANCE") {
      fVal1 = node->hypocenters.first->lat;
      fVal2 = node->hypocenters.first->lon;
      fVal3 = args.at(0).toFloat();
      fVal4 = args.at(1).toFloat();
      return (float)EarthDistance(fVal1, fVal2, fVal3, fVal4);
   }

   // Handle the 'WeekDay' function.
   // Arguments are: None
   // Returns: Day of week (1-7).
   if (func == "WEEKDAY") {
      QDate Date;
      Hypoc = node->hypocenters.first;
      Date.setDate(Hypoc->time.year,Hypoc->time.month,Hypoc->time.day);
      return Date.dayOfWeek();
   }

   return 0;
}




// ***********************************************
// Inspects a token and returns the token type.
// Return values are:
// 0 - Unknown token.
// 1 - A left paranthesis.
// 2 - A right paranthesis.
// 3 - An relational operator (like '<=').
// 4 - An logical operator (like 'AND').
// 5 - A variable (like $MAG).
// 6 - An integer (like -30).
// 7 - A float (like 30.2 or .45).
// 8 - A string (like '"BER"').
// 9 - A function (like 'INRANGE[]').
// ********************************************
int GetTokenType(QString token)
{
   bool ok;

   // Make sure token is uppercase.
   token = token.toUpper();

   // Check for paranthesis.
   if (token == "(") return TTLEFTPAR;
   if (token == ")") return TTRIGHTPAR;

   // Check for relational operators.
   if (token == "=") return TTRELATOPER;
   if (token == "<") return TTRELATOPER;
   if (token == ">") return TTRELATOPER;
   if (token == "<=") return TTRELATOPER;
   if (token == ">=") return TTRELATOPER;

   // Check for logical operators.
   if (token == "AND") return TTLOGICOPER;
   if (token == "OR") return TTLOGICOPER;

   // Check for variables.
   if (GetVarType(token) != "unknown") return TTVARIABLE;

   // Check for integer and decimal value.
   token.toInt(&ok); if (ok) return TTINTEGER;
   token.toDouble(&ok); if (ok) return TTFLOAT;

   // Check for string value.
   if (token.startsWith("\"") && token.endsWith("\"")) return TTSTRING;

   // Check for functions.
   if (token.startsWith("CONTAINS[") && token.endsWith("]")) return TTBFUNCTION;
   if (token.startsWith("DISTANCE[") && token.endsWith("]")) return TTVFUNCTION;
   if (token.startsWith("HASFPS[") && token.endsWith("]")) return TTBFUNCTION;
   if (token.startsWith("HASMAGNITUDE[") && token.endsWith("]")) return TTBFUNCTION;
   if (token.startsWith("HASSTATION[") && token.endsWith("]")) return TTBFUNCTION;
   if (token.startsWith("INPOLYGON[") && token.endsWith("]")) return TTBFUNCTION;
   if (token.startsWith("INRANGE[") && token.endsWith("]")) return TTBFUNCTION;
   if (token.startsWith("ISFELT[") && token.endsWith("]")) return TTBFUNCTION;
   if (token.startsWith("WEEKDAY[") && token.endsWith("]")) return TTVFUNCTION;

   return TTUNKNOWN;
}




// **************************************
// Returns the type of a variable.
// **************************************
QString GetVarType(QString Variable)
{
   Variable = Variable.toUpper();
   if (Variable == "$ACTION") return "string";
   if (Variable == "$AGENCY") return "string";
   if (Variable == "$AMPL") return "float";
   if (Variable == "$AMPLPERIOD") return "float";
   if (Variable == "$BACKAZIMUT") return "float";
   if (Variable == "$COMMENTS") return "string";
   if (Variable == "$COMP") return "string";
   if (Variable == "$CORNFREQ") return "float";
   if (Variable == "$DATE") return "string";
   if (Variable == "$DEPTH") return "float";
   if (Variable == "$DEPTHERR") return "float";
   if (Variable == "$DISTIND") return "string";
   if (Variable == "$EPIDIST") return "float";
   if (Variable == "$EVENTIND") return "string";
   if (Variable == "$GAP") return "float";
   if (Variable == "$HOUR") return "integer";
   if (Variable == "$LAT") return "float";
   if (Variable == "$LATERR") return "float";
   if (Variable == "$LOCALITY") return "string";
   if (Variable == "$LON") return "float";
   if (Variable == "$LONERR") return "float";
   if (Variable == "$MAG") return "float";
   if (Variable == "$MAG-W") return "float";
   if (Variable == "$MAG-L") return "float";
   if (Variable == "$MAG-C") return "float";
   if (Variable == "$MAG_B") return "float";
   if (Variable == "$MAG-B") return "float";
   if (Variable == "$MAG_S") return "float";
   if (Variable == "$MAG-S") return "float";
   if (Variable == "$MODEL") return "string";
   if (Variable == "$NUMFPS") return "integer";
   if (Variable == "$NUMPOL") return "integer";
   if (Variable == "$NUMSTAT") return "integer";
   if (Variable == "$PHASENAME") return "string";
   if (Variable == "$QUALITY") return "string";
   if (Variable == "$RMS") return "float";
   if (Variable == "$STACODE") return "string";
   if (Variable == "$STRDROP") return "float";
   if (Variable == "$TRVLTMERES") return "float";

   return "unknown";
}




// **************************************************************
// Returns all arguments to a function in a QStringList variable.
// **************************************************************
void GetFunctionArgs(QString function, QStringList *args)
{
   // Remove function's name and brackets.
   function.chop(1); function.remove(0, function.indexOf("[", 0) + 1);

   // Return all arguments seperated by a comma.
   *args = function.split(",", QString::SkipEmptyParts);
}




// **************************************
// Checks if a token is an operator.
// **************************************
bool isOperator(QString token)
{
   int type = GetTokenType(token);
   if (type == TTRELATOPER) return true;
   if (type == TTLOGICOPER) return true;
   return false;
}




// ********************************
// Checks if a token is an operand.
// ********************************
bool isOperand(QString token)
{
   if (GetTokenType(token) >= TTVARIABLE) return true;
   return false;
}




// ******************************************************************
// Checks if a token is a valid property for the HasStation function.
// ******************************************************************
bool isValidHasStationProperty(QString Variable)
{
   Variable = Variable.toUpper();
   if (Variable == "$AMPL") return true;
   if (Variable == "$AMPLPERIOD") return true;
   if (Variable == "$BACKAZIMUT") return true;
   if (Variable == "$COMP") return true;
   if (Variable == "$CORNFREQ") return true;
   if (Variable == "$EPIDIST") return true;
   if (Variable == "$PHASENAME") return true;
   if (Variable == "$STACODE") return true;
   if (Variable == "$STRDROP") return true;
   if (Variable == "$TRVLTMERES") return true;

   return false;
}




// ********************************************************************
// Checks if a token is a valid property for the HasMagnitude function.
// ********************************************************************
bool isValidHasMagnitudeProperty(QString Variable)
{
   if (Variable.toUpper() == "$AGENCY") return true;
   if (isReservedHasMagnitudeProperty(Variable)) return true;
   return false;
}




// ***********************************************************************
// Checks if a token is a reserved property for the HasMagnitude function.
// ***********************************************************************
bool isReservedHasMagnitudeProperty(QString Variable)
{
   Variable = Variable.toUpper();
   if (Variable == "$MAG-W") return true;
   if (Variable == "$MAG-L") return true;
   if (Variable == "$MAG-C") return true;
   if (Variable == "$MAG_B") return true;
   if (Variable == "$MAG-B") return true;
   if (Variable == "$MAG_S") return true;
   if (Variable == "$MAG-S") return true;
   return false;
}




// ********************************************************************
// Checks if a token is a valid property for the HasFPS function.
// ********************************************************************
bool isValidHasFPSProperty(QString Variable)
{
   if (Variable.toUpper() == "$AGENCY") return true;
   if (isReservedHasFPSProperty(Variable)) return true;
   return false;
}




// ********************************************************************
// Checks if a token is a reserved property for the HasFPS function.
// ********************************************************************
bool isReservedHasFPSProperty(QString Variable)
{
   if (Variable.toUpper() == "$QUALITY") return true;
   return false;
}





// **********************************************
// Compares the presedence of two operators.
// Returns 'true' if oper1 is greater then oper2.
// **********************************************
bool OperCmp(QString oper1, QString oper2)
{
   int pres1 = 0, pres2 = 0;

   if (oper1 == "(") pres1 = 0;
   if (oper1 == ")") pres1 = 0;
   if (oper1.toUpper() == "OR") pres1 = 1;
   if (oper1.toUpper() == "AND") pres1 = 2;
   if (oper1 == "=") pres1 = 3;
   if (oper1 == "<") pres1 = 4;
   if (oper1 == ">") pres1 = 4;
   if (oper1 == "<=") pres1 = 4;
   if (oper1 == ">=") pres1 = 4;

   if (oper2 == "(") pres2 = 0;
   if (oper2 == ")") pres2 = 0;
   if (oper2.toUpper() == "OR") pres2 = 1;
   if (oper2.toUpper() == "AND") pres2 = 2;
   if (oper2 == "=") pres2 = 3;
   if (oper2 == "<") pres2 = 4;
   if (oper2 == ">") pres2 = 4;
   if (oper2 == "<=") pres2 = 4;
   if (oper2 == ">=") pres2 = 4;

   return (pres1 > pres2);
}
