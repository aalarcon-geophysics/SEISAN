#include <QApplication>
#include <QEvent>
#include <QKeyEvent>
#include "logviewfilter.h"


// ********************************************************************
// Constructor function for the class.
// ********************************************************************
logviewfilter::logviewfilter(QObject *parent) : QObject(parent)
{

}




// ********************************************************************
// Event filter for the Log View. Handles keyboard inputs.
// ********************************************************************
bool logviewfilter::eventFilter(QObject* object, QEvent* event)
{
   Q_UNUSED(object)

   if (event->type()==QEvent::KeyPress) {
      // Transform QEvent into QKeyEvent.
      QKeyEvent* pKeyEvent=static_cast<QKeyEvent*>(event);

      // Handle pressed key.
      switch(pKeyEvent->key()) {
         case Qt::Key_T:
            if (QApplication::keyboardModifiers() & Qt::ControlModifier) {
               emit SetTimeInterval();
               return true;
            }
      }
   }

   return false;
}
