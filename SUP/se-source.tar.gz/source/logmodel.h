#ifndef LOGMODEL_H
#define LOGMODEL_H

#include <QListView>
#include <QAbstractListModel>

class logmodel : public QAbstractListModel
{
   Q_OBJECT

public:
   enum msg_type { info, warning, error };
   explicit logmodel(QObject *parent = 0);
   int rowCount(const QModelIndex &parent = QModelIndex()) const;
   void SetView(QListView*);
   QVariant data(const QModelIndex &index, int role = Qt::DisplayRole) const;
   QString GetMsgFilename(int);
   int GetNumberOfLines();

signals:
   void show_log_view();

public slots:
   void WriteLog(logmodel::msg_type, QString, QString, bool = false);
   void WriteLog(logmodel::msg_type, QString, bool = false);
   void WriteLog2File();
   void ShowLogView();
   void ClearLogFile();
   void ClearLog();

private:
   QStringList MsgList;
   QList<int> MsgTypeList;
   QListView *ModelView;
   QStringList MsgFileList;
   int MessagesInModel;
};

#endif // LOGMODEL_H
