#include <QApplication>
#include "mainwindow.h"
#include "library.h"

int main(int argc, char *argv[])
{
   // The QApplication object must be created before any other
   // objects related to the user interface are created.
   QApplication a(argc, argv, true);

   // Set locale.
   #ifdef Q_OS_LINUX
   QLocale::setDefault(QLocale(QLocale::English, QLocale::UnitedStates));
   #endif

   // Set style sheet for taskbar.
   a.setStyleSheet(QString("QStatusBar::item { border: 0px solid black } "));

   // Set application font size.
   QFont AppFont = a.font();
   AppFont.setPointSize(8);
   #ifdef Q_OS_LINUX
   AppFont.setStretch(96);
   #endif
   a.setFont(AppFont);

   // Create the main window class.
   MainWindow w;

   // Show the main window.
   w.show();

   // Enter the main event loop and waits until exit() is called.
   return a.exec();
}
