/*
 * 2014-06-20 Peter Voss: fixed for qcp 1.2.1

#include <QDebug>
*/
#include "driftofhypocentersdlg.h"
#include "ui_driftofhypocentersdlg.h"
#include "mainwindow.h"
#include <cstdlib>
#include <QString>

#include <iostream>
#include "qcustomplot.h"

DriftOfHypocentersDlg::DriftOfHypocentersDlg(db *database, QWidget *parent) : QDialog(parent), ui(new Ui::DriftOfHypocentersDlg) {

    ui->setupUi(this);

    ui->customPlot->plotLayout()->insertRow(0); // inserts an empty row above the default axis rect
    ui->customPlot->plotLayout()->addElement(0, 0, new QCPPlotTitle(ui->customPlot, "SEISAN: Tempo-spatial hypocenter distribution"));
    ui->radioButton_PDF->setChecked(true);
    ui->spinBox_X_Size->setRange(1.0,8000.0);
    ui->spinBox_X_Size->setValue(700.0);
    ui->spinBox_X_Size->setSingleStep(1.0);
    ui->spinBox_Y_Size->setRange(1.0,8000.0);
    ui->spinBox_Y_Size->setValue(700.0);
    ui->spinBox_Y_Size->setSingleStep(1.0);

    DataBase=database;

    // initial plot
    DriftOfHypocentersDlg_plot_lat();

    connect( ui->pushButton_done, SIGNAL( clicked() ), this, SLOT( close() ) );
    connect( ui->pushButton_Print, SIGNAL( clicked() ), this, SLOT( outputPrint() ) );

    // plot when "Latitude" is clicked
    connect( ui->pushButton_plot_lat, SIGNAL( clicked() ), this, SLOT( DriftOfHypocentersDlg_plot_lat() ) );

    // plot when "Latitude" is clicked
    connect( ui->pushButton_plot_long, SIGNAL( clicked() ), this, SLOT( DriftOfHypocentersDlg_plot_long() ) );

    // plot when "Depth" is clicked
    connect( ui->pushButton_plot_depth, SIGNAL( clicked() ), this, SLOT( DriftOfHypocentersDlg_plot_depth() ) );

}

DriftOfHypocentersDlg::~DriftOfHypocentersDlg() {
    delete ui;
}

void DriftOfHypocentersDlg::outputPrint() {
    int xsize = ui->spinBox_X_Size->value();
    int ysize = ui->spinBox_Y_Size->value();
    if (ui->radioButton_PDF->isChecked())
        ui->customPlot->savePdf("se-DriftOfHypocentersDlg.pdf",0,xsize,ysize);
    if (ui->radioButton_PS->isChecked())
        ui->customPlot->savePdf("se-DriftOfHypocentersDlg.ps",0,xsize,ysize);
    if (ui->radioButton_PNG->isChecked())
        ui->customPlot->savePng("se-DriftOfHypocentersDlg.png",xsize,ysize,1,-1);
    if (ui->radioButton_JPG->isChecked())
        ui->customPlot->saveJpg("se-DriftOfHypocentersDlg.jpg",xsize,ysize,1,-1);
    if (ui->radioButton_BMP->isChecked())
        ui->customPlot->saveBmp("se-DriftOfHypocentersDlg.bmp",xsize,ysize,1);
}

void DriftOfHypocentersDlg::DriftOfHypocentersDlg_plot_lat() {

    int NumEvents = DataBase->NumEvents();
    event_node_ *Node;

    QVector<double> yval(NumEvents);
    QVector<double> xval(NumEvents);

    double xmin=999999.9, xmax=-999999.9;
    double ymin=999999.9, ymax=-999999.9;

    for (int i=0; i<NumEvents; ++i){
        Node = DataBase->EventByIndex(i);
        xval[i]=(double)Node->hypocenters.first->time.year;
        xval[i]=xval[i]+1.0/12*(double)Node->hypocenters.first->time.month;
        xval[i]=xval[i]+1.0/365*(double)Node->hypocenters.first->time.day;
        xval[i]=xval[i]+1.0/(24*365)*(double)Node->hypocenters.first->time.hour;
        xval[i]=xval[i]+1.0/(60*24*365)*(double)Node->hypocenters.first->time.minute;
        xval[i]=xval[i]+1.0/(3600*24*365)*(double)Node->hypocenters.first->time.second;
        if ( xval[i] > xmax ) xmax = xval[i];
        if ( xval[i] < xmin ) xmin = xval[i];
        yval[i]=(double)Node->hypocenters.first->lat;
        if ( yval[i] > ymax ) ymax = yval[i];
        if ( yval[i] < ymin ) ymin = yval[i];
    }

    ui->customPlot->clearPlottables();

    QPen pen;
    pen.setColor(QColor(255,0,0));
    ui->customPlot->addGraph();
    ui->customPlot->graph()->setPen(pen);
    ui->customPlot->graph()->setData(xval, yval);

    ui->customPlot->graph()->setLineStyle(QCPGraph::lsNone);
    ui->customPlot->graph()->setScatterStyle(QCPScatterStyle(QCPScatterStyle::ssDisc, Qt::red, Qt::white, 5));

    // labels:
    ui->customPlot->plotLayout()->remove(ui->customPlot->plotLayout()->element(0,0));
    ui->customPlot->plotLayout()->addElement(0, 0, new QCPPlotTitle(ui->customPlot, "SEISAN: Epicenter latitudes over time"));
    ui->customPlot->xAxis->setLabel("Year");
    ui->customPlot->yAxis->setLabel("Latitude [degree]");

    double dum = (xmax-xmin)/40.;
    ui->customPlot->xAxis->setRange(xmin-dum, xmax+dum);
    dum = (ymax-ymin)/40.;
    ui->customPlot->yAxis->setRange(ymin-dum, ymax+dum);
    ui->customPlot->setInteractions(QCP::iRangeDrag | QCP::iRangeZoom);
    ui->customPlot->replot();

}



void DriftOfHypocentersDlg::DriftOfHypocentersDlg_plot_long() {

    int NumEvents = DataBase->NumEvents();
    event_node_ *Node;

    QVector<double> yval(NumEvents);
    QVector<double> xval(NumEvents);

    double xmin=999999.9, xmax=-999999.9;
    double ymin=999999.9, ymax=-999999.9;

    for (int i=0; i<NumEvents; ++i){
        Node = DataBase->EventByIndex(i);
        xval[i]=(double)Node->hypocenters.first->time.year;
        xval[i]=xval[i]+1.0/12*(double)Node->hypocenters.first->time.month;
        xval[i]=xval[i]+1.0/365*(double)Node->hypocenters.first->time.day;
        xval[i]=xval[i]+1.0/(24*365)*(double)Node->hypocenters.first->time.hour;
        xval[i]=xval[i]+1.0/(60*24*365)*(double)Node->hypocenters.first->time.minute;
        xval[i]=xval[i]+1.0/(3600*24*365)*(double)Node->hypocenters.first->time.second;
        if ( xval[i] > xmax ) xmax = xval[i];
        if ( xval[i] < xmin ) xmin = xval[i];
        yval[i]=(double)Node->hypocenters.first->lon;
        if ( yval[i] > ymax ) ymax = yval[i];
        if ( yval[i] < ymin ) ymin = yval[i];
    }

    ui->customPlot->clearPlottables();

    QPen pen;
    pen.setColor(QColor(255,0,0));
    ui->customPlot->addGraph();
    ui->customPlot->graph()->setPen(pen);
    ui->customPlot->graph()->setData(yval, xval);

    ui->customPlot->graph()->setLineStyle(QCPGraph::lsNone);
    ui->customPlot->graph()->setScatterStyle(QCPScatterStyle(QCPScatterStyle::ssDisc, Qt::red, Qt::white, 5));

    // labels:
    ui->customPlot->plotLayout()->remove(ui->customPlot->plotLayout()->element(0,0));
    ui->customPlot->plotLayout()->addElement(0, 0, new QCPPlotTitle(ui->customPlot, "SEISAN: Epicenter longitudes over time"));
    ui->customPlot->yAxis->setLabel("Year");
    ui->customPlot->xAxis->setLabel("Longitudes [degree]");

    double dum = (xmax-xmin)/40.;
    ui->customPlot->yAxis->setRange(xmin-dum, xmax+dum);
    dum = (ymax-ymin)/40.;
    ui->customPlot->xAxis->setRange(ymin-dum, ymax+dum);
    ui->customPlot->setInteractions(QCP::iRangeDrag | QCP::iRangeZoom);
    ui->customPlot->replot();
}




void DriftOfHypocentersDlg::DriftOfHypocentersDlg_plot_depth() {

    int NumEvents = DataBase->NumEvents();
    event_node_ *Node;

    QVector<double> yval(NumEvents);
    QVector<double> xval(NumEvents);

    double xmin=999999.9, xmax=-999999.9;
    double ymin=999999.9, ymax=-999999.9;

    for (int i=0; i<NumEvents; ++i){
        Node = DataBase->EventByIndex(i);
        xval[i]=(double)Node->hypocenters.first->time.year;
        xval[i]=xval[i]+1.0/12*(double)Node->hypocenters.first->time.month;
        xval[i]=xval[i]+1.0/365*(double)Node->hypocenters.first->time.day;
        xval[i]=xval[i]+1.0/(24*365)*(double)Node->hypocenters.first->time.hour;
        xval[i]=xval[i]+1.0/(60*24*365)*(double)Node->hypocenters.first->time.minute;
        xval[i]=xval[i]+1.0/(3600*24*365)*(double)Node->hypocenters.first->time.second;
        if ( xval[i] > xmax ) xmax = xval[i];
        if ( xval[i] < xmin ) xmin = xval[i];
        yval[i]=-1.0*(double)Node->hypocenters.first->depth;
        if ( yval[i] > ymax ) ymax = yval[i];
        if ( yval[i] < ymin ) ymin = yval[i];
    }

    ui->customPlot->clearPlottables();

    QPen pen;
    pen.setColor(QColor(255,0,0));
    ui->customPlot->addGraph();
    ui->customPlot->graph()->setPen(pen);
    ui->customPlot->graph()->setData(xval, yval);

    ui->customPlot->graph()->setLineStyle(QCPGraph::lsNone);
    ui->customPlot->graph()->setScatterStyle(QCPScatterStyle(QCPScatterStyle::ssDisc, Qt::red, Qt::white, 5));


    // labels:
    ui->customPlot->plotLayout()->remove(ui->customPlot->plotLayout()->element(0,0));
    ui->customPlot->plotLayout()->addElement(0, 0, new QCPPlotTitle(ui->customPlot, "SEISAN: Hypocenter depth over time"));
    ui->customPlot->xAxis->setLabel("Year");
    ui->customPlot->yAxis->setLabel("Depth [km]");

    double dum = (xmax-xmin)/40.;
    ui->customPlot->xAxis->setRange(xmin-dum, xmax+dum);
    dum = (ymax-ymin)/40.;
    ui->customPlot->yAxis->setRange(ymin-dum, ymax+dum);
    ui->customPlot->setInteractions(QCP::iRangeDrag | QCP::iRangeZoom);
    ui->customPlot->replot();

}
