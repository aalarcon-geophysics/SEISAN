/*
 * 2014-06-20 Peter Voss: fixed for qcp 1.2.1

#include <QDebug>
*/
#include "magvsmagdlg.h"
#include "ui_magvsmagdlg.h"
#include "mainwindow.h"
#include <cstdlib>
#include <QString>

#include <iostream>
#include "qcustomplot.h"

MagVsMagDlg::MagVsMagDlg(db *database, QWidget *parent) : QDialog(parent), ui(new Ui::MagVsMagDlg) {

    ui->setupUi(this);

    ui->customPlot->plotLayout()->insertRow(0); // inserts an empty row above the default axis rect
    ui->customPlot->plotLayout()->addElement(0, 0, new QCPPlotTitle(ui->customPlot, "SEISAN: Magnitude vs magnitude"));


    ui->radioButton_MW->setChecked(true);
    ui->radioButton_ML_3->setChecked(true);
    ui->radioButton_PDF->setChecked(true);
    ui->spinBox_X_Size->setRange(1.0,8000.0);
    ui->spinBox_X_Size->setValue(700.0);
    ui->spinBox_X_Size->setSingleStep(1.0);
    ui->spinBox_Y_Size->setRange(1.0,8000.0);
    ui->spinBox_Y_Size->setValue(700.0);
    ui->spinBox_Y_Size->setSingleStep(1.0);

    DataBase=database;

    // initial plot
    MagVsMagDlg_plot();

    connect( ui->pushButton_done, SIGNAL( clicked() ), this, SLOT( close() ) );
    connect( ui->pushButton_Print, SIGNAL( clicked() ), this, SLOT( outputPrint() ) );

    // plot when "Plot" is clicked
    connect( ui->pushButton_plot, SIGNAL( clicked() ), this, SLOT( MagVsMagDlg_plot() ) );
}

MagVsMagDlg::~MagVsMagDlg() {
    delete ui;
}

void MagVsMagDlg::outputPrint() {
    int xsize = ui->spinBox_X_Size->value();
    int ysize = ui->spinBox_Y_Size->value();
    if (ui->radioButton_PDF->isChecked())
        ui->customPlot->savePdf("se-MagVsMagDlg.pdf",0,xsize,ysize);
    if (ui->radioButton_PS->isChecked())
        ui->customPlot->savePdf("se-MagVsMagDlg.ps",0,xsize,ysize);
    if (ui->radioButton_PNG->isChecked())
        ui->customPlot->savePng("se-MagVsMagDlg.png",xsize,ysize,1,-1);
    if (ui->radioButton_JPG->isChecked())
        ui->customPlot->saveJpg("se-MagVsMagDlg.jpg",xsize,ysize,1,-1);
    if (ui->radioButton_BMP->isChecked())
        ui->customPlot->saveBmp("se-MagVsMagDlg.bmp",xsize,ysize,1);
}



void MagVsMagDlg::MagVsMagDlg_plot() {

    // magnitude type for the 1st axis:
    int ShowM = 0, ShowML=0, ShowMW=0, ShowMC=0, ShowMb=0, ShowMB=0, ShowMs=0, ShowMS=0;
    if (ui->radioButton_M->isChecked())  ShowM  = 1;
    if (ui->radioButton_ML->isChecked()) ShowML = 1;
    if (ui->radioButton_MW->isChecked()) ShowMW = 1;
    if (ui->radioButton_MC->isChecked()) ShowMC = 1;
    if (ui->radioButton_Mb->isChecked()) ShowMb = 1;
    if (ui->radioButton_MB->isChecked()) ShowMB = 1;
    if (ui->radioButton_Ms->isChecked()) ShowMs = 1;
    if (ui->radioButton_MS->isChecked()) ShowMS = 1;

    // magnitude type for the 2nd axis:
    int Show2M = 0, Show2ML=0, Show2MW=0, Show2MC=0, Show2Mb=0, Show2MB=0, Show2Ms=0, Show2MS=0;
    if (ui->radioButton_M_3->isChecked())  Show2M  = 1;
    if (ui->radioButton_ML_3->isChecked()) Show2ML = 1;
    if (ui->radioButton_MW_3->isChecked()) Show2MW = 1;
    if (ui->radioButton_MC_3->isChecked()) Show2MC = 1;
    if (ui->radioButton_Mb_3->isChecked()) Show2Mb = 1;
    if (ui->radioButton_MB_3->isChecked()) Show2MB = 1;
    if (ui->radioButton_Ms_3->isChecked()) Show2Ms = 1;
    if (ui->radioButton_MS_3->isChecked()) Show2MS = 1;

    int NumEvents = DataBase->NumEvents();
    event_node_ *Node;

    QVector<double> xall(NumEvents);
    QVector<double> yall(NumEvents);

    float Xmagnitude, Ymagnitude;
    float MinMag=999.9, MaxMag=-999.9;
    int UseEvents=0;

    for (int i=0; i<NumEvents; i++){
        Xmagnitude=-999.9;
        Ymagnitude=-999.9;
        Node = DataBase->EventByIndex(i);

        if (ShowM && Node->hypocenters.nmag>0)
            Xmagnitude = Node->hypocenters.mag_all[0].mag;
        if (ShowML && Node->hypocenters.first->magnitudes.ML.nmag>0)
            Xmagnitude = Node->hypocenters.first->magnitudes.ML.mag[0];
        if (ShowMW && Node->hypocenters.first->magnitudes.MW.nmag>0)
            Xmagnitude = Node->hypocenters.first->magnitudes.MW.mag[0];
        if (ShowMC && Node->hypocenters.first->magnitudes.MC.nmag>0)
            Xmagnitude = Node->hypocenters.first->magnitudes.MC.mag[0];
        if (ShowMb && Node->hypocenters.first->magnitudes.Mb.nmag>0)
            Xmagnitude = Node->hypocenters.first->magnitudes.Mb.mag[0];
        if (ShowMB && Node->hypocenters.first->magnitudes.MB.nmag>0)
            Xmagnitude = Node->hypocenters.first->magnitudes.MB.mag[0];
        if (ShowMs && Node->hypocenters.first->magnitudes.Ms.nmag>0)
            Xmagnitude = Node->hypocenters.first->magnitudes.Ms.mag[0];
        if (ShowMS && Node->hypocenters.first->magnitudes.MS.nmag>0)
            Xmagnitude = Node->hypocenters.first->magnitudes.MS.mag[0];

        if (Show2M && Node->hypocenters.nmag>0)
            Ymagnitude = Node->hypocenters.mag_all[0].mag;
        if (Show2ML && Node->hypocenters.first->magnitudes.ML.nmag>0)
            Ymagnitude = Node->hypocenters.first->magnitudes.ML.mag[0];
        if (Show2MW && Node->hypocenters.first->magnitudes.MW.nmag>0)
            Ymagnitude = Node->hypocenters.first->magnitudes.MW.mag[0];
        if (Show2MC && Node->hypocenters.first->magnitudes.MC.nmag>0)
            Ymagnitude = Node->hypocenters.first->magnitudes.MC.mag[0];
        if (Show2Mb && Node->hypocenters.first->magnitudes.Mb.nmag>0)
            Ymagnitude = Node->hypocenters.first->magnitudes.Mb.mag[0];
        if (Show2MB && Node->hypocenters.first->magnitudes.MB.nmag>0)
            Ymagnitude = Node->hypocenters.first->magnitudes.MB.mag[0];
        if (Show2Ms && Node->hypocenters.first->magnitudes.Ms.nmag>0)
            Ymagnitude = Node->hypocenters.first->magnitudes.Ms.mag[0];
        if (Show2MS && Node->hypocenters.first->magnitudes.MS.nmag>0)
            Ymagnitude = Node->hypocenters.first->magnitudes.MS.mag[0];

        if (Xmagnitude > -999.0 && Ymagnitude > -999.0){
            xall[UseEvents]=Xmagnitude;
            yall[UseEvents]=Ymagnitude;
            ++UseEvents;
            // set limits for plot
            if (Xmagnitude<MinMag)
                MinMag=Xmagnitude;
            if (Xmagnitude>MaxMag)
                MaxMag=Xmagnitude;
            if (Ymagnitude<MinMag)
                MinMag=Ymagnitude;
            if (Ymagnitude>MaxMag)
                MaxMag=Ymagnitude;
        }
    }

    if (MaxMag < -99.9)
        MaxMag = 9.7;
    if (MinMag > 99.9)
        MinMag = -9.7;

    xall.resize(UseEvents);
    yall.resize(UseEvents);

    double zMax=0;
    double dzMax=0;
    QVector<double> zall(UseEvents);
    int count1=0;
    QVector<double> x1(UseEvents);
    QVector<double> y1(UseEvents);
    int count2=0;
    QVector<double> x2(UseEvents);
    QVector<double> y2(UseEvents);
    int count3=0;
    QVector<double> x3(UseEvents);
    QVector<double> y3(UseEvents);
    int count4=0;
    QVector<double> x4(UseEvents);
    QVector<double> y4(UseEvents);
    int count5=0;
    QVector<double> x5(UseEvents);
    QVector<double> y5(UseEvents);
    if (UseEvents>0){
        //set all to zero:
        for (int i=0; i<UseEvents; i++)
            zall[i]=1.0;
        // count
        for (int i=0; i<UseEvents; i++){
            for (int j=i+1; j<UseEvents; j++){
                if(xall[i]==xall[j] && yall[i]==yall[j] && zall[j]>0.0){
                    ++zall[i];
                    zall[j]=-1.0;
                }
            }
        }

        // find zMax
        for (int i=0; i<UseEvents; i++)
            if(zall[i]>zMax)
                zMax=zall[i];

        // define 5 intervals
        dzMax=log10(zMax)/5.0;
        if (zMax<7)
            dzMax=0.0;
        count1=0;
        for (int i=0; i<UseEvents; i++){
            if(zall[i]>0 && zall[i]<=(int)(pow(10,dzMax))){
                x1[count1]=xall[i];
                y1[count1]=yall[i];
                ++count1;
            }
        }
        x1.resize(count1);
        y1.resize(count1);
        count2=0;
        for (int i=0; i<UseEvents; i++){
            if(zall[i]>(int)(pow(10,dzMax)) && zall[i]<=(int)(pow(10,dzMax*2))){
                x2[count2]=xall[i];
                y2[count2]=yall[i];
                ++count2;
            }
        }
        x2.resize(count2);
        y2.resize(count2);
        //next
        count3=0;
        for (int i=0; i<UseEvents; i++){
            if(zall[i]>(int)(pow(10,dzMax*2)) && zall[i]<=(int)(pow(10,dzMax*3))){
                x3[count3]=xall[i];
                y3[count3]=yall[i];
                ++count3;
            }
        }
        x3.resize(count3);
        y3.resize(count3);
        //next
        count4=0;
        for (int i=0; i<UseEvents; i++){
            if(zall[i]>(int)(pow(10,dzMax*3)) && zall[i]<=(int)(pow(10,dzMax*4))){
                x4[count4]=xall[i];
                y4[count4]=yall[i];
                ++count4;
            }
        }
        x4.resize(count4);
        y4.resize(count4);
        //next
        count5=0;
        for (int i=0; i<UseEvents; i++){
            if(zall[i]>(int)(pow(10,dzMax*4)) && zall[i]<=(int)(zMax)){
                x5[count5]=xall[i];
                y5[count5]=yall[i];
                ++count5;
            }
        }
        x5.resize(count5);
        y5.resize(count5);
    }
    //qDebug() << "Maxcount:"<<Maxcount<<", UseEvents:"<<UseEvents<<", zMax:"<<zMax;
    /*for (int i=0; i<count1; i++){
        qDebug() << "x1"<<x1[i]<<"y1"<<y1[i];
    }*/

    ui->customPlot->clearPlottables();

    // add reference graph
    QVector<double> yValue(90);
    QVector<double> xValue(90);
    for (int i=0; i<90; i++){
        xValue[i]=(double)i-10.0;
        yValue[i]=(double)i-10.0;
    }
    QPen pen;
    pen.setColor(QColor(0,0,255));
    ui->customPlot->addGraph();
    ui->customPlot->graph()->setPen(pen);
    ui->customPlot->graph()->setData(xValue, yValue);
    ui->customPlot->graph()->setLineStyle(QCPGraph::lsLine);
    ui->customPlot->graph()->removeFromLegend();

    pen.setColor(QColor(255,0,0));
    ui->customPlot->addGraph();
    ui->customPlot->graph()->setPen(pen);
    ui->customPlot->graph()->setData(xall, yall);
    ui->customPlot->graph()->setLineStyle(QCPGraph::lsNone);
    //ui->customPlot->graph()->setScatterStyle(QCPScatterStyle::ssDisc);
    //ui->customPlot->graph()->setScatterSize(5);
    ui->customPlot->graph()->setScatterStyle(QCPScatterStyle(QCPScatterStyle::ssDisc, Qt::blue, Qt::white, 5));
    ui->customPlot->graph()->removeFromLegend();


    //checkBox_show_count
    Qt::CheckState ShowCount;
    ShowCount = ui->checkBox_show_count->checkState();

    if (ShowCount == Qt::Checked ){
    pen.setColor(QColor(0,0,255));
    ui->customPlot->addGraph();
    ui->customPlot->graph()->setPen(pen);
    ui->customPlot->graph()->setData(x1, y1);
    ui->customPlot->graph()->setName(QString("Count [1, %1]").arg((int)(pow(10,dzMax))));
    ui->customPlot->graph()->setLineStyle(QCPGraph::lsNone);
    //ui->customPlot->graph()->setScatterStyle(QCPScatterStyle::ssDisc);
    //ui->customPlot->graph()->setScatterSize(5);
    ui->customPlot->graph()->setScatterStyle(QCPScatterStyle(QCPScatterStyle::ssDisc, Qt::blue, Qt::white, 5));

    pen.setColor(QColor(0,255,255));
    ui->customPlot->addGraph();
    ui->customPlot->graph()->setPen(pen);
    ui->customPlot->graph()->setData(x2, y2);
    ui->customPlot->graph()->setName(QString("Count [%1, %2]").arg(1+(int)(pow(10,dzMax))).arg((int)(pow(10,dzMax*2))));
    ui->customPlot->graph()->setLineStyle(QCPGraph::lsNone);
    //ui->customPlot->graph()->setScatterStyle(QCPScatterStyle::ssDisc);
    //ui->customPlot->graph()->setScatterSize(5);
    ui->customPlot->graph()->setScatterStyle(QCPScatterStyle(QCPScatterStyle::ssDisc, QPen(QPen(QColor(0, 255, 255))), Qt::white, 5));

    pen.setColor(QColor(255,255,0));
    ui->customPlot->addGraph();
    ui->customPlot->graph()->setPen(pen);
    ui->customPlot->graph()->setData(x3, y3);
    ui->customPlot->graph()->setName(QString("Count [%1, %2]").arg(1+(int)(pow(10,dzMax*2))).arg((int)(pow(10,dzMax*3))));
    ui->customPlot->graph()->setLineStyle(QCPGraph::lsNone);
    //ui->customPlot->graph()->setScatterStyle(QCPScatterStyle::ssDisc);
    //ui->customPlot->graph()->setScatterSize(5);
    //ui->customPlot->graph()->setScatterStyle(QCPScatterStyle(QCPScatterStyle::ssDisc, Qt::blue, Qt::white, 5));
    ui->customPlot->graph()->setScatterStyle(QCPScatterStyle(QCPScatterStyle::ssDisc, QPen(QPen(QColor(255, 255, 0))), QBrush(Qt::white), 5));

    pen.setColor(QColor(255,165,0));
    ui->customPlot->addGraph();
    ui->customPlot->graph()->setPen(pen);
    ui->customPlot->graph()->setData(x4, y4);
    ui->customPlot->graph()->setName(QString("Count [%1, %2]").arg(1+(int)(pow(10,dzMax*3))).arg((int)(pow(10,dzMax*4))));
    ui->customPlot->graph()->setLineStyle(QCPGraph::lsNone);
    //ui->customPlot->graph()->setScatterStyle(QCPScatterStyle::ssDisc);
    //ui->customPlot->graph()->setScatterSize(5);
    ui->customPlot->graph()->setScatterStyle(QCPScatterStyle(QCPScatterStyle::ssDisc, QPen(QPen(QColor(255,165, 0))), Qt::white, 5));
    //ui->customPlot->graph()->setScatterStyle(QCPScatterStyle(QCPScatterStyle::ssDisc, QPen(Qt::black, 1.5), QBrush(Qt::white), 9));
    //graph1->setPen(QPen(QColor(120, 120, 120), 2));

    pen.setColor(QColor(255,0,0));
    ui->customPlot->addGraph();
    ui->customPlot->graph()->setPen(pen);
    ui->customPlot->graph()->setData(x5, y5);
    ui->customPlot->graph()->setName(QString("Count [%1, %2]").arg(1+(int)(pow(10,dzMax*4))).arg(zMax));
    ui->customPlot->graph()->setLineStyle(QCPGraph::lsNone);
    //ui->customPlot->graph()->setScatterStyle(QCPScatterStyle::ssDisc);
    //ui->customPlot->graph()->setScatterSize(5);
    ui->customPlot->graph()->setScatterStyle(QCPScatterStyle(QCPScatterStyle::ssDisc, Qt::red, Qt::white, 5));


    }

    // labels:
    //ui->customPlot->setTitle("Magnitude vs magnitude");
    //ui->customPlot->plotLayout()->insertRow(0); // inserts an empty row above the default axis rect
    //ui->customPlot->plotLayout()->addElement(0, 0, new QCPPlotTitle(ui->customPlot, "SEISAN: Magnitude vs magnitude"));

    if ( ShowM ) ui->customPlot->xAxis->setLabel("M");
    if ( ShowMW ) ui->customPlot->xAxis->setLabel("MW");
    if ( ShowML ) ui->customPlot->xAxis->setLabel("ML");
    if ( ShowMC ) ui->customPlot->xAxis->setLabel("MC");
    if ( ShowMb ) ui->customPlot->xAxis->setLabel("Mb");
    if ( ShowMB ) ui->customPlot->xAxis->setLabel("MB");
    if ( ShowMs ) ui->customPlot->xAxis->setLabel("Ms");
    if ( ShowMS ) ui->customPlot->xAxis->setLabel("MS");

    if ( Show2M ) ui->customPlot->yAxis->setLabel("M");
    if ( Show2MW ) ui->customPlot->yAxis->setLabel("MW");
    if ( Show2ML ) ui->customPlot->yAxis->setLabel("ML");
    if ( Show2MC ) ui->customPlot->yAxis->setLabel("MC");
    if ( Show2Mb ) ui->customPlot->yAxis->setLabel("Mb");
    if ( Show2MB ) ui->customPlot->yAxis->setLabel("MB");
    if ( Show2Ms ) ui->customPlot->yAxis->setLabel("Ms");
    if ( Show2MS ) ui->customPlot->yAxis->setLabel("MS");

    //checkBox_show_legend
    ui->customPlot->legend->setVisible(false);
    Qt::CheckState ShowLegend;
    ShowLegend = ui->checkBox_show_legend->checkState();
    if (ShowLegend == Qt::Checked && ShowCount == Qt::Checked){
        ui->customPlot->legend->setVisible(true);
        //ui->customPlot->legend->setPositionStyle(QCPLegend::psTopLeft);
        //ui->customPlot->axisRect()->insetLayout()->setInsetAlignment(0, Qt::AlignTop|Qt::AlignHCenter);
        ui->customPlot->axisRect()->insetLayout()->setInsetAlignment(0, Qt::AlignTop|Qt::AlignLeft);
    }

    ui->customPlot->xAxis->setRange(MinMag-0.2, MaxMag+0.2);
    ui->customPlot->yAxis->setRange(MinMag-0.2, MaxMag+0.2);
    //ui->customPlot->setRangeDrag(Qt::Horizontal|Qt::Vertical);
    //ui->customPlot->setRangeZoom(Qt::Horizontal|Qt::Vertical);
    ui->customPlot->setInteractions(QCP::iRangeDrag | QCP::iRangeZoom);
    ui->customPlot->replot();
}
