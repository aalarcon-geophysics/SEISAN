/*
 * 2014-06-20 Peter Voss: fixed for qcp 1.2.1

#include <QDebug>
*/
#include "eventsperyeardlg.h"
#include "ui_eventsperyeardlg.h"
#include "mainwindow.h"
#include <cstdlib>
#include <QString>

#include <iostream>
#include "qcustomplot.h"

EventsPerYearDlg::EventsPerYearDlg(db *database, QWidget *parent) : QDialog(parent), ui(new Ui::EventsPerYearDlg) {

    ui->setupUi(this);

    ui->customPlot->plotLayout()->insertRow(0); // inserts an empty row above the default axis rect
    ui->customPlot->plotLayout()->addElement(0, 0, new QCPPlotTitle(ui->customPlot, "SEISAN: Events per year"));

    ui->radioButton_PDF->setChecked(true);
    ui->spinBox_X_Size->setRange(1.0,8000.0);
    ui->spinBox_X_Size->setValue(700.0);
    ui->spinBox_X_Size->setSingleStep(1.0);
    ui->spinBox_Y_Size->setRange(1.0,8000.0);
    ui->spinBox_Y_Size->setValue(700.0);
    ui->spinBox_Y_Size->setSingleStep(1.0);

    ui->radioButton_M->setChecked(true);

    ui->checkBox_log10->setChecked(true);

    ui->spinBox_intervals->setRange(1.0,5.0);
    ui->spinBox_intervals->setValue(1.0);
    ui->spinBox_intervals->setSingleStep(1.0);

    QStringList TableHeader;
    TableHeader << "Min Mag" << "Max Mag";
    ui->tableWidget->setColumnCount(2);
    ui->tableWidget->setRowCount(1);
    ui->tableWidget->setHorizontalHeaderLabels(TableHeader);
    ui->tableWidget->setColumnWidth(0,60);
    ui->tableWidget->setColumnWidth(1,60);

    DataBase=database;

    // initial table
    EventsPerYearDlg_init_table();

    // initial plot
    EventsPerYearDlg_plot();

    connect( ui->pushButton_done, SIGNAL( clicked() ), this, SLOT( close() ) );
    connect( ui->pushButton_Print, SIGNAL( clicked() ), this, SLOT( outputPrint() ) );

    // plot when "table" is clicked
    connect( ui->pushButton_table, SIGNAL( clicked() ), this, SLOT( EventsPerYearDlg_table() ) );

    // plot when "Replot" is clicked
    connect( ui->pushButton_plot, SIGNAL( clicked() ), this, SLOT( EventsPerYearDlg_plot() ) );

}

EventsPerYearDlg::~EventsPerYearDlg() {
    delete ui;
}

void EventsPerYearDlg::outputPrint() {
    int xsize = ui->spinBox_X_Size->value();
    int ysize = ui->spinBox_Y_Size->value();
    if (ui->radioButton_PDF->isChecked())
        ui->customPlot->savePdf("se-EventsPerYearDlg.pdf",0,xsize,ysize);
    if (ui->radioButton_PS->isChecked())
        ui->customPlot->savePdf("se-EventsPerYearDlg.ps",0,xsize,ysize);
    if (ui->radioButton_PNG->isChecked())
        ui->customPlot->savePng("se-EventsPerYearDlg.png",xsize,ysize,1,-1);
    if (ui->radioButton_JPG->isChecked())
        ui->customPlot->saveJpg("se-EventsPerYearDlg.jpg",xsize,ysize,1,-1);
    if (ui->radioButton_BMP->isChecked())
        ui->customPlot->saveBmp("se-EventsPerYearDlg.bmp",xsize,ysize,1);
}

void EventsPerYearDlg::EventsPerYearDlg_table(){
    int intervals = ui->spinBox_intervals->value();
    ui->tableWidget->setRowCount(intervals);
    for (int i=1; i<intervals; ++i) {
        ui->tableWidget->setItem(i, 0, new QTableWidgetItem(QString("-9")));
        ui->tableWidget->setItem(i, 1, new QTableWidgetItem(QString("-9")));
    }
}

// initialt table with min and max M values
void EventsPerYearDlg::EventsPerYearDlg_init_table()
{
    float magnitude, magLow=999.9, magHigh=-999.9;
    int NumEvents = DataBase->NumEvents();
    event_node_ *Node;

    for (int i=0; i<NumEvents; ++i) {
       Node = DataBase->EventByIndex(i);
       if (Node->hypocenters.nmag > 0) {
          magnitude = Node->hypocenters.mag_all[0].mag;
          if( magnitude < magLow) magLow = magnitude;
          if( magnitude > magHigh) magHigh = magnitude;
       }
    }

    ui->tableWidget->setItem(0, 0, new QTableWidgetItem(QString("%1").arg(magLow)));
    ui->tableWidget->setItem(0, 1, new QTableWidgetItem(QString("%1").arg(magHigh)));
}

void EventsPerYearDlg::EventsPerYearDlg_plot() {


    float magLow=-999.9, magHigh=-999.9;
    float magLow1=-999.9, magHigh1=-999.9;
    float magLow2=-999.9, magHigh2=-999.9;
    float magLow3=-999.9, magHigh3=-999.9;
    float magLow4=-999.9, magHigh4=-999.9;

    QTableWidgetItem * tableitem;

    int intervals = ui->spinBox_intervals->value();

    for (int i=0; i<intervals; ++i) {
        if ( i == 0 ) {
            tableitem = ui->tableWidget->item(0,0);
            magLow = tableitem->text().toFloat();
            tableitem = ui->tableWidget->item(0,1);
            magHigh = tableitem->text().toFloat();
        }
        if ( i == 1 ) {
            tableitem = ui->tableWidget->item(1,0);
            magLow1 = tableitem->text().toFloat();
            tableitem = ui->tableWidget->item(1,1);
            magHigh1 = tableitem->text().toFloat();
        }
        if ( i == 2 ) {
            tableitem = ui->tableWidget->item(2,0);
            magLow2 = tableitem->text().toFloat();
            tableitem = ui->tableWidget->item(2,1);
            magHigh2 = tableitem->text().toFloat();
        }
        if ( i == 3 ) {
            tableitem = ui->tableWidget->item(3,0);
            magLow3 = tableitem->text().toFloat();
            tableitem = ui->tableWidget->item(3,1);
            magHigh3 = tableitem->text().toFloat();
        }
        if ( i == 4 ) {
            tableitem = ui->tableWidget->item(4,0);
            magLow4 = tableitem->text().toFloat();
            tableitem = ui->tableWidget->item(4,1);
            magHigh4 = tableitem->text().toFloat();
        }
    }

    // magnitude type:
     int ShowM = 0, ShowML=0, ShowMW=0, ShowMC=0, ShowMb=0, ShowMB=0, ShowMs=0, ShowMS=0;
     if (ui->radioButton_M->isChecked())  ShowM  = 1;
     if (ui->radioButton_ML->isChecked()) ShowML = 1;
     if (ui->radioButton_MW->isChecked()) ShowMW = 1;
     if (ui->radioButton_MC->isChecked()) ShowMC = 1;
     if (ui->radioButton_Mb->isChecked()) ShowMb = 1;
     if (ui->radioButton_MB->isChecked()) ShowMB = 1;
     if (ui->radioButton_Ms->isChecked()) ShowMs = 1;
     if (ui->radioButton_MS->isChecked()) ShowMS = 1;

    int NumEvents = DataBase->NumEvents();
    event_node_ *Node;

    Node = DataBase->EventByIndex(0);
    double FirstYear=(double)Node->hypocenters.first->time.year;
    Node = DataBase->EventByIndex(NumEvents-1);
    double LastYear=(double)Node->hypocenters.first->time.year;

    // Determine incremental values yinc
    QVector<double> yinc(LastYear-FirstYear+1);
    QVector<double> yinc1(LastYear-FirstYear+1);
    QVector<double> yinc2(LastYear-FirstYear+1);
    QVector<double> yinc3(LastYear-FirstYear+1);
    QVector<double> yinc4(LastYear-FirstYear+1);
    QVector<double> xinc(LastYear-FirstYear+1);
    double dum=FirstYear;
    for (int i=0; i<(LastYear-FirstYear+1); ++i) {
        yinc[i]=0.0;
        yinc1[i]=0.0;
        yinc2[i]=0.0;
        yinc3[i]=0.0;
        yinc4[i]=0.0;
        xinc[i]=dum+0.5;
        ++dum;
    }

    float magnitude=-999.9;

    for (int i=0; i<NumEvents; ++i) {
        Node = DataBase->EventByIndex(i);
        dum=(double)Node->hypocenters.first->time.year;
        if (ShowM && Node->hypocenters.nmag>0) magnitude = Node->hypocenters.mag_all[0].mag;
        if (ShowML && Node->hypocenters.first->magnitudes.ML.nmag>0) magnitude = Node->hypocenters.first->magnitudes.ML.mag[0];
        if (ShowMW && Node->hypocenters.first->magnitudes.MW.nmag>0) magnitude = Node->hypocenters.first->magnitudes.MW.mag[0];
        if (ShowMC && Node->hypocenters.first->magnitudes.MC.nmag>0) magnitude = Node->hypocenters.first->magnitudes.MC.mag[0];
        if (ShowMb && Node->hypocenters.first->magnitudes.Mb.nmag>0) magnitude = Node->hypocenters.first->magnitudes.Mb.mag[0];
        if (ShowMB && Node->hypocenters.first->magnitudes.MB.nmag>0) magnitude = Node->hypocenters.first->magnitudes.MB.mag[0];
        if (ShowMs && Node->hypocenters.first->magnitudes.Ms.nmag>0) magnitude = Node->hypocenters.first->magnitudes.Ms.mag[0];
        if (ShowMS && Node->hypocenters.first->magnitudes.MS.nmag>0) magnitude = Node->hypocenters.first->magnitudes.MS.mag[0];
        if ( magnitude >= magLow && magnitude <= magHigh )
            yinc[dum-FirstYear]+=1.0;
        if ( magnitude >= magLow1 && magnitude <= magHigh1 )
            yinc1[dum-FirstYear]+=1.0;
        if ( magnitude >= magLow2 && magnitude <= magHigh2 )
            yinc2[dum-FirstYear]+=1.0;
        if ( magnitude >= magLow3 && magnitude <= magHigh3 )
            yinc3[dum-FirstYear]+=1.0;
        if ( magnitude >= magLow4 && magnitude <= magHigh4 )
            yinc4[dum-FirstYear]+=1.0;
    }

    float Ymax=0.0, dummy;
    for (int i=0; i<(LastYear-FirstYear+1); ++i) {
        dummy=yinc[i]+yinc1[i]+yinc2[i]+yinc3[i]+yinc4[i];
        if ( dummy > Ymax )
            Ymax = dummy;
    }


    QPen pen;
    pen.setColor(QColor(255,0,0));

    ui->customPlot->clearPlottables();

    Qt::CheckState ShowLog10;
    ShowLog10 = ui->checkBox_log10->checkState();
    if (ShowLog10 == Qt::Checked){
        ui->customPlot->yAxis->setScaleType(QCPAxis::stLogarithmic);
        ui->customPlot->yAxis->setScaleLogBase(10);
        ui->customPlot->yAxis->setNumberFormat("eb"); // e = exponential, b = beautiful decimal powers
        ui->customPlot->yAxis->setNumberPrecision(0); // makes sure "1*10^4" is displayed only as "10^4"
        ui->customPlot->yAxis->setSubTickCount(10);
        ui->customPlot->yAxis->setRange(0.5, (6.0*Ymax));
    }
    else {
        ui->customPlot->yAxis->setScaleType(QCPAxis::stLinear);
        ui->customPlot->yAxis->setNumberFormat("f");
        ui->customPlot->yAxis->setRange(0, Ymax+Ymax/2.0);
    }

    // labels:
    //ui->customPlot->setTitle("Events per year");
    //ui->customPlot->plotLayout()->addElement(0, 0, new QCPPlotTitle(ui->customPlot, "SEISAN: Events per year"));
    ui->customPlot->xAxis->setLabel("Year");
    ui->customPlot->yAxis->setLabel("Number of events");
    ui->customPlot->xAxis->setRange(FirstYear-0.25, LastYear+1.25);

    // add histogram:
    QCPBars *MagHistogram = new QCPBars(ui->customPlot->xAxis, ui->customPlot->yAxis);
    QCPBars *MagHistogram1 = new QCPBars(ui->customPlot->xAxis, ui->customPlot->yAxis);
    QCPBars *MagHistogram2 = new QCPBars(ui->customPlot->xAxis, ui->customPlot->yAxis);
    QCPBars *MagHistogram3 = new QCPBars(ui->customPlot->xAxis, ui->customPlot->yAxis);
    QCPBars *MagHistogram4 = new QCPBars(ui->customPlot->xAxis, ui->customPlot->yAxis);

    pen.setWidthF(1.2);
    pen.setColor(QColor(0, 0, 0));

    for (int i=0; i<intervals; ++i) {
        if ( i == 0 ) {
            ui->customPlot->addPlottable(MagHistogram);
            MagHistogram->setName(QString("Magnitudes: [%1, %2]").arg(magLow).arg(magHigh));
            MagHistogram->setPen(pen);
            MagHistogram->setBrush(QColor(255, 0, 0));
            MagHistogram->setWidth(1);
            MagHistogram->setData(xinc, yinc);
        }
        if ( i == 1 ) {
            ui->customPlot->addPlottable(MagHistogram1);
            MagHistogram1->moveAbove(MagHistogram);
            MagHistogram1->setName(QString("Magnitudes: [%1, %2]").arg(magLow1).arg(magHigh1));
            MagHistogram1->setPen(pen);
            MagHistogram1->setBrush(QColor(255, 133, 0));
            MagHistogram1->setWidth(1);
            MagHistogram1->setData(xinc, yinc1);
        }
        if ( i == 2 ) {
            ui->customPlot->addPlottable(MagHistogram2);
            MagHistogram2->moveAbove(MagHistogram1);
            MagHistogram2->setName(QString("Magnitudes: [%1, %2]").arg(magLow2).arg(magHigh2));
            MagHistogram2->setPen(pen);
            MagHistogram2->setBrush(QColor(2, 90, 50));
            MagHistogram2->setWidth(1);
            MagHistogram2->setData(xinc, yinc2);
        }
        if ( i == 3 ) {
            ui->customPlot->addPlottable(MagHistogram3);
            MagHistogram3->moveAbove(MagHistogram2);
            MagHistogram3->setName(QString("Magnitudes: [%1, %2]").arg(magLow3).arg(magHigh3));
            MagHistogram3->setPen(pen);
            MagHistogram3->setBrush(QColor(5, 231, 0));
            MagHistogram3->setWidth(1);
            MagHistogram3->setData(xinc, yinc3);
        }
        if ( i == 4 ) {
            ui->customPlot->addPlottable(MagHistogram4);
            MagHistogram4->moveAbove(MagHistogram3);
            MagHistogram4->setName(QString("Magnitudes: [%1, %2]").arg(magLow4).arg(magHigh4));
            MagHistogram4->setPen(pen);
            MagHistogram4->setBrush(QColor(2, 1, 250));
            MagHistogram4->setWidth(1);
            MagHistogram4->setData(xinc, yinc4);
        }
    }

    ui->customPlot->legend->setVisible(true);
    QFont legendFont = font();
    legendFont.setPointSize(10);
    ui->customPlot->legend->setFont(legendFont);
    ui->customPlot->legend->setSelectedFont(legendFont);
    //ui->customPlot->legend->setSelectable(QCPLegend::spItems);
    //ui->customPlot->legend->setPositionStyle(QCPLegend::psTopLeft);
    //ui->customPlot->setRangeDrag(Qt::Horizontal|Qt::Vertical);
    //ui->customPlot->setRangeZoom(Qt::Horizontal|Qt::Vertical);
    ui->customPlot->setInteractions(QCP::iRangeDrag | QCP::iRangeZoom);
    ui->customPlot->replot();
}



