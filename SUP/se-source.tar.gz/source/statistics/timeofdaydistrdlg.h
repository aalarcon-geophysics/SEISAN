#ifndef TIMEOFDAYDISTRDLG_H
#define TIMEOFDAYDISTRDLG_H

#include <QDialog>
#include "database.h"
#include "qcustomplot.h" // the header file of QCustomPlot. Don't forget to add it to your project, if you use an IDE, so it gets compiled.


namespace Ui {
    class TimeOfDayDistrDlg;
}

class TimeOfDayDistrDlg : public QDialog
{
    Q_OBJECT

public:
    explicit TimeOfDayDistrDlg(db *database, QWidget *parent = 0);
    ~TimeOfDayDistrDlg();

private slots:
    void TimeOfDayDistrDlg_plot();
    void outputPrint();

private:
    Ui::TimeOfDayDistrDlg *ui;
    db *DataBase;
};

#endif
