/*
 * 2014-06-20 Peter Voss: fixed for qcp 1.2.1

#include <QDebug>
*/
#include "poissondlg.h"
#include "ui_poissondlg.h"
#include "mainwindow.h"
#include "qcustomplot.h"
#include <cstdlib>
#include <QString>
#include <iostream>


poissondlg::poissondlg(db *database, QWidget *parent) : QDialog(parent), ui(new Ui::poissondlg)
{
   ui->setupUi(this);

   DataBase=database;

   ui->customPlot->plotLayout()->insertRow(0); // inserts an empty row above the default axis rect
   ui->customPlot->plotLayout()->addElement(0, 0, new QCPPlotTitle(ui->customPlot, "SEISAN: Poisson Distribution"));

   ui->radioButton_PDF->setChecked(true);
   ui->spinBox_X_Size->setRange(1.0,8000.0);
   ui->spinBox_X_Size->setValue(700.0);
   ui->spinBox_X_Size->setSingleStep(1.0);
   ui->spinBox_Y_Size->setRange(1.0,8000.0);
   ui->spinBox_Y_Size->setValue(700.0);
   ui->spinBox_Y_Size->setSingleStep(1.0);

   setupPoisson();

   connect( ui->pushButton_done, SIGNAL( clicked() ), this, SLOT( close() ) );
   connect( ui->pushButton_Print, SIGNAL( clicked() ), this, SLOT( outputPrint() ) );
}


poissondlg::~poissondlg()
{
   delete ui;
}


void poissondlg::outputPrint()
{
   int xsize = ui->spinBox_X_Size->value();
   int ysize = ui->spinBox_Y_Size->value();
   if (ui->radioButton_PDF->isChecked()) ui->customPlot->savePdf("se-poisson.pdf",0,xsize,ysize);
   if (ui->radioButton_PS->isChecked()) ui->customPlot->savePdf("se-poisson.ps",0,xsize,ysize);
   if (ui->radioButton_PNG->isChecked()) ui->customPlot->savePng("se-poisson.png",xsize,ysize,1,-1);
   if (ui->radioButton_JPG->isChecked()) ui->customPlot->saveJpg("se-poisson.jpg",xsize,ysize,1,-1);
   if (ui->radioButton_BMP->isChecked()) ui->customPlot->saveBmp("se-poisson.bmp",xsize,ysize,1);
}


void poissondlg::setupPoisson()
{
   QCPBars *EarthquakeDistribution = new QCPBars(ui->customPlot->xAxis, ui->customPlot->yAxis);
   ui->customPlot->addPlottable(EarthquakeDistribution);
   QPen pen;
   pen.setWidthF(1.2);
   EarthquakeDistribution->setName("Earthquake distribution");
   pen.setColor(QColor(0, 0, 0));
   EarthquakeDistribution->setPen(pen);
   EarthquakeDistribution->setBrush(QColor(255, 0, 0));

   QString line;
   line.resize(4);

   int count = -1;
   int firstyear, lastyear, nyears;

   // Enumerate all events in the event list view.
   int year; event_node_ *Node;
   int NumEvents = DataBase->NumEvents();

   for ( int i=0; i < NumEvents; i++ ) {
      Node = DataBase->EventByIndex(i);
      // Node = EventByIndex(i);
      year = Node->hypocenters.first->time.year;
   }

   Node = DataBase->EventByIndex(0);
   firstyear = Node->hypocenters.first->time.year;

   //lastyear=line.size();
   Node = DataBase->EventByIndex(NumEvents-1);
   lastyear = Node->hypocenters.first->time.year;
   nyears=lastyear-firstyear+1;

   // Find the number of events per year:
   QVector<int> noepy(nyears);
   count = -1;
   for (int i=firstyear; i<lastyear+1; ++i) {
      count += 1;
      noepy[count]=0;
      for ( int j=0; j < NumEvents; j++ ) {
         Node = DataBase->EventByIndex(j);
         year = Node->hypocenters.first->time.year;
         if (i == year ) noepy[count] += 1;
      }
   }

   // Find the year with most eqs:
   int nywme=0;
   for (int i=firstyear; i<lastyear+1; ++i) {
      if (noepy[i-firstyear] > nywme) nywme=noepy[i-firstyear];
   }

   // Total number of eqs:
   int sumeqs = 0;
   for (int i=firstyear; i<lastyear+1; ++i) sumeqs += noepy[i-firstyear];

   // Average delay between two eqs:
   float adbte=nyears/(float)sumeqs;

   // count years/events for histogram:
   // years with zero eqs, years with one event, years with two eqs, ...
   // years with number of eqs
   QVector<double> ywneqs(nywme+1);
   double MAXywneqs=0.0;
   for (int count=0; count<nywme+1; ++count) {
      ywneqs[count]=0;
      for (int i=firstyear; i<lastyear+1; ++i) if (noepy[i-firstyear] == count) { ywneqs[count]+=1; }
      if (MAXywneqs < ywneqs[count]) MAXywneqs = ywneqs[count];
   }

   // Prepare x axis with country labels:
   QVector<double> ticks;
   QVector<QString> labels;
   //  ticks << 1 << 2 << 3 << 4 << 5 << 6 << 7 <<8<<9<<10<<11<<12<<13<<14<<15<<20<<30<<40<<45;
   for (int count=1; count<nywme+3; ++count) ticks << count;
   //  labels << "0" << "1" << "2" << "3" << "4" << "5" << "6"<<"7"<<"8"<<"9"<<"10"<<"11"<<"12"<<""<<"14";
   labels <<"0"<<"1"<<"2"<<"3"<<"4"<<"5"<<""<<""<<""<<""
          <<"10"<<""<<""<<""<<""<<"15"<<""<<""<<""<<""
          <<"20"<<""<<""<<""<<""<<"25"<<""<<""<<""<<""
          <<"30"<<""<<""<<""<<""<<"35"<<""<<""<<""<<""
          <<"40"<<""<<""<<""<<""<<"45";

   ui->customPlot->xAxis->grid()->setVisible(false);
   ui->customPlot->xAxis->setRange(0, (nywme+3));
   ui->customPlot->xAxis->setLabel("Number of earthquakes in yearly intervals");

   // Prepare y axis:
   ui->customPlot->yAxis->setRange(0, (MAXywneqs+MAXywneqs/2.));
   ui->customPlot->yAxis->setPadding(5); // a bit more space to the left border
   ui->customPlot->yAxis->setLabel("Number of yearly intervals");
   ui->customPlot->yAxis->grid()->setSubGridVisible(true);
   QPen gridPen;
   gridPen.setStyle(Qt::SolidLine);
   gridPen.setColor(QColor(0, 0, 0, 25));
   //ui->customPlot->yAxis->setGridPen(gridPen);
   ui->customPlot->yAxis->grid()->setPen(gridPen);
   gridPen.setStyle(Qt::DotLine);
   ui->customPlot->yAxis->grid()->setSubGridPen(gridPen);

   // Add data:
   EarthquakeDistribution->setData(ticks, ywneqs);
   QVector<double> y(nywme+1);

   double ifak=1.0;
   for (int i=0; i<(nywme+1); ++i) {
      if (i>1) ifak=ifak*(double)i;
      if (ifak>pow(10,300)) ifak=pow(10,300);
      y[i] = (double)nyears*(double)qPow((1./adbte),i)*(double)qExp(-1./adbte)/ifak;
   }

   // Plot poisson graph:
   pen.setWidth(4);
   pen.setColor(QColor(0,0,255));
   ui->customPlot->addGraph();
   ui->customPlot->graph(0)->setPen(pen);
   ui->customPlot->graph(0)->setData(ticks, y);
   ui->customPlot->graph(0)->setName("Poisson distribution");

   // Setup legend:
   //ui->customPlot->plotLayout()->addElement(0, 0, new QCPPlotTitle(ui->customPlot, "Poisson distribution"));
   ui->customPlot->legend->setVisible(true);
   ui->customPlot->axisRect()->insetLayout()->setInsetAlignment(0, Qt::AlignTop|Qt::AlignHCenter);
   ui->customPlot->legend->setBrush(QColor(255, 255, 255, 200));
   QPen legendPen;
   legendPen.setColor(QColor(130, 130, 130, 200));
   ui->customPlot->legend->setBorderPen(legendPen);
   QFont legendFont = font();
   legendFont.setPointSize(10);
   ui->customPlot->legend->setFont(legendFont);
   ui->customPlot->setInteractions(QCP::iRangeDrag | QCP::iRangeZoom);
}
