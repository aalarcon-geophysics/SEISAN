#ifndef GUMBEL3DISTDLG_H
#define GUMBEL3DISTDLG_H

#include <QDialog>
#include "database.h"
#include "logmodel.h"
#include "qcustomplot.h"


namespace Ui {
    class Gumbel3DistDlg;
}

class Gumbel3DistDlg : public QDialog
{
    Q_OBJECT

signals:
    // Signals for the log view.
    void WriteLog(logmodel::msg_type, QString);

public:
    explicit Gumbel3DistDlg(db *database, QWidget *parent = 0);
    ~Gumbel3DistDlg();

private slots:
    void plotGumble3();
    void outputPrint();

private:
    Ui::Gumbel3DistDlg *ui;
    db *DataBase;
    QString Message;
};

#endif
