/*
 * Function used to plot time of day versus distance from a given location in polar view.
 * First version 2014-09-30, Good luck Peter Voss
 *
#include <QDebug>
*/

#include "todvsdistdlg.h"
#include "ui_todvsdistdlg.h"
#include "mainwindow.h"
#include "qcustomplot.h"

#include <cstdlib>
#include <QString>
#include <iostream>

TodVsDistDlg::TodVsDistDlg(db *database, QWidget *parent) : QDialog(parent), ui(new Ui::TodVsDistDlg) {

    ui->setupUi(this);

    DataBase=database;

    ui->spinBox_Dist->setRange(1.0,20010.0);
    ui->spinBox_Dist->setSingleStep(1.0);
    ui->spinBox_Dist->setValue(60.0);

    ui->doubleSpinBox_Lat->setRange(-90.0,90.0);
    ui->doubleSpinBox_Lat->setSingleStep(0.01);
    ui->doubleSpinBox_Lat->setValue(55.7);

    ui->doubleSpinBox_Lon->setRange(-180.0,180.0);
    ui->doubleSpinBox_Lon->setSingleStep(0.01);
    ui->doubleSpinBox_Lon->setValue(13.7);

    // qDebug() << "\nstart Sample function B\n";

    // initial plot
    plot();

    connect( ui->pushButton_done, SIGNAL( clicked() ), this, SLOT( close() ) );
    connect( ui->pushButton_PDF, SIGNAL( clicked() ), this, SLOT( outputPDF() ) );
    connect( ui->pushButton_PNG, SIGNAL( clicked() ), this, SLOT( outputPNG() ) );
    connect( ui->pushButton_Plot, SIGNAL( clicked() ), this, SLOT( plot() ) );

}

TodVsDistDlg::~TodVsDistDlg() {
    delete ui;
}

void TodVsDistDlg::outputPDF() {
    ui->customPlot->savePdf("pv.pdf",0,700,700);
}

void TodVsDistDlg::outputPNG() {
    ui->customPlot->savePng("pv.png",700,700,1,-1);
}

void TodVsDistDlg::plot() {

    ui->customPlot->clearPlottables();

    float TimeOfDay;

    // Enumerate all events in the event list view.
    event_node_ *Node;

    int NumEvents = DataBase->NumEvents();

    double plat = ui->doubleSpinBox_Lat->value();
    double plon = ui->doubleSpinBox_Lon->value();

    double MaxDist = ui->spinBox_Dist->value();

    int j=0;
    QVector<double> ypos(NumEvents);
    QVector<double> xpos(NumEvents);

    for ( int i=0; i < NumEvents; i++ ) {
        Node = DataBase->EventByIndex(i);

        TimeOfDay = (float) (Node->hypocenters.first->time.hour)
                     +(float) (Node->hypocenters.first->time.minute)/60.0
                     +         Node->hypocenters.first->time.second/3600.0;

        TimeOfDay = -2.0*3.14*TimeOfDay/24.0+3.14/2.;

        double eqlat = Node->hypocenters.first->lat;
        double eqlon = Node->hypocenters.first->lon;

        double yy=3.14159265359/180.0;
        double aa,cb,cc,sb,sc;
        cb=cos((90.0-eqlat)*yy);
        cc=cos((90.0-plat)*yy);
        sb=sin((90.0-eqlat)*yy);
        sc=sin((90.0-plat)*yy);
        aa=acos(cb*cc+sb*sc*cos((plon-eqlon)*yy))/yy*111.194926645;
        double DistOfEvent = aa / MaxDist ;

        if ( aa <= MaxDist ) {
            xpos[j] = DistOfEvent * cos(TimeOfDay);
            ypos[j] = DistOfEvent * sin(TimeOfDay);
            j++;
        }

    }

    xpos.resize(j);
    ypos.resize(j);

    int Nhour=48;
    QVector<double> ClockY(Nhour), ClockX(Nhour);
    int i=0;
    while ( i < Nhour) {
        ClockX[i] = 1.03*cos((2.0*3.14)*(float)i/2.0/24.0);
        ClockY[i] = 1.03*sin((2.0*3.14)*(float)i/2.0/24.0);
        i++;
        ClockX[i] = 0.0;
        ClockY[i] = 0.0;
        i++;
    }

    QPen pen;

    ui->customPlot->clearPlottables();
    ui->customPlot->clearItems();

    QCPCurve *ClockView = new QCPCurve(ui->customPlot->xAxis, ui->customPlot->yAxis);
    ui->customPlot->addPlottable(ClockView);
    pen.setColor(QColor(0,0,0));
    ClockView->setPen(pen);
    ClockView->setData(ClockX, ClockY);

    // labels:
    QCPItemText * SeisanLabel = new QCPItemText(ui->customPlot);
    ui->customPlot->addItem(SeisanLabel);
    SeisanLabel->setPositionAlignment(Qt::AlignTop|Qt::AlignRight);
    SeisanLabel->position->setType(QCPItemPosition::ptAxisRectRatio);
    SeisanLabel->position->setCoords(0.995, 0.0); // place position at center/top of axis rect
    SeisanLabel->setText("SEISAN");
    SeisanLabel->setFont(QFont(font().family(), 6)); // make font a bit larger

    QCPItemText * text0 = new QCPItemText(ui->customPlot);
    ui->customPlot->addItem(text0);
    text0->setPositionAlignment(Qt::AlignTop|Qt::AlignCenter);
    text0->position->setType(QCPItemPosition::ptAxisRectRatio);
    text0->position->setCoords(0.5, 0.05); // place position at center/top of axis rect
    text0->setText("0/24 UTC");
    text0->setFont(QFont(font().family(), 12)); // make font a bit larger

    QCPItemText * text6 = new QCPItemText(ui->customPlot);
    ui->customPlot->addItem(text6);
    text6->setPositionAlignment(Qt::AlignCenter|Qt::AlignRight);
    text6->position->setType(QCPItemPosition::ptAxisRectRatio);
    text6->position->setCoords(0.95, 0.5); // place position at center/top of axis rect
    text6->setText("6");
    text6->setFont(QFont(font().family(), 12)); // make font a bit larger

    QCPItemText * text12 = new QCPItemText(ui->customPlot);
    ui->customPlot->addItem(text12);
    text12->setPositionAlignment(Qt::AlignBottom|Qt::AlignCenter);
    text12->position->setType(QCPItemPosition::ptAxisRectRatio);
    text12->position->setCoords(0.5, 0.95); // place position at center/top of axis rect
    text12->setText("12 UTC");
    text12->setFont(QFont(font().family(), 12)); // make font a bit larger

    QCPItemText * text18 = new QCPItemText(ui->customPlot);
    ui->customPlot->addItem(text18);
    text18->setPositionAlignment(Qt::AlignCenter|Qt::AlignLeft);
    text18->position->setType(QCPItemPosition::ptAxisRectRatio);
    text18->position->setCoords(0.05, 0.5); // place position at center/top of axis rect
    text18->setText("18");
    text18->setFont(QFont(font().family(), 12)); // make font a bit larger

    float ClockRadius = 1.0/3.0;

    //qDebug() << "nyear:" << nyear << ClockRadius ;

    int pointCount = 500;
    double phi;

    QCPCurve *ClockDisc3 = new QCPCurve(ui->customPlot->xAxis, ui->customPlot->yAxis);
    ui->customPlot->addPlottable(ClockDisc3);
    // generate the curve data points:
    QVector<double> xClockDisc3(pointCount), yClockDisc3(pointCount);
    i=0;
    while( i<pointCount-1 )    {
      phi = (i/(double)(pointCount-1))*2*M_PI+M_PI/12*3-M_PI/24;
      xClockDisc3[i] = cos(phi);
      yClockDisc3[i] = sin(phi);
      i++;
    }
    xClockDisc3[i] = 1.1*cos(phi);
    yClockDisc3[i] = 1.1*sin(phi);
    ClockDisc3->setData(xClockDisc3, yClockDisc3);
    ClockDisc3->setPen(QPen(Qt::blue));
    QCPItemText * ClockDisc3text = new QCPItemText(ui->customPlot);
    ui->customPlot->addItem(ClockDisc3text);
    ClockDisc3text->setPositionAlignment(Qt::AlignCenter|Qt::AlignLeft);
    ClockDisc3text->position->setType(QCPItemPosition::ptAxisRectRatio);
    ClockDisc3text->position->setCoords(0.915, 0.21);
    ClockDisc3text->setText(QString("%1 km").arg(MaxDist));
    //ClockDisc3text->setText(QString("%1").arg(firstyear+2*ClockRadius));
    ClockDisc3text->setFont(QFont(font().family(), 12));

    QCPCurve *ClockDisc2 = new QCPCurve(ui->customPlot->xAxis, ui->customPlot->yAxis);
    ui->customPlot->addPlottable(ClockDisc2);
    // generate the curve data points:
    QVector<double> xClockDisc2(pointCount), yClockDisc2(pointCount);
    i=0;
    while( i<pointCount-1 )    {
      phi = (i/(double)(pointCount-1))*2*M_PI+M_PI/12*4-M_PI/24;
      xClockDisc2[i] = 2*ClockRadius*cos(phi);
      yClockDisc2[i] = 2*ClockRadius*sin(phi);
      i++;
    }
    xClockDisc2[i] = 1.1*cos(phi);
    yClockDisc2[i] = 1.1*sin(phi);
    // pass the data to the curves:
    ClockDisc2->setData(xClockDisc2, yClockDisc2);
    // color the curves:
    ClockDisc2->setPen(QPen(Qt::blue));
    QCPItemText * ClockDisc2text = new QCPItemText(ui->customPlot);
    ui->customPlot->addItem(ClockDisc2text);
    ClockDisc2text->setPositionAlignment(Qt::AlignBottom|Qt::AlignLeft);
    ClockDisc2text->position->setType(QCPItemPosition::ptAxisRectRatio);
    ClockDisc2text->position->setCoords(0.79, 0.14);
    ClockDisc2text->setText(QString("%1 km").arg(2.0*MaxDist/3.0));
    ClockDisc2text->setFont(QFont(font().family(), 12));

    QCPCurve *ClockDisc1 = new QCPCurve(ui->customPlot->xAxis, ui->customPlot->yAxis);
    ui->customPlot->addPlottable(ClockDisc1);
    // generate the curve data points:
    QVector<double> xClockDisc1(pointCount), yClockDisc1(pointCount);
    i=0;
    while( i<pointCount-1 )    {
      phi = (i/(double)(pointCount-1))*2*M_PI+M_PI/12*5-M_PI/24;
      xClockDisc1[i] = ClockRadius*cos(phi);
      yClockDisc1[i] = ClockRadius*sin(phi);
      i++;
    }
    xClockDisc1[i] = 1.1*cos(phi);
    yClockDisc1[i] = 1.1*sin(phi);
    // pass the data to the curves:
    ClockDisc1->setData(xClockDisc1, yClockDisc1);
    // color the curves:
    ClockDisc1->setPen(QPen(Qt::blue));
    QCPItemText * ClockDisc1text = new QCPItemText(ui->customPlot);
    ui->customPlot->addItem(ClockDisc1text);
    ClockDisc1text->setPositionAlignment(Qt::AlignBottom|Qt::AlignLeft);
    ClockDisc1text->position->setType(QCPItemPosition::ptAxisRectRatio);
    ClockDisc1text->position->setCoords(0.68, 0.08);
    ClockDisc1text->setText(QString("%1 km").arg(MaxDist/3.0));
    ClockDisc1text->setFont(QFont(font().family(), 12));

    pen.setColor(QColor(255,0,0));
    ui->customPlot->addGraph();
    ui->customPlot->graph(0)->setPen(pen);
    ui->customPlot->graph(0)->setData(xpos, ypos);
    ui->customPlot->graph(0)->setName("Random graph");
    ui->customPlot->graph(0)->setLineStyle(QCPGraph::lsNone);
    ui->customPlot->graph(0)->setScatterStyle(QCPScatterStyle(QCPScatterStyle::ssCircle, Qt::black, Qt::red, 5));

    ui->customPlot->xAxis->setRange(-1.2, 1.2);
    ui->customPlot->yAxis->setRange(-1.2, 1.2);

    // set blank axis lines:
    ui->customPlot->xAxis->setTicks(false);
    ui->customPlot->yAxis->setTicks(false);
    ui->customPlot->xAxis->setTickLabels(false);
    ui->customPlot->yAxis->setTickLabels(false);
    ui->customPlot->xAxis->grid()->setVisible(false);
    ui->customPlot->yAxis->grid()->setVisible(false);
    ui->customPlot->axisRect()->setAutoMargins(QCP::msNone);
    ui->customPlot->axisRect()->setMargins(QMargins(0,0,0,0));

    // make top right axes clones of bottom left axes:
    //ui->customPlot->setupFullAxesBox();

    ui->customPlot->replot();

}





