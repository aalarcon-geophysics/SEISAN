/*
 * 2014-06-20 Peter Voss: fixed for qcp 1.2.1 and a bug

#include <QDebug>
*/
#include <QString>
#include <QStatusBar>
#include <cstdlib>
#include <iostream>
#include "completenesscheckdlg.h"
#include "ui_completenesscheckdlg.h"
#include "mainwindow.h"
#include "qcustomplot.h"

#define COMPLETNESS_FILE (const char *)("se-completenss.out")

CompletenessCheckDlg::CompletenessCheckDlg(db *database, QWidget *parent) : QDialog(parent), ui(new Ui::CompletenessCheckDlg)
{
   ui->setupUi(this);

   ui->customPlot->plotLayout()->insertRow(0); // inserts an empty row above the default axis rect
   ui->customPlot->plotLayout()->addElement(0, 0, new QCPPlotTitle(ui->customPlot, "SEISAN: Completeness check"));
   ui->customPlot->setInteractions(QCP::iRangeDrag | QCP::iRangeZoom);
   ui->customPlot->legend->setVisible(true);
   QFont legendFont = font();
   legendFont.setPointSize(10);
   ui->customPlot->legend->setFont(legendFont);
   ui->customPlot->axisRect()->insetLayout()->setInsetAlignment(0, Qt::AlignTop|Qt::AlignLeft);
   ui->doubleSpinBox_StartMag->setValue(3.0);
   ui->doubleSpinBox_StartMag->setSingleStep(1.0);
   ui->doubleSpinBox_StartMag->setRange(-5.0,11.0);
   ui->doubleSpinBox_Interval->setValue(1.0);
   ui->doubleSpinBox_Interval->setSingleStep(0.1);
   ui->doubleSpinBox_Interval->setRange(0.01,4.9);

   DataBase=database;

   ui->radioButton_M->setChecked(true);

   QStringList TableHeader;
   TableHeader << "Min Mag" << "Max Mag"<< "Year";
   ui->tableWidget->setColumnCount(3);
   ui->tableWidget->setRowCount(12);
   ui->tableWidget->setHorizontalHeaderLabels( TableHeader);
   ui->tableWidget->setColumnWidth(0,60);
   ui->tableWidget->setColumnWidth(1,60);
   ui->tableWidget->setColumnWidth(2,57);

   ui->radioButton_PDF->setChecked(true);
   ui->spinBox_X_Size->setRange(1.0,8000.0);
   ui->spinBox_X_Size->setValue(700.0);
   ui->spinBox_X_Size->setSingleStep(1.0);
   ui->spinBox_Y_Size->setRange(1.0,8000.0);
   ui->spinBox_Y_Size->setValue(700.0);
   ui->spinBox_Y_Size->setSingleStep(1.0);

   // plot with default values
   plotcompleteness();

   // at "Replot":
   connect(ui->pushButton_plot, SIGNAL(clicked()), this, SLOT(plotcompleteness()));
   connect(ui->pushButton_Print, SIGNAL(clicked()), this, SLOT(outputPrint()));
   connect(ui->pushButton_done, SIGNAL(clicked()), this, SLOT(close()));
   // highlight both graph and legend
   connect(ui->customPlot, SIGNAL(selectionChangedByUser()), this, SLOT(selectionChanged()));
}


CompletenessCheckDlg::~CompletenessCheckDlg() {
   delete ui;
}


void CompletenessCheckDlg::selectionChanged()
{
   // Synchronize selection of graphs with selection of corresponding legend items:
   for (int i=0; i<ui->customPlot->graphCount(); ++i) {
      QCPGraph *graph = ui->customPlot->graph(i);
      QCPPlottableLegendItem *item = ui->customPlot->legend->itemWithPlottable(graph);
      if (item->selected() || graph->selected()) {
         item->setSelected(true);
         graph->setSelected(true);
      }
   }
}


void CompletenessCheckDlg::outputPrint() {
   int xsize = ui->spinBox_X_Size->value();
   int ysize = ui->spinBox_Y_Size->value();
   if (ui->radioButton_PDF->isChecked()) ui->customPlot->savePdf("se-completeness.pdf",0,xsize,ysize);
   if (ui->radioButton_PS->isChecked()) ui->customPlot->savePdf("se-completeness.ps",0,xsize,ysize);
   if (ui->radioButton_PNG->isChecked()) ui->customPlot->savePng("se-completeness.png",xsize,ysize,1,-1);
   if (ui->radioButton_JPG->isChecked()) ui->customPlot->saveJpg("se-completeness.jpg",xsize,ysize,1,-1);
   if (ui->radioButton_BMP->isChecked()) ui->customPlot->saveBmp("se-completeness.bmp",xsize,ysize,1);
}


void CompletenessCheckDlg::plotcompleteness()
{
   int dumi;
   QTableWidgetItem * completenessYear;// = ui->tableWidget->item(1,2);

   // Magnitude type:
   int ShowM = 0, ShowML=0, ShowMW=0, ShowMC=0, ShowMb=0, ShowMB=0, ShowMs=0, ShowMS=0;
   if (ui->radioButton_M->isChecked())  ShowM  = 1;
   if (ui->radioButton_ML->isChecked()) ShowML = 1;
   if (ui->radioButton_MW->isChecked()) ShowMW = 1;
   if (ui->radioButton_MC->isChecked()) ShowMC = 1;
   if (ui->radioButton_Mb->isChecked()) ShowMb = 1;
   if (ui->radioButton_MB->isChecked()) ShowMB = 1;
   if (ui->radioButton_Ms->isChecked()) ShowMs = 1;
   if (ui->radioButton_MS->isChecked()) ShowMS = 1;

   // Clear old graphs
   ui->customPlot->clearPlottables();
   ui->customPlot->clearGraphs();
   ui->customPlot->clearItems();

   QPen pen;
   pen.setWidthF(1.2);

   float startmag = ui->doubleSpinBox_StartMag->value();
   float MagInterval = ui->doubleSpinBox_Interval->value();
   float magnitude = -999.9;

   int NumEvents = DataBase->NumEvents();
   event_node_ *Node;

   Node = DataBase->EventByIndex(0);
   float StartYear=(float)Node->hypocenters.first->time.year;
   Node = DataBase->EventByIndex(NumEvents-1);
   float EndYear=(float)Node->hypocenters.first->time.year;

   QVector<double> LineColors(1000);
   int count=-1;
   LineColors[++count]=22.0;  LineColors[++count]=22.0;   LineColors[++count]=219.0;
   LineColors[++count]=229.0; LineColors[++count]=54.0;   LineColors[++count]=18.0;
   LineColors[++count]=51.0;  LineColors[++count]=102.0;  LineColors[++count]=219.0;
   LineColors[++count]=177.0; LineColors[++count]=219.0;  LineColors[++count]=219.0;
   LineColors[++count]=192.0; LineColors[++count]=171.0;  LineColors[++count]=56.0;
   LineColors[++count]=159.0; LineColors[++count]=182.0;  LineColors[++count]=163.0;
   LineColors[++count]=142.0; LineColors[++count]=36.0;   LineColors[++count]=106.0;
   LineColors[++count]=60.0;  LineColors[++count]=67.0;   LineColors[++count]=176.0;
   LineColors[++count]=33.0;  LineColors[++count]=111.0;  LineColors[++count]=77.0;
   LineColors[++count]=94.0;  LineColors[++count]=140.0;  LineColors[++count]=104.0;
   for (int i=count; i<1000; ++i) LineColors[i]=104.0;

   double MAXy = 0.0;
   float MaxMag = -999.9;
   float magLow,magHigh;

   // Find largest magnitude:
   for (int i=0; i<NumEvents; ++i) {
      Node = DataBase->EventByIndex(i);
      if (ShowM && Node->hypocenters.nmag>0) magnitude = Node->hypocenters.mag_all[0].mag;
      if (ShowML && Node->hypocenters.first->magnitudes.ML.nmag>0) magnitude = Node->hypocenters.first->magnitudes.ML.mag[0];
      if (ShowMW && Node->hypocenters.first->magnitudes.MW.nmag>0) magnitude = Node->hypocenters.first->magnitudes.MW.mag[0];
      if (ShowMC && Node->hypocenters.first->magnitudes.MC.nmag>0) magnitude = Node->hypocenters.first->magnitudes.MC.mag[0];
      if (ShowMb && Node->hypocenters.first->magnitudes.Mb.nmag>0) magnitude = Node->hypocenters.first->magnitudes.Mb.mag[0];
      if (ShowMB && Node->hypocenters.first->magnitudes.MB.nmag>0) magnitude = Node->hypocenters.first->magnitudes.MB.mag[0];
      if (ShowMs && Node->hypocenters.first->magnitudes.Ms.nmag>0) magnitude = Node->hypocenters.first->magnitudes.Ms.mag[0];
      if (ShowMS && Node->hypocenters.first->magnitudes.MS.nmag>0) magnitude = Node->hypocenters.first->magnitudes.MS.mag[0];
      if (MaxMag < magnitude) MaxMag = magnitude;
   }

   //qDebug() << "MaxMag0" << MaxMag;

   // Count number of intervals:
   magLow=startmag;
   magHigh=startmag+MagInterval;
   count=0;
   while (magLow<MaxMag) {
      magLow=magHigh;
      magHigh=magHigh+MagInterval;
      count++;
   }
   int NumInterval=count;

   // Insert intervals in table:
   ui->tableWidget->setRowCount(NumInterval);
   magLow=startmag;
   magHigh=startmag+MagInterval;
   count=0;
   while (count<NumInterval) {
      ui->tableWidget->setItem(count,0,new QTableWidgetItem(QString("%1").arg(magLow)));
      ui->tableWidget->setItem(count,1,new QTableWidgetItem(QString("%1").arg(magHigh)));
      if (!ui->tableWidget->item(count, 2)) ui->tableWidget->setItem(count,2,new QTableWidgetItem(QString("2070")));
      magLow=magHigh;
      magHigh=magHigh+MagInterval;
      count++;
   }

   // Determine incremental values yinc for each interval
   QVector<double> yinc(NumEvents);
   QVector<double> xval(NumEvents);
   // Number of earthquakes after year of completeness:
   QVector<double> NumEqsComp(NumInterval);
   double YearComp;
   QVector<double> cy(1);
   magLow=startmag;
   magHigh=startmag+MagInterval;
   int cyset;

   for (count=0; count<NumInterval; ++count) {
      // Maximun number of events
      MAXy=0.0;
      // count number of earthquakes after year of completeness:
      NumEqsComp[count]=0.0;
      // read completeness year
      completenessYear = ui->tableWidget->item(count,2);
      if (completenessYear) {
         YearComp=completenessYear->text().toDouble();
         cyset = 0;
         dumi = completenessYear->text().toInt();
      }

      Node = DataBase->EventByIndex(0);
      xval[0]=(double)Node->hypocenters.first->time.year;
      xval[0]=xval[0]+1.0/12*(double)Node->hypocenters.first->time.month;
      xval[0]=xval[0]+1.0/365*(double)Node->hypocenters.first->time.day;
      xval[0]=xval[0]+1.0/(24*365)*(double)Node->hypocenters.first->time.hour;
      xval[0]=xval[0]+1.0/(60*24*365)*(double)Node->hypocenters.first->time.minute;
      xval[0]=xval[0]+1.0/(3600*24*365)*(double)Node->hypocenters.first->time.second;
      if (ShowM && Node->hypocenters.nmag>0) magnitude = Node->hypocenters.mag_all[0].mag;
      if (ShowML && Node->hypocenters.first->magnitudes.ML.nmag>0) magnitude = Node->hypocenters.first->magnitudes.ML.mag[0];
      if (ShowMW && Node->hypocenters.first->magnitudes.MW.nmag>0) magnitude = Node->hypocenters.first->magnitudes.MW.mag[0];
      if (ShowMC && Node->hypocenters.first->magnitudes.MC.nmag>0) magnitude = Node->hypocenters.first->magnitudes.MC.mag[0];
      if (ShowMb && Node->hypocenters.first->magnitudes.Mb.nmag>0) magnitude = Node->hypocenters.first->magnitudes.Mb.mag[0];
      if (ShowMB && Node->hypocenters.first->magnitudes.MB.nmag>0) magnitude = Node->hypocenters.first->magnitudes.MB.mag[0];
      if (ShowMs && Node->hypocenters.first->magnitudes.Ms.nmag>0) magnitude = Node->hypocenters.first->magnitudes.Ms.mag[0];
      if (ShowMS && Node->hypocenters.first->magnitudes.MS.nmag>0) magnitude = Node->hypocenters.first->magnitudes.MS.mag[0];
      if ((magnitude >= magLow) && (magnitude < magHigh)) {
         yinc[0]=1.0;
         if (completenessYear && xval[0]>=YearComp) ++NumEqsComp[count];
      } else {
         yinc[0]=0.0;
      }

      for (int i=1; i<NumEvents; ++i) {
         Node = DataBase->EventByIndex(i);
         xval[i]=(double)Node->hypocenters.first->time.year;
         xval[i]=xval[i]+1.0/12*(double)Node->hypocenters.first->time.month;
         xval[i]=xval[i]+1.0/365*(double)Node->hypocenters.first->time.day;
         xval[i]=xval[i]+1.0/(24*365)*(double)Node->hypocenters.first->time.hour;
         xval[i]=xval[i]+1.0/(60*24*365)*(double)Node->hypocenters.first->time.minute;
         xval[i]=xval[i]+1.0/(3600*24*365)*(double)Node->hypocenters.first->time.second;
         if (ShowM && Node->hypocenters.nmag>0) magnitude = Node->hypocenters.mag_all[0].mag;
         if (ShowML && Node->hypocenters.first->magnitudes.ML.nmag>0) magnitude = Node->hypocenters.first->magnitudes.ML.mag[0];
         if (ShowMW && Node->hypocenters.first->magnitudes.MW.nmag>0) magnitude = Node->hypocenters.first->magnitudes.MW.mag[0];
         if (ShowMC && Node->hypocenters.first->magnitudes.MC.nmag>0) magnitude = Node->hypocenters.first->magnitudes.MC.mag[0];
         if (ShowMb && Node->hypocenters.first->magnitudes.Mb.nmag>0) magnitude = Node->hypocenters.first->magnitudes.Mb.mag[0];
         if (ShowMB && Node->hypocenters.first->magnitudes.MB.nmag>0) magnitude = Node->hypocenters.first->magnitudes.MB.mag[0];
         if (ShowMs && Node->hypocenters.first->magnitudes.Ms.nmag>0) magnitude = Node->hypocenters.first->magnitudes.Ms.mag[0];
         if (ShowMS && Node->hypocenters.first->magnitudes.MS.nmag>0) magnitude = Node->hypocenters.first->magnitudes.MS.mag[0];
         if (magnitude >= magLow && magnitude < magHigh) {
            yinc[i]=yinc[i-1]+1;
            if (completenessYear && xval[i] >= YearComp) ++NumEqsComp[count];
         } else {
            yinc[i]=yinc[i-1];
         }
         if (MAXy < yinc[i]) MAXy = yinc[i];
         if (cyset) { cy[0] = yinc[i];  ++cyset; }
      }

      // Normalize the incremental values
      for (int i=0; i<NumEvents; ++i) if (yinc[i]>0.0) yinc[i]=yinc[i]/MAXy*(count+1.)/NumInterval*100.;

      // Plot the graph of this interval:
      pen.setWidth(2);
      pen.setColor(QColor(LineColors[count*3+0], LineColors[count*3+1], LineColors[count*3+2]));
      ui->customPlot->addGraph();
      ui->customPlot->graph()->setPen(pen);
      ui->customPlot->graph()->setLineStyle(QCPGraph::lsStepLeft);
      ui->customPlot->graph()->setName(QString("Magnitude: [%1;%2[").arg(magLow).arg(magHigh));
      ui->customPlot->graph()->setData(xval, yinc);
      // Add point for completeness value
      if (completenessYear) {
         // Plot red circle at year of completeness:
         QCPItemTracer *phaseTracer = new QCPItemTracer(ui->customPlot);
         ui->customPlot->addItem(phaseTracer);
         phaseTracer->setGraph(ui->customPlot->graph());
         phaseTracer->setGraphKey((float)dumi);
         phaseTracer->setInterpolating(true);
         phaseTracer->setStyle(QCPItemTracer::tsCircle);
         phaseTracer->setPen(QPen(Qt::red));
         phaseTracer->setBrush(Qt::red);
         phaseTracer->setSize(7);
      }
      // Set next interval:
      magLow=magHigh;
      magHigh=magHigh+MagInterval;
   }

   ui->customPlot->setInteractions(QCP::iRangeDrag | QCP::iRangeZoom);

   QFont legendFont = font();
   legendFont.setPointSize(10);
   // Prepare x axis:
   ui->customPlot->xAxis->setRange(StartYear-1, EndYear+1);
   ui->customPlot->xAxis->setLabel("Year");
   // Prepare y axis:
   ui->customPlot->yAxis->setSubTickCount(10);
   ui->customPlot->yAxis->setRange(-2.,102.);
   ui->customPlot->yAxis->setPadding(5); // a bit more space to the left border
   ui->customPlot->yAxis->setLabel("Cumulative number of earthquakes (relative)");
   QPen gridPen;
   gridPen.setStyle(Qt::SolidLine);
   gridPen.setColor(QColor(0, 0, 0, 25));
   gridPen.setStyle(Qt::DotLine);

   ui->customPlot->replot();

   // Compute cumulative values
   QVector<double> NumEqsCompCum(NumInterval);
   if ( MaxMag > -999.0 ) {
       completenessYear = ui->tableWidget->item(NumInterval-1,2);
       dumi = completenessYear->text().toInt();
       NumEqsCompCum[NumInterval-1]=NumEqsComp[NumInterval-1]/(1+EndYear-dumi);
       for (int i=(NumInterval-2); i>-1; --i) {
           completenessYear = ui->tableWidget->item(i,2);
           dumi = completenessYear->text().toInt();
           NumEqsCompCum[i]=NumEqsCompCum[i+1]+NumEqsComp[i]/(1+EndYear-dumi);
       }
   }

   // Save intervals and completeness years that was entered
   QFile *outFile = new QFile(COMPLETNESS_FILE);
   if (outFile->open(QIODevice::WriteOnly | QIODevice::Truncate | QIODevice::Text)) {
      QTextStream out(outFile);
      out << "# Output file from SEISAN Explorer\n";
      out << "# Completeness check:\n";
      out << "# The values in the columns are:\n";
      out << "#   MinMag\n";
      out << "#   MaxMag\n";
      out << "#   Year of completeness\n";
      out << "#   Number of earthquakes after year of completeness\n";
      out << "#   Years since year of completeness\n";
      out << "#   Incremental\n";
      out << "#   Cumulative\n";
      out << QString("# Last year is %1\n").arg(EndYear);
      out << "#  \n";
      QTableWidgetItem * dummyitem;
      float dumf;
      for (int row=0; row < NumInterval; row++) {
         // min mag:
         dummyitem = ui->tableWidget->item(row,0);
         dumf = dummyitem->text().toFloat();
         out << dumf;
         out << "; ";
         // max mag:
         dummyitem = ui->tableWidget->item(row,1);
         dumf = dummyitem->text().toFloat();
         out << dumf;
         out << "; ";
         // year of completeness:
         completenessYear = ui->tableWidget->item(row,2);
         dumi = completenessYear->text().toInt();
         out << dumi;
         out << "; ";
         if (dumi<2070){
            // Number of eqs after year of completeness:
            out << NumEqsComp[row];
            out << "; ";
            // DT - years since year of completeness:
            out << EndYear-dumi+1;
            out << "; ";
            // incremental:
            out << NumEqsComp[row]/(1+EndYear-dumi);
            out << "; ";
            // cumulative:
            out << NumEqsCompCum[row];
            out << "\n";
         } else {
            // fill in dummy values:
            out << " -999999; -999999; -9999999; -9999999\n";
         }
      }
      outFile->close();
   }
}
