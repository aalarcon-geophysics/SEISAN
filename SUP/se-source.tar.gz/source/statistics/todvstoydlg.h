#ifndef TODVSTOYDLG_H
#define TODVSTOYDLG_H

#include <QDialog>
#include "database.h"
#include "qcustomplot.h" // the header file of QCustomPlot. Don't forget to add it to your project, if you use an IDE, so it gets compiled.


namespace Ui {
    class TodVsToyDlg;
}

class TodVsToyDlg : public QDialog
{
    Q_OBJECT

public:
    explicit TodVsToyDlg(db *database, QWidget *parent = 0);
    ~TodVsToyDlg();

private slots:
    void plot();
    void outputPDF();
    void outputPNG();

private:
    Ui::TodVsToyDlg *ui;
    db *DataBase;
};

#endif
