#ifndef WEICHERTDLG_H
#define WEICHERTDLG_H

#include <QDialog>
#include "database.h"
#include "qcustomplot.h"


namespace Ui {
    class WeichertDlg;
}

class WeichertDlg : public QDialog
{
    Q_OBJECT

public:
    explicit WeichertDlg(db *database, QWidget *parent = 0);
    ~WeichertDlg();

private slots:
    void plotWeichert();
    void outputPrint();

private:
    Ui::WeichertDlg *ui;
    db *DataBase;
};

#endif
