/*
 * 2014-06-20 Peter Voss: fixed for qcp 1.2.1

#include <QDebug>
*/
#include "weichertdlg.h"
#include "ui_weichertdlg.h"
#include "mainwindow.h"
#include <cstdlib>
#include <QString>
#include <iostream>
#include "qcustomplot.h"

WeichertDlg::WeichertDlg(db *database, QWidget *parent) : QDialog(parent), ui(new Ui::WeichertDlg)
{
   ui->setupUi(this);

   ui->customPlot->plotLayout()->insertRow(0); // inserts an empty row above the default axis rect
   ui->customPlot->plotLayout()->addElement(0, 0, new QCPPlotTitle(ui->customPlot, "SEISAN: Weichert method"));

   ui->spinBox_Mfirst->setValue(1);
   ui->spinBox_Mfirst->setSingleStep(1);
   ui->spinBox_Mlast->setSingleStep(1);
   ui->spinBox_Mlast->setValue(99999999);
   ui->doubleSpinBox_Mmax->setValue(7.0);
   ui->doubleSpinBox_Mmax->setSingleStep(0.5);
   ui->doubleSpinBox_Ny->setValue(5.0);
   ui->doubleSpinBox_Ny->setSingleStep(0.5);

   QStringList TableHeader_Ny, TableHeader_NyNy;
   TableHeader_Ny << "Incremental"<< "Cumulative"<<"Weichert";
   ui->tableWidget_Ny->setColumnCount(3);
   ui->tableWidget_Ny->setHorizontalHeaderLabels(TableHeader_Ny);
   TableHeader_NyNy << "Ny";
   ui->tableWidget_Ny->setRowCount(1);
   ui->tableWidget_Ny->setVerticalHeaderLabels(TableHeader_NyNy);
   ui->tableWidget_Ny->setColumnWidth(0,100);
   ui->tableWidget_Ny->setColumnWidth(1,100);
   ui->tableWidget_Ny->setColumnWidth(2,100);

   QStringList TableHeader;
   TableHeader << "Min Mag" << "Max Mag"<< "Year"<< "Number" << "DT" << "Incremental"<< "Cumulative";
   ui->tableWidget->setColumnCount(7);
   ui->tableWidget->setHorizontalHeaderLabels(TableHeader);
   ui->tableWidget->setColumnWidth(0,60);
   ui->tableWidget->setColumnWidth(1,60);
   ui->tableWidget->setColumnWidth(2,47);
   ui->tableWidget->setColumnWidth(3,55);
   ui->tableWidget->setColumnWidth(4,40);
   ui->tableWidget->setColumnWidth(5,100);
   ui->tableWidget->setColumnWidth(6,100);

   ui->radioButton_PDF_3->setChecked(true);
   ui->spinBox_X_Size->setRange(1.0,8000.0);
   ui->spinBox_X_Size->setValue(700.0);
   ui->spinBox_X_Size->setSingleStep(1.0);
   ui->spinBox_Y_Size->setRange(1.0,8000.0);
   ui->spinBox_Y_Size->setValue(700.0);
   ui->spinBox_Y_Size->setSingleStep(1.0);

   DataBase=database;

   plotWeichert();

   connect( ui->pushButton_done, SIGNAL( clicked() ), this, SLOT( close() ) );
   connect( ui->pushButton_Print, SIGNAL( clicked() ), this, SLOT( outputPrint() ) );
   connect( ui->pushButton_plot, SIGNAL( clicked() ), this, SLOT( plotWeichert() ) );
}


WeichertDlg::~WeichertDlg()
{
   delete ui;
}


void WeichertDlg::outputPrint()
{
   int xsize = ui->spinBox_X_Size->value();
   int ysize = ui->spinBox_Y_Size->value();
   if (ui->radioButton_PDF_3->isChecked()) ui->customPlot->savePdf("se-weichert.pdf",0,xsize,ysize);
   if (ui->radioButton_PS_3->isChecked()) ui->customPlot->savePdf("se-weichert.ps",0,xsize,ysize);
   if (ui->radioButton_PNG_3->isChecked()) ui->customPlot->savePng("se-weichert.png",xsize,ysize,1,-1);
   if (ui->radioButton_JPG_3->isChecked()) ui->customPlot->saveJpg("se-weichert.jpg",xsize,ysize,1,-1);
   if (ui->radioButton_BMP_3->isChecked()) ui->customPlot->saveBmp("se-weichert.bmp",xsize,ysize,1);
}


void WeichertDlg::plotWeichert()
{
   #define COMPLETNESS_FILE (const char *)("se-completenss.out")
   QFile inputFile("se-completenss.out");
   int count=0;
   int i=0;
   QString comment = "#";
   QTextStream in(&inputFile);
   QList< QStringList > lists;
   if (inputFile.open(QIODevice::ReadOnly)) {
      while (!in.atEnd()) {
         QString line = in.readLine();
         if (comment == line.at(0)) {
            ++i;
         } else {
            lists << line.split(";", QString::SkipEmptyParts);
            ++count;
         }
      }
   }

   inputFile.close();

   int NumInterval=count;

   ui->tableWidget->setRowCount(NumInterval);

   if (ui->spinBox_Mlast->value() > NumInterval) ui->spinBox_Mlast->setValue(NumInterval);

   ui->spinBox_Mfirst->setRange(1,NumInterval);
   ui->spinBox_Mlast->setRange(1,NumInterval);

   QVector<double> incremental(NumInterval);
   QVector<double> LogIncremental(NumInterval);
   QVector<double> incMagValue(NumInterval);

   QVector<double> cumulative(NumInterval);
   QVector<double> LogCumulative(NumInterval);
   QVector<double> cumMagValue(NumInterval);

   QVector<double> NumEqs(NumInterval);
   QVector<double> DT(NumInterval);

   double MagInterval=lists[1][0].toDouble()-lists[0][0].toDouble();

   for ( int row = 0; row < count; ++row ) {
      incMagValue[row]=lists[row][0].toDouble()+MagInterval/2.0;
      cumMagValue[row]=lists[row][0].toDouble();
      NumEqs[row]=lists[row][3].toDouble();
      DT[row]=lists[row][4].toDouble();
      incremental[row]=lists[row][5].toDouble();
      LogIncremental[row]=log10(incremental[row]);
      cumulative[row]=lists[row][6].toDouble();
      LogCumulative[row]=log10(cumulative[row]);
      for ( int column = 0; column < 7; ++column ) {
         ui->tableWidget->setItem(row, column, new QTableWidgetItem(lists[row][column]));
      }
   }

   // Get Cum Min and Cum Max for plot range
   double cumMax=lists[0][6].toDouble();
   double cumMin=lists[NumInterval-1][6].toDouble();

   int bStartNum = ui->spinBox_Mfirst->value();
   int bEndNum = ui->spinBox_Mlast->value();

   // Mmin
   double Mmin = incMagValue[bStartNum-1];
   //qDebug() << "Mmin" << Mmin;

   // Arrays for plotting the values used for estimation b-value
   QVector<double> ydum(2*(bEndNum-bStartNum+1));
   QVector<double> xdum(2*(bEndNum-bStartNum+1));

   // Determine b-value for cumulative values with linear regression:
   double sumx=0.0, sumy=0.0, sumxy=0.0, sumxx=0.0;
   count=0;
   for (int i=(bStartNum-1); i<bEndNum; ++i) {
      sumx=sumx+cumMagValue[i];
      sumy=sumy+LogCumulative[i];
      sumxy=sumxy+LogCumulative[i]*cumMagValue[i];
      sumxx=sumxx+cumMagValue[i]*cumMagValue[i];
      xdum[count]=cumMagValue[i];
      ydum[count]=cumulative[i];
      xdum[count+bEndNum-bStartNum+1]=incMagValue[i];
      ydum[count+bEndNum-bStartNum+1]=incremental[i];
      ++count;
   }
   i=bEndNum-bStartNum+1;

   double m=((double)i*sumxy-sumx*sumy)/((double)i*sumxx-sumx*sumx);
   double bb=(sumy-m*sumx)/(double)i;

   // Compute curve for cum fit
   QVector<double> LogCumulativeFit(NumInterval);
   for (int i=0; i<NumInterval; ++i) LogCumulativeFit[i]=pow(10.0,(bb+cumMagValue[i]*m));

   // Determine b-value for incremental values with linear regression:
   sumx=0.0, sumy=0.0, sumxy=0.0, sumxx=0.0;
   count=0;
   for (int i=(bStartNum-1); i<bEndNum; ++i) {
      sumx=sumx+incMagValue[i];
      sumy=sumy+LogIncremental[i];
      sumxy=sumxy+LogIncremental[i]*incMagValue[i];
      sumxx=sumxx+incMagValue[i]*incMagValue[i];
      ++count;
   }
   i=bEndNum-bStartNum+1;

   double m_inc=((double)i*sumxy-sumx*sumy)/((double)i*sumxx-sumx*sumx);
   double bb_inc=(sumy-m_inc*sumx)/(double)i;

   // Compute curve for incremental fit
   QVector<double> LogIncrementalFit(NumInterval);
   for (int i=0; i<NumInterval; ++i) LogIncrementalFit[i]=pow(10.0,(bb_inc+incMagValue[i]*m_inc));

   double MaxM = ui->doubleSpinBox_Mmax->value();
   double dm;
   int L=bEndNum-bStartNum;
   int LC=bEndNum-bStartNum;
   int N=0;
   int NC;

   QVector<double> FMAG(L+1);
   QVector<double> NEvents(L+1);
   QVector<double> IT(L+1);

   // Set the temp arrays:
   count=0;
   for (int i=(bStartNum-1); i<bEndNum; ++i) {
      FMAG[count]=cumMagValue[i]+0.25;
      NEvents[count]=NumEqs[i];
      IT[count]=DT[i];
      ++count;
   }

   if (MaxM > FMAG[L]) {
      dm=cumMagValue[L]-cumMagValue[L-1];   // last M-distance
      N=(int)floor((MaxM-cumMagValue[L])/dm+0.5);  // check abs=round
      NC=N+L-LC;
      if (N>0) {                              // expand array
         FMAG.resize(L+N+1);
         NEvents.resize(L+N+1);
         for (int i=(L+1); i<(L+N+1); ++i) {
            FMAG[i]=FMAG[i-1]+.5;
            NEvents[i]=0.0;
         }
      }
      if (NC>0) {                              // expand completeness array
         IT.resize(LC+NC+1);
         for (int i=(LC+1); i<(LC+NC+1); ++i) IT[i]=IT[LC];
      }
   }

   int NKOUNT=0;
   double MBar=0.0;

   for (int i=0; i<(L+N-2); ++i) {
      NKOUNT=NKOUNT+NEvents[i];    // total number of events
      MBar=MBar+NEvents[i]*FMAG[i];
   }

   MBar=MBar/(double)NKOUNT;

   double BETA=5.0;
   double BETA0=-5.0;

   double TJEXP;
   double TMEXP;
   double SUMEXP=0.0;
   double STMEX=0.0;
   double SUMTEX=0.0;
   double STM2X=0.0;
   for (int K=0; K<(L+N-1); ++K) {
      TJEXP = IT[K]*exp(-1.0*BETA*FMAG[K]);
      TMEXP = TJEXP * FMAG[K];
      SUMEXP = SUMEXP + exp(-1.0*BETA*FMAG[K]);
      STMEX = STMEX + TMEXP;
      SUMTEX = SUMTEX + TJEXP;
      STM2X = STM2X + FMAG[K]*TMEXP;
   }
   double Res=STMEX/SUMTEX-MBar;

   SUMEXP=0.0;
   STMEX=0.0;
   SUMTEX=0.0;
   STM2X=0.0;
   for (int K=0; K<(L+N-1); ++K) {
      TJEXP = IT[K]*exp(-1.0*BETA0*FMAG[K]);
      TMEXP=TJEXP*FMAG[K];
      SUMEXP=SUMEXP+exp(-1.0*BETA0*FMAG[K]);
      STMEX=STMEX+TMEXP;
      SUMTEX=SUMTEX+TJEXP;
      STM2X=STM2X+FMAG[K]*TMEXP;
   }
   double Res0=STMEX/SUMTEX-MBar;

   double Sm=1.0, BETA1, Res1;
   do {
      Sm = Res*(BETA-BETA0)/(Res-Res0);
      BETA1 = BETA-Sm;

      SUMEXP=0.0;    STMEX=0.0;    SUMTEX=0.0;    STM2X=0.0;
      for (int i=0; i<(L+N-1); ++i) {
         TJEXP = IT[i]*exp(-1.0*BETA1*FMAG[i]);
         TMEXP = TJEXP * FMAG[i];
         SUMEXP = SUMEXP + exp(-1.0*BETA1*FMAG[i]);
         STMEX = STMEX + TMEXP;
         SUMTEX = SUMTEX + TJEXP;
         STM2X = STM2X + FMAG[i]*TMEXP;
      }
      Res1=STMEX/SUMTEX-(double)MBar;
      if (Res1*Res0 > 0.0) {
         Res0=Res;
         BETA0=BETA;
      } else {
         if (Res0 == 0) BETA = BETA1;
      }
      Res = Res1;
      BETA = BETA1;
   } while (fabs(Sm) >= 0.0000000001 && fabs(Res) >= 0.000000000000001);

   double B=BETA/log(10);
   double NyAtM0 = (double)NKOUNT * SUMEXP / SUMTEX;

   // Compute curve for cum fit
   QVector<double> LogWeichertFit(NumInterval);
   for (int i=0; i<NumInterval; ++i) LogWeichertFit[i]=pow(10.0,(NyAtM0-cumMagValue[i]*B));

   // Initiate plot
   ui->customPlot->clearPlottables();

   //ui->customPlot->setRangeDrag(Qt::Horizontal|Qt::Vertical);
   //ui->customPlot->setRangeZoom(Qt::Horizontal|Qt::Vertical);
   ui->customPlot->setInteractions(QCP::iRangeDrag | QCP::iRangeZoom);


   //ui->customPlot->setupFullAxesBox();
   //ui->customPlot->setTitle("Weichert method");
   //ui->customPlot->plotLayout()->addElement(0, 0, new QCPPlotTitle(ui->customPlot, "SEISAN: Weichert method"));

   ui->customPlot->legend->setVisible(true);
   QFont legendFont = font();
   legendFont.setPointSize(10);
   ui->customPlot->legend->setFont(legendFont);
   ui->customPlot->legend->setSelectedFont(legendFont);
   //ui->customPlot->legend->setSelectable(QCPLegend::spItems); // legend box shall not be selectable, only legend items
   // Prepare x axis:
   ui->customPlot->xAxis->setSubTickCount(0);
   //ui->customPlot->xAxis->setGrid(false);
   ui->customPlot->xAxis->setRange(3, 8);
   ui->customPlot->xAxis->setLabel("Earthquake magnitude");
   // Prepare y axis:
   ui->customPlot->yAxis->setScaleType(QCPAxis::stLogarithmic);
   ui->customPlot->yAxis->setScaleLogBase(10);
   ui->customPlot->yAxis->setNumberFormat("eb"); // e = exponential, b = beautiful decimal powers
   ui->customPlot->yAxis->setNumberPrecision(0); // makes sure "1*10^4" is displayed only as "10^4"
   ui->customPlot->yAxis->setSubTickCount(10);
   ui->customPlot->yAxis->setRange(cumMin/1.5, cumMax+cumMax*10);
   ui->customPlot->yAxis->setPadding(5); // a bit more space to the left border
   ui->customPlot->yAxis->setLabel("Number of earthquakes");
   //ui->customPlot->yAxis->setSubGrid(true);
   QPen gridPen;
   gridPen.setStyle(Qt::SolidLine);
   gridPen.setColor(QColor(0, 0, 0, 25));
   //ui->customPlot->yAxis->setGridPen(gridPen);
   gridPen.setStyle(Qt::DotLine);
   //ui->customPlot->yAxis->setSubGridPen(gridPen);

   QPen pen;
   pen.setWidthF(1.2);

   pen.setWidth(2);
   pen.setColor(QColor(0,0,255));
   ui->customPlot->addGraph();
   ui->customPlot->graph()->setPen(pen);

   ui->customPlot->graph()->setData(incMagValue, incremental);
   ui->customPlot->graph()->setName("incremental");
   ui->customPlot->graph()->setLineStyle(QCPGraph::lsNone);
   //ui->customPlot->graph()->setScatterStyle(QCP::ssDisc);
   //ui->customPlot->graph()->setScatterSize(5);
   ui->customPlot->graph()->setScatterStyle(QCPScatterStyle(QCPScatterStyle::ssDisc, Qt::blue, Qt::white, 5));

   pen.setColor(QColor(255,0,0));
   ui->customPlot->addGraph();
   ui->customPlot->graph()->setPen(pen);
   ui->customPlot->graph()->setData(cumMagValue, cumulative);
   ui->customPlot->graph()->setName("cumulative");
   ui->customPlot->graph()->setLineStyle(QCPGraph::lsNone);
   //ui->customPlot->graph()->setScatterStyle(QCP::ssDisc);
   //ui->customPlot->graph()->setScatterSize(5);
   ui->customPlot->graph()->setScatterStyle(QCPScatterStyle(QCPScatterStyle::ssDisc, Qt::red, Qt::white, 5));

   pen.setColor(QColor(0,0,0));
   ui->customPlot->addGraph();
   ui->customPlot->graph()->setPen(pen);
   ui->customPlot->graph()->setData(xdum, ydum);
   ui->customPlot->graph()->setName("Used to estimate a and b");
   ui->customPlot->graph()->setLineStyle(QCPGraph::lsNone);
   //ui->customPlot->graph()->setScatterStyle(QCP::ssCircle);
   //ui->customPlot->graph()->setScatterSize(11);
   ui->customPlot->graph()->setScatterStyle(QCPScatterStyle(QCPScatterStyle::ssCircle, Qt::black, Qt::white, 11));

   double NyMag = ui->doubleSpinBox_Ny->value();

   pen.setColor(QColor(255,0,0));
   ui->customPlot->addGraph();
   ui->customPlot->graph()->setPen(pen);
   ui->customPlot->graph()->setData(cumMagValue, LogCumulativeFit);
   ui->customPlot->graph()->setName(QString("LINREG b=%1, a=%2").arg(-1.*m).arg(bb));
   ui->customPlot->graph()->setLineStyle(QCPGraph::lsLine);
   ui->tableWidget_Ny->setItem(0,1,new QTableWidgetItem(QString("%1").arg(pow(10.0,(bb+m*NyMag)))));

   pen.setColor(QColor(0,0,255));
   ui->customPlot->addGraph();
   ui->customPlot->graph()->setPen(pen);
   ui->customPlot->graph()->setData(incMagValue, LogIncrementalFit);
   ui->customPlot->graph()->setName(QString("LINREG b=%1, a=%2").arg(-1.*m_inc).arg(bb_inc));
   ui->customPlot->graph()->setLineStyle(QCPGraph::lsLine);
   ui->tableWidget_Ny->setItem(0,0,new QTableWidgetItem(QString("%1").arg(pow(10.0,(bb_inc+m_inc*NyMag)))));

   pen.setColor(QColor(0,255,0));
   ui->customPlot->addGraph();
   ui->customPlot->graph()->setPen(pen);
   ui->customPlot->graph()->setData(cumMagValue, LogWeichertFit);
   ui->customPlot->graph()->setName(QString("Weichert b=%1, Mmin=%2").arg(B).arg(Mmin));
   ui->customPlot->graph()->setLineStyle(QCPGraph::lsLine);
   ui->tableWidget_Ny->setItem(0,2,new QTableWidgetItem(QString("%1").arg(pow(10.0,(log10(NyAtM0)+B*Mmin-B*NyMag)))));

   //qDebug() << "pow(10.0,(NyAtM0+B*Mmin-B*NyMag))" <<pow(10.0,(NyAtM0+B*Mmin-B*NyMag));
   //qDebug() << "NyAtM0" <<NyAtM0;
   //qDebug() << "Mmin" <<Mmin;
   //qDebug() << "NyMag" <<NyMag;

   ui->customPlot->replot();
}
