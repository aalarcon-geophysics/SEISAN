#ifndef TIMEINTERVALDLG_H
#define TIMEINTERVALDLG_H

#include <QDialog>
#include <QDate>

#include "types.h"

namespace Ui {
    class TimeIntervalDlg;
}

class TimeIntervalDlg : public QDialog
{
   Q_OBJECT

public:
   explicit TimeIntervalDlg(se_config*, QWidget *parent = 0);
   ~TimeIntervalDlg();

public slots:
   void OkButton();
   void CancelButton();

private slots:
   void currentdaterb_clicked();
   void endofmonthrb_clicked();
   void userspecrb_clicked();

private:
   int EndDateType;
   se_config *Config;
   Ui::TimeIntervalDlg *ui;
   QString Message, AppName;
   QDate StartDate, EndDate;
};

#endif // TIMEINTERVALDLG_H
