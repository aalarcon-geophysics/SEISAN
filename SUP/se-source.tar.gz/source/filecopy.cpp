#include <QFile>
#include <QDir>

#include "filecopy.h"


// ***************************************
// Constructor function.
// ***************************************
filecopy::filecopy(logmodel *Log, QString LogMsgPrefix)
{
   // Save variables to local storage.
   this->Log = Log;
   this->LogMsgPrefix = LogMsgPrefix;
   FileList.clear();
}




// ***************************************
// Clear the class instance.
// ***************************************
void filecopy::Clear()
{
   FileList.clear();
}




// ***************************************
// Add a file to to the file copy list.
// ***************************************
void filecopy::AddFile(QString FileName, QString SrcPath, QString DestPath, bool Overwrite)
{
   fileinfo FileInfo;
   FileInfo.FileName = FileName; FileInfo.SrcPath = SrcPath;
   FileInfo.DestPath = DestPath; FileInfo.Overwrite = Overwrite;
   FileList.append(FileInfo);
}




// ****************************************************
// Copy all files in the file list. Returns false if
// a problem occurs during the copying of the file(s).
// ****************************************************
bool filecopy::Copy()
{
   bool CopyOK;
   QString Message, SrcFile, DestFile;

   // Return if list is empty.
   if (FileList.isEmpty()) return false;

   // Copy files one by one.
   CopyOK = true;
   for (int Index=0;Index<FileList.size();Index++) {
      // Create full path to source file.
      SrcFile = FileList.at(Index).SrcPath + "/" + FileList.at(Index).FileName;
      SrcFile = QDir::toNativeSeparators(SrcFile);

      // Create full path to destination file.
      DestFile = FileList.at(Index).DestPath + "/" + FileList.at(Index).FileName;
      DestFile = QDir::toNativeSeparators(DestFile);

      // Create destination directory if needed.
      if (!QFile::exists(FileList.at(Index).DestPath)) {
          QDir DestDir = QDir();
          DestDir.mkpath(FileList.at(Index).DestPath);
      }

      // Delete exiting file if overwrite is requested.
      if (QFile::exists(DestFile) && FileList.at(Index).Overwrite) QFile::remove(DestFile);

      // Copy the file.
      if (!QFile::copy(SrcFile, DestFile)) {
         // Log copy failure to log view.
         CopyOK = false;
         Message = LogMsgPrefix;
         Message.append("Could not copy '" + SrcFile + "' to '" +  FileList.at(Index).DestPath + "'.");
         Log->WriteLog(logmodel::error, Message);
      }
   }

   return CopyOK;
}
