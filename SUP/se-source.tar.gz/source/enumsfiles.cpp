#include <QDir>
#include <QDebug>
#include "enumsfiles.h"
#include "fortran.h"
#include "library.h"

void enumsfiles::SetDatabase(db_info DbInfo, QDate StartDate, QDate StopDate, QStringList *SfileList)
{
   // Save some variables.
   dbtype = DbInfo.Type;
   dbpath = QDir::cleanPath(DbInfo.Path);
   sfilelist = SfileList;

   // Prepare to read from default database.
   if (DbInfo.Type == default_database) {
      memset(dbname, 32, sizeof dbname);                                         // Database name must be empty.
      qstr2fstr(startdate, StartDate.toString("yyyyMMdd"), sizeof startdate);    // Set start date.
      qstr2fstr(stopdate, StopDate.toString("yyyyMMdd"), sizeof stopdate);       // Set stop date.
   }

   // Prepare to read from normal database. Name of the REA db is given.
   if (DbInfo.Type == normal_database_by_name) {
      qstr2fstr(dbname, DbInfo.Name, sizeof dbname);
      qstr2fstr(startdate, StartDate.toString("yyyyMMdd"), sizeof startdate);    // Set start date.
      qstr2fstr(stopdate, StopDate.toString("yyyyMMdd"), sizeof stopdate);       // Set stop date.
   }

   // Prepare to read from normal database. Path to the db folder is given.
   if (DbInfo.Type == normal_database_by_path) {
      dbpath = QDir::toNativeSeparators(dbpath).append("/");
      qstr2fstr(dbname, dbpath, sizeof dbname);                                  // Database name must be set to the database path.
      qstr2fstr(startdate, StartDate.toString("yyyyMMdd"), sizeof startdate);    // Set start date.
      qstr2fstr(stopdate, StopDate.toString("yyyyMMdd"), sizeof stopdate);       // Set stop date.
   }

   // Prepare to read from local database.
   if (DbInfo.Type == local_database) {
      qstr2fstr(dbname, QString(",,"), sizeof dbname);  // Database name must be set to ",,".
      dbpath = QDir::toNativeSeparators(dbpath);
      memset(startdate, 32, sizeof startdate);          // Start date is not used.
      memset(stopdate, 32, sizeof stopdate);            // Stop date is not used.
   }

   // Prepare to read from index file.
   if (DbInfo.Type == index_file) {
      qstr2fstr(dbname, DbInfo.Name, sizeof dbname);    // Full path to index file in 'dbname'.
      memset(startdate, 32, sizeof startdate);          // Start date is not used.
      memset(stopdate, 32, sizeof stopdate);            // Stop date is not used.
   }
}




// *******************************************************************
// This function scans a Seisan database for S-files, and stores all
// found S-files (with full path name) in QStringList 'sfilelist'.
// Function also reports on its progress by signaling class 'database'.
// Function also signals class 'database' when scanning is complete.
// *******************************************************************
void enumsfiles::run()
{
   char key[10], eventfile[81];
   QString CurrentDir, EventFile;
   int progress, last_progress, num_sfiles;
   sint fromeev, filenr, newmonth, status, fstart;

   // Clear the termination flag.
   mtx_terminate.lock();
   terminate = false;
   mtx_terminate.unlock();

   // Check if we are opening a local database.
   if (dbtype == local_database) {
      // Save current directory, and change current
      // working directory to folder with S-Files.
      CurrentDir = QDir::currentPath();
      QDir::setCurrent(dbpath);
   }

   // Call fortran function 'findevin' repeatedly to get all
   // S-files in database/indexfile. Files are added to 'sfilelist'.
   seisan_explorer_.se_out = 1;
   qstr2fstr(key, QString("start"), sizeof key);
   num_sfiles = last_progress = 0;
   fromeev = filenr = status = fstart = newmonth = 0;
   while (status == 0 && sfilelist->size() <= MAX_EVENTS) {
      memset(eventfile, 32, sizeof eventfile);
      findevin_(dbname, startdate, stopdate, key, &fromeev, &filenr, eventfile,
                &fstart, &newmonth, &status, sizeof dbname, sizeof startdate,
                sizeof stopdate, sizeof key, sizeof eventfile);
      qstr2fstr(key, QString("next"), sizeof key);

      if (status == 0) {
         // Append path to filename and add filename to 'sfilelist'.
         UnPadString(eventfile, sizeof eventfile);
         EventFile = eventfile;
         if (dbtype == local_database) EventFile.prepend(dbpath + "/");
         EventFile = QDir::cleanPath(EventFile);
         sfilelist->append(QDir::toNativeSeparators(EventFile));
         num_sfiles = sfilelist->size();

         // For every 1000 file, report progress and
         // check if thread has been asked to terminate.
         progress = (num_sfiles/1000)*1000;
         if (progress > last_progress) {
            // Save last progress value.
            last_progress = progress;

            // Inform db class of current progress.
            emit EnumSfilesProgress(progress);

            // Check if thread has been asked to terminate.
            mtx_terminate.lock();
            if (terminate) {
               mtx_terminate.unlock();
               // If we have opened an index file, then
               // change back to saved working directory.
               if (dbtype == local_database) QDir::setCurrent(CurrentDir);
               return;
            }
            mtx_terminate.unlock();
         }

         // Check number of file read against program limitation.
         if (num_sfiles == MAX_EVENTS+1) {
            // Remove the last read file from file list.
            sfilelist->removeLast();
            // If we have opened an index file, then
            // change back to saved working directory.
            if (dbtype == local_database) QDir::setCurrent(CurrentDir);
            // Signal database class that reading has been stopped.
            emit EnumSfilesDone(1);
            return;
         }
      }
   }

    // If we have opened a local database, then
    // change back to saved working directory.
    if (dbtype == local_database) QDir::setCurrent(CurrentDir);

    // Signal database class that reading is sucessfully done.
    emit EnumSfilesProgress(num_sfiles);
    emit EnumSfilesDone(0);
    return;
}




// **********************************************************
// This function can be called to stop the thread function.
// Thread will stop at the earliest convenience.
// **********************************************************
void enumsfiles::Cancel()
{
   // Check if thread is running.
   if (isRunning()) {
      // Set cancel signal.
      mtx_terminate.lock();
      terminate = true;
      mtx_terminate.unlock();
   }
}
