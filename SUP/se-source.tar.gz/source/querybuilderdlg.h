#ifndef QUERYBUILDERDLG_H
#define QUERYBUILDERDLG_H

#include <QDialog>
#include <QString>
#include <QTextCursor>

namespace Ui {
class QueryBuilderDlg;
}

class QueryBuilderDlg : public QDialog
{
   Q_OBJECT

public:
   explicit QueryBuilderDlg(QWidget *parent = 0);
   ~QueryBuilderDlg();
   void InitDialog(QString*, char);

public slots:
   // Operator buttons.
   void EqButton();
   void SmallerButton();
   void SmallerEqButton();
   void LargerButton();
   void LargerEqButton();
   void AndButton();
   void OrButton();
   void LeftParButton();
   void RightParButton();

   // Event properties buttons.
   void ActionButton();
   void AgencyButton();
   void AmplButton();
   void AmplPeriodButton();
   void BackAzimutButton();
   void CommentsButton();
   void CompButton();
   void CornFreqButton();
   void DateButton();
   void DepthButton();
   void DepthErrButton();
   void DistIndButton();
   void EpiDistButton();
   void EventIndButton();
   void GapButton();
   void HourButton();
   void LatButton();
   void LatErrButton();
   void LocalityButton();
   void LonButton();
   void LonErrButton();
   void MagbButton();
   void MagBButton();
   void MagButton();
   void MagCButton();
   void MagLButton();
   void MagsButton();
   void MagSButton();
   void MagWButton();
   void ModelButton();
   void NumFpsButton();
   void NumPolarButton();
   void NumStatButton();
   void PhaseNameButton();
   void QualityButton();
   void RmsButton();
   void StaCodeButton();
   void StrDropButton();
   void TrvlTmeResButton();
   void WeekDayButton();

   // Function buttons.
   void ContainsButton();
   void HasFpsButton();
   void HasMagnitudeButton();
   void HasStationButton();
   void InRangeButton();
   void IsFeltButton();
   void DistanceButton();
   void InPolygonButton();

   // 'OK' and 'Cancel' buttons.
   void accept();
   void reject();

private:
   Ui::QueryBuilderDlg *ui;
   QTextCursor cursor;
   QString *QExpr;
   char eType;
};

#endif // QUERYBUILDERDLG_H
