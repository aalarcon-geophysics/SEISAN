#ifndef DEBUG_H
#define DEBUG_H

#include "types.h"

void PhasesToConsole(event_node_*, QString);
void QStringToDebugFile(QString, bool);

#endif // DEBUG_H
