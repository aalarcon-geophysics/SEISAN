#ifndef SPEEDSEARCHDLG_H
#define SPEEDSEARCHDLG_H

#include <QDialog>
#include <QString>

#include "database.h"

namespace Ui {
   class SpeedSearchDlg;
}

class SpeedSearchDlg : public QDialog
{
   Q_OBJECT

public:
   explicit SpeedSearchDlg(QWidget *parent = 0);
   ~SpeedSearchDlg();
   void InitDialog(db*, char Key);

signals:
   void SpeedSearch(QString, bool);   // Slot used to signal the database.

public slots:
   void LineChanged();                // Slot used by the dialog box line widget.

private:
   Ui::SpeedSearchDlg *ui;
   QString Line;
   db *database;
   bool start;                        // Used to indicate start of search.
};

#endif // SPEEDSEARCHDLG_H
