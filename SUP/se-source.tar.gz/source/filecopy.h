#ifndef FILECOPY_H
#define FILECOPY_H

#include <QObject>
#include "logmodel.h"

struct fileinfo {
   QString FileName;
   QString SrcPath;
   QString DestPath;
   bool Overwrite;
};

typedef QList<struct fileinfo> QListFileCopyInf;

class filecopy
{
public:
   filecopy(logmodel*, QString LogMsgPrefix = QString());
   void AddFile(QString, QString, QString, bool);           // Add a file to be copied.
   void Clear();                                            // Clear the class instance.
   bool Copy();                                             // Copy the files.

private:
   logmodel *Log;
   QString LogMsgPrefix;
   QListFileCopyInf FileList;
};

#endif // FILECOPY_H
