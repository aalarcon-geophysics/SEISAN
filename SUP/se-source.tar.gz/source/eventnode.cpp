//
// This file contains functions related to database event nodes.
//

#include <QChar>
#include <QDebug>
#include <QString>
#include <QFileInfo>
#include <QStringList>
#include <QApplication>
#include "locale.h"
#include "library.h"
#include "fortran.h"
#include "eventnode.h"

// This large buffer/variable is placed here so
// that it goes on the heap instead of the stack.
// It is used by the WriteSFile/ReadSfile functions.
static char SFileData[MAX_SFILE_LINES][80];


// *********************************************************************************
// Locates an event using hypmain and return a located node. Returns pointer to
// new allocated node. Returns 0 if loacation fails. Messages from hypmain are
// returned in stringlist 'ReturnMsg'.
// *********************************************************************************
event_node_* NodeLocate(event_node_ *Node, QStringList *ReturnMsgs)
{
   QString Message;
   comblck_rea9* rea9 = &rea9_;
   signed int FromSE, LocStat, NumMesg;
   char TmpFile[80], Messages[80*2000], Line[81];

   // Clear list for return messages.
   ReturnMsgs->clear();

   // Create path/name for a temporary S-file.
   strcpy(TmpFile, "se-locate.tmp");

   // Write temporary S-file for hypmain using data from 'Node'.
   char Status; bool WriteOK;
   strcpy(Node->metadata.sfile, TmpFile);
   WriteOK = WriteSfile(Node, &Status);

   // If write failed, write error message in the log view.
   if (!WriteOK) {
      if (Status == 1) Message = "Unable to locate. Function 'rea_event_out' returned an error.";
      if (Status == 2) Message = "Unable to locate. Cannot open file '" + QString(TmpFile) + "'.";
      if (Status == 3) Message = "Unable to locate. Cannot write to file '" + QString(TmpFile) + "'.";
      ReturnMsgs->append(Message);
      QFile::remove(QString(TmpFile));
      return nullptr;
   }

   // Clear the rea9 common block.
   memset(rea9, 0, sizeof(comblck_rea9));

   // Call hypmain to locate. Function will update the common blocks.
   // Variable 'LocStat' returns value > 0 (true) if locate succeeds.
   // Messages are returned in variable 'Message' as a string with
   // up to 50 lines of 80 characters. NumMesg holds number of lines.
   PadString(TmpFile, sizeof(TmpFile)); memset(Messages, 32, sizeof(Messages));
   hypmain_((char*)TmpFile, &(FromSE=1), (char*)Messages, &NumMesg, &LocStat, sizeof(TmpFile), sizeof(Messages));
   UnPadString(TmpFile, sizeof(TmpFile));

   // Delete temporary file.
   QFile::remove(QString(TmpFile));

   // Save messages from hypmain to 'ReturnMsg'.
   for (int i=0;i<NumMesg;i++) {
      memcpy(Line, Messages+(i*80), 80);
      Line[80]=0; UnPadString(Line, sizeof(Line));
      ReturnMsgs->append(Line);
   }

   // If hypmain succeeded to locate the event,
   // return the result from the common blocks.
   // If hypmain failes, return zero.
   if (LocStat) return CreateNodeFromCommonBlocks();

   return nullptr;
}




// ***************************************************************
// This function returns a list of all wavefiles in an event file.
// ***************************************************************
void NodeGetWaveFiles(event_node_ *Node, QStringList *FileList)
{
   char line[81];

   // Clear the list.
   FileList->clear();

   // Create list of wavefiles.
   for (int i=0;i<Node->wavefiles.numlines;i++) {
      memcpy(line, Node->wavefiles.lines+i*80, 80);
      line[80]=0; FileList->append(line);
   }
}




// *********************************************************************
// This function copies all comment lines from a node to a QStringList
// structure. For each line in stringlist, the space in column one is
// removed, and so are all trailing spaces including the line number
// character (3) at column 79. Empty lines will be ignored.
// *********************************************************************
void NodeGetComments(event_node_ *Node, QStringList *CommentList)
{
   // Copy all comment lines to 'CommentList'.
   GetTextLines(&Node->comments, CommentList);
}




// *********************************************************************
// This function copies all comment lines from a QStringList structure
// to an event node. For each line, a space will be added to column one.
// Line will also be padded with spaces and the line number character
// (3) wil be added as well in column 79. The lines is assumed to no
// longer than 78 characters long.
// *********************************************************************
bool NodeIsRegistered(event_node_ *Node)
{
    QString Action;
    NodeGetIdlineAction(Node, &Action);
    if (Action.toUpper() == "UP") return true;
    if (Action.toUpper() == "UPD") return true;
    if (Action.toUpper() == "REG") return true;
    if (Action.toUpper() == "REE") return true;
    return false;
}




// *********************************************************************
// This function copies all comment lines from a QStringList structure
// to an event node. For each line, a space will be added to column one.
// Line will also be padded with spaces and the line number character
// (3) wil be added as well in column 79. The lines is assumed to be no
// longer than 78 characters long.
// *********************************************************************
void NodeSetComments(event_node_ *Node, QStringList Comments)
{
   QString line;

   // Free all existing comment lines.
   if (Node->comments.numlines) {
      Node->comments.numlines = 0;
      delete [] Node->comments.lines;
      Node->comments.lines = (char*) nullptr;
   }

   // Add new comment lines if any.
   if (Comments.size()) {
      // Allocate memory for new comment lines.
      Node->comments.lines = new (std::nothrow) char [Comments.size()*80];
      if (!Node->comments.lines) return;
      // Add new comment lines to node.
      for (int i=0;i<Comments.size();i++) {
         line = Comments.at(i);
         line.insert(0, QChar(' '));
         line.insert(79, QChar('3'));
         memcpy(Node->comments.lines+i*80, line.toLocal8Bit().data(), 80);
      }
      Node->comments.numlines = Comments.size();
   }
}




// *********************************************************************
// This function adds a comment line to a node.
// *********************************************************************
void NodeAddComment(event_node_ *Node, QString Comment)
{
     // Check that Comment is not empty.
     if (!Comment.size()) return;

     // Add new comment to CommentList.
     AddTextLine(&Node->comments, Comment, QChar('3'));
}




// *********************************************************************
// This function adds a hypocenter to a node.
// *********************************************************************
bool NodeAddHypocenter(event_node_ *Node, hypocenter_ *HypoCenter)
{
   hypocenter_ *NewHypo, *pHypo, *pLastHypo;

   // Allocate memory for the new hypocenter.
   NewHypo = new hypocenter_;

   // Return if memory allocation failed.
   if (!NewHypo) return false;

   // Copy user data to the allocated hypocenter.
   *NewHypo = *HypoCenter; NewHypo->next = nullptr;

   // Get pointer to the last hypocenter in the node.
   if (Node->hypocenters.first) {
      // Node already has one or more hypocenters.
      pHypo = pLastHypo = Node->hypocenters.first;
      while (pHypo) { pLastHypo = pHypo; pHypo = pHypo->next; }
      // Attach the new hypocenter to the list of hypocenters.
      Node->hypocenters.nhyp++;
      pLastHypo->next = NewHypo;
   } else {
      // Node has no hypocenters.
      Node->hypocenters.nhyp = 1;
      Node->hypocenters.first = NewHypo;
   }

    return true;
}




// **********************************************************************
// This function adds a line to a text_lines structure.
// **********************************************************************
void AddTextLine(text_lines *TextLines, QString Line, QChar LineType)
{
   QStringList TextList;

   // Check that line is not empty.
   if (!Line.size()) return;

   // Read all existing lines into TextList.
   GetTextLines(TextLines, &TextList);

   // Add new line to TextList.
   TextList.append(Line.trimmed());

   // Write TextList back to the event node.
   SetTextLines(TextLines, TextList, LineType);
}




// *********************************************************************
// This function copies all lines from a text_lines structure to a
// QStringList structure. For each line, the space in column one is
// removed, and so are all trailing spaces including the line number
// character at column 80. Empty lines will be ignored.
// *********************************************************************
void GetTextLines(text_lines *TextLines, QStringList *Lines)
{
   QString qsline;
   char line[81];

   // Copy all comment lines to 'CommentList'.
   for (int i=0;i<TextLines->numlines;i++) {
      memcpy(line, TextLines->lines+i*80, 80);
      line[80]=0; qsline = line; qsline[79] = 32;
      qsline.remove(0, 1); UnPadQString(&qsline);
      if (qsline.size()) Lines->append(qsline);
   }
}




// *********************************************************************
// This function returns the number of magnitudes in a hypocenter.
// *********************************************************************
int HypGetNumberOfMagnitudes(hypocenter_ *Hypo)
{
   int NumMags;
   NumMags  = Hypo->magnitudes.MW.nmag;
   NumMags += Hypo->magnitudes.ML.nmag;
   NumMags += Hypo->magnitudes.MN.nmag;
   NumMags += Hypo->magnitudes.MC.nmag;
   NumMags += Hypo->magnitudes.Mb.nmag;
   NumMags += Hypo->magnitudes.MB.nmag;
   NumMags += Hypo->magnitudes.Ms.nmag;
   NumMags += Hypo->magnitudes.MS.nmag;
   NumMags += Hypo->magnitudes.MU.nmag;

   return NumMags;
}




// **********************************************************
// This function initializes all values in a hypocenter.
// **********************************************************
void HypInitialize(hypocenter_ *Hypo)
{
   Hypo->time.year = Hypo->time.month = Hypo->time.day = -999;
   Hypo->time.hour = Hypo->time.minute = Hypo->time.second = -999;
   Hypo->lat = Hypo->lon = Hypo->depth = Hypo->nstat = -999;
   Hypo->rms = Hypo->gap = Hypo->sec_err = Hypo->lat_err = -999;
   Hypo->lon_err = Hypo->depth_err = -999;
   Hypo->modl_id = Hypo->dist_id = Hypo->evnt_id = Hypo->fix_org = 32;
   Hypo->depth_flag = Hypo->epi_flag = 32;
   Hypo->agency[0] = Hypo->autoproc[0] = 0;
   Hypo->high_accuracy = Hypo->error = 0;
   Hypo->cov[0] = Hypo->cov[1] = Hypo->cov[2] = -9.9e10;
   Hypo->magnitudes.MW.nmag = Hypo->magnitudes.ML.nmag = 0;
   Hypo->magnitudes.MN.nmag = Hypo->magnitudes.MC.nmag = 0;
   Hypo->magnitudes.Mb.nmag = Hypo->magnitudes.MB.nmag = 0;
   Hypo->magnitudes.Ms.nmag = Hypo->magnitudes.MS.nmag = 0;
   Hypo->magnitudes.MU.nmag = 0;
   for (int i=0;i<6;i++) {
      Hypo->magnitudes.MW.mag[i] = -999.0;
      Hypo->magnitudes.MW.mag_agency[i][0] = 0;
      Hypo->magnitudes.MW.order[i] = -999.0;
      Hypo->magnitudes.ML.mag[i] = -999.0;
      Hypo->magnitudes.ML.mag_agency[i][0] = 0;
      Hypo->magnitudes.ML.order[i] = -999.0;
      Hypo->magnitudes.MN.mag[i] = -999.0;
      Hypo->magnitudes.MN.mag_agency[i][0] = 0;
      Hypo->magnitudes.MN.order[i] = -999.0;
      Hypo->magnitudes.MC.mag[i] = -999.0;
      Hypo->magnitudes.MC.mag_agency[i][0] = 0;
      Hypo->magnitudes.MC.order[i] = -999.0;
      Hypo->magnitudes.Mb.mag[i] = -999.0;
      Hypo->magnitudes.Mb.mag_agency[i][0] = 0;
      Hypo->magnitudes.Mb.order[i] = -999.0;
      Hypo->magnitudes.MB.mag[i] = -999.0;
      Hypo->magnitudes.MB.mag_agency[i][0] = 0;
      Hypo->magnitudes.MB.order[i] = -999.0;
      Hypo->magnitudes.Ms.mag[i] = -999.0;
      Hypo->magnitudes.Ms.mag_agency[i][0] = 0;
      Hypo->magnitudes.Ms.order[i] = -999.0;
      Hypo->magnitudes.MS.mag[i] = -999.0;
      Hypo->magnitudes.MS.mag_agency[i][0] = 0;
      Hypo->magnitudes.MS.order[i] = -999.0;
      Hypo->magnitudes.MU.mag[i] = -999.0;
      Hypo->magnitudes.MU.mag_agency[i][0] = 0;
      Hypo->magnitudes.MU.order[i] = -999.0;
   }
   Hypo->next = nullptr;
}




// ****************************************************************************
// This function set text lines in a text_lines structure. All existing lines
// will be deleted. A line number character will be added as well in column 80.
// The lines is assumed to no longer than 78 characters long.
// ****************************************************************************
void SetTextLines(text_lines *TextLines, QStringList Lines, QChar LineType)
{
   QString line;

   // Free all existing lines from structure.
   if (TextLines->numlines) {
      TextLines->numlines = 0;
      delete [] TextLines->lines;
      TextLines->lines = (char*) nullptr;
   }

   // Add lines to structure.
   if (Lines.size()) {
      // Allocate memory for lines.
      TextLines->lines = new (std::nothrow) char [Lines.size()*80];
      if (!TextLines->lines) return;
      // Add new lines.
      for (int i=0;i<Lines.size();i++) {
         line = Lines.at(i);
         line.insert(0, QChar(' '));
         line.insert(79, LineType); // This also extends the line to 80 characters.
         memcpy(TextLines->lines+i*80, line.toLocal8Bit().data(), 80);
      }
      TextLines->numlines = Lines.size();
   }
}




// *********************************************************************
// This function sets the ACTION parameter for the ID-line in a node.
// *********************************************************************
void NodeGetIdlineAction(event_node_ *Node, QString *Action)
{
   //Get the ID line from the node.
   QString IdLine = Node->id_line;

   // Return the ACTION parameter.
   *Action = IdLine.mid(8, 3).trimmed();
}




// *********************************************************************
// This function sets the ACTION parameter for the ID-line in a node.
// *********************************************************************
void NodeSetIdlineAction(event_node_ *Node, QString Action)
{
   // Check that Action is not empty.
   if (!Action.size()) return;

   // Extend Action to 3 characters if needed.
   if (Action.size() < 3) Action = Action.leftJustified(3);

   //Get the ID line from the node.
   QString IdLine = Node->id_line;

   // Set ACTION parameter in column 9.
   IdLine.replace(8, 3, Action);

   // Write updated line back to node.
   strcpy(Node->id_line, IdLine.toLatin1().data());
}




// **********************************************************************
// This function sets update time for the ID-line in a node.
// Current UTC date and time is used.
// **********************************************************************
void NodeSetIdlineUpdatetime(event_node_ *Node)
{
   //Get the ID line from the node.
   QString IdLine = Node->id_line;

   // Set date and time parameter in column 13.
   QDateTime DateTime = QDateTime::currentDateTimeUtc();
   IdLine.replace(12,14, DateTime.toString("yy-MM-dd hh:mm"));

   // Write updated line back to node.
   strcpy(Node->id_line, IdLine.toLatin1().data());
}




// *********************************************************************
// This function sets the operator code for the ID-line in a node.
// *********************************************************************
void NodeSetIdlineOperator(event_node_ *Node, QString Operator)
{
   // Check that operator is not empty.
   if (!Operator.size()) return;

   // Extend operator to 4 characters if needed.
   if (Operator.size() < 4) Operator = Operator.leftJustified(4);

   //Get the ID line from the node.
   QString IdLine = Node->id_line;

   // Set operator code in column 31.
   IdLine.replace(30, 4, Operator.toUpper());

   // Write updated line back to node.
   strcpy(Node->id_line, IdLine.toLatin1().data());
}




// *********************************************************************
// This function sets the ID code for the ID-line in a node. The
// ID code is taken from the ID parameter (if it has been given).
// Otherwice, the ID string is generated from 'metadata.sfile'.
// *********************************************************************
void NodeSetIdlineID(event_node_ *Node, QString ID)
{
   QString IdLine, FileName, IdString;

   // If ID string is given, it must be 14 characters.
   if (ID.size()) if (ID.size() != 14) return;

   // Get the ID line from the node.
   IdLine = Node->id_line;

   // Insert ID string into ID line.
   if (ID.size()) {
      // A 14 character ID has been gived in ID parameter.
      IdLine.replace(60, 14, ID);
   } else {
      // An ID has not been given in ID parameter. Create the ID from the file name.
      FileName = GetNameFromFilePath(QString(Node->metadata.sfile));
      IdString = FileName.mid(13, 6) + FileName.mid(0, 2) + FileName.mid(3, 4) + FileName.mid(8, 2);
      IdLine.replace(60, 14, IdString);
   }

   // Write ID line back to event node.
   strcpy(Node->id_line, IdLine.toLatin1().data());
}




// *********************************************************************
// This function returns the ID for the ID-line in a node.
// *********************************************************************
QString NodeGetIdlineID(event_node_ *Node)
{
   // Get the ID line ID from the node.
   return QString(Node->id_line).mid(60, 14);
}


// *********************************************************************
// This function sets a file name for the S-file based on the
// date, time and distance-id found in the first hypocenter.
// Function returns true if file name has been changed.
// Function returns false if file name did not have to be changed.
// *********************************************************************
bool NodeSetFileNameFromHypo(event_node_ *Node)
{
   QString ID, FileName, NewFileName;
   QString Year, Month, Day, Hour, Minute, Second;

   // Get the file name.
   FileName = QString(Node->metadata.sfile);

   // Get the length of the full file name including the path.
   int len = FileName.size();

   // Modify file name using data from first hypocenter.
   NewFileName = Node->metadata.sfile;
   Year = QString("%1").arg(Node->hypocenters.first->time.year, 4, 10, QChar('0'));
   NewFileName.replace(len-6, 4, Year);
   Month = QString("%1").arg(Node->hypocenters.first->time.month, 2, 10, QChar('0'));
   NewFileName.replace(len-2, 2, Month);
   Day = QString("%1").arg(Node->hypocenters.first->time.day, 2, 10, QChar('0'));
   NewFileName.replace(len-19, 2, Day);
   Hour = QString("%1").arg(Node->hypocenters.first->time.hour, 2, 10, QChar('0'));
   NewFileName.replace(len-16, 2, Hour);
   Minute = QString("%1").arg(Node->hypocenters.first->time.minute, 2, 10, QChar('0'));
   NewFileName.replace(len-14, 2, Minute);
   Second = QString("%1").arg((int)Node->hypocenters.first->time.second, 2, 10, QChar('0'));
   NewFileName.replace(len-11, 2, Second);
   ID = QString(Node->hypocenters.first->dist_id).toUpper();
   NewFileName.replace(len-9, 1, ID);

   // Return false if file name will not change.
   if (NewFileName == FileName) return false;

   // File name will change. Set new filename.
   strcpy(Node->metadata.sfile, NewFileName.toLatin1().data());

   // Update the ID-line so it corresponds to the new file name.
   ID = Year + Month + Day + Hour + Minute + Second;
   NodeSetIdlineID(Node, ID);

   return true;
}




// *****************************************************************
// This function resolves a file name conflict for the given node in
// the given directory.
// *****************************************************************
void NodeSetUniqueFileName(event_node_* Node)
{
   // Get a unique name for the S-file.
   QString File = Node->metadata.sfile;
   while (QFile::exists(File)) AddOneSecToSfileName(&File);

   // Save new file name to the node.
   strcpy(Node->metadata.sfile, File.toLocal8Bit().data());
}




// *********************************************************************
// This function is used to return a single property value
// for a node. The value returned is either a float or a string.
// *********************************************************************
void NodeGetProperty(event_node_ *node, QString property, prop_value *value)
{
   int count;
   phase_ *phase;
   QStringList StrList;

   // Initialize 'novalue'.
   value->novalue = false;

   // These properties return a numerical value.
   value->valueType = 0;
   if (property == "$LAT") {
      value->number = node->hypocenters.first->lat;
      return;
   }
   if (property == "$LON") {
      value->number = node->hypocenters.first->lon;
      return;
   }
   if (property == "$DEPTH") {
      value->number = node->hypocenters.first->depth;
      return;
   }
   if (property == "$RMS") {
      value->number = node->hypocenters.first->rms;
      return;
   }
   if (property == "$GAP") {
      value->number = node->hypocenters.first->gap;
      return;
   }
   if (property == "$HOUR") {
      value->number = (float)node->hypocenters.first->time.hour;
      return;
   }
   if (property == "$NUMSTAT") {
      value->number = (float)node->hypocenters.first->nstat;
      return;
   }
   if (property == "$NUMMACROS") {
      value->number = (float)node->macros.numlines;
      return;
   }
   if (property == "$MAG") {
      if (!node->hypocenters.nmag) { value->number = -999; return; }
      value->number = node->hypocenters.mag_all[0].mag;
      return;
   }
   if (property == "$LATERR") {
      value->number = node->hypocenters.first->lat_err;
      return;
   }
   if (property == "$LONERR") {
      value->number = node->hypocenters.first->lon_err;
      return;
   }
   if (property == "$DEPTHERR") {
      value->number = node->hypocenters.first->depth_err;
      return;
   }
   if (property == "$NUMFPS") {
      value->number = node->faults.numlines;
      return;
   }
   if (property == "$NUMPOL") {
      count = 0;
      if (node->phases.nphase) {
         phase = node->phases.first;
         for (int i=0;i<node->phases.nphase;i++) {
            if (phase->polarity != 32) count++;
            phase = phase->next;
         }
      }
      value->number = count; return;
   }

   // These properties return a string value.
   value->valueType = 1;
   if (property == "$ACTION") {
      if (!strlen(node->action)) { value->string = ""; return; }
      value->string = QString(node->action).toUpper();
      return;
   }
   if (property == "$MODEL") {
      if (node->hypocenters.first->modl_id == 32) { value->string = ""; return; }
      value->string = QString(node->hypocenters.first->modl_id);
      return;
   }
   if (property == "$AGENCY") {
      if (!strlen(node->hypocenters.first->agency)) { value->string = ""; return; }
      value->string = QString(node->hypocenters.first->agency).trimmed().toUpper();
      return;
   }
   if (property == "$DISTIND") {
      if (node->hypocenters.first->dist_id == 32) { value->string = ""; return; }
      value->string = QString(node->hypocenters.first->dist_id).toUpper();
      return;
   }
   if (property == "$EVENTIND") {
      if (node->hypocenters.first->evnt_id == 32) { value->string = ""; return; }
      value->string = QString(node->hypocenters.first->evnt_id).toUpper();
      return;
   }
   if (property == "$LOCALITY") {
      if (!strlen(node->locality)) { value->string = ""; return; }
      value->string = QString(node->locality).toUpper();
      return;
   }
   if (property == "$COMMENTS") {
      if (!node->comments.numlines) { value->string = ""; return; }
      value->string.clear(); NodeGetComments(node, &StrList);
      for (int i=0;i<StrList.size();i++) value->string.append(StrList.at(i) + " ");
      return;
   }
   if (property == "$DATE") {
      value->string = node->metadata.datetime;
      value->string.chop(4);
      return;
   }
}




// *****************************************************************************
// This function is used to return a single property value for a phase line in
// the node. The value returned in 'value' is either a float, or a string, or
// nothing if no value exists for the property.
// *****************************************************************************
void NodeGetStationProperty(phase_ *phase, QString property, prop_value *value)
{
   // Initialize 'novalue'.
   value->novalue = false;

   // Make property uppercase.
   property = property.toUpper();

   // These properties return a numerical value.
   value->valueType = 0;
   if (property == "$EPIDIST") {
      value->number = phase->dist;
      if (value->number == -999) value->novalue = true;
      return;
   }
   if (property == "$AMPL") {
      value->number = phase->amp;
      if (value->number == -999) value->novalue = true;
      return;
   }
   if (property == "$AMPLPERIOD") {
      value->number = phase->per;
      if (value->number == -999) value->novalue = true;
      return;
   }
   if (property == "$BACKAZIMUT") {
      value->number = phase->baz_obs;
      if (value->number == -999) value->novalue = true;
      return;
   }
   if (property == "$TRVLTMERES") {
      value->number = phase->res;
      if (value->number == -999) value->novalue = true;
      return;
   }
   if (property == "$STRDROP") {
      value->number = phase->spectral.sdrop;
      if (value->number == -999) value->novalue = true;
      return;
   }
   if (property == "$CORNFREQ") {
      value->number = phase->spectral.cornerf;
      if (value->number == -999) value->novalue = true;
      return;
   }

   // These properties return a string value.
   value->valueType = 1;
   if (property == "$STACODE") {
      if (!strlen(phase->station)) { value->string = ""; return; }
      value->string = QString(phase->station).toUpper(); return;
   }
   if (property == "$PHASENAME") {
      if (!strlen(phase->phase)) { value->string = ""; return; }
      value->string = QString(phase->phase).toUpper(); return;
   }
   if (property == "$COMP") {
      if (strlen(phase->comp3)) { value->string = QString(phase->comp3).toUpper(); return; }
      if (strlen(phase->comp2)) { value->string = QString(phase->comp2).toUpper(); return; }
      value->string = ""; return;
   }
}




// ***************************************************************
// This function is used to check if a node has a
// fault plane solution with a particular quality.
// ***************************************************************
bool NodeHasFpsQuality(event_node_ *Node, QString Quality)
{
   char line[81];
   QString NodeQuality;

   // Search all lines for the FPS quality.
   Quality = Quality.toUpper();
   for (int i=0;i<Node->faults.numlines;i++) {
      memcpy(line, Node->faults.lines+i*80, 80); line[80]=0;
      NodeQuality = line[77];
      NodeQuality = NodeQuality.trimmed().toUpper();
      if (NodeQuality == Quality) return true;
   }
   return false;
}




// ********************************************************************************
// This function returns a list of all fault plane solutions.
// Agency and quality are returned.
// ********************************************************************************
void NodeGetAllFPS(event_node_ *node, QList<agency_fps> *AgencyFPSList)
{
   agency_fps AgencyFps;
   char line[81], agency[4];

   // Create a list off all agencies that has a magnitude.
   for (int i=0;i<node->faults.numlines;i++) {
      // Get the line.
      memcpy(line, node->faults.lines+i*80, 80); line[80]=0;
      // Get the agency.
      memcpy(agency, line+66, 3); agency[3] = 0;
      AgencyFps.agency = agency;
      AgencyFps.agency = AgencyFps.agency.trimmed().toUpper();
      // Get the quality.
      AgencyFps.quality = line[77];
      AgencyFps.quality = AgencyFps.quality.trimmed().toUpper();
      // Add agency magnitudes to list.
      AgencyFPSList->append(AgencyFps);
   }
}




// **********************************************************************************
// This function is used to check if a node has a magnitude of a particular type.
// **********************************************************************************
bool NodeHasMagType(event_node_ *node, QString Type)
{
   QString NodeType;

   // Look for type in all magnitudes.
   for (int i=0;i<node->hypocenters.nmag;i++) {
      NodeType = node->hypocenters.mag_all[i].type;
      if (Type == NodeType) return true;
   }
   return false;
}




// ********************************************************************************
// This function returns a list of agencies and their
// corresponding magnitudes from all hypocenters.
// ********************************************************************************
void NodeGetAllHypocenterMags(event_node_ *node, QList<agency_mags> *AgencyMagsList)
{
   float Mag;
   QString Agency, Type;
   agency_mags AgencyMags;
   QStringList AgencyList;

   // Create a list off all agencies that has a magnitude.
   for (int i=0;i<node->hypocenters.nmag;i++) {
      Agency = QString(node->hypocenters.mag_all[i].agency).toUpper().trimmed();
      if (!AgencyList.contains(Agency)) AgencyList.append(Agency);
   }

   // Create a table listing all agencies and their corresponding magnitudes.
   AgencyMags.MB = AgencyMags.Mb = AgencyMags.MC = AgencyMags.ML = -999;
   AgencyMags.MN = AgencyMags.MS = AgencyMags.Ms = AgencyMags.MW = -999;
   for (int i=0;i<AgencyList.size();i++) {
      AgencyMags.agency = AgencyList.at(i);
      for (int j=0;j<node->hypocenters.nmag;j++) {
         Type = QString(node->hypocenters.mag_all[j].type);
         Agency = QString(node->hypocenters.mag_all[j].agency).toUpper().trimmed();
         if (Agency == AgencyMags.agency) {
            Mag = node->hypocenters.mag_all[j].mag;
            if (Type == "B") AgencyMags.MB = Mag;
            if (Type == "b") AgencyMags.Mb = Mag;
            if (Type == "S") AgencyMags.MS = Mag;
            if (Type == "s") AgencyMags.Ms = Mag;
            if (Type == "C") AgencyMags.MC = Mag;
            if (Type == "L") AgencyMags.ML = Mag;
            if (Type == "N") AgencyMags.MN = Mag;
            if (Type == "W") AgencyMags.MW = Mag;
         }
      }
      // Add agency magnitudes to list.
      AgencyMagsList->append(AgencyMags);
   }
}




// ********************************************************************************
// This function returns a list of agencies and their
// corresponding magnitudes from the primary hypocenter.
// ********************************************************************************
void NodeGetPriHypocenterMags(event_node_ *node, QList<agency_mags> *AgencyMagsList)
{
   QString Agency;
   hypocenter_ *hyp;
   agency_mags AgencyMags;
   QStringList AgencyList;

   // Create a pointer to the primary hypocenter.
   hyp = node->hypocenters.first;

   // Create a list off all agencies that has a magnitude.
   for (int i=0;i<hyp->magnitudes.MB.nmag;i++) {
      Agency = QString(hyp->magnitudes.MB.mag_agency[i]).toUpper().trimmed();
      if (!AgencyList.contains(Agency)) AgencyList.append(Agency);
   }
   for (int i=0;i<hyp->magnitudes.Mb.nmag;i++) {
      Agency = QString(hyp->magnitudes.Mb.mag_agency[i]).toUpper().trimmed();
      if (!AgencyList.contains(Agency)) AgencyList.append(Agency);
   }
   for (int i=0;i<hyp->magnitudes.MC.nmag;i++) {
      Agency = QString(hyp->magnitudes.MC.mag_agency[i]).toUpper().trimmed();
      if (!AgencyList.contains(Agency)) AgencyList.append(Agency);
   }
   for (int i=0;i<hyp->magnitudes.ML.nmag;i++) {
      Agency = QString(hyp->magnitudes.ML.mag_agency[i]).toUpper().trimmed();
      if (!AgencyList.contains(Agency)) AgencyList.append(Agency);
   }
   for (int i=0;i<hyp->magnitudes.MN.nmag;i++) {
      Agency = QString(hyp->magnitudes.MN.mag_agency[i]).toUpper().trimmed();
      if (!AgencyList.contains(Agency)) AgencyList.append(Agency);
   }
   for (int i=0;i<hyp->magnitudes.MS.nmag;i++) {
      Agency = QString(hyp->magnitudes.MS.mag_agency[i]).toUpper().trimmed();
      if (!AgencyList.contains(Agency)) AgencyList.append(Agency);
   }
   for (int i=0;i<hyp->magnitudes.Ms.nmag;i++) {
      Agency = QString(hyp->magnitudes.Ms.mag_agency[i]).toUpper().trimmed();
      if (!AgencyList.contains(Agency)) AgencyList.append(Agency);
   }
   for (int i=0;i<hyp->magnitudes.MW.nmag;i++) {
      Agency = QString(hyp->magnitudes.MW.mag_agency[i]).toUpper().trimmed();
      if (!AgencyList.contains(Agency)) AgencyList.append(Agency);
   }

   // Create a table listing all agencies and their corresponding magnitudes.
   AgencyMags.MB = AgencyMags.Mb = AgencyMags.MC = AgencyMags.ML = -999;
   AgencyMags.MN = AgencyMags.MS = AgencyMags.Ms = AgencyMags.MW = -999;
   for (int i=0;i<AgencyList.size();i++) {
      AgencyMags.agency = AgencyList.at(i);
      for (int j=0;j<hyp->magnitudes.MB.nmag;j++) {
         Agency = QString(hyp->magnitudes.MB.mag_agency[j]).toUpper().trimmed();
         if (Agency == AgencyMags.agency) AgencyMags.MB = hyp->magnitudes.MB.mag[j];
      }
      for (int j=0;j<hyp->magnitudes.Mb.nmag;j++) {
         Agency = QString(hyp->magnitudes.Mb.mag_agency[j]).toUpper().trimmed();
         if (Agency == AgencyMags.agency) AgencyMags.Mb = hyp->magnitudes.Mb.mag[j];
      }
      for (int j=0;j<hyp->magnitudes.MC.nmag;j++) {
         Agency = QString(hyp->magnitudes.MC.mag_agency[j]).toUpper().trimmed();
         if (Agency == AgencyMags.agency) AgencyMags.MC = hyp->magnitudes.MC.mag[j];
      }
      for (int j=0;j<hyp->magnitudes.ML.nmag;j++) {
         Agency = QString(hyp->magnitudes.ML.mag_agency[j]).toUpper().trimmed();
         if (Agency == AgencyMags.agency) AgencyMags.ML = hyp->magnitudes.ML.mag[j];
      }
      for (int j=0;j<hyp->magnitudes.MN.nmag;j++) {
         Agency = QString(hyp->magnitudes.MN.mag_agency[j]).toUpper().trimmed();
         if (Agency == AgencyMags.agency) AgencyMags.MN = hyp->magnitudes.MN.mag[j];
      }
      for (int j=0;j<hyp->magnitudes.MS.nmag;j++) {
         Agency = QString(hyp->magnitudes.MS.mag_agency[j]).toUpper().trimmed();
         if (Agency == AgencyMags.agency) AgencyMags.MS = hyp->magnitudes.MS.mag[j];
      }
      for (int j=0;j<hyp->magnitudes.Ms.nmag;j++) {
         Agency = QString(hyp->magnitudes.Ms.mag_agency[j]).toUpper().trimmed();
         if (Agency == AgencyMags.agency) AgencyMags.Ms = hyp->magnitudes.Ms.mag[j];
      }
      for (int j=0;j<hyp->magnitudes.MW.nmag;j++) {
         Agency = QString(hyp->magnitudes.MW.mag_agency[j]).toUpper().trimmed();
         if (Agency == AgencyMags.agency) AgencyMags.MW = hyp->magnitudes.MW.mag[j];
      }

      // Add agency magnitudes to list.
      AgencyMagsList->append(AgencyMags);
   }
}




// ********************************************************************************
// This function returns the list of phases.
// ********************************************************************************
void NodeGetPhases(event_node_ *Node, QListPhase *PhaseList)
{
   // Clear the list.
   PhaseList->clear();

   // Return if node has no phases.
   if (!Node->phases.nphase) return;

   // Return the phases.
   phase_ *phase = Node->phases.first;
   while (phase) { PhaseList->append(*phase); phase = phase->next; }
}




// ********************************************************************************
// This function sets phases for a node. All exisitng phases are deleted.
// if PhaseList is empty, then all existing phases for the node will be deleted.
// ********************************************************************************
bool NodeSetPhases(event_node_ *Node, QListPhase *PhaseList)
{
   phase_ *Phase, *NextPhase, *LastPhase;

   // Remove all existing phases.
   if (Node->phases.nphase) {
      Phase = Node->phases.first;
      while (Phase) {
         NextPhase = Phase->next;
         delete Phase;
         Phase = NextPhase;
      }
   }
   Node->phases.nphase = 0;

   // Return here if PhaseList is empty.
   if (PhaseList->isEmpty()) return true;

   // Add first phase in PhaseList to the node.
   LastPhase = Phase = new (std::nothrow) phase_;
   *Phase = PhaseList->at(0);
   Node->phases.nphase = 1;
   Node->phases.first = Phase;
   Node->phases.first->next = nullptr;

   // Return if there are no more phases.
   if (PhaseList->size() == 1) return true;

   // Add the rest of the phases.
   for (int i=1;i<PhaseList->size();i++) {
      Phase = new (std::nothrow) phase_;
      LastPhase->next = Phase;
      *Phase = PhaseList->at(i);
      Phase->next = nullptr;
      Node->phases.nphase ++;
      LastPhase = Phase;
   }

   return true;
}





// ********************************************************************************
// This function returns a list of agencies and their
// corresponding magnitudes from the primary hypocenter.
// ********************************************************************************
void NodeGetPriHypocenterDateTime(event_node_ *node, QString *Date, QString *Time)
{
   hypocenter_ *hyp;

   // Create a pointer to the primary hypocenter.
   hyp = node->hypocenters.first;

   // Get the date.
   Date->clear();
   *Date = QString::number(node->hypocenters.first->time.year);
   Date->append(QString("%1").arg(hyp->time.month, 2, 10, QChar('0')));
   Date->append(QString("%1").arg(hyp->time.day, 2, 10, QChar('0')));

   // Get the time.
   Time->clear();
   Time->append(QString("%1").arg(hyp->time.hour, 2, 10, QChar('0')));
   Time->append(QString("%1").arg(hyp->time.minute, 2, 10, QChar('0')));
   Time->append(QString("%1").arg((int)hyp->time.second, 2, 10, QChar('0')));
}




// **************************************************************************************
// This reads a single S-file into a database node structure.
// Memory for the node is allocated in this function.
//
// Return values:
// 1 - A pointer to the new node.
// 2 - A status value is returnes in 'status'.
// 3 - Error messages from rea_event_in is returned in 'problems'. File not read.
//
// The following status values are used:
// 0 - No error or warning. File is read.
// 1 - Unable to open S-file. File not read.
// 2 - Function rea_event_in() returned an error (see 'problems'). File not read.
// 3 - Memory allocation failed, we are out of memory. File not read.
// 4 - Function rea_event_in() returned a non-fatal error (see 'problems'). File is read.
// 5 - S-file has an invalid date. File not read.
// 6 - S-file is empty.
// **************************************************************************************
event_node_* ReadSfile(char* file, char *status, QStringList *problems)
{
   QFile Sfile;
   QDate fDate;
   event_node_ *Node;
   sint unit, read_code, all;
   hypocenter_ *HypData;
   char line[192];

   // Create new pointers to fortran common blocks.
   // This is done to simplify debugging in Qt Creator.
   comblck_hyp4* hyp4 = &hyp4_; comblck_rea4* rea4 = &rea4_;

   // Clear the 'problems' message list.
   if (problems) problems->clear();


   // Open the S-file. Abort if file cannot be opened.
   *status = 0;
   Sfile.setFileName(file);
   if (!Sfile.open(QIODevice::ReadOnly | QIODevice::Text)) { *status = 1; return nullptr; }

   // Abort if file is empty.
   if (!Sfile.size()) { *status = 6; return nullptr; }

   // Read S-file into the SFileData array.
   memset(SFileData, 32, sizeof(SFileData));
   bool Done = false; size_t LineLength;
   rea4_.rea_nrecord = rea4->rea_nhead = 0;
   while(!Done && rea4->rea_nrecord<MAX_SFILE_LINES) {
      LineLength = static_cast<size_t>(Sfile.readLine(line, sizeof(line)));
      if (LineLength >=3 && !IsDataLineEmpty(line, LineLength)) {
         memset(SFileData[rea4->rea_nrecord], 32, 80);
         memcpy(SFileData[rea4->rea_nrecord], line, LineLength-1);
         if (LineLength == 81 && line[79] != 32 && line[79] != '4') rea4->rea_nhead++;
         rea4->rea_nrecord++;
      }
      Done = Sfile.atEnd();
   }

   // Close the S-file.
   Sfile.close();

   // Read S-file from SFileData array into common blocks. On linux,
   // the LC_NUMERIC locale setting must be temporarily set to
   // POSIX to avoid problems with decimal point when using
   // a locale that has a decimal point other than '.'(dot).
   #ifdef Q_OS_LINUX
   char *locale = setlocale(LC_NUMERIC, NULL); setlocale(LC_NUMERIC, "POSIX");
   #endif
   rea_event_in_(&(unit=0), &(all=1), (char*)SFileData, &(read_code=-1), sizeof(SFileData));
   #ifdef Q_OS_LINUX
   setlocale(LC_NUMERIC, locale);
   #endif

   // Handle errors and warnings from common block 'rea_mes'.
   if (read_code) {
      // Copy any messages from rea_event_in() to the 'problems' list.
      if (problems) GetReaMesMessages(problems);
      // Set or return error codes.
      if (read_code == 1) { *status = 2; return nullptr; }
      if (read_code == 2) *status = 4;
      if (read_code == 3) { *status = 2; return nullptr; }
   }

   // Abort if no header lines have been read.
   if (!rea4->rea_nhead) {
       if (problems) problems->append("No header lines was read.");
       *status = 2; return nullptr;
   }

   // Abort if no hypocenters have been read.
   if (!rea4->rea_nhyp) {
       if (problems) problems->append("No hypocenters was read.");
       *status = 2; return nullptr;
   }

   // Make sure first hypocenter at least has a year.
   if (hyp4->hyp_year[0] == -999) { *status = 2; return nullptr; }

   // Create the node. Take values from common blocks.
   Node = CreateNodeFromCommonBlocks();
   if (!Node) { *status = 3; return nullptr; }

   // Set name of S-file.
   strcpy(Node->metadata.sfile, file);

   // Check if file has an invalid date.
   HypData = Node->hypocenters.first;
   fDate.setDate(HypData->time.year, HypData->time.month, HypData->time.day);
   if (!fDate.isValid()) { FreeNode(Node); *status = 5; return nullptr; }

   // Return pointer to new node.
   return Node;
}




// *********************************************************************
// This function creates an event node from the current contents of the
// fortran common blocks. The filename is not written into the metadata
// structure. Memory for the node is allocated here. Function returns a
// pointer to the new node. A null pointer is returned if memory
// allocation failed.
// *********************************************************************
event_node_* CreateNodeFromCommonBlocks()
{
   char str4[5];
   bool OutOfMem;
   int index, i, i2;
   event_node_ *Node;
   phase_ *PhaseData, *LastPhase = nullptr;
   hypocenter_ *HypData, *LastHypo = nullptr;

   // Create new pointers to fortran common blocks.
   // This is done to simplify debugging in Qt Creator.
   comblck_hyp1* hyp1 = &hyp1_; comblck_hyp4* hyp4 = &hyp4_;
   comblck_hyp5* hyp5 = &hyp5_; comblck_rea1* rea1 = &rea1_;
   comblck_rea2* rea2 = &rea2_; comblck_rea3* rea3 = &rea3_;
   comblck_rea4* rea4 = &rea4_; comblck_rea5* rea5 = &rea5_;
   comblck_rea8* rea8 = &rea8_;
   comblck_rea_new_format* reanf = &rea_new_format_;

   // Allocate memory for a new database node.
   if (!(Node = new (std::nothrow) event_node_)) return nullptr;

   // Copy all information from common blocks
   // to new db node (except for the filename).
   // First, copy number of header lines.
   Node->nhead = rea4->rea_nhead;

   // Copy number of lines.
   Node->nrecord = rea4->rea_nrecord;

   // Copy number of stations.
   Node->nstat = rea4->rea_nstat;

   // Copy number of spectra.
   Node->nspec = rea4->rea_nspec;

   // Copy action parameter.
   fstr2char(Node->action, rea3->rea_action, 3);

   // Copy locality.
   fstr2char(Node->locality, rea4->rea_locality, 68);

   // Copy macro data (type 2 lines).
   OutOfMem = false;
   Node->macros.numlines = rea4->rea_nmacro;
   if (Node->macros.numlines) {
      if ((Node->macros.lines = new (std::nothrow) char [rea4->rea_nmacro*80])) {
         for (int i=0;i<rea4->rea_nmacro;i++) {
            memcpy((Node->macros.lines+i*80), rea4->rea_macro[i], 80);
         }
      } else {
         OutOfMem = true;
      }
   }

   // Copy wave filenames (type 6 lines).
   Node->wavefiles.numlines = rea4->rea_nwav;
   if (Node->wavefiles.numlines && !OutOfMem) {
      if ((Node->wavefiles.lines = new (std::nothrow) char [rea4->rea_nwav*80])) {
         for (int i=0;i<rea4->rea_nwav;i ++) {
            memcpy((Node->wavefiles.lines+i*80), rea4->rea_wav[i], 80);
         }
      } else {
         OutOfMem = true;
      }
   }

   // Copy faults (type F lines).
   Node->faults.numlines = rea4->rea_nfault;
   if (Node->faults.numlines && !OutOfMem) {
      if ((Node->faults.lines = new (std::nothrow) char [rea4->rea_nfault*80])) {
         for (int i=0;i<rea4->rea_nfault;i ++) {
            memcpy((Node->faults.lines+i*80), rea4->rea_fault[i], 80);
         }
      } else {
         OutOfMem = true;
      }
   }

   // Copy comment lines (type 3 lines).
   Node->comments.numlines = rea4->rea_ncomment;
   if (Node->comments.numlines && !OutOfMem) {
      if ((Node->comments.lines = new (std::nothrow) char [rea4->rea_ncomment*80])) {
         for (int i=0;i<rea4->rea_ncomment;i ++) {
            memcpy((Node->comments.lines+i*80), rea4->rea_comment[i], 80);
         }
      } else {
         OutOfMem = true;
      }
   }

   // Copy ID-line and line number for the ID line.
   // If ID-line is missing, create an empty ID-line ending with 'I'.
   Node->id_line_num = reanf->rea_id_line_number;
   memcpy(Node->id_line, rea4->rea_id_line, 80);
   if (Node->id_line[1] == 32) {
      memcpy(Node->id_line, " ACTION:", 8); memcpy(Node->id_line +  27, "OP:", 3);
      memcpy(Node->id_line +  35, "STATUS:", 7); memcpy(Node->id_line + 57, "ID:", 3);
      Node->id_line[79] = 'I';
   }

   // Copy phase data to event node.
   LastPhase = nullptr;
   Node->phases.nphase = rea4->rea_nphase;
   for (index=0;index<Node->phases.nphase;index ++) {
      // Copy data for phase pointed to by 'index'.
      if (!OutOfMem && (PhaseData = new (std::nothrow) phase_)) {
         fstr2char(PhaseData->station, rea5->rea_stat[index], 5);
         fstr2char(PhaseData->agency, rea5->rea_agency[index], 5);
         fstr2char(PhaseData->oper, rea5->rea_operator[index], 5);
         fstr2char(PhaseData->comp, rea4->rea_comp[index], 4);
         fstr2char(PhaseData->comp2, rea2->rea_co[index], 2);
         fstr2char(PhaseData->comp3, rea3->rea_com[index], 3);
         fstr2char(PhaseData->phase, rea8->rea_phase[index], 8);
         PhaseData->onset = rea1->rea_onset[index];
         PhaseData->weight_in = rea1->rea_weight_in[index];
         fstr2char(PhaseData->weight_out,rea2->rea_weight_out[index], 2);
         PhaseData->polarity = rea1->rea_polarity[index];
         PhaseData->year = rea4->rea_year[index];
         PhaseData->month = rea4->rea_month[index];
         PhaseData->day = rea4->rea_day[index];
         PhaseData->hour = rea4->rea_hour[index];
         PhaseData->min = rea4->rea_min[index];
         PhaseData->sec = rea4->rea_sec[index];
         PhaseData->abs_time = rea8->rea_abs_time[index];
         PhaseData->coda = rea4->rea_coda[index];
         PhaseData->amp = rea4->rea_amp[index];
         PhaseData->per = rea4->rea_per[index];
         PhaseData->baz_obs = rea4->rea_baz_obs[index];
         PhaseData->baz_cal = rea4->rea_baz_cal[index];
         PhaseData->vel = rea4->rea_vel[index];
         PhaseData->ain = rea4->rea_ain[index];
         PhaseData->baz_res = rea4->rea_baz_res[index];
         PhaseData->res = rea4->rea_res[index];
         PhaseData->dist = rea4->rea_dist[index];
         PhaseData->az = rea4->rea_az[index];
         memcpy(PhaseData->location, rea2->rea_location[index], 2); PhaseData->location[2]=0;
         memcpy(PhaseData->network, rea2->rea_network[index], 2); PhaseData->network[2]=0;
         fstr2char(PhaseData->autoproc,rea4->rea_auto[index], 20);
         PhaseData->spectral.moment = rea4->rea_moment[index];
         PhaseData->spectral.sdrop = rea4->rea_sdrop[index];
         PhaseData->spectral.omega0 = rea4->rea_omega0[index];
         PhaseData->spectral.cornerf = rea4->rea_cornerf[index];
         PhaseData->spectral.radius = rea4->rea_radius[index];
         PhaseData->spectral.swin = rea4->rea_swin[index];
         PhaseData->spectral.slope = rea4->rea_slope[index];
         PhaseData->spectral.vs = rea4->rea_vs[index];
         PhaseData->spectral.vp = rea4->rea_vp[index];
         PhaseData->spectral.q_below_1Hz = rea4->rea_q_below_1hz[index];
         PhaseData->spectral.q0 = rea4->rea_q0[index];
         PhaseData->spectral.qalpha = rea4->rea_qalpha[index];
         PhaseData->spectral.kappa = rea4->rea_kappa[index];
         PhaseData->spectral.density = rea4->rea_density[index];
         PhaseData->spectral.geo_dist = rea4->rea_geo_dist[index];
         PhaseData->spectral.spec_mw = reanf->rea_spec_mw[index];
         PhaseData->spectral.spec_phase = reanf->rea_spec_phase[index];
         PhaseData->magnitudes.mc = rea4->rea_mc[index];
         PhaseData->magnitudes.ml = rea4->rea_ml[index];
         PhaseData->magnitudes.mb = rea4->rea_mb[index];
         PhaseData->magnitudes.ms = rea4->rea_ms[index];
         PhaseData->magnitudes.mw = rea4->rea_mw[index];
         PhaseData->next = nullptr;
         // Add phase to event node.
         if (!index) {
            Node->phases.first = PhaseData;
         } else {
            LastPhase->next = PhaseData;
         }
         LastPhase = PhaseData;
      } else {
         OutOfMem = true;
      }
   }


   // Copy spectral averages to event node.
   Node->spectral_avg.av_moment = rea4->rea_av_moment;
   Node->spectral_avg.av_sdrop = rea4->rea_av_sdrop;
   Node->spectral_avg.av_omega0 = rea4->rea_av_omega0;
   Node->spectral_avg.av_cornerf = rea4->rea_av_cornerf;
   Node->spectral_avg.av_radius = rea4->rea_av_radius;
   Node->spectral_avg.av_swin = rea4->rea_av_swin;
   Node->spectral_avg.av_mw = rea4->rea_av_mw;
   Node->spectral_avg.av_slope = rea4->rea_av_slope;
   Node->spectral_avg.sd_moment = reanf->rea_sd_moment;
   Node->spectral_avg.sd_sdrop = reanf->rea_sd_sdrop;
   Node->spectral_avg.sd_omega0 = reanf->rea_sd_omega0;
   Node->spectral_avg.sd_cornerf = reanf->rea_sd_cornerf;
   Node->spectral_avg.sd_radius = reanf->rea_sd_radius;
   Node->spectral_avg.sd_swin = reanf->rea_sd_swin;
   Node->spectral_avg.sd_mw = reanf->rea_sd_mw;
   Node->spectral_avg.sd_slope = reanf->rea_sd_slope;


   // Copy hypocenter data to event node.
   // First copy all magnitues from all hypocenters in to mag_all list.
   Node->hypocenters.nmag = rea4->rea_nmag;
   if (rea4->rea_nmag) {
      if (!OutOfMem && (Node->hypocenters.mag_all = new (std::nothrow) mag_info [rea4->rea_nmag])) {
         for (int i=0;i<Node->hypocenters.nmag;i ++) {
            Node->hypocenters.mag_all[i].mag = hyp4->hyp_mag_all[i];
            Node->hypocenters.mag_all[i].type = hyp1->hyp_mag_type_all[i];
            memcpy(Node->hypocenters.mag_all[i].agency, hyp5->hyp_mag_agency_all[i], 5);
            Node->hypocenters.mag_all[i].main_agency = (bool)hyp4->hyp_mag_all_main[i];
         }
      } else {
         OutOfMem = true;
      }
   }
   // Copy hypocenter data for all hypocenters.
   Node->hypocenters.nhyp = rea4->rea_nhyp;
   for (index=0;index<Node->hypocenters.nhyp;index ++) {
      // Copy data for hypocenter pointed to by 'index'.
      if (!OutOfMem && (HypData = new (std::nothrow) hypocenter_)) {
         HypData->time.year = hyp4->hyp_year[index];
         HypData->time.month = hyp4->hyp_month[index];
         HypData->time.day = hyp4->hyp_day[index];
         HypData->time.hour = hyp4->hyp_hour[index];
         HypData->time.minute = hyp4->hyp_min[index];
         HypData->time.second = hyp4->hyp_sec[index];
         HypData->modl_id = hyp1->hyp_model[index];
         HypData->dist_id = hyp1->hyp_dist_id[index];
         HypData->evnt_id = hyp1->hyp_type[index]; //event-id
         HypData->fix_org = hyp1->hyp_fix_org[index];
         HypData->lat = hyp4->hyp_lat[index];
         HypData->lon = hyp4->hyp_lon[index];
         HypData->depth = hyp4->hyp_depth[index];
         HypData->depth_flag = hyp1->hyp_depth_flag[index];
         HypData->epi_flag = hyp1->hyp_epi_flag[index];
         fstr2char(HypData->agency, hyp5->hyp_agency[index], 5);
         HypData->nstat = hyp4->hyp_nstat[index];
         HypData->rms = hyp4->hyp_rms[index];
         HypData->high_accuracy = (char)hyp1->hyp_high_accuracy[index];
         HypData->error = (char)hyp1->hyp_error[index];
         HypData->gap = hyp4->hyp_gap[index];
         HypData->sec_err = hyp4->hyp_sec_err[index];
         HypData->lat_err = hyp4->hyp_lat_err[index];
         HypData->lon_err = hyp4->hyp_lon_err[index];
         HypData->depth_err = hyp4->hyp_depth_err[index];
         HypData->cov[0] = hyp4->hyp_cov[index][0];
         HypData->cov[1] = hyp4->hyp_cov[index][1];
         HypData->cov[2] = hyp4->hyp_cov[index][2];
         fstr2char(HypData->autoproc, hyp4->hyp_auto[index], 20);

         // Copy magnitude data for this hypocenter.
         int magorder = 0;
         for (i=0;i<6;i++) {
            if (hyp1->hyp_mag_type[index][i] == 'W') {
               i2 = HypData->magnitudes.MW.nmag++;
               HypData->magnitudes.MW.mag[i2] = hyp4->hyp_mag[index][i];
               memcpy(HypData->magnitudes.MW.mag_agency[i2], hyp5->hyp_mag_agency[index][i], 5);
               HypData->magnitudes.MW.order[i2] = magorder; magorder++;
            }
            if (hyp1->hyp_mag_type[index][i] == 'L') {
               i2 = HypData->magnitudes.ML.nmag++;
               HypData->magnitudes.ML.mag[i2] = hyp4->hyp_mag[index][i];
               memcpy(HypData->magnitudes.ML.mag_agency[i2], hyp5->hyp_mag_agency[index][i], 5);
               HypData->magnitudes.ML.order[i2] = magorder; magorder++;
            }
            if (hyp1->hyp_mag_type[index][i] == 'N') {
               i2 = HypData->magnitudes.MN.nmag++;
               HypData->magnitudes.MN.mag[i2] = hyp4->hyp_mag[index][i];
               memcpy(HypData->magnitudes.MN.mag_agency[i2], hyp5->hyp_mag_agency[index][i], 5);
               HypData->magnitudes.MN.order[i2] = magorder; magorder++;
            }
            if (hyp1->hyp_mag_type[index][i] == 'C') {
               i2 = HypData->magnitudes.MC.nmag++;
               HypData->magnitudes.MC.mag[i2] = hyp4->hyp_mag[index][i];
               memcpy(HypData->magnitudes.MC.mag_agency[i2], hyp5->hyp_mag_agency[index][i], 5);
               HypData->magnitudes.MC.order[i2] = magorder; magorder++;
            }
            if (hyp1->hyp_mag_type[index][i] == 'b') {
               i2 = HypData->magnitudes.Mb.nmag++;
               HypData->magnitudes.Mb.mag[i2] = hyp4->hyp_mag[index][i];
               memcpy(HypData->magnitudes.Mb.mag_agency[i2], hyp5->hyp_mag_agency[index][i], 5);
               HypData->magnitudes.Mb.order[i2] = magorder; magorder++;
            }
            if (hyp1->hyp_mag_type[index][i] == 'B') {
               i2 = HypData->magnitudes.MB.nmag++;
               HypData->magnitudes.MB.mag[i2] = hyp4->hyp_mag[index][i];
               memcpy(HypData->magnitudes.MB.mag_agency[i2], hyp5->hyp_mag_agency[index][i], 5);
               HypData->magnitudes.MB.order[i2] = magorder; magorder++;
            }
            if (hyp1->hyp_mag_type[index][i] == 's') {
               i2 = HypData->magnitudes.Ms.nmag++;
               HypData->magnitudes.Ms.mag[i2] = hyp4->hyp_mag[index][i];
               memcpy(HypData->magnitudes.Ms.mag_agency[i2], hyp5->hyp_mag_agency[index][i], 5);
               HypData->magnitudes.Ms.order[i2] = magorder; magorder++;
            }
            if (hyp1->hyp_mag_type[index][i] == 'S') {
               i2 = HypData->magnitudes.MS.nmag++;
               HypData->magnitudes.MS.mag[i2] = hyp4->hyp_mag[index][i];
               memcpy(HypData->magnitudes.MS.mag_agency[i2], hyp5->hyp_mag_agency[index][i], 5);
               HypData->magnitudes.Ms.order[i2] = magorder; magorder++;
            }
            if (hyp1->hyp_mag_type[index][i] == ' ' && (int)hyp4->hyp_mag[index][i] !=-999) {
               // This is a magnitude with no type.
               i2 = HypData->magnitudes.MU.nmag++;
               HypData->magnitudes.MU.mag[i2] = hyp4->hyp_mag[index][i];
               memcpy(HypData->magnitudes.MU.mag_agency[i2], hyp5->hyp_mag_agency[index][i], 5);
               HypData->magnitudes.MU.order[i2] = magorder; magorder++;
            }
         }

         // Add hypocenter to event node.
         if (!index) {
            Node->hypocenters.first = HypData;
            LastHypo = HypData;
         } else {
            LastHypo->next = HypData;
            LastHypo = HypData;
         }
      } else {
         OutOfMem = true;
      }
   }

   // Create a date/time string in the metadata structure.
   HypData = Node->hypocenters.first;
   sprintf(str4, "%04u", HypData->time.year);
   strcpy(Node->metadata.datetime, str4);
   if (HypData->time.month == -999) {
      strcpy(str4, "??");
   } else {
      sprintf(str4, "%02u", Node->hypocenters.first->time.month);
   }
   strcat(Node->metadata.datetime, str4);
   if (HypData->time.day == -999) {
      strcpy(str4, "??");
   } else {
      sprintf(str4, "%02u", Node->hypocenters.first->time.day);
   }
   strcat(Node->metadata.datetime, str4);
   if (HypData->time.hour == -999) {
       strcpy(str4, "??");
   } else {
       sprintf(str4, "%02u", Node->hypocenters.first->time.hour);
   }
   strcat(Node->metadata.datetime, str4);
   if (HypData->time.minute == -999) {
      strcpy(str4, "??");
   } else {
      sprintf(str4, "%02u", Node->hypocenters.first->time.minute);
   }
   strcat(Node->metadata.datetime, str4);

   // If we have run out of memory, free up all allocated node memory.
   if (OutOfMem) { FreeNode(Node); return nullptr; }

   // Return pointer to new node.
   return Node;
}




// *************************************************************************
// This function writes an S-file from an event node. Any existing file will
// be overwritten. Function returns 'false' if file could not be written.
// The filename is created from 'metadata.sfile'.
//
// One of the following status values are also returned in 'status':
// 0 - No error occurred.
// 1 - Function 'rea_event_out' returned an error.
// 2 - Unable to open S-file.
// 3 - Unable to write S-file.
// 4 - unable to allocate memory.
// *************************************************************************
bool WriteSfile(event_node_ *Node, char *status)
{
   QFile Sfile;
   QByteArray line;
   char *locale;
   bool bResult;
   int index, i, i2;
   signed int unit, write_code, all;
   phase_ *PhaseData;
   hypocenter_ *HypData;

   // Create new pointers to fortran common blocks.
   // This is done to simplify debugging in QtCreator.
   comblck_hyp1* hyp1 = &hyp1_; comblck_hyp4* hyp4 = &hyp4_;
   comblck_hyp5* hyp5 = &hyp5_; comblck_rea1* rea1 = &rea1_;
   comblck_rea2* rea2 = &rea2_; comblck_rea3* rea3 = &rea3_;
   comblck_rea4* rea4 = &rea4_; comblck_rea5* rea5 = &rea5_;
   comblck_rea8* rea8 = &rea8_;
   comblck_rea_new_format* reanf = &rea_new_format_;

   // Clear the common blocks.
   ClearCommonBlocks();

   // Copy all information from db node to common blocks.
   // Copy number of stations.
   rea4->rea_nstat = Node->nstat;

   // Copy number of spectra.
   rea4->rea_nspec = Node->nspec;

   // Copy action parameter.
   char2fstr(rea3->rea_action, Node->action, 3);

   // Copy locality.
   char2fstr(rea4->rea_locality, Node->locality, 68);

   // Copy macro data.
   rea4->rea_nmacro = Node->macros.numlines;
   for (int i=0;i<rea4->rea_nmacro;i++) {
      memcpy(rea4->rea_macro[i], Node->macros.lines+i*80, 80);
   }

   // Copy wave filenames.
   rea4->rea_nwav = Node->wavefiles.numlines;
   for (int i=0;i<rea4->rea_nwav;i++) {
      memcpy(rea4->rea_wav[i], Node->wavefiles.lines+i*80, 80);
   }

   // Copy faults.
   rea4->rea_nfault = Node->faults.numlines;
   for (int i=0;i<rea4->rea_nfault;i++) {
      memcpy(rea4->rea_fault[i], Node->faults.lines+i*80, 80);
   }

   // Copy comment lines.
   rea4->rea_ncomment = Node->comments.numlines;
   for (int i=0;i<rea4->rea_ncomment;i++) {
      memcpy(rea4->rea_comment[i], Node->comments.lines+i*80, 80);
   }

   // Copy ID-line and line number for the ID line.
   char2fstr(rea4->rea_id_line, Node->id_line, 80);
   reanf->rea_id_line_number = Node->id_line_num;

   // Copy phases from event node.
   rea4->rea_nphase = Node->phases.nphase;
   if (rea4->rea_nphase) {
      PhaseData = Node->phases.first;
      for (index=0;index<Node->phases.nphase;index++) {
         // Copy data for one phase.
         char2fstr(rea5->rea_stat[index], PhaseData->station, 5);
         char2fstr(rea5->rea_agency[index], PhaseData->agency, 5);
         char2fstr(rea5->rea_operator[index], PhaseData->oper, 5);
         char2fstr(rea4->rea_comp[index], PhaseData->comp, 4);
         char2fstr(rea2->rea_co[index], PhaseData->comp2, 2);
         char2fstr(rea2->rea_location[index], PhaseData->location, 2);
         char2fstr(rea2->rea_network[index], PhaseData->network, 2);
         char2fstr(rea3->rea_com[index], PhaseData->comp3, 3);
         char2fstr(rea8->rea_phase[index], PhaseData->phase, 8);
         rea1->rea_onset[index] = PhaseData->onset;
         rea1->rea_weight_in[index] = PhaseData->weight_in;
         char2fstr(rea2->rea_weight_out[index], PhaseData->weight_out, 2);
         rea1->rea_polarity[index] = PhaseData->polarity;
         rea4->rea_year[index] = PhaseData->year;
         rea4->rea_month[index] = PhaseData->month;
         rea4->rea_day[index] = PhaseData->day;
         rea4->rea_hour[index] = PhaseData->hour;
         rea4->rea_min[index] = PhaseData->min;
         rea4->rea_sec[index] = PhaseData->sec;
         rea8->rea_abs_time[index] = PhaseData->abs_time;
         rea4->rea_coda[index] = PhaseData->coda;
         rea4->rea_amp[index] = PhaseData->amp;
         rea4->rea_per[index] = PhaseData->per;
         rea4->rea_baz_obs[index] = PhaseData->baz_obs;
         rea4->rea_baz_cal[index] = PhaseData->baz_cal;
         rea4->rea_vel[index] = PhaseData->vel;
         rea4->rea_ain[index] = PhaseData->ain;
         rea4->rea_baz_res[index] = PhaseData->baz_res;
         rea4->rea_res[index] = PhaseData->res;
         rea4->rea_dist[index] = PhaseData->dist;
         rea4->rea_az[index] = PhaseData->az;
         char2fstr(rea4->rea_auto[index], PhaseData->autoproc, 20);
         rea4->rea_moment[index] = PhaseData->spectral.moment;
         rea4->rea_sdrop[index] = PhaseData->spectral.sdrop;
         rea4->rea_omega0[index] = PhaseData->spectral.omega0;
         rea4->rea_cornerf[index] = PhaseData->spectral.cornerf;
         rea4->rea_radius[index] = PhaseData->spectral.radius;
         rea4->rea_swin[index] = PhaseData->spectral.swin;
         rea4->rea_slope[index] = PhaseData->spectral.slope;
         rea4->rea_vs[index] = PhaseData->spectral.vs;
         rea4->rea_vp[index] = PhaseData->spectral.vp;
         rea4->rea_q_below_1hz[index] = PhaseData->spectral.q_below_1Hz;
         rea4->rea_q0[index] = PhaseData->spectral.q0;
         rea4->rea_qalpha[index] = PhaseData->spectral.qalpha;
         rea4->rea_kappa[index] = PhaseData->spectral.kappa;
         rea4->rea_density[index] = PhaseData->spectral.density;
         rea4->rea_geo_dist[index] = PhaseData->spectral.geo_dist;
         reanf->rea_spec_mw[index] = PhaseData->spectral.spec_mw;
         reanf->rea_spec_phase[index] = PhaseData->spectral.spec_phase;
         rea4->rea_mc[index] = PhaseData->magnitudes.mc;
         rea4->rea_ml[index] = PhaseData->magnitudes.ml;
         rea4->rea_mb[index] = PhaseData->magnitudes.mb;
         rea4->rea_ms[index] = PhaseData->magnitudes.ms;
         rea4->rea_mw[index] = PhaseData->magnitudes.mw;
         // Move to next phase.
         PhaseData = PhaseData->next;
      }
   }

   // Copy spectral averages.
   rea4->rea_av_moment = Node->spectral_avg.av_moment;
   rea4->rea_av_sdrop = Node->spectral_avg.av_sdrop;
   rea4->rea_av_omega0 = Node->spectral_avg.av_omega0;
   rea4->rea_av_cornerf = Node->spectral_avg.av_cornerf;
   rea4->rea_av_radius = Node->spectral_avg.av_radius;
   rea4->rea_av_swin = Node->spectral_avg.av_swin;
   rea4->rea_av_mw = Node->spectral_avg.av_mw;
   rea4->rea_av_slope = Node->spectral_avg.av_slope;
   reanf->rea_sd_moment = Node->spectral_avg.sd_moment;
   reanf->rea_sd_sdrop = Node->spectral_avg.sd_sdrop;
   reanf->rea_sd_omega0 = Node->spectral_avg.sd_omega0;
   reanf->rea_sd_cornerf = Node->spectral_avg.sd_cornerf;
   reanf->rea_sd_radius = Node->spectral_avg.sd_radius;
   reanf->rea_sd_swin = Node->spectral_avg.sd_swin;
   reanf->rea_sd_mw = Node->spectral_avg.sd_mw;
   reanf->rea_sd_slope = Node->spectral_avg.sd_slope;


   // Copy hypocenter data.
   rea4->rea_nhyp = Node->hypocenters.nhyp;
   if (rea4->rea_nhyp) {
      HypData = Node->hypocenters.first;
      for (index=0;index<Node->hypocenters.nhyp;index ++) {
         hyp4->hyp_year[index] = HypData->time.year;
         hyp4->hyp_month[index] = HypData->time.month;
         hyp4->hyp_day[index] = HypData->time.day;
         hyp4->hyp_hour[index] = HypData->time.hour;
         hyp4->hyp_min[index] = HypData->time.minute;
         hyp4->hyp_sec[index] = HypData->time.second;
         hyp1->hyp_model[index] = HypData->modl_id;
         hyp1->hyp_dist_id[index] = HypData->dist_id;
         hyp1->hyp_type[index] = HypData->evnt_id;
         hyp1->hyp_fix_org[index] = HypData->fix_org;
         hyp4->hyp_lat[index] = HypData->lat;
         hyp4->hyp_lon[index] = HypData->lon;
         hyp4->hyp_depth[index] = HypData->depth;
         hyp1->hyp_depth_flag[index] = HypData->depth_flag;
         hyp1->hyp_epi_flag[index] = HypData->epi_flag;
         char2fstr(hyp5->hyp_agency[index], HypData->agency, 5);
         hyp4->hyp_nstat[index] = HypData->nstat;
         hyp4->hyp_rms[index] = HypData->rms;
         hyp1->hyp_high_accuracy[index] = HypData->high_accuracy;
         hyp1->hyp_error[index] = HypData->error;
         hyp4->hyp_gap[index] = HypData->gap;
         hyp4->hyp_sec_err[index] = HypData->sec_err;
         hyp4->hyp_lat_err[index] = HypData->lat_err;
         hyp4->hyp_lon_err[index] = HypData->lon_err;
         hyp4->hyp_depth_err[index] = HypData->depth_err;
         hyp4->hyp_cov[index][0] = HypData->cov[0];
         hyp4->hyp_cov[index][1] = HypData->cov[1];
         hyp4->hyp_cov[index][2] = HypData->cov[2];
         char2fstr(hyp4->hyp_auto[index], HypData->autoproc, 20);
         // Copy magnitude data.
         for (i=0;i<HypData->magnitudes.MU.nmag;i++) {
            i2 = HypData->magnitudes.MU.order[i];
            hyp1->hyp_mag_type[index][i2] = ' ';
            hyp4->hyp_mag[index][i2] = HypData->magnitudes.MU.mag[i];
            char2fstr(hyp5->hyp_mag_agency[index][i2], HypData->magnitudes.MU.mag_agency[i], 5);
            i2++;
         }
         for (i=0;i<HypData->magnitudes.MW.nmag;i++) {
            i2 = HypData->magnitudes.MW.order[i];
            hyp1->hyp_mag_type[index][i2] = 'W';
            hyp4->hyp_mag[index][i2] = HypData->magnitudes.MW.mag[i];
            char2fstr(hyp5->hyp_mag_agency[index][i2], HypData->magnitudes.MW.mag_agency[i], 5);
            i2++;
         }
         for (i=0;i<HypData->magnitudes.ML.nmag;i++) {
            i2 = HypData->magnitudes.ML.order[i];
            hyp1->hyp_mag_type[index][i2] = 'L';
            hyp4->hyp_mag[index][i2] = HypData->magnitudes.ML.mag[i];
            char2fstr(hyp5->hyp_mag_agency[index][i2], HypData->magnitudes.ML.mag_agency[i], 5);
            i2++;
         }
         for (i=0;i<HypData->magnitudes.MN.nmag;i++) {
            i2 = HypData->magnitudes.MN.order[i];
            hyp1->hyp_mag_type[index][i2] = 'N';
            hyp4->hyp_mag[index][i2] = HypData->magnitudes.MN.mag[i];
            char2fstr(hyp5->hyp_mag_agency[index][i2], HypData->magnitudes.MN.mag_agency[i], 5);
            i2++;
         }
         for (i=0;i<HypData->magnitudes.MC.nmag;i++) {
            i2 = HypData->magnitudes.MC.order[i];
            hyp1->hyp_mag_type[index][i2] = 'C';
            hyp4->hyp_mag[index][i2] = HypData->magnitudes.MC.mag[i];
            char2fstr(hyp5->hyp_mag_agency[index][i2], HypData->magnitudes.MC.mag_agency[i], 5);
            i2++;
         }
         for (i=0;i<HypData->magnitudes.Mb.nmag;i++) {
            i2 = HypData->magnitudes.Mb.order[i];
            hyp1->hyp_mag_type[index][i2] = 'b';
            hyp4->hyp_mag[index][i2] = HypData->magnitudes.Mb.mag[i];
            char2fstr(hyp5->hyp_mag_agency[index][i2], HypData->magnitudes.Mb.mag_agency[i], 5);
            i2++;
         }
         for (i=0;i<HypData->magnitudes.MB.nmag;i++) {
            i2 = HypData->magnitudes.MB.order[i];
            hyp1->hyp_mag_type[index][i2] = 'B';
            hyp4->hyp_mag[index][i2] = HypData->magnitudes.MB.mag[i];
            char2fstr(hyp5->hyp_mag_agency[index][i2], HypData->magnitudes.MB.mag_agency[i], 5);
            i2++;
         }
         for (i=0;i<HypData->magnitudes.Ms.nmag;i++) {
            i2 = HypData->magnitudes.Ms.order[i];
            hyp1->hyp_mag_type[index][i2] = 's';
            hyp4->hyp_mag[index][i2] = HypData->magnitudes.Ms.mag[i];
            char2fstr(hyp5->hyp_mag_agency[index][i2], HypData->magnitudes.Ms.mag_agency[i], 5);
            i2++;
         }
         for (i=0;i<HypData->magnitudes.MS.nmag;i++) {
            i2 = HypData->magnitudes.MS.order[i];
            hyp1->hyp_mag_type[index][i2] = 'S';
            hyp4->hyp_mag[index][i2] = HypData->magnitudes.MS.mag[i];
            char2fstr(hyp5->hyp_mag_agency[index][i2], HypData->magnitudes.MS.mag_agency[i], 5);
            i2++;
         }

         // Move to next hypocenter.
         HypData = HypData->next;
      }
   }

   // Create the S-file contents from the data in the common blocks.
   // Function rea_event_out will write S-file lines into SFileData array.
   // The LC_NUMERIC locale setting must be temporarily set to 'POSIX'
   // to avoid problems with decimal point when using a locale that has
   // a desimal point other than '.'(dot) is used.
   memset(SFileData, 32, sizeof(SFileData));
   locale = setlocale(LC_NUMERIC, nullptr); setlocale(LC_NUMERIC, "POSIX");
   rea_event_out_(&(unit=0), &(all=1), (char*)SFileData, &write_code, sizeof(SFileData));
   setlocale(LC_NUMERIC, locale);
   if (write_code) { *status = 1; return false; }

   // Create the S-file. File will be overwritten if it already exists.
   Sfile.setFileName(QString(Node->metadata.sfile));
   bResult = Sfile.open(QIODevice::WriteOnly|QIODevice::Text|QIODevice::Truncate);
   if (!bResult) { *status = 2; return false; }

   // Write the new S-file from the SFileData array. Abort if write a error occur.
   for (index=0;index<rea4_.rea_nrecord;index++) {
      line.clear(); line.append(SFileData[index], 80); line.append('\n');
      if (Sfile.write(line, 81) == -1) { Sfile.close(); *status = 3; return false; }
   }

   // S-file was created sucessfully. Close file and return.
   Sfile.close(); *status = 0;
   return true;
}




// ****************************************************************
// This function creates a full copy of an event  node. It will
// allocate new memory as needed. Function returns a pointer to
// the new node. Function returns NULL if memory allocation failed.
// ****************************************************************
event_node_* CopyNode(event_node_ *Node)
{
   int NumLines;

   // Return here if a nullpointer to
   // existing node has been given.
   if (!Node) return nullptr;

   // Allocate memory for a new node.
   event_node_ *NewNode = new (std::nothrow) event_node_;

   // Return if memory allocation failed.
   if (!NewNode) return nullptr;

   // Copy the node main body.
   *NewNode = *Node;

   // Allocate memory, and copy macrolines.
   NewNode->macros.lines = nullptr;
   NumLines = Node->macros.numlines;
   if (NumLines) {
      if ((NewNode->macros.lines = new (std::nothrow) char [NumLines*80])) {
         memcpy((NewNode->macros.lines), Node->macros.lines, (size_t)NumLines*80);
      } else {
         FreeNode(NewNode);
         return nullptr;
      }
   }

   // Allocate memory, and copy wave file names.
   NewNode->wavefiles.lines = nullptr;
   NumLines = Node->wavefiles.numlines;
   if (NumLines) {
      if ((NewNode->wavefiles.lines = new (std::nothrow) char [NumLines*80])) {
         memcpy((NewNode->wavefiles.lines), Node->wavefiles.lines, (size_t)NumLines*80);
      } else {
         FreeNode(NewNode);
         return nullptr;
      }
   }

   // Allocate memory, and copy fault lines.
   NewNode->faults.lines = nullptr;
   NumLines = Node->faults.numlines;
   if (NumLines) {
      if ((NewNode->faults.lines = new (std::nothrow) char [NumLines*80])) {
         memcpy((NewNode->faults.lines), Node->faults.lines, (size_t)NumLines*80);
      } else {
         FreeNode(NewNode);
         return nullptr;
      }
   }

   // Allocate memory and copy comment lines.
   NewNode->comments.lines = nullptr;
   NumLines = Node->comments.numlines;
   if (NumLines) {
      if ((NewNode->comments.lines = new (std::nothrow) char [NumLines*80])) {
         memcpy((NewNode->comments.lines), Node->comments.lines, (size_t)NumLines*80);
      } else {
         FreeNode(NewNode);
         return nullptr;
      }
   }

   // Copy phase structures.
   NewNode->phases.first = nullptr;
   phase_ *PhaseData, *NextNodePhase = nullptr, *LastNewNodePhase = nullptr;
   for (int index=0;index<Node->phases.nphase;index++) {
      // Allocate memory for new phase.
      if (!(PhaseData = new (std::nothrow) phase_)) { FreeNode(NewNode); return nullptr; }

      // Add the new phase.
      if (!index) {
         // Add the first phase.
         NewNode->phases.first = PhaseData;
         *PhaseData = *Node->phases.first;
         PhaseData->next = nullptr;
         NextNodePhase = Node->phases.first->next;
         LastNewNodePhase = PhaseData;
      } else {
         *PhaseData = *NextNodePhase;
         PhaseData->next = nullptr;
         LastNewNodePhase->next = PhaseData;
         NextNodePhase = NextNodePhase->next;
         LastNewNodePhase = PhaseData;
      }
   }

   // Allocate memory, and copy hypocenter magnitudes.
   NewNode->hypocenters.mag_all = nullptr;
   if (Node->hypocenters.mag_all) {
      if (!(NewNode->hypocenters.mag_all = new (std::nothrow) mag_info [Node->hypocenters.nmag])) {
          FreeNode(NewNode);
          return nullptr;
      }
      memcpy(NewNode->hypocenters.mag_all, Node->hypocenters.mag_all, sizeof(mag_info)*Node->hypocenters.nmag);
   }

   // Copy hypocenters.
   hypocenter_ *HypocData, *NextNodeHypoc = nullptr, *LastNewNodeHypoc = nullptr;
   NewNode->hypocenters.first = nullptr;
   for (int index=0;index<Node->hypocenters.nhyp;index++) {
      // Allocate memory for new hypocenter.
      if (!(HypocData = new (std::nothrow) hypocenter_)) { FreeNode(NewNode); return nullptr; }
      // Add the new hypocenter.
      if (!index) {
         NewNode->hypocenters.first = HypocData;
         *HypocData = *Node->hypocenters.first;
         HypocData->next = nullptr;
         NextNodeHypoc = Node->hypocenters.first->next;
         LastNewNodeHypoc = HypocData;
      } else {
         *HypocData = *NextNodeHypoc;
         HypocData->next = nullptr;
         LastNewNodeHypoc->next = HypocData;
         NextNodeHypoc = NextNodeHypoc->next;
         LastNewNodeHypoc = HypocData;
      }
   }

   // Return pointer to new node.
   return NewNode;
}




// *****************************************************
// This function is used by the database to
// free up all memory used by a database node.
// *****************************************************
void FreeNode(event_node_ *Node)
{
   // Check for nullpointer to node.
   if (!Node) return;

   // Free macrolines.
   if (Node->macros.numlines) delete [] Node->macros.lines;

   // Free wave file names.
   if (Node->wavefiles.numlines) delete [] Node->wavefiles.lines;

   // Free fault lines.
   if (Node->faults.numlines) delete [] Node->faults.lines;

   // Free comment lines.
   if (Node->comments.numlines) delete [] Node->comments.lines;

   // Free all phase structures.
   struct phase_ *Phase, *NextPhase;
   if (Node->phases.nphase) {
      Phase = Node->phases.first;
      while (Phase) {
         NextPhase = Phase->next;
         delete Phase;
         Phase = NextPhase;
      }
   }

   // Free hypocenter magnitudes.
   if (Node->hypocenters.mag_all) delete[] Node->hypocenters.mag_all;

   // Free all hypocenter structures.
   struct hypocenter_ *Hyp, *NextHyp;
   if (Node->hypocenters.nhyp) {
      Hyp = Node->hypocenters.first;
      while (Hyp) {
         NextHyp = Hyp->next;
         delete Hyp;
         Hyp = NextHyp;
      }
   }

   // Free up the main node structure.
   delete Node;
}




// *****************************************************************
// This function returns the distance indicator for an event node.
// ******************************************************************
QChar NodeGetDistanceIndicator(event_node_* Node)
{
   return QChar(Node->hypocenters.first->dist_id);
}




// *****************************************************************
// This function returns the event indicator for an event node.
// ******************************************************************
QChar NodeGetEventIndicator(event_node_* Node)
{
   return QChar(Node->hypocenters.first->evnt_id);
}




// *****************************************************************
// This function returns the model indicator for an event node.
// ******************************************************************
QChar NodeGetModelIndicator(event_node_* Node)
{
   return QChar(Node->hypocenters.first->modl_id);
}




// *****************************************************************
// This function sets the distance indicator for an event node.
// ******************************************************************
void NodeSetDistanceIndicator(event_node_* Node, QChar DistInd)
{
   // Change the event file name.
   int len = (int)strlen(Node->metadata.sfile);
   Node->metadata.sfile[len-9] = DistInd.toUpper().toLatin1();

   // Change the first hypocenter line.
   Node->hypocenters.first->dist_id = DistInd.toUpper().toLatin1();
}




// *****************************************************************
// This function sets the event indicator for an event node.
// ******************************************************************
void NodeSetEventIndicator(event_node_* Node, QChar EventInd)
{
   // Change the first hypocenter line.
   Node->hypocenters.first->evnt_id = EventInd.toLatin1();
}




// *****************************************************************
// This function sets the model indicator for an event node.
// ******************************************************************
void NodeSetModelIndicator(event_node_* Node, QChar EventInd)
{
   // Change the first hypocenter line.
   Node->hypocenters.first->modl_id = EventInd.toLatin1();
}




// *****************************************************************
// This function compares two event nodes for sorting purposes.
// The currently selected sort order is taken into consideration.
// Return values: -1=node1<node2 ,0=nodes are equal , 1=node1>node2.
// A node with missing data is larger (>) then a node with data.
// ******************************************************************
char NodeCmp(event_node_ *node1, event_node_ *node2, sortCol SortColumn)
{
   int iValue1, iValue2;
   float fValue1, fValue2;
   QChar Char1, Char2;
   QString Str1, Str2;

   switch (SortColumn) {
      case Action:
      // A 3 character string.
      // If first string character is 0, then data is missing.
      iValue1 = (int)node1->action[0];
      iValue2 = (int)node2->action[0];
      if (!iValue1 && !iValue2) return 0;
      if (iValue1 && iValue2) {
         return (char)strcmp(node1->action, node2->action);
      } else {
         if (!iValue1) { return 1; } else { return -1; }
      }

      case DateTime:
      if (node1->hypocenters.first->time.year < node2->hypocenters.first->time.year) return -1;
      if (node1->hypocenters.first->time.year > node2->hypocenters.first->time.year) return 1;
      if (node1->hypocenters.first->time.month < node2->hypocenters.first->time.month) return -1;
      if (node1->hypocenters.first->time.month > node2->hypocenters.first->time.month) return 1;
      if (node1->hypocenters.first->time.day < node2->hypocenters.first->time.day) return -1;
      if (node1->hypocenters.first->time.day > node2->hypocenters.first->time.day) return 1;
      if (node1->hypocenters.first->time.hour < node2->hypocenters.first->time.hour) return -1;
      if (node1->hypocenters.first->time.hour > node2->hypocenters.first->time.hour) return 1;
      if (node1->hypocenters.first->time.minute < node2->hypocenters.first->time.minute) return -1;
      if (node1->hypocenters.first->time.minute > node2->hypocenters.first->time.minute) return 1;
      if (node1->hypocenters.first->time.second < node2->hypocenters.first->time.second) return -1;
      if (node1->hypocenters.first->time.second > node2->hypocenters.first->time.second) return 1;
      return 0;

      case Latitude:
      fValue1 = node1->hypocenters.first->lat;
      fValue2 = node2->hypocenters.first->lat;
      if (fValue1 == fValue2) return 0;
      if ((int)fValue1 != -999 && (int)fValue2 != -999) {
         if (fValue1 > fValue2) { return 1; } else { return -1; }
      } else {
         if ((int)fValue1 == -999) { return 1; } else { return -1; };
      }

      case Longitude:
      fValue1 = node1->hypocenters.first->lon;
      fValue2 = node2->hypocenters.first->lon;
      if (fValue1 == fValue2) return 0;
      if ((int)fValue1 != -999 && (int)fValue2 != -999) {
         if (fValue1 > fValue2) { return 1; } else { return -1; }
      } else {
         if ((int)fValue1 == -999) { return 1; } else { return -1; };
      }

      case Depth:
      fValue1 = node1->hypocenters.first->depth;
      fValue2 = node2->hypocenters.first->depth;
      if (fValue1 == fValue2) return 0;
      if ((int)fValue1 != -999 && (int)fValue2 != -999) {
         if (fValue1 > fValue2) { return 1; } else { return -1; }
      } else {
         if ((int)fValue1 == -999) { return 1; } else { return -1; };
      }

      case Model:
      // One character. A value of '32' means data missing.
      iValue1 = (int)node1->hypocenters.first->modl_id;
      iValue2 = (int)node2->hypocenters.first->modl_id;
      if (iValue1 == iValue2) return 0;
      if (iValue1 != 32 && iValue2 != 32) {
         if (iValue1 > iValue2) { return 1; } else { return -1; }
      } else {
         if (iValue1 == 32) { return 1; } else { return -1; }
      }

      case Agency:
      // A 3 character string.
      iValue1 = (int)node1->hypocenters.first->agency[0];
      iValue2 = (int)node2->hypocenters.first->agency[0];
      if (iValue1 == 32 && iValue2 == 32) return 0;
      if (iValue1 != 32 && iValue2 != 32) {
         return (char)strcmp(node1->hypocenters.first->agency, node2->hypocenters.first->agency);
      } else {
         if (iValue1 == 32)  { return 1; } else { return -1; }
      }

      case RMS:
      fValue1 = node1->hypocenters.first->rms;
      fValue2 = node2->hypocenters.first->rms;
      if (fValue1 == fValue2) return 0;
      if ((int)fValue1 != -999 && (int)fValue2 != -999) {
         if (fValue1 > fValue2) { return 1; } else { return -1; }
      } else {
         if ((int)fValue1 == -999) { return 1; } else { return -1; };
      }

      case Gap:
      fValue1 = node1->hypocenters.first->gap;
      fValue2 = node2->hypocenters.first->gap;
      if (fValue1 == fValue2) return 0;
      if ((int)fValue1 != -999 && (int)fValue2 != -999) {
         if (fValue1 > fValue2) { return 1; } else { return -1; }
      } else {
         if ((int)fValue1 == -999) { return 1; } else { return -1; };
      }

      case ErrLat:
      fValue1 = node1->hypocenters.first->lat_err;
      fValue2 = node2->hypocenters.first->lat_err;
      if (fValue1 == fValue2) return 0;
      if ((int)fValue1 != -999 && (int)fValue2 != -999) {
         if (fValue1 > fValue2) { return 1; } else { return -1; }
      } else {
         if ((int)fValue1 == -999) { return 1; } else { return -1; };
      }

      case ErrLon:
      fValue1 = node1->hypocenters.first->lon_err;
      fValue2 = node2->hypocenters.first->lon_err;
      if (fValue1 == fValue2) return 0;
      if ((int)fValue1 != -999 && (int)fValue2 != -999) {
         if (fValue1 > fValue2) { return 1; } else { return -1; }
      } else {
         if ((int)fValue1 == -999) { return 1; } else { return -1; };
      }

      case ErrDep:
      fValue1 = node1->hypocenters.first->depth_err;
      fValue2 = node2->hypocenters.first->depth_err;
      if (fValue1 == fValue2) return 0;
      if ((int)fValue1 != -999 && (int)fValue2 != -999) {
         if (fValue1 > fValue2) { return 1; } else { return -1; }
      } else {
         if ((int)fValue1 == -999) { return 1; } else { return -1; };
      }

      case Dist:
      // One character. A value of '32' means data missing.
      iValue1 = (int)node1->hypocenters.first->dist_id;
      iValue2 = (int)node2->hypocenters.first->dist_id;
      if (iValue1 == iValue2) return 0;
      if (iValue1 != 32 && iValue2 != 32) {
         if (iValue1 > iValue2) { return 1; } else { return -1; }
      } else {
         if (iValue1 == 32) { return 1; } else { return -1; }
      }

      case Type:
      // One character. A value of '32' means data missing.
      iValue1 = (int)node1->hypocenters.first->evnt_id;
      iValue2 = (int)node2->hypocenters.first->evnt_id;
      if (iValue1 == iValue2) return 0;
      if (iValue1 != 32 && iValue2 != 32) {
         if (iValue1 > iValue2) { return 1; } else { return -1; }
      } else {
         if (iValue1 == 32) { return 1; } else { return -1; }
      }

      case MInt:
      fValue1 = fValue2 = -999.0; Str1.clear();Str2.clear();
      if (node1->macros.numlines) {
         Str1 = QString(node1->macros.lines).mid(27,2).simplified();
         Char1 = QString(node1->macros.lines).at(29);
      }
      if (node2->macros.numlines) {
         Str2 = QString(node2->macros.lines).mid(27,2).simplified();
         Char2 = QString(node2->macros.lines).at(29);
      }
      if (!Str1.isEmpty()) fValue1 = Str1.toFloat();
      if (!Str2.isEmpty()) fValue2 = Str2.toFloat();
      if (Char1.toLatin1() == '+') fValue1 = fValue1 + 0.1;
      if (Char1.toLatin1() == '-') fValue1 = fValue1 - 0.1;
      if (Char2.toLatin1() == '+') fValue2 = fValue2 + 0.1;
      if (Char2.toLatin1() == '-') fValue2 = fValue2 - 0.1;
      if (fValue1 == fValue2) return 0;
      if ((int)fValue1 != -999 && (int)fValue2 != -999) {
         if (fValue1 > fValue2) { return 1; } else { return -1; }
      } else {
         if ((int)fValue1 == -999) { return 1; } else { return -1; }
      }

      case NSta:
      iValue1 = node1->hypocenters.first->nstat;
      iValue2 = node2->hypocenters.first->nstat;
      if (iValue1 == iValue2) return 0;
      if (iValue1 != -999 && iValue2 != -999) {
         if (iValue1 > iValue2) { return 1; } else { return -1; }
      } else {
         if (iValue1 == -999) { return 1; } else { return -1; };
      }

      case M:
      fValue1 = fValue2 = 0.0;
      if (node1->hypocenters.nmag) fValue1 = node1->hypocenters.mag_all[0].mag;
      if (node2->hypocenters.nmag) fValue2 = node2->hypocenters.mag_all[0].mag;
      if (fValue1 == fValue2) return 0;
      if (fValue1 != 0.0 && fValue2 != 0.0) {
         if (fValue1 > fValue2) { return 1; } else { return -1; }
      } else {
         if (fValue1 == 0.0) { return 1; } else { return -1; };
      }

      case MW:
      fValue1 = node1->hypocenters.first->magnitudes.MW.mag[0];
      fValue2 = node2->hypocenters.first->magnitudes.MW.mag[0];
      if (fValue1 == fValue2) return 0;
      if (fValue1 != 0.0 && fValue2 != 0.0) {
         if (fValue1 > fValue2) { return 1; } else { return -1; }
      } else {
         if (fValue1 == 0.0) { return 1; } else { return -1; };
      }

      case ML:
      fValue1 = node1->hypocenters.first->magnitudes.ML.mag[0];
      fValue2 = node2->hypocenters.first->magnitudes.ML.mag[0];
      if (fValue1 == fValue2) return 0;
      if (fValue1 != 0.0 && fValue2 != 0.0) {
         if (fValue1 > fValue2) { return 1; } else { return -1; }
      } else {
         if (fValue1 == 0.0) { return 1; } else { return -1; };
      }

      case MN:
      fValue1 = node1->hypocenters.first->magnitudes.MN.mag[0];
      fValue2 = node2->hypocenters.first->magnitudes.MN.mag[0];
      if (fValue1 == fValue2) return 0;
      if (fValue1 != 0.0 && fValue2 != 0.0) {
         if (fValue1 > fValue2) { return 1; } else { return -1; }
      } else {
         if (fValue1 == 0.0) { return 1; } else { return -1; };
      }

      case MC:
      fValue1 = node1->hypocenters.first->magnitudes.MC.mag[0];
      fValue2 = node2->hypocenters.first->magnitudes.MC.mag[0];
      if (fValue1 == fValue2) return 0;
      if (fValue1 != 0.0 && fValue2 != 0.0) {
         if (fValue1 > fValue2) { return 1; } else { return -1; }
      } else {
         if (fValue1 == 0.0) { return 1; } else { return -1; };
      }

      case Mb:
      fValue1 = node1->hypocenters.first->magnitudes.Mb.mag[0];
      fValue2 = node2->hypocenters.first->magnitudes.Mb.mag[0];
      if (fValue1 == fValue2) return 0;
      if (fValue1 != 0.0 && fValue2 != 0.0) {
         if (fValue1 > fValue2) { return 1; } else { return -1; }
      } else {
         if (fValue1 == 0.0) { return 1; } else { return -1; };
      }

      case MB:
      fValue1 = node1->hypocenters.first->magnitudes.MB.mag[0];
      fValue2 = node2->hypocenters.first->magnitudes.MB.mag[0];
      if (fValue1 == fValue2) return 0;
      if (fValue1 != 0.0 && fValue2 != 0.0) {
         if (fValue1 > fValue2) { return 1; } else { return -1; }
      } else {
         if (fValue1 == 0.0) { return 1; } else { return -1; };
      }

      case Ms:
      fValue1 = node1->hypocenters.first->magnitudes.Ms.mag[0];
      fValue2 = node2->hypocenters.first->magnitudes.Ms.mag[0];
      if (fValue1 == fValue2) return 0;
      if (fValue1 != 0.0 && fValue2 != 0.0) {
         if (fValue1 > fValue2) { return 1; } else { return -1; }
      } else {
         if (fValue1 == 0.0) { return 1; } else { return -1; };
      }

      case MS:
      fValue1 = node1->hypocenters.first->magnitudes.MS.mag[0];
      fValue2 = node2->hypocenters.first->magnitudes.MS.mag[0];
      if (fValue1 == fValue2) return 0;
      if (fValue1 != 0.0 && fValue2 != 0.0) {
         if (fValue1 > fValue2) { return 1; } else { return -1; }
      } else {
         if (fValue1 == 0.0) { return 1; } else { return -1; };
      }

      case Locality:
      // A 68 character string.
      // If first string character is 0, then data is missing.
      iValue1 = (int)node1->locality[0];
      iValue2 = (int)node2->locality[0];
      if (!iValue1 && !iValue2) return 0;
      if (iValue1 && iValue2) {
         return (char)strcmp(node1->locality, node2->locality);
      } else {
         if (!iValue1) { return 1; } else { return -1; }
      }

      case SFile:
      return (char)strcmp(node1->metadata.sfile, node2->metadata.sfile);

      default:
      return 2;
   }
}




// ****************************************************************************
// The LessThan functions below compares two event nodes. They
// always returns true if node1 < node2, else they return false.
// ****************************************************************************
bool LessThan_DateTime(event_node_ *node1, event_node_ *node2)
{
   return (NodeCmp(node1, node2, DateTime) == -1);
}

bool LessThan_Action(event_node_ *node1, event_node_ *node2)
{
   return (NodeCmp(node1, node2, Action) == -1);
}

bool LessThan_Latitude(event_node_ *node1, event_node_ *node2)
{
   return (NodeCmp(node1, node2, Latitude) == -1);
}

bool LessThan_Longitude(event_node_ *node1, event_node_ *node2)
{
   return (NodeCmp(node1, node2, Longitude) == -1);
}

bool LessThan_Depth(event_node_ *node1, event_node_ *node2)
{
   return (NodeCmp(node1, node2, Depth) == -1);
}

bool LessThan_Model(event_node_ *node1, event_node_ *node2)
{
   return (NodeCmp(node1, node2, Model) == -1);
}

bool LessThan_Agency(event_node_ *node1, event_node_ *node2)
{
   return (NodeCmp(node1, node2, Agency) == -1);
}

bool LessThan_RMS(event_node_ *node1, event_node_ *node2)
{
   return (NodeCmp(node1, node2, RMS) == -1);
}

bool LessThan_Gap(event_node_ *node1, event_node_ *node2)
{
   return (NodeCmp(node1, node2, Gap) == -1);
}

bool LessThan_ErrLat(event_node_ *node1, event_node_ *node2)
{
   return (NodeCmp(node1, node2, ErrLat) == -1);
}

bool LessThan_ErrLon(event_node_ *node1, event_node_ *node2)
{
   return (NodeCmp(node1, node2, ErrLon) == -1);
}

bool LessThan_ErrDep(event_node_ *node1, event_node_ *node2)
{
   return (NodeCmp(node1, node2, ErrDep) == -1);
}

bool LessThan_Dist(event_node_ *node1, event_node_ *node2)
{
   return (NodeCmp(node1, node2, Dist) == -1);
}

bool LessThan_Type(event_node_ *node1, event_node_ *node2)
{
   return (NodeCmp(node1, node2, Type) == -1);
}

bool LessThan_MInt(event_node_ *node1, event_node_ *node2)
{
   return (NodeCmp(node1, node2, MInt) == -1);
}

bool LessThan_NSta(event_node_ *node1, event_node_ *node2)
{
   return (NodeCmp(node1, node2, NSta) == -1);
}

bool LessThan_M(event_node_ *node1, event_node_ *node2)
{
   return (NodeCmp(node1, node2, M) == -1);
}

bool LessThan_MW(event_node_ *node1, event_node_ *node2)
{
   return (NodeCmp(node1, node2, MW) == -1);
}

bool LessThan_ML(event_node_ *node1, event_node_ *node2)
{
   return (NodeCmp(node1, node2, ML) == -1);
}

bool LessThan_MN(event_node_ *node1, event_node_ *node2)
{
   return (NodeCmp(node1, node2, MN) == -1);
}

bool LessThan_MC(event_node_ *node1, event_node_ *node2)
{
   return (NodeCmp(node1, node2, MC) == -1);
}

bool LessThan_Mb(event_node_ *node1, event_node_ *node2)
{
   return (NodeCmp(node1, node2, Mb) == -1);
}

bool LessThan_MB(event_node_ *node1, event_node_ *node2)
{
   return (NodeCmp(node1, node2, MB) == -1);
}

bool LessThan_Ms(event_node_ *node1, event_node_ *node2)
{
   return (NodeCmp(node1, node2, Ms) == -1);
}

bool LessThan_MS(event_node_ *node1, event_node_ *node2)
{
   return (NodeCmp(node1, node2, MS) == -1);
}

bool LessThan_Locality(event_node_ *node1, event_node_ *node2)
{
   return (NodeCmp(node1, node2, Locality) == -1);
}

bool LessThan_SFile(event_node_ *node1, event_node_ *node2)
{
   return (NodeCmp(node1, node2, SFile) == -1);
}
