#include <QFileDialog>
#include <QMessageBox>
#include "library.h"
#include "convertcatfiledlg.h"
#include "ui_convertcatfiledlg.h"

// ******************************************
// Constructor function.
// ******************************************
ConvertCatFileDlg::ConvertCatFileDlg(QWidget *parent, QString *CatFile, QString *DbPath)
                                    : QDialog(parent), ui(new Ui::ConvertCatFileDlg)
{
   // Set up user interface.
   ui->setupUi(this);

   // Initialization.
   dbPath = DbPath;
   catFile = CatFile;
   ConvertDone = false;
   WorkDir = QDir::currentPath();
   AppName = QCoreApplication::applicationName();
   Message = "WARNING: Existing files in the destination directory will be deleted.";
}



// ******************************************
// Destructor function.
// ******************************************
ConvertCatFileDlg::~ConvertCatFileDlg()
{
   delete ui;
}



// *************************************************************
// Handle the 'Select file' button. User selects a catalog file.
// *************************************************************
void ConvertCatFileDlg::SelectFile()
{
   // Bring up file selection dialog box. User must point
   // to a CAT-file. Return if user cancels the operation.
   Message = "Please select a catalog file:";
   *catFile = QFileDialog::getOpenFileName(this, Message, WorkDir, "All files (*.*)");

   // Return if user did not select a file.
   if (catFile->isNull()) return;

   // Show the filepath in the 'FilePath' line edit widget.
   *catFile = QDir::toNativeSeparators(*catFile);
   ui->CatFile->setText(*catFile);

   // Suggest name of destination folder based on name of cat-file.
   QString DestFolder = QDir::currentPath();
   DestFolder.append("/" + GetNameFromFilePath(*catFile) + "_ldb");
   DestFolder = QDir::toNativeSeparators(DestFolder);
   ui->DestFolder->setText(DestFolder);
}



// ******************************************
// Handle the 'Select folder' button.
// ******************************************
void ConvertCatFileDlg::SelectFolder()
{
   // Bring up file selection dialog box. User must point
   // to a folder. Return if user cancels the operation.
   Message = "Please select a directory for the local database:";
   DestFolder = QFileDialog::getExistingDirectory(this, Message, WorkDir, QFileDialog::ShowDirsOnly);

   // Return if user did not select a folder.
   if (DestFolder.isNull()) return;

   // Show the path in the FolderPath line edit widget.
   ui->DestFolder->setText(DestFolder);
}



// ******************************************
// Handle the 'Extract/Continue' button.
// ******************************************
void ConvertCatFileDlg::Extract()
{
   QString CatFileName, CatFileFolder;

   // Check if 'Continue' button has been pressed.
   if (ConvertDone) {
      // Return path to local database.
      *dbPath = DestFolder;
      done(1);
   }

   // Get catalog file from dialog box.
   *catFile = QDir::toNativeSeparators(ui->CatFile->text());

   // Check that the catalog file exists.
   QFileInfo CFile(*catFile);
   if (CFile.exists() && CFile.isFile()) {
      // Get the file name and folder for the catalog file.
      CatFileName = CFile.fileName();
      CatFileFolder = CFile.absolutePath();
   } else {
      // Invalid file name entered.
      Message = "Non-existing or invalid catalog file entered.";
      QMessageBox::critical(NULL, AppName, Message);
      ui->CatFile->selectAll(); ui->CatFile->setFocus();
      return;
   }

   // Get or set the destination folder.
   DestFolder = QDir::toNativeSeparators(ui->DestFolder->text());
   if (DestFolder.isEmpty()) {
      // Create a default subfolder name in the catalog file's folder.
      DestFolder = QDir::toNativeSeparators(CatFileFolder + "/" + CatFileName + "_ldb");
      // Show the path in the 'FolderPath' line edit widget.
      ui->DestFolder->setText(DestFolder);
   }

   // Check that the destination folder do not contain the catalog file.
   if (QFile::exists(DestFolder + "/" + CatFileName)) {
      Message = "The folder where the catalog file resides cannot be used as the destination directory.";
      QMessageBox::critical(NULL, AppName, Message);
      ui->DestFolder->selectAll(); ui->DestFolder->setFocus();
      return;
   }

   // If the destination folder already exists then clean it.
   if (QDir(ui->DestFolder->text()).exists()) {
      // Clean out existing destination folder.
      CleanDir(DestFolder);
   } else {
      // Create the destination folder.
      if (!CreatePath(DestFolder)) {
         Message = "Unable to create destination folder!";
         QMessageBox::critical(NULL, AppName, Message);
         ui->DestFolder->selectAll(); ui->DestFolder->setFocus();
         return;
      }
   }

   // Convert catalog file to local database.
   int NumFiles, NumWritten;
   ConvertCatFileToLocalDb(*catFile, DestFolder, &NumFiles, &NumWritten);

   // Set the status labels.
   ui->NumFilesLabel->setText("Number of S-files in catalog file: " + QString::number(NumFiles));
   ui->NumWrittenLabel->setText("Number of S-files written to disk: " + QString::number(NumWritten));

   // Check for errors.
   if (!NumWritten) {
      // Error in catalog file. No S-files have been written.
      Message = "<font color=\"red\">";
      Message.append("No valid S-files was found in catalog file.");
      ui->ResultLabel->setText(Message);
   } else {
      // At least one S-file was written to the local database.
      ConvertDone = true;
      // Rename 'Extract' button to 'Continue'.
      ui->ExtractButton->setText("Continue");
      // Set text for the result message label.
      Message = "Extraction is done. Press 'Continue' to open database.";
      if (NumWritten != NumFiles) {
         Message.append("<font color=\"red\">");
         Message.append("Some S-files could not be written. ");
         Message.append("Please check catalog file for errors.");
      }
      ui->ResultLabel->setText(Message);
   }
}



// ******************************************
// Handle the 'Cancel' button.
// ******************************************
void ConvertCatFileDlg::Cancel()
{
   // Close the dialog and return 0.
   done(0);
}



