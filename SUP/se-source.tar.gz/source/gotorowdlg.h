#ifndef GOTOROWDLG_H
#define GOTOROWDLG_H

#include <QDialog>
#include <QString>

namespace Ui {
   class GoToRowDlg;
}

class GoToRowDlg : public QDialog
{
   Q_OBJECT

public:
   explicit GoToRowDlg(QWidget *parent = 0);
   ~GoToRowDlg();

public slots:
   void GoToRow();

private:
   Ui::GoToRowDlg *ui;
   QString Line;
};

#endif // GOTOROWDLG_H
