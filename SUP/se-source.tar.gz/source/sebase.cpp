#include <Qt>
#include <QPalette>
#include <QTableView>
#include <QInputDialog>

#include "google.h"
#include "sebase.h"
#include "string.h"
#include "fortran.h"
#include "mergedlg.h"
#include "filecopy.h"
#include "gotorowdlg.h"
#include "regeventdlg.h"
#include "filterviewdlg.h"
#include "fileeditordlg.h"
#include "addarclinedlg.h"
#include "setcommentsdlg.h"
#include "waveformviewerdlg.h"
#include "edittypeonelinedlg.h"


// ***************************************************
// Destructor for the class.
// ***************************************************
SEBASE::~SEBASE()
{
   // Delete allocated objects.
   if (ELVModel) delete ELVModel;
   if (DB) delete DB;
}


// ***************************************************
// Constructor for the class.
// ***************************************************
SEBASE::SEBASE(SEBASE_CONF *SEDBCONF)
{
   // Copy starttup parameters to local storage.
   Conf = *SEDBCONF;

   // Initialize variables.
   AccTimeInt = 30;
   DbStatus = db::closed;
   AppName = QCoreApplication::applicationName();

   // Create a new database object.
   DB = new db(Conf.LogModel);

   // Configure properties for the event list view widget.
   ELView.setSelectionBehavior(QAbstractItemView::SelectRows);
   ELView.setSelectionMode(QAbstractItemView::ExtendedSelection);
   ELView.setDragEnabled(true); ELView.setAcceptDrops(true);
   ELView.setDragDropMode(QAbstractItemView::DragDrop);

   // Modify colors for the event list view. When view is inactive, selected
   // rows should use the same colors as with an active view. This is done to
   // make 'Speed Search' operation in the view more visible for the operator.
   QPalette Palette = ELView.palette();
   QColor Color = Palette.color(QPalette::Active, QPalette::Highlight);
   Palette.setColor(QPalette::Inactive, QPalette::Highlight, Color);
   Color = Palette.color(QPalette::Active, QPalette::HighlightedText);
   Palette.setColor(QPalette::Inactive, QPalette::HighlightedText, Color);
   ELView.setPalette(Palette);

   // Create and set a data model for the event list view.
   ELVModel = new eventlistmodel(DB);
   ELView.setModel(ELVModel);
   ELVModel->SetView(&ELView);

   // Save pointer to event list view's header object.
   ELVHeader = ELView.horizontalHeader();

   // Configure properties for the event list view's horizontal header object.
   ELVHeader->setFixedHeight(30);
   ELVHeader->setMinimumSectionSize(37);
   ELVHeader->setDefaultSectionSize(100);
   ELVHeader->setSortIndicatorShown(true);
   ELVHeader->setSortIndicator(ColDateTime, Qt::AscendingOrder);

   // Configure properties for the event list view's vertical header object.
   ELView.verticalHeader()->hide();
   ELView.verticalHeader()->sectionResizeMode(QHeaderView::Fixed);
   ELView.verticalHeader()->setDefaultSectionSize(22);

   // Enable the context menu for the event list view.
   ELView.setContextMenuPolicy(Qt::CustomContextMenu);
   QObject::connect(&ELView, SIGNAL(customContextMenuRequested(const QPoint&)), this, SLOT(CCMR_EventListView(const QPoint&)));

   // Create connections from the event list view.
   QObject::connect(&ELView, SIGNAL(doubleClicked(const QModelIndex&)), this, SLOT(ELV_Double_Click(const QModelIndex&)));

   // Install event filter for the event list view.
   ELView.installEventFilter(&ELVFilter);

   // Create connections from ELVFilter.
   connect(&ELVFilter, SIGNAL(ELV_Add_ARC_Line_To_Sfile()), this, SLOT(ELV_Add_ARC_Line_To_Sfile()));
   connect(&ELVFilter, SIGNAL(ELV_Add_Type1_Line_To_Sfile()), this, SLOT(ELV_Add_Type1_Line_To_Sfile()));
   connect(&ELVFilter, SIGNAL(ELV_Associate_Events()), this, SLOT(ELV_Associate_Events()));
   connect(&ELVFilter, SIGNAL(ELV_Duplicate_Event()), this, SLOT(ELV_Duplicate_Event()));
   connect(&ELVFilter, SIGNAL(ELV_Edit_With_Text_Editor()), this, SLOT(ELV_Edit_With_Text_Editor()));
   connect(&ELVFilter, SIGNAL(ELV_Edit_Comment_Lines()), this, SLOT(ELV_Edit_Comment_Lines()));
   connect(&ELVFilter, SIGNAL(ELV_Edit_StationHyp()), this, SLOT(ELV_Edit_StationHyp()));
   connect(&ELVFilter, SIGNAL(ELV_Locate_Event()), this, SLOT(ELV_Locate_Event()));
   connect(&ELVFilter, SIGNAL(ELV_Merge_Events()), this, SLOT(ELV_Merge_Events()));
   connect(&ELVFilter, SIGNAL(ELV_Copy_Events()), this, SLOT(ELV_Copy_Events()));
   connect(&ELVFilter, SIGNAL(ELV_Plot_With_Mulplot()), this, SLOT(ELV_Plot_With_Mulplot()));
   connect(&ELVFilter, SIGNAL(ELV_Plot_With_Mulplot_Menu()), this, SLOT(ELV_Plot_With_Mulplot_Menu()));
   connect(&ELVFilter, SIGNAL(ELV_Set_Distance_Indicator()), this, SLOT(ELV_Set_Distance_Indicator()));
   connect(&ELVFilter, SIGNAL(ELV_Set_Event_Indicator()), this, SLOT(ELV_Set_Event_Indicator()));
   connect(&ELVFilter, SIGNAL(ELV_Set_Model_Indicator()), this, SLOT(ELV_Set_Model_Indicator()));
   connect(&ELVFilter, SIGNAL(ELV_Delete_Events()), this, SLOT(ELV_Delete_Events()));
   connect(&ELVFilter, SIGNAL(ELV_Refresh_View()), this, SLOT(ELV_Refresh_View()));
   connect(&ELVFilter, SIGNAL(ELV_Select_All()), this, SLOT(ELV_Select_All()));
   connect(&ELVFilter, SIGNAL(ELV_Launch_EEV()), this, SLOT(ELV_Launch_EEV()));
   connect(&ELVFilter, SIGNAL(ELV_Show_Events_With_GE()), this, SLOT(ELV_Show_Events_With_GE()));
   connect(&ELVFilter, SIGNAL(ELV_Show_Events_With_Map()), this, SLOT(ELV_Show_Events_With_Map()));
   connect(&ELVFilter, SIGNAL(ELV_Show_Events_With_SV()), this, SLOT(ELV_Show_Events_With_SV()));
   connect(&ELVFilter, SIGNAL(ELV_Show_Path_To_Wavefiles()), this, SLOT(ELV_Show_Path_To_Wavefiles()));
   connect(&ELVFilter, SIGNAL(ELV_GoToNextNewEvent()), this, SLOT(ELV_GoToNextNewEvent()));
   connect(&ELVFilter, SIGNAL(ELV_GoToRowNr()), this, SLOT(ELV_GoToRowNr()));
   connect(&ELVFilter, SIGNAL(ELV_Register_Event()), this, SLOT(ELV_Register_Event()));
   connect(&ELVFilter, SIGNAL(ELV_Reload_Event()), this, SLOT(ELV_Reload_Event()));
   connect(&ELVFilter, SIGNAL(ELV_Load_Event()), this, SLOT(ELV_Load_Event()));
   connect(&ELVFilter, SIGNAL(ELV_Unload_Event()), this, SLOT(ELV_Unload_Event()));
   connect(&ELVFilter, SIGNAL(ELV_Set_Time_Interval()), this, SLOT(ELV_Set_Time_Interval()));
   connect(&ELVFilter, SIGNAL(ELV_Set_Filter()), this, SLOT(ELV_Set_Filter()));

   // Create connections from ELVFilter to ELVModel.
   QObject::connect(&ELVFilter, SIGNAL(ActivateSpeedSearch(char)), ELVModel, SLOT(ActivateSpeedSearch(char)));
   QObject::connect(&ELVFilter, SIGNAL(ScrollToNextSelection()), ELVModel, SLOT(ScrollToNextSelection()));
   QObject::connect(&ELVFilter, SIGNAL(ScrollToPrevSelection()), ELVModel, SLOT(ScrollToPrevSelection()));
   QObject::connect(&ELVFilter, SIGNAL(MarkUnmarkSelectedRows()), ELVModel, SLOT(MarkUnmarkSelectedRows()));
   QObject::connect(&ELVFilter, SIGNAL(UnmarkAllRows()), ELVModel, SLOT(UnmarkAllRows()));
   QObject::connect(&ELVFilter, SIGNAL(ScrollToNextMarkedEvent()), ELVModel, SLOT(ScrollToNextMarkedEvent()));
   QObject::connect(&ELVFilter, SIGNAL(ScrollToPrevMarkedEvent()), ELVModel, SLOT(ScrollToPrevMarkedEvent()));

   // Configure the event list view header.
   SetEventListViewHeaders(Conf.AppConf);

   // Create a vertical layout for the page.
   PageWidget.setLayout(&PageLayout);

   // Insert event list view widget into the layout.
   PageLayout.addWidget(&ELView);

   // Create connections from the event list view header object.
   QObject::connect(ELVHeader, SIGNAL(sortIndicatorChanged(int, Qt::SortOrder)), this, SLOT(ELV_Sort_Indicator_Changed(int, Qt::SortOrder)));

   // Create connections from the event list view data model.
   QObject::connect(ELVModel, SIGNAL(EventsDropped(QStringList)), this, SLOT(EventsDropped(QStringList)));
   QObject::connect(ELVModel, SIGNAL(RowChanged(int)), this, SLOT(RowChanged(int)));

   // Create connections from the database.
   QObject::connect(DB, SIGNAL(db_open_progress(db::dbStatus, int)), this, SLOT(db_open_progress(db::dbStatus, int)));
   QObject::connect(DB, SIGNAL(db_open_result(db::dbStatus, db::dbError)), this, SLOT(db_open_result(db::dbStatus, db::dbError)));
   QObject::connect(DB, SIGNAL(db_filter_progress(char)), this, SLOT(db_filter_progress(char)));
   QObject::connect(DB, SIGNAL(db_event_added(int)), ELVModel, SLOT(InsertRow(int)));
   QObject::connect(DB, SIGNAL(db_event_removed(int)), ELVModel, SLOT(RemoveRow(int)));
   QObject::connect(DB, SIGNAL(db_event_updated(int)), ELVModel, SLOT(RefreshRow(int)));
   QObject::connect(DB, SIGNAL(db_speedsearch_reply(int)), ELVModel, SLOT(SpeedSearchReply(int)));
}




// ***************************************************************
// This function adjust the columns widts to their contents.
// ***************************************************************
void SEBASE::AutoSizeColumns()
{
   ELView.resizeColumnsToContents();
}




// ********************************************************************
// Brings up the Event List View popup meny. This function is signaled
// from EventListView when user right-clicks inside the vidget view.
// ********************************************************************
void SEBASE::CCMR_EventListView(const QPoint &pos)
{
   Q_UNUSED(pos)

   QAction* menuItem;
   event_node_ *EventPtr;
   QModelIndexList ModelIndexes;

   // Get the list of selected rows.
   ModelIndexes = ELView.selectionModel()->selectedRows();
   int NumSelectedRows = ModelIndexes.count();

   // Exit if no rows are selected. This should not be possible.
   if (!NumSelectedRows) return;

   // Get pointer to the first selected event.
   EventPtr = DB->EventByIndex(ModelIndexes.at(0).row());

   // Create a up the popup menu adapted to current selection.
   QMenu *popupMenu = new QMenu();

   // Add 'Add line' item to menu.
   QMenu *AddLineMenu = popupMenu->addMenu( "Add line" );

   // Add 'Add ARC line' item to AddLineMenu menu.
   menuItem = new QAction("Add ARC line", this);
   menuItem->setShortcut(QKeySequence("a"));
   menuItem->setShortcutVisibleInContextMenu(true);
   AddLineMenu->addAction(menuItem);
   connect(menuItem, SIGNAL(triggered()), this, SLOT(ELV_Add_ARC_Line_To_Sfile()));
   if (DbStatus != db::open) menuItem->setDisabled(true);
   if (NumSelectedRows > 1) menuItem->setDisabled(true);

   // Add 'Add hypocenter line' item to AddLineMenu menu.
   menuItem = new QAction("Add hypocenter line", this);
   menuItem->setShortcut(QKeySequence("h"));
   menuItem->setShortcutVisibleInContextMenu(true);
   AddLineMenu->addAction(menuItem);
   connect(menuItem, SIGNAL(triggered()), this, SLOT(ELV_Add_Type1_Line_To_Sfile()));
   if (DbStatus != db::open) menuItem->setDisabled(true);
   if (NumSelectedRows > 1) menuItem->setDisabled(true);

   // Add 'Associate' item to menu.
   menuItem = new QAction("Associate", this);
   menuItem->setShortcut(QKeySequence("shift+a"));
   menuItem->setShortcutVisibleInContextMenu(true);
   popupMenu->addAction(menuItem);
   connect(menuItem, SIGNAL(triggered()), this, SLOT(ELV_Associate_Events()));
   if (DbStatus != db::open) menuItem->setDisabled(true);
   if (NumSelectedRows > 1) menuItem->setDisabled(true);

   // Add 'Copy to file' item to menu.
   menuItem = new QAction("Copy to file", this);
   menuItem->setShortcut(QKeySequence("shift+c"));
   menuItem->setShortcutVisibleInContextMenu(true);
   popupMenu->addAction(menuItem);
   connect(menuItem, SIGNAL(triggered()), this, SLOT(ELV_Copy_Events()));

   // Add 'Delete' item to menu.
   menuItem = new QAction("Delete", this);
   menuItem->setShortcut(QKeySequence("d"));
   menuItem->setShortcutVisibleInContextMenu(true);
   popupMenu->addAction(menuItem);
   connect(menuItem, SIGNAL(triggered()), this, SLOT(ELV_Delete_Events()));
   if (DbInfo.Type == index_file) menuItem->setDisabled(true);
   if (DbStatus != db::open) menuItem->setDisabled(true);
   if (NumSelectedRows > 10) menuItem->setDisabled(true);

   // Add 'Duplicate' item to menu.
   menuItem = new QAction("Duplicate", this);
   menuItem->setShortcut(QKeySequence("shift+d"));
   menuItem->setShortcutVisibleInContextMenu(true);
   popupMenu->addAction(menuItem);
   connect(menuItem, SIGNAL(triggered()), this, SLOT(ELV_Duplicate_Event()));
   if (DbInfo.Type == index_file) menuItem->setDisabled(true);
   if (DbStatus != db::open) menuItem->setDisabled(true);
   if (NumSelectedRows > 1) menuItem->setDisabled(true);

   // Add 'Edit comment lines' item to menu.
   menuItem = new QAction("Edit comment lines", this);
   menuItem->setShortcut(QKeySequence("c"));
   menuItem->setShortcutVisibleInContextMenu(true);
   popupMenu->addAction(menuItem);
   connect(menuItem, SIGNAL(triggered()), this, SLOT(ELV_Edit_Comment_Lines()));
   if (NumSelectedRows > 1) menuItem->setDisabled(true);

  // Add 'Edit with text editor' item to menu.
   menuItem = new QAction("Edit with text editor", this);
   menuItem->setShortcut(QKeySequence("e"));
   menuItem->setShortcutVisibleInContextMenu(true);
   popupMenu->addAction(menuItem);
   connect(menuItem, SIGNAL(triggered()), this, SLOT(ELV_Edit_With_Text_Editor()));
   if (DbStatus != db::open) menuItem->setDisabled(true);
   if (NumSelectedRows > 5 ) menuItem->setDisabled(true);

   // Add 'EEV' item to menu.
   menuItem = new QAction("EEV", this);
   menuItem->setShortcut(QKeySequence("<"));
   menuItem->setShortcutVisibleInContextMenu(true);
   popupMenu->addAction(menuItem);
   connect(menuItem, SIGNAL(triggered()), this, SLOT(ELV_Launch_EEV()));
   if (NumSelectedRows > 1 ) menuItem->setDisabled(true);

   // Add 'Locate' item to menu.
   menuItem = new QAction("Locate", this);
   menuItem->setShortcut(QKeySequence("l"));
   menuItem->setShortcutVisibleInContextMenu(true);
   popupMenu->addAction(menuItem);
   connect(menuItem, SIGNAL(triggered()), this, SLOT(ELV_Locate_Event()));
   if (NumSelectedRows > 1) menuItem->setDisabled(true);

   // Add 'Merge' item to menu.
   menuItem = new QAction("Merge", this);
   menuItem->setShortcut(QKeySequence("m"));
   menuItem->setShortcutVisibleInContextMenu(true);
   popupMenu->addAction(menuItem);
   connect(menuItem, SIGNAL(triggered()), this, SLOT(ELV_Merge_Events()));
   if (DbStatus != db::open) menuItem->setDisabled(true);
   if (NumSelectedRows < 2) menuItem->setDisabled(true);

   // Add 'Plot with mulplot' item to menu.
   menuItem = new QAction("Plot with Mulplot", this);
   menuItem->setShortcut(QKeySequence("p"));
   menuItem->setShortcutVisibleInContextMenu(true);
   popupMenu->addAction(menuItem);
   connect(menuItem, SIGNAL(triggered()), this, SLOT(ELV_Plot_With_Mulplot()));
   if (DbStatus != db::open) menuItem->setDisabled(true);
   if (NumSelectedRows > 1) menuItem->setDisabled(true);
   if (NumSelectedRows == 1 && !EventPtr->wavefiles.numlines) menuItem->setDisabled(true);

   // Add 'Plot with mulplot (show plot menu)' item to menu.
   menuItem = new QAction("Plot with Mulplot (show plot menu)", this);
   menuItem->setShortcut(QKeySequence("shift+p"));
   menuItem->setShortcutVisibleInContextMenu(true);
   popupMenu->addAction(menuItem);
   connect(menuItem, SIGNAL(triggered()), this, SLOT(ELV_Plot_With_Mulplot_Menu()));
   if (DbStatus != db::open) menuItem->setDisabled(true);
   if (NumSelectedRows > 1) menuItem->setDisabled(true);
   if (NumSelectedRows == 1 && !EventPtr->wavefiles.numlines) menuItem->setDisabled(true);

   // Add 'Register' item to menu.
   menuItem = new QAction("Register", this);
   menuItem->setShortcut(QKeySequence("r"));
   menuItem->setShortcutVisibleInContextMenu(true);
   popupMenu->addAction(menuItem);
   connect(menuItem, SIGNAL(triggered()), this, SLOT(ELV_Register_Event()));
   if (DbStatus != db::open) menuItem->setDisabled(true);
   if (NumSelectedRows > 1) menuItem->setDisabled(true);
   if (!EventPtr->wavefiles.numlines) menuItem->setDisabled(true);

   // Add 'Reload event' item to menu.
   menuItem = new QAction("Reload event", this);
   menuItem->setShortcut(QKeySequence("ctrl+r"));
   menuItem->setShortcutVisibleInContextMenu(true);
   popupMenu->addAction(menuItem);
   connect(menuItem, SIGNAL(triggered()), this, SLOT(ELV_Reload_Event()));
   if (DbStatus != db::open) menuItem->setDisabled(true);
   if (NumSelectedRows > 1) menuItem->setDisabled(true);

   // Add 'Set distance indicator' item to menu.
   menuItem = new QAction("Set distance indicator", this);
   menuItem->setShortcut(QKeySequence("ctrl+d"));
   menuItem->setShortcutVisibleInContextMenu(true);
   popupMenu->addAction(menuItem);
   connect(menuItem, SIGNAL(triggered()), this, SLOT(ELV_Set_Distance_Indicator()));

   // Add 'Set event indicator' item to menu.
   menuItem = new QAction("Set event indicator", this);
   menuItem->setShortcut(QKeySequence("ctrl+e"));
   menuItem->setShortcutVisibleInContextMenu(true);
   popupMenu->addAction(menuItem);
   connect(menuItem, SIGNAL(triggered()), this, SLOT(ELV_Set_Event_Indicator()));

   // Add 'Set model indicator' item to menu.
   menuItem = new QAction("Set model indicator", this);
   menuItem->setShortcut(QKeySequence("ctrl+m"));
   menuItem->setShortcutVisibleInContextMenu(true);
   popupMenu->addAction(menuItem);
   connect(menuItem, SIGNAL(triggered()), this, SLOT(ELV_Set_Model_Indicator()));

   // Add 'Show path to wave files' item to menu.
   menuItem = new QAction("Show path to wave files", this);
   menuItem->setShortcut(QKeySequence("w"));
   menuItem->setShortcutVisibleInContextMenu(true);
   popupMenu->addAction(menuItem);
   connect(menuItem, SIGNAL(triggered()), this, SLOT(ELV_Show_Path_To_Wavefiles()));

   // Add 'Show with Google Earth' item to menu.
   menuItem = new QAction("Show with Google Earth", this);
   menuItem->setShortcut(QKeySequence("shift+g"));
   menuItem->setShortcutVisibleInContextMenu(true);
   popupMenu->addAction(menuItem);
   connect(menuItem, SIGNAL(triggered()), this, SLOT(ELV_Show_Events_With_GE()));

   // Add 'Show with map command' item to menu.
   menuItem = new QAction("Show with map command", this);
   menuItem->setShortcut(QKeySequence("shift+m"));
   menuItem->setShortcutVisibleInContextMenu(true);
   popupMenu->addAction(menuItem);
   connect(menuItem, SIGNAL(triggered()), this, SLOT(ELV_Show_Events_With_Map()));

   // Add 'Show with Seismicity Viewer' item to menu.
   menuItem = new QAction("Show with Seismicity Viewer", this);
   menuItem->setShortcut(QKeySequence("v"));
   menuItem->setShortcutVisibleInContextMenu(true);
   popupMenu->addAction(menuItem);
   connect(menuItem, SIGNAL(triggered()), this, SLOT(ELV_Show_Events_With_SV()));

   // Add 'Simple Waveform Viewer' item to menu.
   menuItem = new QAction("Simple Waveform Viewer", this);
   popupMenu->addAction(menuItem);
   connect(menuItem, SIGNAL(triggered()), this, SLOT(ELV_SimpleWaveformViewer()));

   // Add separator to menu.
   popupMenu->addSeparator();

   // Add 'Mark/Unmark' item to menu.
   menuItem = new QAction("Mark/Unmark", this);
   menuItem->setShortcut(QKeySequence("ctrl+x"));
   menuItem->setShortcutVisibleInContextMenu(true);
   popupMenu->addAction(menuItem);
   connect(menuItem, SIGNAL(triggered()), ELVModel, SLOT(MarkUnmarkSelectedRows()));
   if (DbStatus != db::open) menuItem->setDisabled(true);

   // Add 'Unmark all' item to menu.
   menuItem = new QAction("Unmark all", this);
   menuItem->setShortcut(QKeySequence("alt+x"));
   menuItem->setShortcutVisibleInContextMenu(true);
   popupMenu->addAction(menuItem);
   connect(menuItem, SIGNAL(triggered()), ELVModel, SLOT(UnmarkAllRows()));
   if (DbStatus != db::open) menuItem->setDisabled(true);

   // Add 'Select all events' item to menu.
   menuItem = new QAction("Select all events", this);
   menuItem->setShortcut(QKeySequence("ctrl+a"));
   menuItem->setShortcutVisibleInContextMenu(true);
   popupMenu->addAction(menuItem);
   connect(menuItem, SIGNAL(triggered()), this, SLOT(ELV_Select_All()));
   if (DbStatus != db::open) menuItem->setDisabled(true);

   // Add 'Load event file into Explorer' item to menu.
   menuItem = new QAction("Load event file into Explorer", this);
   menuItem->setShortcut(QKeySequence("f3"));
   menuItem->setShortcutVisibleInContextMenu(true);
   popupMenu->addAction(menuItem);
   connect(menuItem, SIGNAL(triggered()), this, SLOT(ELV_Load_Event()));
   if (DbStatus != db::open) menuItem->setDisabled(true);
   if (NumSelectedRows > 1 ) menuItem->setDisabled(true);

   // Add 'Unoad event file from Explorer' item to menu.
   menuItem = new QAction("Unload event file from Explorer", this);
   menuItem->setShortcut(QKeySequence("f4"));
   menuItem->setShortcutVisibleInContextMenu(true);
   popupMenu->addAction(menuItem);
   connect(menuItem, SIGNAL(triggered()), this, SLOT(ELV_Unload_Event()));
   if (DbStatus != db::open) menuItem->setDisabled(true);
   if (NumSelectedRows > 1 ) menuItem->setDisabled(true);

   // Add 'Refresh view' item to menu.
   menuItem = new QAction("Refresh view", this);
   menuItem->setShortcut(QKeySequence("f5"));
   menuItem->setShortcutVisibleInContextMenu(true);
   popupMenu->addAction(menuItem);
   connect(menuItem, SIGNAL(triggered()), this, SLOT(ELV_Refresh_View()));

   // Show popup menu at mouse position.
   popupMenu->exec(QCursor::pos());
}




// **************************************************
// Close the database. No user confirmation required.
// **************************************************
void SEBASE::Close()
{
   // Close all opened file editors.
   emit close_file_editor();

   // Stop all running mulplt processes.
   qDeleteAll(MulpltHandlers);
   MulpltHandlers.clear();

   // Close the DB class.
   DB->Close();

   // Reset the event list view model.
   ELVModel->Reset();

   // Remove the tab for the event list view from the tab widget.
   Conf.TabWidget->removeTab(TabIndex());

   // Set database status.
   DbStatus = db::closed;

   // Signal that database is closed.
   emit closed(this);
}




// **************************************************
// Returns the current active row/index (zero-based).
// **************************************************
int SEBASE::CurrentRow()
{
   return ELView.currentIndex().row();
}




// *******************************************************
// Forward filtering progress from database to mainwindow.
// *******************************************************
void SEBASE::db_filter_progress(char Progress)
{
   // Display filtering progress in percents.
   if (Progress < 100) {
      Message = "Filtering database, ";
      Message.append(QString::number(Progress) + "% done.");
      emit show_sb_message(Message, 0);
   } else {
      Message = "Database filtering done.";
      emit show_sb_message(Message, 5000);
   }
}




// ***********************************************************
// Slot for database (DB). Open progress report.
// ***********************************************************
void SEBASE::db_open_progress(db::dbStatus db_status, int progress)
{
   // Save the SEBASE status.
   DbStatus = db_status;

   // DB is scanning for S-files.
   if (DbStatus == db::enum_sfiles) {
      DoOnceAtLoadStart = true;
      // Display number of S-files found.
      Message = "Loading database, enumerating event files... (";
      Message.append(QString::number(progress) + " files found).");
   }

   // DB is reading S-files.
   if (DbStatus == db::read_sfiles) {
      if (DoOnceAtLoadStart) {
         // Things we do only once.
         if (DB->NumEvents() > 200 || progress == 100) {
            // Reset the Event List View model.
            ELVModel->Reset();
            // Add new data to the Event List View model.
            ELVModel->FetchMoreData();
            // Select first row in Event List View.
            ELVModel->SelectRow(0, true, true, false);
            // Fit column widths automatically.
            AutoSizeColumns();
            // Switch to Event List View.
            Conf.TabWidget->setCurrentIndex(TabIndex());
            // Reset flag.
            DoOnceAtLoadStart = false;
         }
      } else {
         // Add new data to the Event List View model.
         ELVModel->FetchMoreData();
      }
      // Display read progress in percents.
      Message = "Loading database, reading event files... (";
      Message.append(QString::number(progress)+ "% done.)");
   }

   // Signal progress status.
   emit show_sb_message(Message, 0);
}




// ****************************************************************
// Slot for database(DB). Open process has ended.
// ****************************************************************
void SEBASE::db_open_result(db::dbStatus status, db::dbError error)
{
   // Save the database status.
   DbStatus = status;

   // Database has been opened.
   if (DbStatus == db::open) {
      // Set tab title.
      SetTabTitle();
      // Size the column widths.
      AutoSizeColumns();
      // Signal the result and the total load time.
      emit open_result(status, error, (int)LdStartTime.secsTo(QDateTime::currentDateTime()));
   }

   // Database open failed.
   if (DbStatus == db::closed) {
      // Reset the event list view model.
      ELVModel->Reset();

      // Remove the event list view tab from the tab widget.
      Conf.TabWidget->removeTab(TabIndex());

      // Signal the result.
      emit open_result(status, error, 0);
   }
}




// ******************************************************************
// This function unloads an event from the database and deletes the
// S-file from disk. It also updates the event log view. User will
// NOT be asked for permission before delete. If 'Quiet' is true then
// all messages normally going to the log window will be supressed.
// ******************************************************************
bool SEBASE::DeleteEvent(int DbIndex, int *Status, bool Select, bool Quiet)
{
   int NumEvents;
   QString FileName, Message;

   // Get filename for the selected row.
   // Return if DbIndex is out of bounds.
   if (!DB->FileByIndex(DbIndex, &FileName)) return false;

   // Delete the event file from disk.
   if ((*Status = DeleteSfileFromDisk(FileName, DbInfo))) {
      if (!Quiet) {
         // Delete operation failed. Write error message to log.
         Message = "Unable to delete event. ";
         if (*Status == 1) Message.append("Event file was not found.");
         if (*Status == 2) Message.append("Failed to delete event file.");
         if (*Status == 3) Message.append("Failed to locate DELET database.");
         if (*Status == 4) Message.append("Failed to copy event to DELET database.");
         Conf.LogModel->WriteLog(logmodel::error, Message);
      }
      return false;
   }

   // S-file has been deleted.
   if (!Quiet) {
      Message = "Event file '" + FileName + "' was deleted.";
      Conf.LogModel->WriteLog(logmodel::info, Message);
   }

   // Remove event from SE.
   DB->RemoveEvent(DbIndex);

   // Get number of events in db.
   NumEvents = DB->NumEvents();

   // Select a new row.
   if (Select && NumEvents) {
      if (DbIndex == NumEvents) {
         // The row at the end was deleted.
         ELVModel->SelectRow(DbIndex-1, true, true, false);
      } else {
         // A row in the middle or at the start was deleted.
         ELVModel->SelectRow(DbIndex, true, true, false);
         emit cur_row_data_changed(this);
      }
   }

   // Signal that number of events has changed.
   emit num_events_changed(NumEvents);

   return true;
}




// ****************************************************
// User has double clicked on a line in the event
// list view. OPen the text editor for this event.
// ****************************************************
void SEBASE::ELV_Double_Click(const QModelIndex &index)
{
   Q_UNUSED(index)

   ELV_Edit_With_Text_Editor();
}




// *******************************************************************
// This function adds an ARC line to the S-file of the selected event.
// *******************************************************************
void SEBASE::ELV_Add_ARC_Line_To_Sfile()
{
   // Check that database is open.
    if (DbStatus == db::closed) return;
    if (DbStatus != db::open) { ShowMessage(300); return; }

   // Check that at least one predefined network name has been loaded.
   if (!Conf.PredefNetworks.size()) {
      Message = "No network list found. You can define the list by adding a line to SEISAN.DEF:\n\n";
      Message.append("SE_VIRTUAL_NETWORKS Network1,Network2,Network3,Network4,...\n\n");
      Message.append("NOTE: Seisan Explorer must be restarted for changes to take effect.");
      QMessageBox::warning(0, AppName, Message);
      return;
   }

   // Get the list of selected rows.
   ELVModel->GetSelection(&ELVSelection);

   // Exit if no rows are selected.
   if (!ELVSelection.size()) return;

   // Only one row can be selected.
   if (ELVSelection.size() > 1) { ShowMessage(310, true); return; }

   // Bring up the 'Add line to event file' dialog box. The
   // dialog function will update the node, and rewrite the S-file.
   AddArcLineDlg *Dialog = new AddArcLineDlg(DB, ELVSelection.at(0).index, Conf.PredefNetworks);
   Dialog->setAttribute(Qt::WA_DeleteOnClose, true);
   Dialog->exec();
}




// *********************************************************************
// This function adds a type 1 line to the S-file of the selected event.
// *********************************************************************
void SEBASE::ELV_Add_Type1_Line_To_Sfile()
{
   int DbIndex;
   char Status;
   event_node_ *Node;

   // Check that database is open.
   if (DbStatus == db::closed) return;
   if (DbStatus != db::open) { ShowMessage(300); return; }

   // Get the list of selected rows.
   ELVModel->GetSelection(&ELVSelection);

   // Exit if no rows are selected.
   if (!ELVSelection.size()) return;

   // Only one row can be selected.
   if (ELVSelection.size() > 1) { ShowMessage(310, true); return; }

   // Get database index and pointer to event node.
   Node = DB->EventByIndex((DbIndex = ELVSelection.at(0).index));

   // Copy some default values from the primary hypocenter.
   hypocenter_ HypoCenter;
   HypoCenter.time = Node->hypocenters.first->time;
   HypoCenter.dist_id = Node->hypocenters.first->dist_id;
   HypoCenter.lat = Node->hypocenters.first->lat;
   HypoCenter.lon = Node->hypocenters.first->lon;
   HypoCenter.depth = Node->hypocenters.first->depth;
   HypoCenter.modl_id = Node->hypocenters.first->modl_id;
   HypoCenter.evnt_id = Node->hypocenters.first->evnt_id;
   strcpy(HypoCenter.agency, Node->hypocenters.first->agency);

   // Bring up the 'Edit type 1 line' dialog box.
   EditTypeOneLineDlg *Editor = new EditTypeOneLineDlg(0, &HypoCenter);
   Editor->setAttribute(Qt::WA_DeleteOnClose, true);
   Editor->setWindowTitle("Add hypocenter line to event file");

   // Save the new hypocenter to event file.
   if (Editor->exec() == QDialog::Accepted) {
      // Add new hypocenter to node.
      NodeAddHypocenter(Node, &HypoCenter);
      // Rewrite the event file.
      if (!DB->UpdateSfile(DbIndex, &Status)) {
         // Unable to write new event file. Write error message to the log.
         Message = "Failed to add hypocenter to '";
         Message.append(Node->metadata.sfile); Message.append("'.");
         Conf.LogModel->WriteLog(logmodel::error, Message);
         emit Conf.LogModel->show_log_view();
         return;
      }

      // Reload updated event into SE.
      ReloadEvent(DbIndex);
   }
}




// ***********************************************************************
// This function handles the 'Accosiate events' menu item. Function is
// used to find events that are close to each other in time. The time
// interval supplied by the user specifies how close the events has to be.
// Search will go downwards from the currently selected event in event
// list view. Found events will be selected in the list.
// ***********************************************************************
void SEBASE::ELV_Associate_Events()
{
   bool ok;
   char str7[8];
   int DbIndex;
   QString label;
   sortCol CurrSortColumn;
   Qt::SortOrder CurrSortOrder;

   // Check that database is open.
   if (DbStatus != db::open) return;

   // Check current sort order. Sort order must be 'DateTime'.
   DB->SortCriteria(&CurrSortColumn, &CurrSortOrder);
   if (CurrSortColumn != DateTime) {
      Message = "Event list must be sorted by date and time.";
      emit show_sb_message(Message, 8000);
      return;
   }

   // Get the list of selected rows.
   ELVModel->GetSelection(&ELVSelection);

   // Exit if no rows are selected.
   if (!ELVSelection.size()) return;

   // Only one row can be selected.
   if (ELVSelection.size() > 1) { ShowMessage(310, true); return; }

   // Start the search from the selected row.
   DbIndex = ELVSelection.at(0).index;

   // Bring up dialog box and ask user for time interval (in seconds).
   label.append("Search starts from the selected row.\n");
   label.append("Please enter time interval in seconds:");
   QString Title = "Associate events";
   AccTimeInt = QInputDialog::getInt(0, Title, label, AccTimeInt, 0, 3600, 10, &ok, Qt::Dialog);
   if (!ok) return;

   // Search for events. This is done by the database.
   // Database will return a list of found indexes.
   // If IndexList.size() is zero then none was found.
   QList<int> IndexList;
   DB->AssociateEvents(AccTimeInt, DbIndex, &IndexList);
   if (!IndexList.size()) {
      Message = "No associations where found.";
      emit show_sb_message(Message, 8000);
      return;
   } else {
      // Select the events in the event list view.
      QApplication::setOverrideCursor(QCursor(Qt::WaitCursor));
      ELVModel->SelectRows(&IndexList, true);
      QApplication::restoreOverrideCursor();
      // Write number of found events.
      sprintf(str7, "%i", IndexList.size());
      Message.clear(); Message.append(QString(str7));
      Message.append(" events has been selected.");
      emit show_sb_message(Message, 8000);
   }
}




// ***********************************************************************
// This function copies one or more selected event files to a file. This
// function is signaled from the Event List View popup menmu. Name of out
// file is 'se-select.out'. File is placed in the current working folder.
// ***********************************************************************
void SEBASE::ELV_Copy_Events()
{
   QString FileName;
   int NumSelectedRows;
   QStringList FileList;

   // Get the list of selected rows.
   ELVModel->GetSelection(&ELVSelection);

   // Get number of selected rows.
   NumSelectedRows = ELVSelection.size();

   // Exit if no rows are selected.
   if (!NumSelectedRows) return;

   // Add all selected event files to file list.
   for (int i=0;i<NumSelectedRows;i++) {
      // Get filename for this row.
      DB->FileByIndex(ELVSelection.at(i).index, &FileName);
      // Add to file list.
      FileList.append(FileName);
   }

   // Merge together all files in the file list
   // and save the result in the outfile. The
   // files in the file list are not modified.
   if (!MergeFiles(FileList, QString("se-select.out"))) {
      // Merge failed. Write error message in the log.
      Message = "The 'Copy to file' function failed. Check disk space and write permissions for work folder.";
      Conf.LogModel->WriteLog(logmodel::error, Message);
      emit Conf.LogModel->show_log_view();
   } else {
      QString FileName = BuildPath(QDir::currentPath(), "se-select.out");
      Message = "Selected events have been copied to '" + FileName + "'.";
      emit show_sb_message(Message, 8000);
   }
}




// ********************************************************************
// This function handles the 'Delete' menu item. This
// function is signaled from the Event List View popup menmu.
// ********************************************************************
void SEBASE::ELV_Delete_Events()
{
   QString FileName;
   bool DelError;
   int NumRows, DbIndex, dStatus;

   // Check that database is not an index file.
   if (DbInfo.Type == index_file) {
      Message = "Delete is not supported when database is an index file.";
      emit show_sb_message(Message, 8000);
      return;
   }

   // Check that database is open.
   if (DbStatus == db::closed) return;
   if (DbStatus != db::open) { ShowMessage(300); return; }

   // Get the list and number of selected rows.
   ELVModel->GetSelection(&ELVSelection);
   NumRows = ELVSelection.size();

   // Exit if no rows are selected.
   if (!NumRows) return;

   // Check number of selected rows. Max 10 events can be selected.
   if (NumRows > 10) {
      Message = "A maximum of 10 selections are allowed for this operation.";
      emit show_sb_message(Message, 8000);
      return;
   }

   // Ask user for confirmation.
   if (NumRows == 1) {
      // Get filename for the one selected row.
      DB->FileByIndex(ELVSelection.at(0).index, &FileName);
      Message = "Are you sure you want to delete this event from the Seisan database?\n" + FileName;
   } else {
      Message = "WARNING: You have selected " + QString::number(NumRows) + " events for deletion.\n";
      Message.append("Are you sure you want to delete these events from the Seisan database?");
   }
   if (QMessageBox::question(0, "Delete", Message, QMB_YES | QMB_NO, QMB_NO) != QMB_YES) return;

   // Delete selected events from database.
   DelError = false;
   for (int i=0;i<NumRows;i++) {
      DbIndex = DB->IndexById(ELVSelection.at(i).id);
      if (!DeleteEvent(DbIndex, &dStatus, true, false)) DelError = true;
   }

   // If any errors occurred, signal that log view should be shown.
   if (DelError) emit Conf.LogModel->show_log_view();
}




// ********************************************************************
// This function duplicates the selected event.
// This function is signaled from the Event List View popup menmu.
// ********************************************************************
void SEBASE::ELV_Duplicate_Event()
{
   int DbIndex;
   QString FileName, DupFile;

   // Check that database is not an index file.
   if (DbInfo.Type == index_file) {
       Message = "Duplicate is not supported when database is an index file.";
       emit show_sb_message(Message, 8000);
       return;
   }

   // Check that database is open.
   if (DbStatus == db::closed) return;
   if (DbStatus != db::open) { ShowMessage(300); return; }

   // Get the list of selected rows.
   ELVModel->GetSelection(&ELVSelection);

   // Exit if no rows are selected.
   if (!ELVSelection.size()) return;

   // Only one row can be selected.
   if (ELVSelection.size() > 1) { ShowMessage(310, true); return; }

   // Get file name for this event.
   DbIndex = ELVSelection.at(0).index;
   DB->FileByIndex(DbIndex, &FileName);

   // Duplicate the file.
   if (!DuplicateSfileOnDisk(FileName, &DupFile, Conf.Operator->GetConfirmedId())) {
      Message = "Failed to duplicate event file. Check event file and database folder permissions.";
      Conf.LogModel->WriteLog(logmodel::error, Message);
      emit Conf.LogModel->show_log_view();
   } else {
      // Duplication succeeded. Load file into database.
      DbIndex = DB->LoadEventAndResort(DupFile);
      if (DbIndex >= 0) {
         emit num_events_changed(DB->NumEvents());
         emit show_sb_message("Duplication succeeded.", 5000);
      }
      if (DbIndex == -1) {
         Message = "Failed to load duplicated event. Check event file '" + DupFile + "' for errors.";
         Conf.LogModel->WriteLog(logmodel::error, Message);
         emit Conf.LogModel->show_log_view();
      }
   }
}




// ********************************************************************
// This function handles the 'Edit comment lines' menu item.
// This function is signaled from the Event List View popup menmu.
// ********************************************************************
void SEBASE::ELV_Edit_Comment_Lines()
{
   char Status;
   event_node_ *Node;
   QStringList CommentList;
   SetCommentsDlg *Editor;

   // Get the list of selected rows.
   ELVModel->GetSelection(&ELVSelection);

   // Exit if no rows are selected.
   if (!ELVSelection.size()) return;

   // Only one row can be selected.
   if (ELVSelection.size() > 1) { ShowMessage(310, true); return; }

   // Get pointer to event node.
   Node = DB->EventByIndex(ELVSelection.at(0).index);

   // Get all comment lines.
   NodeGetComments(Node, &CommentList);

   // Bring up the comments editor.
   Editor = new SetCommentsDlg(0, &CommentList, Conf.PredefComments);
   Editor->setAttribute(Qt::WA_DeleteOnClose, true);
   if (Editor->exec() == QDialog::Accepted) {
      // Save new comments to node.
      NodeSetComments(Node, CommentList);
      // Rewrite the event file.
      if (!DB->UpdateSfile(ELVSelection.at(0).index, &Status)) {
         // Unable to write new event file.
         // Write error message to the log.
         Message = "Failed to update comments for '";
         Message.append(Node->metadata.sfile); Message.append("'.");
         Conf.LogModel->WriteLog(logmodel::error, Message);
         emit Conf.LogModel->show_log_view();
      }
   }
}




// ********************************************************************
// This function edits the STATIONx.HYP file for the selected event.
// This function is signaled from the Event List View keyboard filter.
// This signal is forwarded to the main window.
// ********************************************************************
void SEBASE::ELV_Edit_StationHyp()
{
   emit edit_stationhyp_file();
}




// ********************************************************************
// This function handles the 'Edit with text editor' menu item.
// This function is signaled from the Event List View popup menmu.
// ********************************************************************
void SEBASE::ELV_Edit_With_Text_Editor()
{
   int DbIndex;
   QPoint Position;
   QString FileName;
   FileEditorDlg *Editor;

   // Check that database is open.
   if (DbStatus == db::closed) return;
   if (DbStatus != db::open) { ShowMessage(300); return; }

   // Get the list of selected rows.
   ELVModel->GetSelection(&ELVSelection);
   int NumRows = ELVSelection.size();

   // Exit if no rows are selected.
   if (!NumRows) return;

   // A maximum of one row can be selected.
   if (NumRows > 5) {
      Message = "A maximum of 5 selections are allowed for this operation.";
      emit show_sb_message(Message, 8000);
      return;
   }

   // Open an editor for each selected event
   bool FirstEditor = true;
   for (int i=0;i<NumRows;i++) {
      // Get database index for event.
      DbIndex = ELVSelection.at(i).index;
      // Get file name for event.
      DB->FileByIndex(DbIndex, &FileName);
      // Bring up the editor. Editor will automatically
      // be destroyed when the user closes the window.
      Editor = new FileEditorDlg();
      Editor->setAttribute(Qt::WA_DeleteOnClose, true);
      if (Editor->LoadFile(FileName)) {
         // File was sucessfully opened. Connect signals to/from editor.
         connect(this, SIGNAL(close_file_editor()), Editor, SLOT(Close()));
         connect(Editor, SIGNAL(file_saved(QString)), this, SLOT(FileSaved(QString)));
         // Adjust screen position of editors on sreen so
         // that they do not overlap each other completley.
         if (FirstEditor) {
            // The first editor will be positioned into its
            // default position. Get and save this position.
            Position = Editor->pos(); FirstEditor = false;
         } else {
            // Change position on screen for this editor
            // slightly compared to the previous editor.
            Position.setX(Position.rx()+50);
            Position.setY(Position.ry()+50);
            Editor->move(Position);
            // Only the first editor window should
            // save its position when it closes.
            Editor->SavePos = false;
         }
         // Show the editor window.
         Editor->show();
      } else {
         // File could not be opened.
         delete Editor;
         Message = "<b>Unable to open file '" + FileName + "' for editing.</b>";
         QMessageBox::critical(0, AppName, Message);
      }
   }
}




// ********************************************************************
// This function moves current selection to the next row number that
// has Action = NEW. The current selection is lost.
// ********************************************************************
void SEBASE::ELV_GoToNextNewEvent()
{
   event_node_ *Node;

   // Return if the database is closed.
   if (DbStatus == db::closed) return;

   // Get number of selected rows.
   ELVModel->GetSelection(&ELVSelection);
   int NumSelectedRows = ELVSelection.size();

   // Get number of events in database.
   int NumEvents = DB->NumEvents();

   // If only one row is selected, then start search
   // from selected row. Othervise, search from top.
   int StartRow = 0;
   if (NumSelectedRows == 1) {
      StartRow = ELVSelection.at(0).index + 1;
      if (StartRow == NumEvents) StartRow = 0;
   }

   // Search for next event with Action = 'NEW' .
   for (int Index=StartRow;Index<NumEvents;Index++) {
      Node = DB->EventByIndex(Index);
      if (!QString::compare(QString(Node->action), "NEW", Qt::CaseInsensitive)) {
         // Select the found row and return.
         ELVModel->SelectRow(Index, true, true, true);
         return;
      }
   }
}




// ********************************************************************
// This function is brings up the 'Goto' dialog box. This dialog
// box is used to move current selection to a particular row number.
// The current selection is lost.
// ********************************************************************
void SEBASE::ELV_GoToRowNr()
{
   // Return if the database is closed.
   if (DbStatus == db::closed) return;

   // Get number of events in database.
   // Return if the database is empty.
   int NumEvents = DB->NumEvents();
   if (!NumEvents) return;

   // Open the dialog box.
   GoToRowDlg *Dialog = new GoToRowDlg();  // Create the dialog.
   RowNum = Dialog->exec();             // Open the dialog box.
   delete Dialog;                          // Destroy the dialog.
   if (RowNum > 0) {
      // Check row number.
      int NumEvents = DB->NumEvents();
      if (RowNum > NumEvents) RowNum = NumEvents;
      // Select the new row.
      ELVModel->SelectRow(RowNum-1, true, true, true);
   }
}




// ********************************************************************
// This function handles the 'EEV' menu item. This
// function is signaled from the Event List View popup menmu.
// ********************************************************************
void SEBASE::ELV_Launch_EEV()
{
   int DbIndex, NewIndex;
   QString Eev, EventFile;
   sfile_nameinfo NameInfo;
   QDateTime ModTime1, ModTime2;

   // Get the list of selected rows.
   ELVModel->GetSelection(&ELVSelection);

   // Exit if no rows are selected.
   if (!ELVSelection.size()) return;

   // Only one event can be selected.
   if (ELVSelection.size() > 1) { ShowMessage(310, true); return; }

   // Create a platform dependant name for the 'eev' program.
   Eev = "eev.exe";
   #ifdef Q_OS_LINUX
   Eev = "eev";
   #endif

   // Check that the 'eev' program exists.
   if (!IsFileInPath(Eev)) {
      Message = "EEV: Cannot find eev in the path.";
      Conf.LogModel->WriteLog(logmodel::error, Message);
      emit Conf.LogModel->show_log_view();
      return;
   }

   // Get date/time from the name of the event file.
   DbIndex = ELVSelection.at(0).index;
   DB->FileByIndex(DbIndex, &EventFile);
   GetSfileNameInfo(EventFile, &NameInfo);

   // Save the event file modification time.
   GetFileModTime(EventFile, &ModTime1);

   // Prepare the eev command line.
   QString Command = Eev + " " + NameInfo.DateStr + NameInfo.TimeStr + " ";
   Command.append(DbInfo.Name + " -seisanexp SAME " + Conf.Operator->GetConfirmedId());

   // Start xterm for eev if we are running on the Linux platform.
   #ifdef Q_OS_LINUX
   Command.prepend("xterm -e ");
   #endif

   // Launch eev.Execution will hang here until eev ends.
   std::system(Command.toLatin1().data());

   // Check if event file has been updated.
   GetFileModTime(EventFile, &ModTime2);
   if (ModTime1 != ModTime2) {
      // Eventfile has been updated. Save event identity.
      int EventId = DB->IdByIndex(DbIndex);
      // Reload the event file in database.
      if (DB->ReloadEventAndResort(DbIndex)) {
         // Event file could not be reloaded.
         Message = "Unable to locate event. Failed to reload the updated event file.";
         Conf.LogModel->WriteLog(logmodel::error, Message);
         emit Conf.LogModel->show_log_view();
      } else {
         // Event file has been reloaded. Select the correct row.
         NewIndex = DB->IndexById(EventId);
         ELVModel->SelectRow(NewIndex, true, true, true);
         if (NewIndex == DbIndex) emit cur_row_data_changed(this);
      }
   }
}




// ********************************************************************
// This function load an event file from disk into Explorer. This
// function is signaled from the Event List View popup menu.
// It is not allowed to
// - load an S-file from another database.
// - Load an S-file that is not within the current time interval.
// ********************************************************************
void SEBASE::ELV_Load_Event()
{
   QString File;
   int EventIndex;
   sfile_nameinfo NameInfo;

   // Check that database is open.
   if (DbStatus == db::closed) return;
   if (DbStatus != db::open) { ShowMessage(300); return; }

   // Bring up file selection dialog box. Return if user
   // cancel the operation. User must point to an S-file.
   Message = "Please select an event file to load:";
   File = QFileDialog::getOpenFileName(0, Message, DbInfo.Path);
   File = QDir::toNativeSeparators(File);

   // Return if user did not select a file.
   if (File.isNull()) return;

   // Check that the selected file is an S-file.
   if (!IsSfileNameOk(GetNameFromFilePath(File))) {
      Message = "<b>The selected file has an invalid name.</b>";
      QMessageBox::critical(0, "Load event file", Message);
      return;
   }

   // Get the path/folder for the selected file.
   GetSfileNameInfo(File, &NameInfo);

   // Check that user has selected a file from the current database.
   // This test is skipped if an index file has been opened.
   if (DbInfo.Type != index_file) {
      if (!NameInfo.Path.startsWith(DbInfo.Path)) {
         Message = "Please select an event file from the currently opened database.";
         QMessageBox::critical(0, "Load event file", Message);
         return;
      }
   }

   // Check if file is outside the current time interval.
   if (NameInfo.Date < Conf.AppConf.TimeIntDates.StartDate || NameInfo.Date > Conf.AppConf.TimeIntDates.EndDate) {
      Message = "Cannot load an event that is outside the current time interval.";
      QMessageBox::critical(0, "Load event file", Message);
      return;
   }

   // Check that event file is not already loaded.
   EventIndex = DB->IndexByFile(File);
   if (EventIndex != -1) {
      Message = "<b>This event file is already loaded.</b>";
      QMessageBox::information(0, "Load event file", Message);
      ELVModel->SelectRow(EventIndex, true, true, true);
      return;
   }

   // Load the event file
   LoadEvent(File);
}




// ********************************************************************
// This function handles the 'Locate event' menu item.
// This function is signaled from the Event List View popup menmu.
// ********************************************************************
void SEBASE::ELV_Locate_Event()
{
   emit locate_event();
}




// ***********************************************************************
// This function merges two or more selected events files.
// ***********************************************************************
void SEBASE::ELV_Merge_Events()
{
   QListEventID FailedMerges;
   QString DestFile, MergeFile;
   bool MergeError, ReloadError, DeleteError;
   int EventIndex, uStatus, mStatus, NumSelectedRows;
   int NumMergedFiles, NumDeletedFiles, EventID, dStatus=0;

   // Check that database is open.
   if (DbStatus == db::closed) return;
   if (DbStatus != db::open) { ShowMessage(300); return; }

   // Get the list of selected rows.
   ELVModel->GetSelection(&ELVSelection);

   // Get number of selected rows.
   NumSelectedRows = ELVSelection.size();

   // Exit if less than two rows are selected.
   if (NumSelectedRows < 2) return;

   // Mark the destination event with a '+' in the view.
   ELVModel->TagRow(ELVSelection.at(0).index);

   // Get file name of destination file.
   DB->FileByIndex(ELVSelection.at(0).index, &DestFile);

   // Build the dialog box message.
   Message = "You have selected " + QString::number(NumSelectedRows-1) + " event(s)";
   Message.append(" for merging with the event in row number ");
   Message.append(QString::number(ELVSelection.at(0).index+1));
   Message.append(".\n(Row number ");
   Message.append(QString::number(ELVSelection.at(0).index+1));
   Message.append(" has been marked with a plus sign in the 'Date and Time' column)\n\n");
   Message.append("Press 'Merge' if you want to keep the ");
   Message.append(QString::number(NumSelectedRows-1));
   Message.append(" event(s) after merging.\n");
   Message.append("Press 'Merge and delete' if you want the ");
   Message.append(QString::number(NumSelectedRows-1));
   Message.append(" event(s) to be deleted after merging.");

   // Create and open the dialog box.
   MergeDlg *Dialog = new MergeDlg(Message);
   Dialog->setAttribute(Qt::WA_DeleteOnClose, true);
   uStatus = Dialog->exec();

   // Unmark the destination event in the view.
   ELVModel->UntagRow();

   // Return if user pressed 'Cancel'.
   if (!uStatus) return;

   // Write informational message in the log.
   Message = "Merge status: Starting merge operation for destination file " + DestFile + "'. ";
   Conf.LogModel->WriteLog(logmodel::info, Message);

   // Merge files.
   NumMergedFiles = NumDeletedFiles = 0;
   MergeError = ReloadError = DeleteError = false;
   for (int i=1;i<NumSelectedRows;i++) {
      // Loop trough all files that are to be merged.
      // First get event id and name of file to be merged.
      EventID = ELVSelection.at(i).id;
      DB->FileById(EventID, &MergeFile);

      // Merge the two files and handle the merge result.
      mStatus = MergeSfilesOnDisk(DestFile, MergeFile);
      if (!mStatus) {
         // Merge succeeded.
         NumMergedFiles++;
         Message = "Merge status: Merge succeeded for '" + MergeFile + "'. ";
         Conf.LogModel->WriteLog(logmodel::info, Message);
         // Delete merged file if requested.
         if (uStatus == 2) {
            if (DeleteEvent(DB->IndexById(EventID), &dStatus, true, true)) {
               // File has been deleted. Update the log.
               NumDeletedFiles++;
               Message = "Merge status: Successfully deleted '" + MergeFile + "'.";
               Conf.LogModel->WriteLog(logmodel::info, Message);
            } else {
               // Unable to delete merge file.
               DeleteError = true;
               Message = "Merge status: Unable to delete merge file '" + MergeFile + "'. ";
               if (dStatus == 1) Message.append("File was not found.");
               if (dStatus == 2) Message.append("Could not delete file.");
               if (dStatus == 3) Message.append("Failed to locate DELET database.");
               if (dStatus == 4) Message.append("Failed to copy file to DELET database.");
               Conf.LogModel->WriteLog(logmodel::error, Message);
            }
         }
      } else {
         // Merge failed for this file.
         MergeError = true;
         FailedMerges.append(ELVSelection.at(i));
         // Write error message.
         Message = "Merge status: Merge failed for '" + MergeFile + "'. ";
         if (mStatus == 1) Message.append("Unable to find one of the event files.");
         if (mStatus == 2) Message.append("Unable to open one of the event files.");
         if (mStatus == 3) Message.append("File is more than 24 hours apart from destination file.");
         if (mStatus == 4) Message.append("File is dated the day before the destination file.");
         if (mStatus == 5) Message.append("Unable to open destination file for writing.");
         Conf.LogModel->WriteLog(logmodel::error, Message);
      }
   }

   // All files have now been processed. Reload
   // the destination event if it has been merged.
   if (NumMergedFiles) {
      EventIndex = DB->IndexById(ELVSelection.at(0).id);
      mStatus = DB->ReloadEventAndResort(EventIndex);
      if (mStatus > 0 && mStatus < 4) {
         // Destination event cannot be reloaded.
         ReloadError = true;
         Message = "Unable to reload the destination event. ";
         if (mStatus == 1) Message.append("Cannot open file.");
         if (mStatus == 2) Message.append("Error in file.");
         if (mStatus == 3) Message.append("Out of memory.");
         if (mStatus == 5) Message.append("Event has invalid date.");
         Conf.LogModel->WriteLog(logmodel::error, Message);
      }
   }

   // If events have been deleted, clear all selections. Then reselect
   // the destination event. Also reselect all events that failed to merge.
   if (NumDeletedFiles) {
      ELVModel->ClearSelection();
      if (!ReloadError) {
         EventIndex = DB->IndexById(ELVSelection.at(0).id);
         ELVModel->SelectRow(EventIndex, false, true, false);
      }
      for (int i=0;i<FailedMerges.size();i++) {
         EventIndex = DB->IndexById(FailedMerges.at(i).id);
         ELVModel->SelectRow(EventIndex, false, false, false);
      }
   }

   // Switch to log view if an error has occurred,
   // else inform user that the operation succeeded.
   if (MergeError || ReloadError || DeleteError) {
      emit Conf.LogModel->show_log_view();
   } else {
      Message = "Merge operation completed successfully.";
      emit show_sb_message(Message, 5000);
   }
}




// ********************************************************************
// This function handles the 'Plot with Mulplot (P)' menu item.
// This function is signaled from the Event List View popup menmu.
// ********************************************************************
void SEBASE::ELV_Plot_With_Mulplot()
{
   Plot_With_Mulplot(true);
}




// ********************************************************************
// This function handles the 'Plot with Mulplot (Shift-P)' menu item.
// This function is signaled from the Event List View popup menmu.
// ********************************************************************
void SEBASE::ELV_Plot_With_Mulplot_Menu()
{
   Plot_With_Mulplot(false);
}




// ********************************************************************
// This function refreshes the Event List View. This function
// is signaled from the Event List View popup menmu.
// ********************************************************************
void SEBASE::ELV_Refresh_View()
{
   RowNum = CurrentRow();
   ELVModel->Reset();
   ELVModel->SelectRow(RowNum, false, true, false);
}




// ********************************************************************
// This function handles the 'Register' menu item.
// This function is signaled from the Event List View popup menmu.
// ********************************************************************
void SEBASE::ELV_Register_Event()
{
   // Check that database is open.
   if (DbStatus == db::closed) return;
   if (DbStatus != db::open) { ShowMessage(300); return; }

   // Get the list of selected rows.
   ELVModel->GetSelection(&ELVSelection);

   // Exit if no rows are selected.
   if (!ELVSelection.size()) return;

   // Only one row can be selected.
   if (ELVSelection.size() > 1) { ShowMessage(310, true); return; }

   // Register the selected event.
   RegisterEvent(ELVSelection.at(0).index);
}




// ********************************************************************
// This function handles the 'Reload event from disk' menu item.
// Function is signaled from the Event List View popup menu.
// ********************************************************************
void SEBASE::ELV_Reload_Event()
{
   int DbIndex;

   // Check that database is open.
   if (DbStatus == db::closed) return;
   if (DbStatus != db::open) { ShowMessage(300); return; }

   // Find index for the currently selected event.
   // Get the list of selected rows.
   ELVModel->GetSelection(&ELVSelection);

   // Exit if no rows are selected.
   if (!ELVSelection.size()) return;

   // A maximum of 1 row can be selected.
   if (ELVSelection.size() > 1) { ShowMessage(310, true); return; }

   // Get datatabase presentation index for this event.
   DbIndex = ELVSelection.at(0).index;

   // Reload the event into SE.
   ReloadEvent(DbIndex);
}




// ***********************************************************************
// This function shows one or more selected events with Google Earth.
// Google Earth is NOT being started, only the KML file is created.
// ***********************************************************************
void SEBASE::ELV_Show_Events_With_GE()
{
   float Lat, Lon;
   event_node_ *Node;
   int NumSelectedRows;
   QList<event_node_*> EventList;

   // Get the list of selected rows.
   ELVModel->GetSelection(&ELVSelection);

   // Get number of selected rows.
   NumSelectedRows = ELVSelection.size();

   // Exit if no rows are selected.
   if (!NumSelectedRows) return;

   // Copy pointers to all events that have a location into 'EventList'.
   for (int i=0;i<NumSelectedRows;i++) {
      Node = DB->EventByIndex(ELVSelection.at(i).index);
      Lat = Node->hypocenters.first->lat;
      Lon = Node->hypocenters.first->lon;
      if (Lat != -999.0 && Lon != -999.0) EventList.append(Node);
   }

   // Return here if 'EventList' is empty.
   if (!EventList.size()) {
      Message = "The selected events do not have a location.";
      emit show_sb_message(Message, 8000);
      return;
   }

   // Set the URL for the map icon.
   QString IconUrl = "http://maps.google.com/mapfiles/kml/pal2/icon26.png";

   // Set the KML color string for the map icon.
   QString IconColor = "ff00ff00";

   // These variables defines the size of the map icons.
   float mSize = 0.6; float xSize = 0.2; float ySize = 0.5;

   // Write the KML file.
   QFile *KmlFile = new QFile(SEC_KML_FILE);
   if (KmlFile->open(QIODevice::WriteOnly | QIODevice::Truncate | QIODevice::Text)) {
      WriteKmlHeader(KmlFile);
      for (int i=0;i<EventList.size();i++) {
         WriteKml(EventList[i], KmlFile, IconUrl, IconColor, true, mSize, xSize, ySize);
      }
      WriteKmlTail(KmlFile);
      KmlFile->close();

      // Notify user if some events where not shown.
      if (NumSelectedRows != EventList.size()) {
         Message = "Some events are not shown because they do not have a location.";
         emit show_sb_message(Message, 5000);
         return;
      }
   } else {
       Message = "Unable to open file '" + QString(SEC_KML_FILE) + "' for writing.";
       Conf.LogModel->WriteLog(logmodel::error, Message);
       emit Conf.LogModel->show_log_view();
   }
}




// ************************************************************************
// This function shows one or more selected events with SEISAN map command.
// ************************************************************************
void SEBASE::ELV_Show_Events_With_Map()
{
   float Lat, Lon;
   event_node_ *Node;
   int NumSelectedRows;
   QString Map, Shell, ShellPar;
   QStringList FileList, ArgList;

   // Get the list of selected rows.
   ELVModel->GetSelection(&ELVSelection);

   // Get number of selected rows.
   NumSelectedRows = ELVSelection.size();

   // Exit if no rows are selected.
   if (!NumSelectedRows) return;

   // Add all events that have a location into 'FileList'.
   for (int i=0;i<NumSelectedRows;i++) {
      Node = DB->EventByIndex(ELVSelection.at(i).index);
      Lat = Node->hypocenters.first->lat;
      Lon = Node->hypocenters.first->lon;
      if (Lat != -999.0 && Lon != -999.0) FileList.append(Node->metadata.sfile);
   }

   // Return here if 'EventList' is empty.
   if (!FileList.size()) {
      Message = "The selected events do not have a location.";
      emit show_sb_message(Message, 8000);
      return;
   }

   // Set a platform dependant shell program.
   #ifdef Q_OS_WIN32
   Shell = "cmd.exe";
   ShellPar = "/c";
   #endif
   #ifdef Q_OS_LINUX
   Shell = "xterm";
   ShellPar = "-e";
   #endif

   // Set platform dependant name for the map command.
   #ifdef Q_OS_WIN32
      Map = "map.exe";
   #endif
   #ifdef Q_OS_LINUX
      Map = "map";
   #endif

   // Check that the map program exists in the path.
   if (!IsFileInPath(Map)) {
      Message = "Cannot find the map program in the path.";
      Conf.LogModel->WriteLog(logmodel::error, Message);
      emit Conf.LogModel->ShowLogView();
      return;
   }

   // Merge together all files in the file list and save the result in the outfile.
   if (!MergeFiles(FileList, QString("map.out"))) {
      // Merge failed. Write error message in the log.
      Message = "Unable to create file 'map.out'. Check disk space and write permissions for work folder.";
      Conf.LogModel->WriteLog(logmodel::error, Message);
      emit Conf.LogModel->show_log_view();
      return;
   }

   // Start the map program.
   ArgList.append(ShellPar); ArgList.append(Map); ArgList.append("map.out");
   if (!QProcess::startDetached(Shell, ArgList)) {
      Message = "Unable to launch map command (unknown problem).";
      Conf.LogModel->WriteLog(logmodel::error, Message);
      emit Conf.LogModel->ShowLogView();
   }
}




// ***********************************************************************
// This function shows one or more selected events with
// Seismicity Viewer. Seismicity Viewer is a java program.
// ***********************************************************************
void SEBASE::ELV_Show_Events_With_SV()
{
   int NumSelectedRows;
   QString Command, Java;
   QStringList ArgList;

   // Get the list of selected rows.
   ELVModel->GetSelection(&ELVSelection);

   // Get number of selected rows.
   NumSelectedRows = ELVSelection.size();

   // Exit if no rows are selected.
   if (!NumSelectedRows) return;

   // Create platform dependant names for the java program.
   #ifdef Q_OS_WIN32
   Java = "java.exe";
   #endif
   #ifdef Q_OS_LINUX
   Java = "java";
   #endif

   // Check that the 'java' command exists in the path.
   if (!IsFileInPath(Java)) {
      Message = "Plot with Seismicity Viewer: Cannot find the 'java' command in the path.";
      Conf.LogModel->WriteLog(logmodel::error, Message);
      emit Conf.LogModel->show_log_view();
      return;
   }

   // Check that the file 'seis2viewer.jar' exists in PRO directory.
   QString seis2viewer = BuildPath(Conf.AppConf.SEISAN_TOP, "PRO", "seis2viewer.jar");
   if (!QFile::exists(seis2viewer)) {
      Message = "Plot with Seismicity Viewer: Cannot find the file '" + seis2viewer + "'.";
      Conf.LogModel->WriteLog(logmodel::error, Message);
      emit Conf.LogModel->show_log_view();
      return;
   }

   // Build platform dependant command and arugument list.
   #ifdef Q_OS_WIN32
   Command = Java;
   ArgList.append("-jar");
   ArgList.append(BuildPath(Conf.AppConf.SEISAN_TOP, "PRO", "seis2viewer.jar"));
   ArgList.append("se-select.out");
   #endif
   #ifdef Q_OS_LINUX
   Command = "xterm";
   ArgList.append("-e"); ArgList.append(Java); ArgList.append("-jar");
   ArgList.append(BuildPath(Conf.AppConf.SEISAN_TOP, "PRO", "seis2viewer.jar"));
   ArgList.append("se-select.out");
   #endif

   // Write the file 'se-select.out'.
   ELV_Copy_Events();

   // Execute the command.
   if (!QProcess::startDetached(Command, ArgList)) {
      Message = "Failed to start Seismicity Viewer.";
      Conf.LogModel->WriteLog(logmodel::error, Message);
      emit Conf.LogModel->show_log_view();
      return;
   }
}


// ***********************************************************************
// This function shows one or more selected events with
// Seismicity Viewer. Seismicity Viewer is a java program.
// ***********************************************************************
void SEBASE::ELV_Show_Path_To_Wavefiles()
{
   int NumWaveFiles;
   char FileListIn[500][80], FileListOut[500][200];
   QString WaveFile;

   // Check that database is open.
   if (DbStatus == db::closed) return;
   if (DbStatus != db::open) { ShowMessage(300); return; }

   // Find index for the currently selected event.
   // Get the list of selected rows.
   ELVModel->GetSelection(&ELVSelection);

   // Exit if no rows are selected.
   if (!ELVSelection.size()) return;

   // A maximum of 1 row can be selected.
   if (ELVSelection.size() > 1) { ShowMessage(310, true); return; }

   // Get pointer to event node.
   int DbIndex = ELVSelection.at(0).index;
   event_node_ *Node = DB->EventByIndex(DbIndex);

   // Get number of wave files for this event.
   NumWaveFiles = Node->wavefiles.numlines;

   // Check if node has any wavefiles.
   if (!NumWaveFiles) { ShowMessage(350, true); return; }

   // Create a list of wave files for fortran function find_waveform_files_.
   memset(FileListIn, 32, sizeof(FileListIn));
   for (int i=0;i<NumWaveFiles; i++) {
      // Copy 78 characters. Col 1 and col 80 will be skipped.
      memcpy(FileListIn[i], Node->wavefiles.lines+i*80+1, 78);
   }

   // Get list of wavefiles with full path.
   memset(FileListOut, 32, sizeof(FileListOut));
   find_waveform_files_(&NumWaveFiles, (char*)FileListIn, (char*)FileListOut, sizeof(FileListIn), sizeof(FileListOut));

   // If no wavefiles was found inform user and return.
   if (!NumWaveFiles) { ShowMessage(351, true); return; }

   // At least one wavefile was found. Write wave files to the log window.
   Message = "Wave files found for " + QString(Node->metadata.sfile) + ":";
   Conf.LogModel->WriteLog(logmodel::info, Message);
   for (int index=0;index<NumWaveFiles; index++) {
      fstr2qstr(&WaveFile, FileListOut[index], 200);
      Conf.LogModel->WriteLog(logmodel::info, WaveFile);
   }

   // Show the log view.
   emit Conf.LogModel->show_log_view();
}



// ********************************************************************
// This function selects all events in the Event List View.
// This function is signaled from the Event List View popup menmu.
// ********************************************************************
void SEBASE::ELV_Select_All()
{
   // Check that database is open.
   if (DbStatus == db::closed) return;
   if (DbStatus != db::open) { ShowMessage(300); return; }

   // Select all rows.
   ELView.selectAll();
}




// ********************************************************************
// This function handles the 'Set distance indicator' menu item.
// This function is signaled from the Event List View popup menmu.
// ********************************************************************
void SEBASE::ELV_Set_Distance_Indicator()
{
   char status;
   bool Error = false;
   int NumRows, DbIndex;
   QChar NewDI;
   event_node_ *Node;
   sortCol CurrSortColumn;
   QList<int> EventIdList;
   Qt::SortOrder CurrSortOrder;

   // Check that database is open.
   if (DbStatus == db::closed) return;
   if (DbStatus != db::open) { ShowMessage(300); return; }

   // Get the list of selected rows.
   ELVModel->GetSelection(&ELVSelection);

   // Get number of selected rows.
   NumRows = ELVSelection.size();

   // Exit if no rows are selected.
   if (!NumRows) return;

   // Bring up dialog box and ask for new
   // distance indicator ('L','R' or 'D').
   bool ok, done = false;
   QString Title = "Set distance indicator.";
   QString Label = "Enter new distance indicator for " + QString::number(NumRows) + " selected event(s):";
   QString Line = "Valid values are: L,R,D";
   while (!done) {
      Line = QInputDialog::getText(0, Title, Label, QLineEdit::Normal, Line, &ok, Qt::Dialog);
      if (!ok) return;
      NewDI = Line.at(0).toUpper();
      if (NewDI == 'L' || NewDI == 'R' || NewDI == 'D') done = true;
   }

   // Get current sort criteria used by database.
   DB->SortCriteria(&CurrSortColumn, &CurrSortOrder);

   // Save the unique event ID for all selected events.
   for (int i=0;i<NumRows;i++) EventIdList.append(DB->IdByIndex(ELVSelection.at(i).index));

   // Change distance indicator for selcted events.
   for (int i=0;i<NumRows;i++) {
      // Get pointer to event node.
      DbIndex = ELVSelection.at(i).index;
      Node = DB->EventByIndex(DbIndex);

      // Change distance indicator if needed.
      if ((NewDI != NodeGetDistanceIndicator(Node))) {
         // Save full path to existing event file.
         QString OldFile = QString(Node->metadata.sfile);

         // Update event node with new distance indicator.
         // This will change the node's file name.
         NodeSetDistanceIndicator(Node, NewDI);

         // Update the event file on disk. Old file will be deleted.
         if (!DB->UpdateSfile(DbIndex, &status, OldFile)) {
            // Unable to write new event file. Write error message to the log.
            Message = "Failed to update distance indicator for '" + OldFile + "'. Cannot write to file.";
            Conf.LogModel->WriteLog(logmodel::error, Message);
            Error = true;
         }
      }
   }

   // Update event list view.
   if (CurrSortColumn == ColDist) DB->Resort(false);
   ELVModel->Reset();
   for (int i=0;i<NumRows;i++) ELVModel->SelectRow(DB->IndexById(EventIdList.at(i)), false, true, true);

   // Update the locate window with current selection.
   RowChanged(ELVModel->CurrentRow());

   // If errors occurred, switch to Log View.
   if (Error) emit Conf.LogModel->show_log_view();
}




// ********************************************************************
// This function handles the 'Set event indicator' menu item.
// This function is signaled from the Event List View popup menmu.
// ********************************************************************
void SEBASE::ELV_Set_Event_Indicator()
{
   char status;
   int NumRows, DbIndex;
   bool Error = false;
   bool Done = false;
   QString NewEI;
   event_node_ *Node;
   QList<int> EventIdList;
   sortCol CurrSortColumn;
   Qt::SortOrder CurrSortOrder;

   // Check that database is open.
   if (DbStatus == db::closed) return;
   if (DbStatus != db::open) { ShowMessage(300); return; }

   // Get the list of selected rows.
   ELVModel->GetSelection(&ELVSelection);

   // Get number of selected rows.
   NumRows = ELVSelection.size();

   // Exit if no rows are selected.
   if (!NumRows) return;

   // Prepare the help text for the dialog box.
   QString HelpText = "<b>Short description of event indicators:</b>";
   HelpText.append("<br>Q = Local earthquake<br>E = Local explosion<br>P = Suspected/probable local explosion");
   HelpText.append("<br>I = Local seismic event induced by man-made activity<br>F/A = Suspected/probable mining explosion");
   HelpText.append("<br>V = Local volcanic event<br>L = Local landslide<br>S = Local acoustic signal><br>C = Local frost quake");
   HelpText.append("<br>G = Local glacial earthquake<br>O = Confirmed Other<br>&lt;SPACE&gt; = Local seismic event of unknown origin");

   // Bring up dialog box and ask for new event indicator.
   QString Title = "Set event indicator";
   QString Label = "Enter new event indicator for " + QString::number(NumRows) + " selected event(s):             ";
   QInputDialog *Dlg = new QInputDialog();
   Dlg->setWindowTitle(Title); Dlg->setLabelText(Label);
   Dlg->setInputMode(QInputDialog::TextInput);
   Dlg->setWhatsThis(HelpText);
   while (!Done) {
      // Get event indicator type from user.
      if (Dlg->exec() == QDialog::Accepted) {
         // Check the given event indicator.
         NewEI = Dlg->textValue().trimmed();
         if (NewEI.isEmpty()) { NewEI = " "; Done = true; }
         if (NewEI.size() == 1 && NewEI.at(0).isLetter()) Done = true;
      } else {
         // User has canceled.
         delete Dlg;
         return;
      }

      // Write error message if event idicator is invalid.
      if (!Done) QMessageBox::critical(0, AppName, "Invalid event indicator.");
   }
   delete Dlg;

   // Get current sort criteria used by database.
   DB->SortCriteria(&CurrSortColumn, &CurrSortOrder);

   // Save the unique event ID for all selected events.
   for (int i=0;i<NumRows;i++) EventIdList.append(DB->IdByIndex(ELVSelection.at(i).index));

   // Change event indicator for selcted events.
   for (int i=0;i<NumRows;i++) {
      // Get pointer to event node.
      DbIndex = ELVSelection.at(i).index;
      Node = DB->EventByIndex(DbIndex);

      // Change event indicator if needed.
      if ((NewEI != NodeGetEventIndicator(Node))) {
         // Save path to existing event file.
         QString OldFile = QString(Node->metadata.sfile);

         // Update event node with new event indicator.
         NodeSetEventIndicator(Node, NewEI.at(0));

         // Write the updated node to a new event file.
         if (!DB->UpdateSfile(DbIndex, &status)) {
            // Unable to write new event file. Write error message to the log.
            Message = "Failed to update event indicator for '" + OldFile + "'. Cannot write to file.";
            Conf.LogModel->WriteLog(logmodel::error, Message);
            Error = true;
        }
      }
   }

   // Update event list view.
   if (CurrSortColumn == ColType) DB->Resort(false);
   ELVModel->Reset();
   for (int i=0;i<NumRows;i++) ELVModel->SelectRow(DB->IndexById(EventIdList.at(i)), false, true, true);

   // Update the locate window with current selsction.
   RowChanged(ELVModel->CurrentRow());

   // If errors occurred, switch to Log View.
   if (Error) emit Conf.LogModel->show_log_view();

}




// ********************************************************************
// This function handles the 'Set model indicator' menu item.
// This function is signaled from the Event List View popup menmu.
// ********************************************************************
void SEBASE::ELV_Set_Model_Indicator()
{
   char status;
   int NumRows, DbIndex;
   bool Error = false;
   QChar NewMI;
   event_node_ *Node;
   QList<int> EventIdList;
   sortCol CurrSortColumn;
   Qt::SortOrder CurrSortOrder;

   // Check that database is open.
   if (DbStatus == db::closed) return;
   if (DbStatus != db::open) { ShowMessage(300); return; }

   // Get the list of selected rows.
   ELVModel->GetSelection(&ELVSelection);

   // Get number of selected rows.
   NumRows = ELVSelection.size();

   // Exit if no rows are selected.
   if (!NumRows) return;

   // Bring up dialog box and ask for new model indicator.
   bool Ok, done = false;
   QString Title = "Set model indicator.";
   QString Label = "Enter new model indicator for " + QString::number(NumRows) + " selected event(s):";
   while (!done) {
      QString Line = QInputDialog::getText(0, Title, Label, QLineEdit::Normal, "Valid values: <SPACE>, or a character", &Ok, Qt::Dialog);
      if (!Ok) return;
      if (Line.size()) { NewMI = Line.at(0); done = true; }
   }

   // Get current sort criteria used by database.
   DB->SortCriteria(&CurrSortColumn, &CurrSortOrder);

   // Save the unique event ID for all selected events.
   for (int i=0;i<NumRows;i++) EventIdList.append(DB->IdByIndex(ELVSelection.at(i).index));

   // Change model indicator for selcted events.
   for (int i=0;i<NumRows;i++) {
      // Get pointer to event node.
      DbIndex = ELVSelection.at(i).index;
      Node = DB->EventByIndex(DbIndex);

      // Change model indicator if needed.
      if ((NewMI != NodeGetModelIndicator(Node))) {
         // Save path to existing event file.
         QString OldFile = QString(Node->metadata.sfile);

         // Update event node with new event indicator.
         NodeSetModelIndicator(Node, NewMI);

         // Write the updated node to a new event file.
         if (!DB->UpdateSfile(DbIndex, &status)) {
            // Unable to write new event file. Write error message to the log.
            Message = "Failed to update event indicator for '" + OldFile + "'. Cannot write to file.";
            Conf.LogModel->WriteLog(logmodel::error, Message);
            Error = true;
        }
      }
   }

   // Update event list view.
   if (CurrSortColumn == ColModel) DB->Resort(false);
   ELVModel->Reset();
   for (int i=0;i<NumRows;i++) ELVModel->SelectRow(DB->IndexById(EventIdList.at(i)), false, true, true);

   // Update the locate window with current selsction.
   RowChanged(ELVModel->CurrentRow());

   // If errors occurred, switch to Log View.
   if (Error) emit Conf.LogModel->show_log_view();

}




// ***********************************************
// This function is signaled when user presses
// Ctrl-F. User want to filter the event list.
// ***********************************************
void SEBASE::ELV_Set_Filter()
{
   SetFilter();
}




// ***********************************************
// This function is signaled when user presses
// Ctrl-T. Signal will be emitted to mainwindow.
// ***********************************************
void SEBASE::ELV_Set_Time_Interval()
{
   emit set_time_interval();
}




// ***********************************************
// This function is called from main window
// to set new time interval dates.
// ***********************************************
void SEBASE::SetTimeInterval(tm_int TimeIntDates)
{
   Conf.AppConf.TimeIntDates = TimeIntDates;
}




// ********************************************************************
// This function is signaled when the user presses one of the
// column headers to change either the sort column or sort order.
// ********************************************************************
void SEBASE::ELV_Sort_Indicator_Changed(int logicalIndex, Qt::SortOrder NewSortOrder)
{
   sortCol NewSortColumn;
   sortCol CurrSortColumn;
   Qt::SortOrder CurrSortOrder;

   // Get new sort column.
   NewSortColumn = (sortCol)logicalIndex;

   // Get current sort criteria used by database.
   DB->SortCriteria(&CurrSortColumn, &CurrSortOrder);

   // Return if nothing has changed.
   if (NewSortColumn == CurrSortColumn && NewSortOrder == CurrSortOrder) return;

   // If user has selected the row number column, or database
   // is still loading, then do not switch to new sort order.
   if (NewSortColumn == RowNr || DbStatus != db::open) {
      // Restore the previous column selection in event list view header.
      ELVHeader->setSortIndicator((int)CurrSortColumn, CurrSortOrder);
      QApplication::beep();
      return;
   }

   // Set new sort column or sort order.
   if (NewSortColumn != CurrSortColumn) {
      // Sort database by new column.
      DB->SetSortCol(NewSortColumn);
      // Update the view and select first row.
      ELVModel->Reset(); ELVModel->SelectRow(0, true, true, false);
   } else {
      // Set new database sort order.
      DB->SetSortOrd(NewSortOrder);
      // Update the view.
      ELVModel->Reset(); ELVModel->SelectRow(0, true, true, false);
   }
}




// ******************************************************
// Brings up the 'Simple Waveform Viewer' dialog box.
// ******************************************************
void SEBASE::ELV_SimpleWaveformViewer()
{
   // Bring up the dialog box.
   SimpleWaveformViewerDlg *dialog = new SimpleWaveformViewerDlg();
   dialog->exec(); delete dialog;
}




// ********************************************************************
// This function unloads an event from Seisan Explorer. This
// function is signaled from the Event List View popup menmu.
// ********************************************************************
void SEBASE::ELV_Unload_Event()
{
   QString FileName;

   // Check that database is open.
   if (DbStatus == db::closed) return;
   if (DbStatus != db::open) { ShowMessage(300); return; }

   // Get the list of selected rows.
   ELVModel->GetSelection(&ELVSelection);

   // Exit if no rows are selected.
   if (!ELVSelection.size()) return;

   // Only one event can be selected.
   if (ELVSelection.size() > 1) { ShowMessage(310, true); return; }

   // Get filename for the one selected row.
   DB->FileByIndex(ELVSelection.at(0).index, &FileName);
   Message = "Are you sure you want to remove this event from Explorer?\n";
   Message.append("The event file will not be deleted from the Seisan database.");
   if (QMessageBox::question(0, "Remove", Message, QMB_YES | QMB_NO, QMB_NO) != QMB_YES) return;

   // Unload event and update the view.
   UnloadEvent(ELVSelection.at(0).index);
}




// ************************************************************
// Receives a list of event files to be imported into database.
// The first entry in the list is the filesystem path to the
// database we import from. Example 'C:\Seismo\REA\MYDB_'.
// ************************************************************
void SEBASE::EventsDropped(QStringList EventList)
{
   // Check that a database currently is opened.
   if (DbStatus != db::open) return;

   // Activate this SE window.
   QApplication::activeWindow();

   // Check if current database is an index file.
   QString WinTitle = "Import dropped events.";
   if (DbInfo.Type == index_file) {
      Message = "Cannot import into an index-file database.";
      QMessageBox::information(0, WinTitle, Message);
      return;
   }

   // The first item in the EventList is the disk path to the database
   // we import from. Get and remove this path from the event file list.
   QString ImportDbPath = EventList.takeFirst();

   // Get event information from first file.
   sfile_nameinfo NameInfo;
   GetSfileNameInfo(EventList.at(0), &NameInfo);

   // Check if we are importing from this database.
   if (ImportDbPath == DbInfo.Path) return;

   // Ask user for import confirmation.
   Message = "Would you like to import " + QString::number(EventList.size());
   Message.append(" dropped event(s) into database?");
   QMessageBox::StandardButton reply;
   reply = QMessageBox::question(0, WinTitle, Message, QMessageBox::Yes|QMessageBox::No, QMessageBox::No);
   if (reply == QMessageBox::No) return;

   // Import events and inform the user about any import errors.
   if (!LoadEvents(EventList)) {
      Message = "One or more events could not be imported or loaded. See the log for details.";
      QMessageBox::critical(0, WinTitle, Message);
      emit Conf.LogModel->show_log_view();
   }
}




// ***************************************************************
// Slot for the FileEditorDlg class. This function is signaled
// when a file editor is closed by a press on the the Save button.
// The event file must be reloaded since it has probably changed.
// ***************************************************************
void SEBASE::FileSaved(QString FilePath)
{
   // Check that a database currently is opened.
   if (DbStatus != db::open) return;

   // Get the index of the file.
   int DbIndex = DB->IndexByFile(FilePath);

   // Return if file is no longer in database.
   if (DbIndex == -1) return;

   // Reload event into database.
   ReloadEvent(DbIndex);
}




// ***************************************************************************
// This function handles incoming messages from mulplt. The mulplt instance
// is pointed to by 'MulPlt'. These messages are signaled from an instance
// of the MulpltHandler class.
// ***************************************************************************
void SEBASE::HandleMulpltMsg(MulpltHandler *MulPlt, QString Msg, QString File)
{
   QString NewFile;
   int DbIndex, DbId, Status;

   // Check that database is open.
   if (DbStatus != db::open) return;

   // Get number of events in database.
   int NumEvents = DB->NumEvents();

   // Process a "SBMESSAGE This is a message." message from mulplt.
   // The message will be shown in the status bar.
   if (Msg.startsWith("SBMESSAGE")) {
      emit show_sb_message("Mulplt: " + Msg.mid(10), 5000);
      return;
   }

   // Process a "PUMESSAGE This is a message." message from mulplt.
   // The message will be shown in a popup window.
   if (Msg.startsWith("PUMESSAGE")) {
      QMessageBox::information(0, "Mulplt:", Msg.mid(10));
      return;
   }

   // Process a NEXT message.
   if (Msg.startsWith("NEXT")) {
      // Get index for mulplt's current event.
      DbIndex = DB->IndexByFile(File);
      // if this event is no longer loaded in SE we will close mulplt.
      if (DbIndex == -1) { MulPlt->Close(); return; }
      // Move selection to the next event in the event list.
      DbIndex++;
      // If we are at end of the list then reload the same event.
      if (DbIndex == NumEvents) {
         QApplication::beep();
         emit show_sb_message("Already at end of list.", 3000);
         MulPlt->LoadFile(File);
         return;
      }
      // Get filename for the next row.
      DB->FileByIndex(DbIndex, &File);
      // If next event is already loaded in another
      // instance of mulplt, then exit mulplt.
      if (IsEventOpenInMulplt(File)) {
         MulPlt->Close();
         Message = "Next event is already open in another mulplt instance.";
         emit show_sb_message(Message, 8000);
         return;
      }
      // Select the next event in the event list.
      ELVModel->SelectRow(DbIndex, true, true, true);
      // Tell mulplt to load the next event.
      MulPlt->LoadFile(File);
      return;
   }

   // Process a PREV message.
   if (Msg.startsWith("PREV")) {
      // Get index for the event mulplt was last started with.
      DbIndex = DB->IndexByFile(File);
      // if this event is no longer loaded in SE then we close mulplt.
      if (DbIndex == -1) { MulPlt->Close(); return; }
      // Move to the previous event in the event list.
      DbIndex--;
      // If we are at start then then reload the same event.
      if (DbIndex == -1)  {
         QApplication::beep();
         emit show_sb_message("Already at start of list.", 5000);
         MulPlt->LoadFile(File);
         return;
      }
      // Get filename for the previous row.
      DB->FileByIndex(DbIndex, &File);
      // If previous event is already loaded in another instance of mulplt, then exit mulplt.
      if (IsEventOpenInMulplt(File)) {
         MulPlt->Close();
         Message = "Previous event is already open in another mulplt instance.";
         emit show_sb_message(Message, 8000);
         return;
      }
      // Select the previous event in the event list.
      ELVModel->SelectRow(DbIndex, true, true, true);
      // Tell mulplt to load the previous event.
      MulPlt->LoadFile(File);
      return;
   }

   // Process a "RELOAD" message.
   if (Msg.startsWith("RELOAD")) {
      // Get index for the event mulplt was last started with.
      DbIndex = DB->IndexByFile(File);
      // Close mulplt if this event is not loaded in SE.
      if (DbIndex == -1) { MulPlt->Close(); return; }
      // Reload the given event file.
      ReloadEvent(DbIndex);
      return;
   }

   // Process a "LOCATE" message.
   if (Msg.startsWith("LOCATE")) {
      // Get index for the event mulplt was started with.
      DbIndex = DB->IndexByFile(File);
      // Close mulplt if this event is not loaded in SE.
      if (DbIndex == -1) { MulPlt->Close(); return; }
      // Select the event in the event list.
      ELVModel->SelectRow(DbIndex, true, true, true);
      // Locate the event.
      emit locate_event();
      // Tell mulplt that locate is done.
      MulPlt->SendMsg("DONE");
      return;
   }

   // Process a "DELETE" message.
   if (Msg.startsWith("DELETE")) {
      // Get database index for the file to be deleted.
      DbIndex = DB->IndexByFile(File);

      // Ask user for permission to delete the event.
      Message = "Are you sure you want to delete this event from the Seisan database?\n" + File;
      if (QMessageBox::question(0, "Delete", Message, QMB_YES | QMB_NO, QMB_NO) != QMB_YES) {
         // User do not want to delete the event. Reload the same file or quit.
         if (DbIndex >= 0) MulPlt->LoadFile(File);
         if (DbIndex <  0) MulPlt->SendMsg("QUIT");
         return;
      }
      // Delete event from database.
      if (DbIndex >= 0) {
         // Event is currently loaded in SE. Unload the
         // event from SE and delete event file from disk.
         // The DeleteEvent() function will update the log.
         if (DeleteEvent(DbIndex, &Status, false, false)) {
            // Select the next event in the event list.
            if (DbIndex == DB->NumEvents()) DbIndex = 0;
            ELVModel->SelectRow(DbIndex, true, true, true);
            // Get filename for the next event.
            DB->FileByIndex(DbIndex, &File);
            // Tell mulplt to load the next event.
            MulPlt->LoadFile(File);
         }
      } else {
         // Event is not loaded into SE. Event file will be deleted from disk.
         Status = DeleteSfileFromDisk(File, DbInfo);
         if (!Status) {
            // Delete operation succeeded. Write message to log.
            Message = "Event file '" + File + "' has been deleted.";
            Conf.LogModel->WriteLog(logmodel::info, Message);
         } else {
            // Delete operation failed. Write error message to log.
            Message = "Unable to delete event. ";
            if (Status == 1) Message.append("Event file was not found.");
            if (Status == 2) Message.append("Failed to delete event file.");
            if (Status == 3) Message.append("Failed to locate DELET database.");
            if (Status == 4) Message.append("Failed to copy event file to DELET database.");
            Conf.LogModel->WriteLog(logmodel::error, Message);
         }
      }
      return;
   }

   // Process a "REGISTER" message.
   if (Msg.startsWith("REGISTER")) {
      // Get database index for the event that mulplt has loaded.
      DbIndex = DB->IndexByFile(File);
      // Exit if the event is no longer loaded in SE.
      if (DbIndex == -1) {
         Message = "Cannot register event. It is no longer loaded in SE.";
         QMessageBox::critical(0, AppName, Message);
         return;
      }
      // Get the database id for the event.
      DbId = DB->IdByIndex(DbIndex);
      // Register the event.
      RegisterEvent(DbIndex);
      // File name and database index may have changed. Get
      // the current file name usning the event database id.
      DB->FileByIndex(DB->IndexById(DbId), &NewFile);
      // Ask mulplt to reload the event.
      MulPlt->LoadFile(NewFile);
   }
}




// **********************************************************************
// This function checks if an event is open in a running mulplt instance.
// **********************************************************************
bool SEBASE::IsEventOpenInMulplt(QString SFile)
{
   int Index;
   MulpltHandler *Handler;

   // Return false if no 'MulpltHandler' instances are running.
   if (MulpltHandlers.isEmpty()) return false;

   // Enumerate all existing 'MulpltHandler' instances and see
   // if there any running mulplt instance handeling this event.
   for (Index=0;Index<MulpltHandlers.size();Index++) {
      Handler = MulpltHandlers.at(Index);
      if (Handler->Running) if (SFile == Handler->SFile) return true;
   }

   return false;
}




// ********************************************************************
// This function loads an event file from disk into Explorer. Returns
// the index for the loaded event. Returns error codes if load failed:
// Error code -1: Error in S-file
// Warning code -2: The event is loaded but has been filtered out.
// ********************************************************************
int SEBASE::LoadEvent(QString File)
{
   // Load event file into Explorer.
   int EventIndex = DB->LoadEventAndResort(File);
   if (EventIndex == -1) {
      Message = "Unable to load the event file. Check file for errors.";
      Conf.LogModel->WriteLog(logmodel::error, Message);
      emit Conf.LogModel->show_log_view();
      return EventIndex;
   }
   if (EventIndex == -2) {
      Message = "The loaded event has been filtered from Event List view.";
      emit show_sb_message(Message, 8000);
      return EventIndex;
   }

   // Select the new event in the view.
   ELVModel->SelectRow(EventIndex, true, true, true);

   // Signal that event is added and that current row has changed.
   emit cur_row_changed(this);
   emit num_events_changed(DB->NumEvents());

   return EventIndex;
}




// ********************************************************************
// This function imports several event files into the current database
// and loads them into SE. Function returns 'true' if all event files
// was successfylly copied into current database and loaded into SE.
// Function return false if some problem occurred. All problems are
// written to the log.
// ********************************************************************
bool SEBASE::LoadEvents(QStringList EventFiles)
{
   bool Errors;
   int EventId, NumEventFiles;
   int NumImported, NumLoadErrors, NumOutOfBand;
   sfile_nameinfo NameInfo;
   QDir Path;
   QList<int> EventsLoaded;

   // Check if opened database is an index file.
   if (DbInfo.Type == index_file) {
      Conf.LogModel->WriteLog(logmodel::error, "Cannot import into an index-file database.");
      return false;
   }

   // Get number of events to import.
   NumEventFiles = EventFiles.size();

   // Create a progress bar dialog object.
   QProgressDialog Progress("Importing files, please wait...", "Stop import", 0, NumEventFiles, 0);
   Progress.setWindowModality(Qt::WindowModal);
   Progress.setWindowTitle(AppName);
   Progress.setFixedWidth(400);

   // Import event files.
   Errors = false;
   NumImported = NumLoadErrors = NumOutOfBand = 0;
   for (int index=0;index<NumEventFiles;index++) {
      // Get information about the event.
      QString EventFile = EventFiles.at(index);
      GetSfileNameInfo(EventFile, &NameInfo);

      // Get path to the destination directory.
      QString DestFolder = DbInfo.Path;
      if (DbInfo.Type == default_database || DbInfo.Type == normal_database_by_path || DbInfo.Type == normal_database_by_name) {
         // Add YYYY/MM subfolders to the path.
         DestFolder.append("/" + NameInfo.Year + "/" + NameInfo.Month);
         DestFolder = QDir::toNativeSeparators(DestFolder);
      }

      // Create destination folder if needed.
      Path.setPath(DestFolder);
      if (!Path.exists(DestFolder)) {
         // Destination folder do not exist.
         if (!Path.mkpath(DestFolder)) {
            // Unable to create destination folder.
            Message = "Unable to import event file '" + EventFile + "'. ";
            Message.append("Cannot create destination folder '" + DestFolder + "'.");
            Conf.LogModel->WriteLog(logmodel::error, Message);
            Errors = true;
         }
      }

      // Create the file name for the new event file.
      // The filename will be changed if a file with an
      // identical name already exists in the destination folder.
      QString NewFile = DestFolder + "/" + NameInfo.Name;
      while (QFile::exists(NewFile)) AddOneSecToSfileName(&NewFile);

      // Copy event file into current database file structure.
      QFile SFile(EventFile);
      if (!SFile.copy(NewFile)) {
         // Unable to copy S-File to destination folder.
         Message = "Unable to import event file '" + EventFile + "'. ";
         Message.append("Cannot copy event file to destination folder '" + DestFolder + "'.");
         Conf.LogModel->WriteLog(logmodel::error, Message);
         Errors = true;
      } else {
         NumImported++;
         Message = "Successfully imported event file '" + NewFile + "'.";
         Conf.LogModel->WriteLog(logmodel::info, Message);
      }

      // If date/time of event file is within the current
      // time interval, then load event file into SE.
      GetSfileNameInfo(NewFile, &NameInfo);
      if (NameInfo.Date >= Conf.AppConf.TimeIntDates.StartDate && NameInfo.Date <= Conf.AppConf.TimeIntDates.EndDate) {
         // Date of new event file is within current time interval.
         EventId = DB->LoadEvent(NewFile);
         // Add event to list of loaded events.
         if (EventId != -1) EventsLoaded.append(EventId);
         // If file could not be loaded, make a note in the log.
         if (EventId == -1) {
            NumLoadErrors++;
            Message = "Unable to load imported event file '" + NewFile + "'. Check file for errors.";
            Conf.LogModel->WriteLog(logmodel::error, Message);
            Errors = true;
         }
      } else {
         // Date/time is not within the current time
         // interval. This event file cannot be loaded.
         NumOutOfBand++;
      }

      // Update the progress bar.
      Progress.setValue(index);

      // Check if user want to cancel the import.
      if (Progress.wasCanceled()) break;
   }

   // Close the progress dialog window.
   Progress.setValue(NumEventFiles);

   // Write number of imported event files to the log.
   Message = "Successfully imported " + QString::number(NumImported);
   Message.append(" out of " + QString::number(NumEventFiles) + " event file(s).");
   Conf.LogModel->WriteLog(logmodel::info, Message);

   // Write number of files that could not be loaded (because of an error) to the log.
   if (NumLoadErrors) {
      Message = "Failed to load " + QString::number(NumLoadErrors);
      Message.append(" imported event file(s). Please check file(s) for errors.");
      Conf.LogModel->WriteLog(logmodel::error, Message);
      Errors = true;
   }

   // Write number of files that could not be loaded (outside current time interval) to the log.
   if (NumOutOfBand) {
      Message = "Failed to load " + QString::number(NumOutOfBand) + " imported event file(s). ";
      Message.append("File date(s) are outside current time interval. Please reload the database");
      Conf.LogModel->WriteLog(logmodel::warning, Message);
      Errors = true;
   }

   // Get number of events loaded into SE.
   int NumLoaded = EventsLoaded.size();

   // Exit here if no events was loaded into SE.
   if (!NumLoaded) return !Errors;

   // Resort the database and reload the event list view.
   DB->Resort(true); ELVModel->Reset();

   // If number of loaded events is 2000 or less, then select (highlight) all loaded
   // events. If number of events is larger than 2000, then we will just select the
   // last loaded event to avoid waiting a long time for the view to update itself.
   if (NumLoaded <= 2000) {
      // All events will be selected (highlighted).
      for (int i=0;i<NumLoaded;i++) EventsLoaded[i] = DB->IndexById(EventsLoaded[i]);
      ELVModel->SelectRows(&EventsLoaded, true);
   } else {
      // Just select (highlight) the last loaded event.
      ELVModel->SelectRow(DB->IndexById(EventsLoaded.last()), true, true, true);
   }

   // Update window title to show correct number of events.
   SetTabTitle();

   return !Errors;
}



// *****************************************************
// Move event list view selection down one step.
// *****************************************************
void SEBASE::NavigateDown()
{
   if (DbStatus == db::closed) return;
   RowNum = CurrentRow();
   if (RowNum+1 < NumEvents()) {
      ELVModel->SelectRow(RowNum + 1, true, true, false);
   } else {
      QApplication::beep();
   }

}




// *****************************************************
// Move event list view selection up one step.
// *****************************************************
void SEBASE::NavigateUp()
{
   if (DbStatus == db::closed) return;
   int RowNum = CurrentRow();
   if (RowNum) {
      ELVModel->SelectRow(RowNum-1, true, true, false);
   } else {
      QApplication::beep();
   }
}




// *****************************************************
// Retun number of events in model.
// *****************************************************
int SEBASE::NumEvents()
{
   if (DbStatus == db::closed) return 0;
   return ELVModel->GetNumModelEvents();
}




// *******************************************************************
// Load S-files into the Seisan Explorer database and event list view.
// *******************************************************************
void SEBASE::Open(db_info DbInfo)
{
   // Save database information.
   this->DbInfo = DbInfo;

   // Insert a new tab for the event list view into the tab widget.
   Conf.TabWidget->addTab(&PageWidget, QString());

   // Set database name on the event list view tab.
   Conf.TabWidget->setTabText(TabIndex(), DbInfo.Name);

   // Resize columns and show the event list view.
   ELView.resizeColumnsToContents(); ELView.show();

   // Start the database load. Database (DB) will send several
   // 'db_open_progress' signals during the database load. When
   // load is done, DB will issue a final 'db_open_result' signal.
   LdStartTime = QDateTime::currentDateTime();
   DB->Open(DbInfo, Conf.AppConf.TimeIntDates.StartDate, Conf.AppConf.TimeIntDates.EndDate);
}




// ********************************************************************
// This function handles the 'Plot with Mulplot' menu item.
// ********************************************************************
void SEBASE::Plot_With_Mulplot(bool plotdefault)
{
   int DbIndex;
   QString File;
   QStringList ArgList;
   MulpltHandler *MulPlt;

   // Check that database is open.
   if (DbStatus == db::closed) return;
   if (DbStatus != db::open) { ShowMessage(300); return; }

   // Get the list of selected rows.
   ELVModel->GetSelection(&ELVSelection);

   // Exit if no rows are selected.
   if (!ELVSelection.size()) return;

   // Only one row can be selected.
   if (ELVSelection.size() > 1) { ShowMessage(310, true); return; }

   // Get index for the selected event.
   DbIndex = ELVSelection.at(0).index;

   // Get full path to event file.
   DB->FileByIndex(DbIndex, &File);

   // The same event cannot be opened in two mulplt instances.
   // Check if there is already a mulplt instance handeling this event.
   if (IsEventOpenInMulplt(File)) {
      Message = "This event is already open in a mulplt window.";
      emit show_sb_message(Message, 8000);
      return;
   }

   // Create a new instance of the MulpltHandler class.
   MulPlt = new MulpltHandler(Conf.LogModel, this);
   MulpltHandlers.append(MulPlt);

   // Connect signals from MulpltHandler.
   connect(MulPlt, SIGNAL(message_received(MulpltHandler*, QString, QString)), this, SLOT(HandleMulpltMsg(MulpltHandler*, QString, QString)));

   // Execute mulplot with the selected event.
   if (plotdefault) ArgList.append("-plotdefault");
   ArgList.append("-operator"); ArgList.append(Conf.Operator->GetConfirmedId());
   ArgList.append("-base"); ArgList.append(DbInfo.Name);
   MulPlt->Start(File, ArgList);
}




// ****************************************************************************
// This function reloads an S-file from disk, and updates the event list view.
// Function will return the database presentation index for the reloaded event.
// If the S-file fails to reload this function will return a value of -1.
// ****************************************************************************
int SEBASE::ReloadEvent(int DbIndex)
{
   int EventId, Status, NewIndex;

   // Check that database is open.
   if (DbStatus != db::open) return false;

   // Get event id for this event.
   EventId = DB->IdByIndex(DbIndex);

   // Reload event into database.
   Status = DB->ReloadEventAndResort(DbIndex);
   if (Status) {
      Message = "Failed to reload updated event file. ";
      if (Status == 1) Message.append("Cannot open file.");
      if (Status == 2) Message.append("Error in file.");
      if (Status == 3) Message.append("Out of memory.");
      if (Status == 5) Message.append("Event has invalid date.");
      Conf.LogModel->WriteLog(logmodel::error, Message);
      emit Conf.LogModel->show_log_view();
      return -1;
   }

   // Update the event list view.
   NewIndex = DB->IndexById(EventId);
   if (NewIndex == DbIndex) {
      // Index has not changed after reoload.
      ELVModel->RefreshRow(NewIndex);
      emit cur_row_data_changed(this);
   } else {
      // Index has changed after reoload.
      ELVModel->SelectRow(NewIndex, true, true, true);
      emit cur_row_changed(this);
   }

   // Write message to status bar.
   Message = "Event sucessfully reloaded.";
   emit show_sb_message(Message, 5000);

   return NewIndex;
}




// **********************************************************
// This function registers an event. File name may change.
// **********************************************************
void SEBASE::RegisterEvent(int DbIndex)
{
   char Status;
   int NewDbIndex;
   QString OldFile;
   event_node_ *Node;
   filecopy *WaveformFiles;

   // Check that database is open.
   if (DbStatus == db::closed) return;

   // Check that DbIndex is valid.
   if (DbIndex < 0 || DbIndex >= NumEvents()) return;

   // Get pointer to event node.
   Node = DB->EventByIndex(DbIndex);

   // Check that event file has a type 6 line.
   if (!Node->wavefiles.numlines) {
      Message = "Cannot register this event. Event file has no type 6 line.";
      QMessageBox::information(0, AppName, Message);
      return;
   }

   // Check if event is already registered.
   if (NodeIsRegistered(Node)) {
      Message = "This event is already registered. Do you want to register it again?";
      if ((QMessageBox::question(0, "Register event", Message, QMB_YES|QMB_NO, QMB_NO) == QMB_NO)) return;
   }

   // Bring up the 'Register event' dialog box.
   // User data will be returned in 'DlgData'.
   RegEventData DlgData;
   DlgData.Node = Node;
   DlgData.SEISAN_TOP = Conf.AppConf.SEISAN_TOP;
   DlgData.DbName = DbInfo.Name;
   DlgData.AltDestDir = AltDestDir;
   DlgData.VolcSubClassVal.clear();
   RegEventDlg *Dlg = new RegEventDlg(&DlgData, 0);
   Dlg->setAttribute(Qt::WA_DeleteOnClose, true);
   if (Dlg->exec() == QDialog::Rejected) return;

   // User pressed OK. Save the alternative destination folder so it can
   // be automatically set the next time user need to register an event.
   AltDestDir = DlgData.AltDestDir;

   // Check if event file will be renamed.
   if (DlgData.DistInd != Node->hypocenters.first->dist_id)  {
      // Event file will be renamed by distance index. Save full path to
      // old file so that DB->UpdateSfile() can delete the file for us.
      OldFile = QString(Node->metadata.sfile);
   }

   // Update the node with new user values.
   NodeSetEventIndicator(Node, DlgData.EventInd);
   NodeSetModelIndicator(Node, DlgData.ModelInd);
   NodeSetDistanceIndicator(Node, DlgData.DistInd);
   NodeSetIdlineAction(Node, "REE");
   NodeSetIdlineUpdatetime(Node);
   NodeSetIdlineOperator(Node, Conf.Operator->GetConfirmedId());
   if (DlgData.VolcSubClassVal.size()) NodeAddComment(Node, "VOLC MAIN " + DlgData.VolcSubClassVal);

   // Update the event file. If S-file is succesfully updated, then the old file will be deleted.
   if (!DB->UpdateSfile(DbIndex, &Status, OldFile)) {
      // Failed to update the event file. UpdateSfile() did
      // not delete the old file. Write error message to log.
      Message = "Failed to register event. Could not write to '" + QString(Node->metadata.sfile) + "'.";
      Conf.LogModel->WriteLog(logmodel::error, Message);
      // Since we have modified the node, we will
      // try to reload the old event file from disk.
      int Index = ReloadEvent(DbIndex);
      if (Index == -1) {
         // Failed to reload the old event file.
         Message = "Failed to register event. Could not reload old event file.";
         Conf.LogModel->WriteLog(logmodel::error, Message);
      }
      emit Conf.LogModel->show_log_view();
      return;
   }

   // Event file has been written. Reload the updated file.
   if ((NewDbIndex = ReloadEvent(DbIndex)) != -1) {
      // The event file was successfully reloaded.
      // If index has changed, select the correct row in event list view.
      if (NewDbIndex != DbIndex) ELVModel->SelectRow(NewDbIndex, true, true, true);
   } else {
      // Failed to reloaded the event file.
      Message = "Register event: Failed to reload the updated event file '" + QString(Node->metadata.sfile) + "'.";
      Conf.LogModel->WriteLog(logmodel::error, Message); emit Conf.LogModel->show_log_view();
      return;
   }

   // Event has been reloaded.
   // Build a list of waveform files to be copied.
   if (DlgData.WaveFiles.size()) {
      WaveformFiles = new filecopy(Conf.LogModel, "Register event: ");
      for (int index=0;index<DlgData.WaveFiles.size();index++) {
         QString DestPath = DlgData.WaveFiles.at(index).DestPath;
         if (DlgData.AltDestDir.size()) DestPath = DlgData.AltDestDir;
         WaveformFiles->AddFile(DlgData.WaveFiles.at(index).Name, QDir::currentPath(), DestPath, true);
      }

      // Copy the waveform files. Existing files will be overwritten.
      if (!WaveformFiles->Copy()) emit Conf.LogModel->show_log_view();
      delete WaveformFiles;
   }
}




// ***********************************************************
// Remove a filter from the Event List view.
// ***********************************************************
void SEBASE::RemoveFilter()
{
   // Return if database is not open.
   if (DbStatus != db::open) return;
   if (!DB->isFilterApplied()) return;

   // Remove any existing filter.
   DB->RemoveFilter();
   ELVModel->Reset();
   ELVModel->SelectRow(0, false, true, false);
   SetTabTitle();
   emit num_events_changed(DB->NumEvents());
}




// *********************************************************************
// The event list model signals that the currnet active row has changed.
// *********************************************************************
void SEBASE::RowChanged(int row)
{
   Q_UNUSED(row);

   emit cur_row_changed(this);
}




// ***************************************************************
// This function turns on or off the user selectable columns based
// on the values found in the EvtListColStat table.
// ***************************************************************
void SEBASE::SetEventListViewHeaders(se_config AppConf)
{
   ELView.setColumnHidden(ColRowNumber, !AppConf.EvtListColStat[0]);    // Row Nr
   ELView.setColumnHidden(ColAction, !AppConf.EvtListColStat[1]);       // Action
   ELView.setColumnHidden(ColModel, !AppConf.EvtListColStat[2]);        // Model
   ELView.setColumnHidden(ColAgency, !AppConf.EvtListColStat[3]);       // Agency
   ELView.setColumnHidden(ColRMS, !AppConf.EvtListColStat[4]);          // RMS
   ELView.setColumnHidden(ColGap, !AppConf.EvtListColStat[5]);          // Gap
   ELView.setColumnHidden(ColErrLat, !AppConf.EvtListColStat[6]);       // Latitude error
   ELView.setColumnHidden(ColErrLon, !AppConf.EvtListColStat[7]);       // Longitude error
   ELView.setColumnHidden(ColErrDep, !AppConf.EvtListColStat[8]);       // Depth error
   ELView.setColumnHidden(ColDist, !AppConf.EvtListColStat[9]);         // Distance Indicator
   ELView.setColumnHidden(ColType, !AppConf.EvtListColStat[10]);        // Event Indicator
   ELView.setColumnHidden(ColMInt, !AppConf.EvtListColStat[11]);        // Max intensity for felt eq.
   ELView.setColumnHidden(ColNrSta, !AppConf.EvtListColStat[12]);       // Number of Stations
   ELView.setColumnHidden(ColM, !AppConf.EvtListColStat[13]);           // Magnitude M
   ELView.setColumnHidden(ColMW, !AppConf.EvtListColStat[14]);          // Magnitude MW
   ELView.setColumnHidden(ColML, !AppConf.EvtListColStat[15]);          // Magnitude ML
   ELView.setColumnHidden(ColMN, !AppConf.EvtListColStat[16]);          // Magnitude MN
   ELView.setColumnHidden(ColMC, !AppConf.EvtListColStat[17]);          // Magnitude MC
   ELView.setColumnHidden(ColMb, !AppConf.EvtListColStat[18]);          // Magnitude Mb
   ELView.setColumnHidden(ColMB, !AppConf.EvtListColStat[19]);          // Magnitude MB
   ELView.setColumnHidden(ColMs, !AppConf.EvtListColStat[20]);          // Magnitude Ms
   ELView.setColumnHidden(ColMS, !AppConf.EvtListColStat[21]);          // Magnitude MS
   ELView.setColumnHidden(ColLocality, !AppConf.EvtListColStat[22]);    // Locality
   ELView.setColumnHidden(ColSFile, !AppConf.EvtListColStat[23]);       // Path to S-File
}




// ***********************************************************
// Brings up the 'Apply filter to Event List view' dialog box.
// ***********************************************************
void SEBASE::SetFilter()
{
   // Return if database is not open.
   if (DbStatus != db::open) return;

   // Create and initialize the dialog.
   FilterDlg = new FilterViewDlg();
   FilterDlg->setAttribute(Qt::WA_DeleteOnClose, true);
   FilterDlg->InitDialog(&DbFilter);

   // Open the dialog box.
   if (FilterDlg->exec() == QDialog::Accepted) {
      if (DbFilter.InclQuery.size()) {
         // Apply the filter.
         DB->ApplyFilter(DbFilter);
         ELVModel->Reset();
         ELVModel->SelectRow(0, false, true, false);
         SetTabTitle();
         emit num_events_changed(DB->NumEvents());
      } else {
         // Remove any existing filter.
         if (DB->isFilterApplied()) {
            DB->RemoveFilter();
            ELVModel->Reset();
            ELVModel->SelectRow(0, false, true, false);
            SetTabTitle();
            emit num_events_changed(DB->NumEvents());
         }
      }
   }
}




// *****************************************************
// Give the keyboard input focus to the event list view.
// *****************************************************
void SEBASE::SetKeyboardFocus()
{
   ELView.setFocus(Qt::OtherFocusReason);
}




// ********************************************************************
// This function returns event ID's for all selected events.
// ********************************************************************
void SEBASE::SelectedEvents(QListEventID *Events)
{
    // Check that database is open.
    if (DbStatus != db::open) {
       Events->clear();
       return;
    }

    // Get the list of selected rows.
    ELVModel->GetSelection(Events);
}




// *******************************************
// Set the text on the event list view tab.
// *******************************************
void SEBASE::SetTabTitle()
{
   if (DbStatus == db::closed) return;

   // Find the database title/description.
   QString Title = DbInfo.Name;
   if (DbInfo.Type == default_database) Title = Conf.AppConf.DEF_BASE;
   if (DbInfo.Type == local_database) Title = DbInfo.Path;

   // Database is enumerating S-files.
   if (DbStatus == db::enum_sfiles) {
      Conf.TabWidget->setTabText(TabIndex(), Title + " (Enumerating S-files ...)");
      return;
   }

   // Database is loading S-files.
   if (DbStatus == db::read_sfiles) {
      Conf.TabWidget->setTabText(TabIndex(), Title + " (Loading S-files ...)");
      return;
   }

   // If a filter is applied, add filter description to title.
   if (DB->isFilterApplied()) {
      Title.append(" [Filter: ");
      if (DbFilter.Description.size()) {
         Title.append(DbFilter.Description.leftRef(60));
         if (DbFilter.Description.size() > 50) Title.append("...");
         Title.append("]");
      } else {
         Title.append("Unnamed]");
      }
   }

   // Set the title.
   Conf.TabWidget->setTabText(TabIndex(), Title.simplified());
}




// *****************************************************
// Returns the tab index used by this database instance.
// *****************************************************
int SEBASE::TabIndex()
{
   return Conf.TabWidget->indexOf(&PageWidget);
}




// **********************************************************
// This function unloads an event from SE.
// **********************************************************
void SEBASE::UnloadEvent(int index)
{
   int NumEvents;

   // Unload event.
   DB->RemoveEvent(index);

   // Get number of events
   NumEvents = DB->NumEvents();

   // Signal that number of events has changed.
   emit num_events_changed(NumEvents);

   // Exit if there are no events in database.
   if (!NumEvents) return;

   // Select a new row and update the locate view.
   RowNum = index; if (index == NumEvents) RowNum = index-1;
   ELVModel->SelectRow(RowNum, true, true, false);

   // Signal that current row has changed.
   emit cur_row_changed(this);
}




// *****************************************************
// This function writes all events to a catalog file.
// Returns true if fuction succeeds.
// *****************************************************
bool SEBASE::WriteToCatFile(QString CatFile)
{
   int NumEvents;
   QByteArray text;
   QString FileName;
   QStringList FileList;
   QFile infile, outfile;

   // Get number of events in database.
   // Return if no events are found.
   NumEvents = DB->NumEvents();
   if (!NumEvents) return false;

   // Add all event files to file list.
   for (int i=0;i<NumEvents;i++) {
      // Get filename for this row.
      DB->FileByIndex(i, &FileName);
      // Add to file list.
      FileList.append(FileName);
   }

   // Merge together all files in the file list
   // and save the result in the outfile.
   // Open out file. Existing file will be overwritten. Abort if 'open' failes.
   outfile.setFileName(CatFile);
   if (!outfile.open(QIODevice::WriteOnly | QIODevice::Truncate | QIODevice::Text)) return false;

   // Copy all files in file list to out file.
   bool error = false;
   for (int index=0;index<NumEvents;index++) {
      infile.setFileName(FileList.at(index));
      if (infile.open(QIODevice::ReadOnly | QIODevice::Text)) {
         text = infile.readAll(); infile.close();
         if (outfile.write(text) == -1) error = true;
      } else {
         // The file either do not exist, or
         // it cannot be openened for reading.
         error = true;
      }
   }
   // Close the out file.
   outfile.close();

   // Return true if function succeded.
   return !error;
}



// *********************************************************************************
// This function writes a predeifined message to a pop-up window, or the status bar.
// *********************************************************************************
void SEBASE::ShowMessage(int MsgNum, bool ToStatusBar)
{
   int MsgType;
   QString Msg;

   // Set the message string.
   if (MsgNum == 300) { Msg = "Cannot perform this operation while database is loading."; MsgType = 2; }
   if (MsgNum == 310) { Msg = "Multiple selections are not allowed for this operation."; MsgType = 2; }
   if (MsgNum == 350) { Msg = "The selected S-file do not refer to any wave files."; MsgType = 0; }
   if (MsgNum == 351) { Msg = "No wave files was found."; MsgType = 0; }

   // Return if no message was been set.
   if (Msg.isEmpty()) return;

   // Show the message on the status bar.
   if (ToStatusBar) { emit show_sb_message(Msg, 8000); return; }

   // Show the message in a dialog box.
   if (MsgType == 0) QMessageBox::information(0, AppName, Msg);
   if (MsgType == 1) QMessageBox::warning(0, AppName, Msg);
   if (MsgType == 2) QMessageBox::critical(0, AppName, Msg);
}
