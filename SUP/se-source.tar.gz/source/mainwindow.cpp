// Program name: Seisan Explorer
// Developed with Qt, version: 5.12.9
// Developer: Øyvind Natvik
// Statistics modules developer: Peter Voss

#include <QDebug>
#include <QProcessEnvironment>

#include "mainwindow.h"
#include "ui_mainwindow.h"
#include "google.h"
#include "fortran.h"
#include "library.h"
#include "aboutdlg.h"
#include "logmodel.h"
#include "seisandb.h"
#include "mergedlg.h"
#include "opendbdlg.h"
#include "gotorowdlg.h"
#include "export2csvdlg.h"
#include "fileeditordlg.h"
#include "gettextlinesdlg.h"
#include "selectworkdirdlg.h"
#include "waveformviewerdlg.h"
#include "convertcatfiledlg.h"
#include "createdatabasedlg.h"
#include "statistics/poissondlg.h"
#include "statistics/weichertdlg.h"
#include "statistics/todvstoydlg.h"
#include "statistics/magvsmagdlg.h"
#include "statistics/todvsdistdlg.h"
#include "statistics/gumbel3distdlg.h"
#include "statistics/eventsperyeardlg.h"
#include "statistics/timeofdaydistrdlg.h"
#include "statistics/gutenbergrichterdlg.h"
#include "statistics/completenesscheckdlg.h"
#include "statistics/driftofhypocentersdlg.h"


// *****************************************
// Constructor for this class.
// *****************************************
MainWindow::MainWindow(QWidget *parent) : QMainWindow(parent), ui(new Ui::MainWindow)
{
   // Register user defined metatypes.
   qRegisterMetaType<db::dbStatus>("db::dbStatus");
   qRegisterMetaType<db::dbError>("db::dbError");
   qRegisterMetaType<logmodel::msg_type>("logmodel::msg_type");

   // Initialize some variables.
   SEDB = nullptr;
   OpenLastUsed = false;
   CatFileOpened = false;
   NoCloseQuery = false;
   NoTimeIntQuery = false;

   // Set program name, version, and build date.
   AppName = "Seisan Explorer";
   AppVersion = "2.7.2";

   // Store organisation and application name.
   // This information is used by QSession.
   QCoreApplication::setOrganizationName("UiB");
   QCoreApplication::setApplicationName(AppName);
   QCoreApplication::setApplicationVersion(AppVersion);

   // Set up the user interface.
   ui->setupUi(this);

   // Set main window title.
   setWindowTitle(AppName + " " + AppVersion);

   // Add labels to the status bar
   statusBar()->addPermanentWidget(&LblInterval);  // Used to show current time interval.
   statusBar()->addPermanentWidget(&LblOperator);  // Used to show operator's identity.

   // Create a connection from the tab widget.
   connect(ui->tabWidget, SIGNAL(currentChanged(int)), this, SLOT(CurrentTabChanged(int)));

   // Create a connection from the operator class.
   connect(&Operator, SIGNAL(SetStatusBarOperator()), this, SLOT(SetStatusBarOperator()));

   // Set a model for the log view.
   ui->LogView->setModel(&LogModel); LogModel.SetView(ui->LogView);

   // Create connections from the log view model.
   connect(&LogModel, SIGNAL(show_log_view()), this, SLOT(ShowLogView()));

   // Create connections to the log view model.
   connect(this, SIGNAL(WriteLog(logmodel::msg_type, QString)), &LogModel, SLOT(WriteLog(logmodel::msg_type, QString)));
   connect(&Operator, SIGNAL(WriteLog(logmodel::msg_type, QString)), &LogModel, SLOT(WriteLog(logmodel::msg_type, QString)));
   connect(&WD, SIGNAL(WriteLog(logmodel::msg_type, QString)), &LogModel, SLOT(WriteLog(logmodel::msg_type, QString)));

   // Enable the context menu for the log view.
   ui->LogView->setContextMenuPolicy(Qt::CustomContextMenu);
   connect(ui->LogView, SIGNAL(customContextMenuRequested(const QPoint&)), this, SLOT(CCMR_LogView(const QPoint&)));

   // Install event filter for the log view.
   ui->LogView->installEventFilter(&LVFilter);

   // Create a connection from the log view filter.
   connect(&LVFilter, SIGNAL(SetTimeInterval()), this, SLOT(SetTimeInterval()));

   // Queue an app start event so that the application
   // gets a start signal when the message queue is up.
   QTimer::singleShot(0, this, SLOT(appStarting()));
}




// *****************************************
// Destructor for this class.
// *****************************************
MainWindow::~MainWindow()
{
   // Save program settings to registry or disk.
   SaveProgramSettings();

   // Delete mainwindow class.
   delete ui;
}





// *********************************************************************
// This signal is shot from the constructor function.
// It signals that the application has now started and
// is processing messages from the message queue.
// *********************************************************************
void MainWindow::appStarting()
{
   // Initilize some members of AppConf structure.
   QProcessEnvironment PE = QProcessEnvironment::systemEnvironment();
   AppConf.SEISAN_TOP = PE.value("SEISAN_TOP");
   AppConf.DEF_BASE = PE.value("DEF_BASE").toUpper();
   AppConf.AppLaunchDir = QDir::currentPath();
   AppConf.SeisanWorkDir = BuildPath(AppConf.SEISAN_TOP, "WOR");
   AppConf.SeisanDatDir = BuildPath(AppConf.SEISAN_TOP, "DAT");

   // Initilize the rest of the AppConf structure.
   // Configuration is loaded from registry or file.
   LoadProgramSettings();

   // Write startup message to the program log.
   Message = AppName + " version ";
   Message.append(AppVersion + " started. ");
   if (Operator.IsSet()) Message.append("Operator is '" + Operator.GetCurrentId() + "'.");
   LogModel.WriteLog(logmodel::info, Message);

   // Set the work directory. Quit if it cannot be set.
   if (WD.Set(&AppConf)) {
       Message = "Unable to set a work directory. SE will close.";
       QMessageBox::critical(this, AppName, Message);
       QApplication::quit();
   }

   // Update the window title (add work directory).
   SetWindowTitle();

   // Check and handle issues with 'SEISAN_TOP'.
   if (AppConf.SEISAN_TOP.isEmpty()) {
      Message = "Environment variable SEISAN_TOP is not defined. SE will close.";
      QMessageBox::critical(this, AppName, Message);
      QApplication::quit();
   }
   if (!QDir(AppConf.SEISAN_TOP).exists()) {
      Message = "Environment variable SEISAN_TOP points to an invalid folder (" + AppConf.SEISAN_TOP + ").\n";
      Message.append("Make sure SEISAN_TOP points to the Seisan installation folder. SE will close.");
      QMessageBox::critical(this, AppName, Message);
      QApplication::quit();
   }
   Message = "Seisan home folder (SEISAN_TOP) is '" + AppConf.SEISAN_TOP + "'.";
   LogModel.WriteLog(logmodel::info, Message);

   // Check and handle issues with 'DEF_BASE'.
   if (AppConf.DEF_BASE.size()) {
      // Make sure DEF_BASE is 5 characters long.
      while (AppConf.DEF_BASE.size() < 5) AppConf.DEF_BASE.append("_");
      // Write value of DEF_BASE to the program log.
      Message = "Default database (DEF_BASE) is " + AppConf.DEF_BASE + ".";
      LogModel.WriteLog(logmodel::info, Message);
   } else {
      // Variable DEF_BASE is not defined. Disable
      // the 'File|Open|Default Database' menu item.
      ui->actionOpen_Default_Database->setDisabled(true);
      // Inform user that DEF_BASE is not properly set.
      Message = "Variable 'DEF_BASE' is not defined. SE will continue with reduced functionality.";
      LogModel.WriteLog(logmodel::warning, Message);
   }

   // Create path to SEISAN.DEF file. If file is present in the
   // work directory then we use this file, otherwise the file
   // in SEISAN_TOP/DAT folder will be used.
   SetSeisanDef(&AppConf, &WD);
   Message = "Location of SEISAN.DEF is '" + AppConf.SEISAN_DEF + "'.";
   LogModel.WriteLog(logmodel::info, Message);

   // Load settings from SEISAN.DEF file.
   LoadPredefComments(AppConf.SEISAN_DEF, &PredefComments);
   Message = "Loaded " + QString::number(PredefComments.size()) + " pre-defined comment(s) from SEISAN.DEF.";
   LogModel.WriteLog(logmodel::info, Message);
   LoadPredefNetworks(AppConf.SEISAN_DEF, &PredefNetworks);
   Message = "Loaded " + QString::number(PredefNetworks.size()) + " pre-defined virtual network(s) from SEISAN.DEF.";
   LogModel.WriteLog(logmodel::info, Message);
   LoadNewNordicFormat(AppConf.SEISAN_DEF);

   // Calculate and show default time interval.
   if (AppConf.UsePrevTimeInterval) {
      // Use start and end dates from last session.
      AppConf.TimeIntDates.EndDateType = 3;
   } else {
      // Use default start and end dates.
      AppConf.TimeIntDates.EndDateType = 1;
      AppConf.TimeIntDates.StartDate = QDate::currentDate().addDays(-AppConf.TimeInterval);
      AppConf.TimeIntDates.EndDate = QDate::currentDate();
   }
   SetStatusBarTimeInterval();

   // Google Earth. Create a KML file named 'se-gmap.kml'.
   // File will be created in the current working directory.
   CreatePriKmlFile();

   // Create a new database instance. Instance is not visible in tab widget at this point.
   SEDBCONF.PredefComments = PredefComments;
   SEDBCONF.PredefNetworks = PredefNetworks;
   SEDBCONF.AppConf = AppConf;
   SEDBCONF.Operator = &Operator;
   SEDBCONF.LogModel = &LogModel;
   SEDBCONF.TabWidget = ui->tabWidget;
   SEDB = new SEBASE(&SEDBCONF);

   // Quit if database could not be created.
   if (!SEDB) QApplication::quit();

   // Create the Locator window. It will be initially hidden.
   LocateView = new LocateDlg(&Operator);

   // Connect signals from SEDB.
   connect(SEDB, SIGNAL(cur_row_changed(SEBASE*)), LocateView, SLOT(RowChanged(SEBASE*)));
   connect(SEDB, SIGNAL(cur_row_data_changed(SEBASE*)), LocateView, SLOT(RowChanged(SEBASE*)));
   connect(SEDB, SIGNAL(edit_stationhyp_file()), this, SLOT(Edit_StationHyp()));
   connect(SEDB, SIGNAL(open_result(db::dbStatus, db::dbError, int)), this, SLOT(DbOpenResult(db::dbStatus, db::dbError, int)));
   connect(SEDB, SIGNAL(set_time_interval(void)), this, SLOT(SetTimeInterval(void)));
   connect(SEDB, SIGNAL(locate_event(void)), this, SLOT(Locate_Event(void)));
   connect(SEDB, SIGNAL(num_events_changed(int)), this, SLOT(SetWindowTitle(void)));
   connect(SEDB, SIGNAL(show_sb_message(QString, int)), ui->statusBar, SLOT(showMessage(QString, int)));

   // User can open a REA database or local database from command line. Check command line arguments.
   //    Syntax for opening a database from REA: 'se <start date> <REA database> [interval]'
   //    Example: 'se 20170610 NNSN_ 60'. Default value for interval is 30 days.
   //    Syntax for opening a local database from SE startup folder: 'se ,,'
   // If a command line error is detected, then SE will ignore the command line.
   if (ProcessCmdLine(&AppConf)) {
      // Open database from command line.
      SEDB->SetTimeInterval(AppConf.TimeIntDates);
      Open_LastUsedDatabase();
   } else {
      // Load last used database if requested. Last time interval will be used.
      if (AppConf.AutoLoad && AppConf.LastUsedDatabaseType != no_database) Open_LastUsedDatabase();
   }
}




// ******************************************************
// Activates a tab in the tab widget.
// ******************************************************
void MainWindow::ActivateTab(QWidget *TabWidget)
{
   ui->tabWidget->setCurrentIndex(ui->tabWidget->indexOf(TabWidget));
}




// *******************************************************
// Opens and read data from the default database folder.
// A database folder contains year/month subfolders.
// *******************************************************
void MainWindow::Open_DefaultDatabase()
{
   // Check if a database is already open.
   if (SEDB->DbStatus == db::open) {
      Message = "<b>A database is already open.</b>";
      Message.append("<br>Please close current database first.");
      QMessageBox::information(this, AppName, Message);
      return;
   }

   // Check if a database is loading.
   if (SEDB->DbStatus != db::closed) {
      Message = "<b>A database is currently loading.</b>";
      Message.append("<br>To stop loading, please close database.");
      QMessageBox::information(this, AppName, Message);
      return;
   }

   // Check that the database folder exist.
   QString Path = BuildPath(AppConf.SEISAN_TOP, "REA", AppConf.DEF_BASE);
   if (!QDir(Path).exists()) {
      Message = "<b>Database defined in environment variable 'DEF_BASE' do not exist.</b>";
      QMessageBox::critical(this, AppName, Message);
      return;
   }

   // Save database path and database name.
   DbInfo.Path = Path;
   DbInfo.Name = AppConf.DEF_BASE;

   // Request time interval from user.
   if (!NoTimeIntQuery && !SetTimeInterval()) return;

   // Write message to program log.
   Message = "Database load started for default database (" + AppConf.DEF_BASE + ").";
   LogModel.WriteLog(logmodel::info, Message);

   // Load database into 'DB' class. This operation may take some time.
   DbInfo.Type = default_database;
   SEDB->Open(DbInfo);
}




// ******************************************************
// Opens and read data from a normal database folder.
// Database folder must contain year/month subfolders.
// ******************************************************
void MainWindow::Open_Database()
{
   // Check if a database is already open.
   if (SEDB->DbStatus == db::open) {
      Message = "<b>A database is already open.</b>";
      Message.append("<br>Please close current database first.");
      QMessageBox::information(this, AppName, Message);
      return;
   }

   // Check if a database is loading.
   if (SEDB->DbStatus != db::closed) {
      Message = "<b>A database is currently loading.</b>";
      Message.append("<br>To stop loading, please close database.");
      QMessageBox::information(this, AppName, Message);
      return;
   }

   if (OpenLastUsed) {
      // Open last used database.
      DbInfo.Name = AppConf.LastUsedDatabaseName;
      DbInfo.Path = AppConf.LastUsedDatabasePath;
      DbInfo.Type = AppConf.LastUsedDatabaseType;
      if (!QDir(DbInfo.Path).exists()) {
         Message = "<b>Database path for last used database do not exist.</b>";
         QMessageBox::critical(this, AppName, Message);
         return;
      }
   } else {
      // Bring up the 'Open database' dialog box.
      QString Db; int DbType;
      OpenDbDlg *OpenDlg = new OpenDbDlg(this);
      OpenDlg->setAttribute(Qt::WA_DeleteOnClose, true);
      OpenDlg->InitDialog(AppConf, &Db, &DbType);
      if (OpenDlg->exec() == QDialog::Rejected) return;

      // Save database path and database name.
      // DbType = 0 -> Db contains a 5 character database name.
      // DbType = 1 -> Db contains a path to a database folder.
      if (DbType == 0) {
         DbInfo.Name = Db;
         DbInfo.Path = AppConf.SEISAN_TOP + "/REA/" + Db;
         DbInfo.Type = normal_database_by_name;
      }
      if (DbType == 1) {
         DbInfo.Path = Db;
         DbInfo.Name = GetNameFromFilePath(Db);
         DbInfo.Type = normal_database_by_path;
      }
   }

   // Request time interval from user.
   if (!NoTimeIntQuery && !SetTimeInterval()) return;

   // Write message to log.
   Message = QString("Database load started (").append(DbInfo.Name).append(").");
   LogModel.WriteLog(logmodel::info, Message);

   // Start loading database.
   SEDB->Open(DbInfo);
}




// **************************************************
// Open and read data from a folder with S-files.
// **************************************************
void MainWindow::Open_LocalDatabase()
{
   QString WorkDir;

   // Check if a database is already open.
   if (SEDB->DbStatus == db::open) {
      Message = "<b>A database is already open.</b>";
      Message.append("<br>Please close current database first.");
      QMessageBox::information(this, AppName, Message);
      return;
   }

   // Check if a database is loading.
   if (SEDB->DbStatus != db::closed) {
      Message = "<b>A database is currently loading.</b>";
      Message.append("<br>To stop loading, please close database.");
      QMessageBox::information(this, AppName, Message);
      return;
   }

   if (!OpenLastUsed) {
      // Set working directory for the folder selection dialg box.
      WorkDir = QDir::currentPath();
      if (AppConf.LastUsedDatabaseType == local_database && QDir(AppConf.LastUsedDatabasePath).exists()) {
         WorkDir = AppConf.LastUsedDatabasePath;
      }

      // Bring up file selection dialog box. User must point to a folder
      // with one or more S-files. Return if user cancels the operation.
      Message = "Please select a folder with S-files:";
      DbInfo.Path = QFileDialog::getExistingDirectory(this, Message, WorkDir, QFileDialog::ShowDirsOnly);

      // Return if user did not select a folder.
      if (DbInfo.Path.isNull()) return;

      // Use native separators in the path.
      DbInfo.Path = QDir::toNativeSeparators(DbInfo.Path);
   } else {
      // Open last used database.
      DbInfo.Path = AppConf.LastUsedDatabasePath;
      if (!QDir(DbInfo.Path).exists()) {
         Message = "<b>Path to last used database do not exist.</b>";
         QMessageBox::critical(this, AppName, Message);
         return;
      }
   }

   // Set current working directory to the database directory. Abort
   // here if we are unable to set database path as current directory.
   int Status = WD.SetByPath(DbInfo.Path);
   if (Status) {
      // Write error message to log.
      Message = QString("Database load aborted: Cannot set database folder as work folder.");
      if (Status == 2) Message.append(" Cannot change to work folder.");
      if (Status == 3) Message.append(" Lock file '" + QString(WORKDIR_LOCK_FILE) + "' exists in database folder.");
      LogModel.WriteLog(logmodel::error, Message);
      return;
   }

   // Working directory may have changed, update window title.
   SetWindowTitle();

   // Set database name to ",,";
   DbInfo.Name = ",,";

   // Write message to log.
   Message = QString("Database load started for local database (").append(DbInfo.Path).append(").");
   LogModel.WriteLog(logmodel::info, Message);

   // Load database into 'DB' class.
   DbInfo.Type = local_database;
   SEDB->Open(DbInfo);
}




// **************************************************
// Converts a catalog file to a local database and
// then opens the local database.
// **************************************************
void MainWindow::Open_CatalogFile()
{
   QString DbPath;
   ConvertCatFileDlg *ConvDlg;

   // Check if a database is already open.
   if (SEDB->DbStatus == db::open) {
      Message = "<b>A database is already open.</b>";
      Message.append("<br>Please close current database first.");
      QMessageBox::information(this, AppName, Message);
      return;
   }

   // Check if a database is loading.
   if (SEDB->DbStatus != db::closed) {
      Message = "<b>A database is currently loading.</b>";
      Message.append("<br>To stop loading, please close the database.");
      QMessageBox::information(this, AppName, Message);
      return;
   }

   // Create and initialize the conversion dialog box.
   ConvDlg = new ConvertCatFileDlg(this, &CatalogFile, &DbPath);
   ConvDlg->setAttribute(Qt::WA_DeleteOnClose, true);

   // Open the catalog file conversion dialog box.
   if (ConvDlg->exec()) {
      OpenLastUsed = true;
      CatFileOpened = true;
      AppConf.LastUsedDatabasePath = DbPath;
      Open_LocalDatabase();
   }
}




// **************************************************
// Opens and read from an index file.
// **************************************************
void MainWindow::Open_IndexFile()
{
   QString WorkDir;

   // Check if a database is already open.
   if (SEDB->DbStatus == db::open) {
      Message = "<b>A database is already open.</b>";
      Message.append("<br>Please close current database first.");
      QMessageBox::information(this, AppName, Message);
      return;
   }

   // Check if a database is loading.
   if (SEDB->DbStatus != db::closed) {
      Message = "<b>A database is currently loading.</b>";
      Message.append("<br>To stop loading, please close database.");
      QMessageBox::information(this, AppName, Message);
      return;
   }

   if (!OpenLastUsed) {
       // Set working directory for the file selection dialg box.
       if (AppConf.LastUsedDatabaseType == index_file && QFile(AppConf.LastUsedDatabaseName).exists()) {
          WorkDir = AppConf.LastUsedDatabaseName;
       } else {
          WorkDir = QDir::currentPath();
       }

       // Bring up file selection dialog box. Return if user cancels
       // the operation. User must point to an index file.
       Message = "Please select an index file:";
       DbInfo.Name = QFileDialog::getOpenFileName(this, Message, WorkDir);

       // Return if user did not select a file.
       if (DbInfo.Name.isNull()) return;

   } else {
       // Open last used index file.
       DbInfo.Name = AppConf.LastUsedDatabaseName;
       if (!QFile(DbInfo.Name).exists()) {
          Message = "<b>Last used index file do not exist.</b>";
          QMessageBox::critical(this, AppName, Message);
          return;
       }
   }

   // Write message to log.
   Message = QString("Database load started with index file (").append(DbInfo.Name).append(").");
   LogModel.WriteLog(logmodel::info, Message);

   // Load events in index file into 'DB' class.
   DbInfo.Type = index_file;
   SEDB->Open(DbInfo);
}




// **************************************************
// Open and read the last used database.
// **************************************************
void MainWindow::Open_LastUsedDatabase()
{
   // Check if a database is already open.
   if (SEDB->DbStatus == db::open) {
      Message = "<b>A database is already open.</b>";
      Message.append("<br>Please close current database first.");
      QMessageBox::information(this, AppName, Message);
      return;
   }

   // Check if a database is loading.
   if (SEDB->DbStatus != db::closed) {
      Message = "<b>A database is currently loading.</b>";
      Message.append("<br>To stop loading, please close database.");
      QMessageBox::information(this, AppName, Message);
      return;
   }

   // Open last used database.
   if (AppConf.LastUsedDatabaseType != no_database) {
      OpenLastUsed = NoTimeIntQuery = true;
      if (AppConf.LastUsedDatabaseType == default_database) Open_DefaultDatabase();
      if (AppConf.LastUsedDatabaseType == normal_database_by_name) Open_Database();
      if (AppConf.LastUsedDatabaseType == normal_database_by_path) Open_Database();
      if (AppConf.LastUsedDatabaseType == local_database) Open_LocalDatabase();
      if (AppConf.LastUsedDatabaseType == index_file) Open_IndexFile();
      OpenLastUsed = NoTimeIntQuery = false;
   } else {
      Message = "<b>No database has previously been used.</b>";
      QMessageBox::information(this, AppName, Message);
   }
}




// ********************************************************************************
// This slot is called by the database when db.open() has finished. The result is
// returned in 'status' and 'error'. 'loadtime' holds the load time in seconds.
// ********************************************************************************
void MainWindow::DbOpenResult(db::dbStatus status, db::dbError error, int loadtime)
{
   // Get type of database.
   db_type DbType = SEDB->DbInfo.Type;

   // Database could not be opened.
   if (status == db::closed) {
      // Restore current working directory if needed.
      if (DbType == local_database) WD.SetEx(&AppConf);
      // Display error message in program log or otherwise.
      statusBar()->clearMessage();
      if (error == db::cancelled) {
         statusBar()->showMessage(QString("Load cancelled."), 10000);
         Message = "Database load was cancelled by user.";
         LogModel.WriteLog(logmodel::info, Message);
         ShowLogView();
      }
      if (error == db::out_of_memory) {
         statusBar()->showMessage(QString("Database closed."), 10000);
         Message = "Out of memory. Unable to open database.";
         LogModel.WriteLog(logmodel::error, Message);
         ShowLogView();
      }
      if (error == db::corrpupt_files) {
         statusBar()->showMessage(QString("Database closed."), 10000);
         Message = "All files in database are corrupted. Unable to open database.";
         LogModel.WriteLog(logmodel::error, Message);
         ShowLogView();
      }
      if (error == db::no_files_found) {
         statusBar()->clearMessage();
         Message = "Unable to open database. ";
         if (DbType == local_database || DbType == index_file) {
            Message.append("No event files could be found.");
         } else {
            Message.append("No events was found. Check current time interval.");
         }
         LogModel.WriteLog(logmodel::error, Message);
      }
      return;
   }

   //
   // Database has been opened (with or without errors).
   //
   if (status == db::open) {
      // Update the window title.
      SetWindowTitle();

      // Update time interval in status bar.
      SetStatusBarTimeInterval();

      // Show message on statusbar.
      statusBar()->showMessage("Database opened.", 10000);

      // Save information about the current database to configuration.
      AppConf.LastUsedDatabaseType = DbType;
      if (DbType == default_database) {
         AppConf.LastUsedDatabaseName.clear();
         AppConf.LastUsedDatabasePath.clear();
         Message = "Default database opened with ";
         Message.append(QString::number(SEDB->DB->NumEvents()) + " events.");
      }
      if (DbType == normal_database_by_name ||
          DbType == normal_database_by_path) {
         AppConf.LastUsedDatabaseName = DbInfo.Name;
         AppConf.LastUsedDatabasePath = DbInfo.Path;
         Message = "Database opened with ";
         Message.append(QString::number(SEDB->DB->NumEvents()) + " events.");
      }
      if (DbType == local_database) {
         // Save information about last database used to configuration.
         AppConf.LastUsedDatabaseName.clear();
         AppConf.LastUsedDatabasePath = DbInfo.Path;
         Message = "Local database opened with ";
         Message.append(QString::number(SEDB->DB->NumEvents()) + " events.");
      }
      if (DbType == index_file) {
         // Save information about last database used to configuration.
         AppConf.LastUsedDatabaseName = DbInfo.Name;
         AppConf.LastUsedDatabasePath.clear();
         Message = "Index file opened with ";
         Message.append(QString::number(SEDB->DB->NumEvents()) + " events.");
      }
      // Append load time to message and write to log window/file.
      Message.append(" Load time " + QString::number(loadtime) + " sec.");
      LogModel.WriteLog(logmodel::info, Message);

      // If database is of type local database or index file,
      // then the user given time interval is neglected. Instead
      // we have to find (and show on the status bar) the actual
      // time interval that has been loaded into the database.
      if (DbType == local_database || DbType == index_file) {
         hypocenter_ *Hyp = SEDB->DB->EventByIndex(0)->hypocenters.first;
         AppConf.TimeIntDates.StartDate.setDate(Hyp->time.year, Hyp->time.month, Hyp->time.day);
         Hyp = SEDB->DB->EventByIndex(SEDB->DB->NumEvents()-1)->hypocenters.first;
         AppConf.TimeIntDates.EndDate.setDate(Hyp->time.year, Hyp->time.month, Hyp->time.day);
      }

      // Inform user of any database error.
      if (error != db::no_error) {
         if (error == db::out_of_memory) {
            // We run out of memory while loading eventfiles.
            Message = "Out of memory while reading from database. ";
            Message.append("Seisan database has only been partly loaded.");
            LogModel.WriteLog(logmodel::warning, Message);
         }
         if (error == db::corrpupt_files) {
            // One or several corrupt S-files was skipped.
            Message = "One or several corrupt S-files was skipped. ";
            Message.append("Seisan database has only been partly loaded.");
            LogModel.WriteLog(logmodel::warning, Message);
         }
         // Switch to Log View to show messages.
         ShowLogView();
      } else {
         // Switch to Event List View to show events.
         ActivateTab(&SEDB->PageWidget);
      }

      // If Locator window is open, show data for the current row.
      if (LocateView) LocateView->RowChanged(SEDB);
   }
}




// **********************************************************
// Close the database. Returns 'true' if database was closed.
// **********************************************************
bool MainWindow::Close_Database()
{
   bool close = false;
   switch (SEDB->DbStatus) {
   case db::open:
      // Close open database.
      if (NoCloseQuery) {
         close = true;
      } else {
         Message = "Do you want to close the database?";
         close = (QMessageBox::question(nullptr, AppName, Message, QMB_YES|QMB_NO, QMB_YES) == QMB_YES);
      }
      if (close) {
         // User have chosen to close the database.
         if (SEDB->DbInfo.Type == local_database) {
            // Check if a catalog file was opened.
            if (CatFileOpened) {
               Message = "Do you want to save changes to catalog file?";
               if ((QMessageBox::question(nullptr, AppName, Message, QMB_YES|QMB_NO, QMB_YES) == QMB_YES)) {
                  if (!SEDB->WriteToCatFile(CatalogFile)) {
                     QMessageBox::critical(nullptr, AppName, "<b>Failed to write catalog file.</b>");
                  }
               }
            }
            // Reset flags.
            CatFileOpened = false;
            // Restore work directory.
            if (WD.SetEx(&AppConf)) if (WD.Set(&AppConf)) QApplication::quit();
         }
         // Hide the locate window if visible.
         if (LocateView->isVisible()) LocateView->hide();
         // Close the database.
         statusBar()->showMessage("Closing database, please wait...", 0);
         SEDB->Close();
         statusBar()->showMessage("Database closed.", 5000);
         SetWindowTitle();
         LogModel.WriteLog(logmodel::info, QString("Database closed."));

         // Switch to the Log View.
         ui->tabWidget->setCurrentIndex(0);
      }
      break;

   case (db::enum_sfiles):
      // Database is currently enumerating S-files.
      // Loading will be terminated.
      Message = "Closing database, please wait...";
      statusBar()->showMessage(Message, 0);
      // Hide the locate window if visible.
      if (LocateView->isVisible()) LocateView->hide();
      SEDB->Close(); close = true;
      break;

   case (db::read_sfiles):
      // Database is currently reading S-files.
      // Loading will be terminated.
      Message = "Closing database, please wait...";
      statusBar()->showMessage(Message, 0);
      // Hide the locate window if visible.
      if (LocateView->isVisible()) LocateView->hide();
      SEDB->Close(); close = true;
      break;

   case (db::closed):
      break;
   }

   return close;
}




// ***********************************************************
// Creates a new database or add folders to existing database.
// ***********************************************************
void MainWindow::Create_Database()
{
   // Create and initialize the dialog.
   CreateDatabaseDlg *CreateDlg = new CreateDatabaseDlg(this, AppConf.SEISAN_TOP);
   CreateDlg->setAttribute(Qt::WA_DeleteOnClose, true);

   // Open the dialog box.
   CreateDlg->exec();
}




// *********************************************************
// Handles File|Exit and close button in upper right corner.
// *********************************************************
void MainWindow::closeEvent(QCloseEvent *event)
{
   // Close the database if it is open.
   bool Close = true;
   if (SEDB->DbStatus != db::closed) Close = Close_Database();

   // Exit the program if appropriate.
   if (Close) { CleanUpOnExit(); event->accept(); }
   if (!Close) event->ignore();
}




// **************************************************
// Let the user edit the SEISAN.DEF file.
// **************************************************
void MainWindow::Edit_SeisanDef()
{
   EditParamFile(1, 0);
}




// **************************************************
// Let the user edit the MULPLT.DEF file.
// **************************************************
void MainWindow::Edit_MulpltDef()
{
   EditParamFile(2, 0);
}




// **************************************************
// Let the user edit the STATIONx.HYP file.
// **************************************************
void MainWindow::Edit_StationHyp()
{
   char Model = '0';
   QListEventID Events;

   // Get the list of selected events.
   SEDB->SelectedEvents(&Events);

   // Get current model for selected event if possible.
   if (Events.size() == 1) {
      // Get the Model for the selected event.
      Model = SEDB->DB->EventByIndex(Events.at(0).index)->hypocenters.first->modl_id;
   }

   // Edit the file.
   EditParamFile(3, Model);
}




// ********************************************************
// Function for editing Seisan parameter files. The files
// can be located in work dir or in Seisan DAT dir. If file
// exists in work dir, then this file will be opened, else
// the file in the DAT dir will be opened.
//
// FileType: 1=SEISAN.DEF, 2=MULPLT.DEF, 3=STATIONx.HYP
// ********************************************************
void MainWindow::EditParamFile(char FileType, char Model)
{
   char model[2];
   QString ID, FilePath, WorkFile, DatFile;
   bool OK, FileInWorkDir = false, FileInDatDir = false;

   // Handle SEISAN.DEF or MULPLT.DEF file.
   FileInWorkDir = FileInDatDir = false;
   if (FileType == 1 || FileType == 2) {
      // Check if file exists in the work directory.
      if (FileType == 1) WorkFile = BuildPath(QDir::currentPath(), "SEISAN.DEF");
      if (FileType == 2) WorkFile = BuildPath(QDir::currentPath(), "MULPLT.DEF");
      FileInWorkDir = QFile::exists(WorkFile);
      // Check if file exists in the DAT directory.
      if (FileType == 1) DatFile = BuildPath(AppConf.SEISAN_TOP, "DAT", "SEISAN.DEF");
      if (FileType == 2) DatFile = BuildPath(AppConf.SEISAN_TOP, "DAT", "MULPLT.DEF");
      FileInDatDir = QFile::exists(DatFile);
   }

   // Handle the STATIONx.HYP file.
   if (FileType == 3) {
      // Set a default model for the dialog box.
       strcpy(model, "0");
       if (Model != 0 && Model != 32) model[0] = Model;
      // Open a dialog box and get model ID for file name.
      ID = QInputDialog::getText(this, "Edit a STATIONx.HYP file.",
                                 "Please enter the file's model identity (one char):",
                                 QLineEdit::Normal, QString(model), &OK);
      // Handle return values from dialog box.
      if (!OK || ID.size() != 1 || ID[0] == ' ') {
          Message = "No valid model identity was entered.";
          statusBar()->showMessage(Message, 5000);
          return;
      }
      // Search for file in work dir.
      WorkFile = BuildPath(QDir::currentPath(), QString("STATION" + ID + ".HYP"));
      FileInWorkDir = QFile::exists(WorkFile);
      // Search for file in DAT dir.
      DatFile = BuildPath(AppConf.SEISAN_TOP, "DAT", QString("STATION" + ID + ".HYP"));
      FileInDatDir = QFile::exists(DatFile);
   }

   // Exit here if file is not found.
   if (!FileInWorkDir && !FileInDatDir) {
      Message = "File was not found in work or DAT folder.";
      statusBar()->showMessage(Message, 5000);
      return;
   }

   // Choose correct file. File in work
   // dir will be selected if it exists.
   if (FileInDatDir) FilePath = DatFile;
   if (FileInWorkDir) FilePath = WorkFile;

   // Bring up the editor.
   FileEditorDlg *Editor = new FileEditorDlg(this);
   Editor->setAttribute(Qt::WA_DeleteOnClose, true);
   FilePath = QDir::toNativeSeparators(FilePath);
   if (Editor->LoadFile(FilePath)) {
      // File was sucessfylly opened. Open editor window.
      Editor->exec();
   } else {
      // File could not be opened.
      Message = "Unable to open file '" + FilePath + "'.";
      QMessageBox::critical(this, AppName, Message);
   }
}




// ***********************************************************
// Brings up the 'Apply filter to Event List view' dialog box.
// ***********************************************************
void MainWindow::SetFilter()
{
   if (SEDB->DbStatus == db::open) {
      // Apply a filter.
      SEDB->SetFilter();
   } else {
      if (SEDB->DbStatus == db::closed) {
         Message = "No database is open. Please open a database first.";
      } else {
         Message = "Cannot perform this operation while database is loading.";
      }
      QMessageBox::information(this, AppName, Message);
   }
}




// ***********************************************************
// Remove a filter from the Event List view.
// ***********************************************************
void MainWindow::RemoveFilter()
{
   // The filter will be removed if it has been set.
   if (SEDB->DbStatus == db::open) SEDB->RemoveFilter();
}




// **************************************************
// Brings up the 'Set Time Interval' dialog box.
// **************************************************
bool MainWindow::SetTimeInterval()
{
   // Save current start and stop dates.
   QDate StartDate = AppConf.TimeIntDates.StartDate;
   QDate EndDate = AppConf.TimeIntDates.EndDate;

   // Create and open the dialog.
   TimeIntervalDlg *TimeIntDlg = new TimeIntervalDlg(&AppConf);
   TimeIntDlg->setAttribute(Qt::WA_DeleteOnClose, true);
   if (TimeIntDlg->exec() == QDialog::Rejected) return false;

   // New time interval has been given.
   // Write a message in the Log View.
   Message = "Time interval set from '" + AppConf.TimeIntDates.StartDate.toString("yyyy.MM.dd");
   Message.append("' to '" + AppConf.TimeIntDates.EndDate.toString("yyyy.MM.dd") + "'.");
   LogModel.WriteLog(logmodel::info, QString(Message));

   // Update status bar text.
   SetStatusBarTimeInterval();

   // If a database is currently open and the user has changed
   // the timeinterval, then reopen the database again with new
   // time interval. User will have to confirm the action first.
   // If a filter is currently active them it will be reapplied.
   if (StartDate != AppConf.TimeIntDates.StartDate || EndDate != AppConf.TimeIntDates.EndDate) {
      // Set the new time interval for the SEDB instance.
      SEDB->SetTimeInterval(AppConf.TimeIntDates);
      // If database is open, ask user if database should be reloaded.
      if (SEDB->DbStatus == db::open) {
         Message = "Time interval has changed. Do you want to reload the database?";
         if (QMessageBox::question(nullptr, AppName, Message, QMB_YES | QMB_NO, QMB_YES) == QMB_YES) {
            // Check if a filter is applied. Tell user to re-apply the filter.
            if (SEDB->DB->isFilterApplied()) {
               Message = "You must reapply the filter manually when database has reopened.";
               QMessageBox::information(nullptr, AppName, Message, QMessageBox::Ok, QMessageBox::Ok);
            }
            // Close current datatabase. Do not ask for confirmation
            SEDB->Close(); SetWindowTitle();
            // Open last used datatabase. Do not ask for time interval.
            NoTimeIntQuery = true;
            Open_LastUsedDatabase();
            NoTimeIntQuery = false;
         }
      }
   }
   return true;
}




// ***********************************************
// Brings up the 'View|Select Columns' dialog box.
// ***********************************************
void MainWindow::SelectColumns()
{
   // Create and open the 'Select Columns' dialog.
   SelectColumnsDlg *SelectColDlg = new SelectColumnsDlg(&AppConf);
   SelectColDlg->setAttribute(Qt::WA_DeleteOnClose, true);
   if (SelectColDlg->exec() == QDialog::Accepted) {
      // User closed the dialog box by pressing the 'OK' button.
      // New checkbox states has been returned to 'AppConf.EvtListColStat'.
      // Update the event list widget.
      SEDB->SetEventListViewHeaders(AppConf);
      SEDB->AutoSizeColumns();
   }
}




// ***********************************************
// Brings up the 'File|Configure' dialog box.
// ***********************************************
void MainWindow::SetConfiguration()
{
   // Create and open the 'Configure' dialog.
   ConfigureDlg *ConfigDlg = new ConfigureDlg(&AppConf);
   ConfigDlg->setAttribute(Qt::WA_DeleteOnClose, true);
   ConfigDlg->exec();
}




// ******************************************************
// Brings up the 'Set work directory' dialog box.
// ******************************************************
void MainWindow::SetWorkDir()
{
   if (SEDB->DbStatus == db::closed) {
      // Create and open the 'Set work directory' dialog box.
      SelectWorkDirDlg *WDDialog = new SelectWorkDirDlg(&AppConf);
      WDDialog->setAttribute(Qt::WA_DeleteOnClose, true);
      if (WDDialog->exec() == QDialog::Rejected) return;

      // Set the new work directory.
      if (!WD.Set(&AppConf)) {
         // User has successfully selected a new work directory.
         // Create Google Earth KML file in new work directory.
         CreatePriKmlFile();

         // Get path to SEISAN.DEF and load settings.
         SetSeisanDef(&AppConf, &WD);
         Message = "Location of SEISAN.DEF is '" + AppConf.SEISAN_DEF + "'.";
         LogModel.WriteLog(logmodel::info, Message);
         LoadPredefComments(AppConf.SEISAN_DEF, &PredefComments);
         Message = "Loaded " + QString::number(PredefComments.size()) + " pre-defined comment(s) from SEISAN.DEF.";
         LogModel.WriteLog(logmodel::info, Message);
         LoadPredefNetworks(AppConf.SEISAN_DEF, &PredefNetworks);
         Message = "Loaded " + QString::number(PredefNetworks.size()) + " pre-defined virtual network(s) from SEISAN.DEF.";
         LogModel.WriteLog(logmodel::info, Message);
         LoadNewNordicFormat(AppConf.SEISAN_DEF);

         // Update the window title.
         SetWindowTitle();
      } else {
         // User has chosen to close SE.
         QApplication::quit();
      }
   } else {
      Message = "Please close the database first.";
      statusBar()->showMessage(Message, 3000);
   }
}




// ******************************************************
// Brings up the 'Poisson Distribution' dialog box.
// ******************************************************
void MainWindow::PoissonDistribution()
{
   // Check that database is open.
   if (SEDB->DbStatus != db::open) {
      Message = "No database is open. Please open a database first.";
      QMessageBox::information(this, AppName, Message);
      return;
   }

   // Bring up the dialog box.
   poissondlg *Dialog = new poissondlg(SEDB->DB);
   Dialog->setAttribute(Qt::WA_DeleteOnClose, true);
   Dialog->exec();
}




// ******************************************************
// Brings up the 'Gutenberg-Richter Relation' dialog box.
// ******************************************************
void MainWindow::GutenbergRichterRelation()
{
   // Check that database is open.
   if (SEDB->DbStatus != db::open) {
      Message = "No database is open. Please open a database first.";
      QMessageBox::information(this, AppName, Message);
      return;
   }

   // Bring up the dialog box.
   GutenbergRichterDlg *Dialog = new GutenbergRichterDlg(SEDB->DB);
   Dialog->setAttribute(Qt::WA_DeleteOnClose, true);
   Dialog->exec();
}




// ******************************************************
// Brings up the 'Completeness' dialog box.
// ******************************************************
void MainWindow::CompletenessCheck()
{
   // Check that database is open.
   if (SEDB->DbStatus != db::open) {
      Message = "No database is open. Please open a database first.";
      QMessageBox::information(this, AppName, Message);
      return;
   }

   // Bring up the dialog box.
   CompletenessCheckDlg *Dialog = new CompletenessCheckDlg(SEDB->DB);
   Dialog->setAttribute(Qt::WA_DeleteOnClose, true);
   Dialog->exec();
}




// ******************************************************
// Brings up the 'Export to CSV' dialog box.
// ******************************************************
void MainWindow::Export2CSV()
{
    // Check that database is open.
    if (SEDB->DbStatus != db::open) {
       Message = "No database is open. Please open a database first.";
       QMessageBox::information(this, AppName, Message);
       return;
    }

    // Bring up the dialog box.
    Export2CsvDlg *Dialog = new Export2CsvDlg(SEDB->DB);
    Dialog->setAttribute(Qt::WA_DeleteOnClose, true);
    Dialog->exec();
}




// ******************************************************
// Brings up the 'Weichert Method' dialog box.
// ******************************************************
void MainWindow::WeichertMethod()
{

   // Check that database is open.
   if (SEDB->DbStatus != db::open) {
      Message = "No database is open. Please open a database first.";
      QMessageBox::information(this, AppName, Message);
      return;
   }

   // Check that the file se-completenss.out exists.
   QFile inputFile("se-completenss.out");
   if (!inputFile.open(QIODevice::ReadOnly))    {
      Message = "<b>There is no se-completeness.out file in WOR.</b>";
      Message.append("<br>Please create the file e.g. with the function Completeness check.");
      QMessageBox::critical(this, AppName, Message);
      return;
   }

   // Bring up the dialog box.
   WeichertDlg *Dialog = new WeichertDlg(SEDB->DB);
   Dialog->setAttribute(Qt::WA_DeleteOnClose, true);
   Dialog->exec();
}




// ******************************************************
// Brings up the 'Magnitude vs Magnitude' dialog box.
// ******************************************************
void MainWindow::MagnitudeVsMagnitude()
{
   // Check that database is open.
   if (SEDB->DbStatus != db::open) {
      Message = "No database is open. Please open a database first.";
      QMessageBox::information(this, AppName, Message);
      return;
   }

   // Bring up the dialog box.
   MagVsMagDlg *Dialog = new MagVsMagDlg(SEDB->DB);
   Dialog->setAttribute(Qt::WA_DeleteOnClose, true);
   Dialog->exec();
}




// ******************************************************
// Brings up the 'Events per year' dialog box.
// ******************************************************
void MainWindow::YearlyDistribution()
{
   // Check that database is open.
   if (SEDB->DbStatus != db::open) {
      Message = "No database is open. Please open a database first.";
      QMessageBox::information(this, AppName, Message);
      return;
   }

   // Bring up the dialog box.
   EventsPerYearDlg *Dialog = new EventsPerYearDlg(SEDB->DB);
   Dialog->setAttribute(Qt::WA_DeleteOnClose, true);
   Dialog->exec();
}




// ******************************************************
// Brings up the 'Time of day distribution' dialog box.
// ******************************************************
void MainWindow::TimeOfDayDistribution()
{
   // Check that database is open.
   if (SEDB->DbStatus != db::open) {
      Message = "No database is open. Please open a database first.";
      QMessageBox::information(this, AppName, Message);
      return;
   }

   // Bring up the dialog box.
   TimeOfDayDistrDlg *Dialog = new TimeOfDayDistrDlg(SEDB->DB);
   Dialog->setAttribute(Qt::WA_DeleteOnClose, true);
   Dialog->exec();
}




// ******************************************************
// Brings up the 'Drift of hypocenters' dialog box.
// ******************************************************
void MainWindow::SpatialDistribution()
{
   // Check that database is open.
   if (SEDB->DbStatus != db::open) {
      Message = "No database is open. Please open a database first.";
      QMessageBox::information(this, AppName, Message);
      return;
   }

   // Bring up the dialog box.
   DriftOfHypocentersDlg *Dialog = new DriftOfHypocentersDlg(SEDB->DB);
   Dialog->setAttribute(Qt::WA_DeleteOnClose, true);
   Dialog->exec();
}




// ***************************************************
// Brings up the 'Time of day vs distance' dialog box.
// ***************************************************
void MainWindow::TimeOfDayVsDistance()
{
   // Check that database is open.
   if (SEDB->DbStatus != db::open) {
      Message = "No database is open. Please open a database first.";
      QMessageBox::information(this, AppName, Message);
      return;
   }

   // Bring up the dialog box.
   TodVsDistDlg *Dialog = new TodVsDistDlg(SEDB->DB);
   Dialog->setAttribute(Qt::WA_DeleteOnClose, true);
   Dialog->exec();
}




// *******************************************************
// Brings up the 'Time of day vs time of year' dialog box.
// *******************************************************
void MainWindow::TimeOfDayVsTimeOfYear()
{
   // Check that database is open.
   if (SEDB->DbStatus != db::open) {
      Message = "No database is open. Please open a database first.";
      QMessageBox::information(this, AppName, Message);
      return;
   }

   // Bring up the dialog box.
   TodVsToyDlg *Dialog = new TodVsToyDlg(SEDB->DB);
   Dialog->setAttribute(Qt::WA_DeleteOnClose, true);
   Dialog->exec();
}




// ********************************************************
// Brings up the 'Gumbel III Distribution Plot' dialog box.
// ********************************************************
void MainWindow::Gumbel3DistributionPlot()
{
   // Check that database is open.
   if (SEDB->DbStatus != db::open) {
      Message = "No database is open. Please open a database first.";
      QMessageBox::information(this, AppName, Message);
      return;
   }

   // Bring up the dialog box.
   Gumbel3DistDlg *Dialog = new Gumbel3DistDlg(SEDB->DB);
   Dialog->setAttribute(Qt::WA_DeleteOnClose, true);
   Dialog->exec();
}




// *************************************
// Brings up the 'Help|About' dialog box.
// *************************************
void MainWindow::AboutSeisanExplorer()
{
   aboutdlg *Dialog = new aboutdlg(this, __DATE__, AppVersion);
   Dialog->setAttribute(Qt::WA_DeleteOnClose, true);
   Dialog->exec();
}




// ********************************************************************
// Brings up the Log View popup meny. This function is signaled
// from LogView widget when user right-clicks inside the vidget view.
// ********************************************************************
void MainWindow::CCMR_LogView(const QPoint &pos)
{
   Q_UNUSED(pos)

   QString FileName;
   QAction *menuItem;

   // Get the list of selected lines. Only one line can be selected.
   QModelIndexList ModelIndexes = ui->LogView->selectionModel()->selectedRows();

   // Create and show the popup menu if
   // the log view holds any information.
   if (LogModel.GetNumberOfLines()) {
      // Create a popup menu.
      QMenu *popupMenu = new QMenu(this);

      // Add 'Edit this event file' item to menu if needed.
      if (!ModelIndexes.isEmpty()) {
         FileName = LogModel.GetMsgFilename(ModelIndexes.at(0).row());
         if (FileName != "none") {
            menuItem = new QAction(tr("Edit this event file"), this);
            popupMenu->addAction(menuItem);
            QObject::connect(menuItem, SIGNAL(triggered(bool)), this, SLOT(LV_Edit_Event()));
            popupMenu->addSeparator();
         }
      }

      // Add 'Clear log view' item to menu.
      menuItem = new QAction(tr("Clear the Log View"), this);
      popupMenu->addAction(menuItem);
      QObject::connect(menuItem, SIGNAL(triggered(bool)), &LogModel, SLOT(ClearLog()));

      // Add seperator to menu.
      popupMenu->addSeparator();

      // Add 'Write to log file' item to menu.
      menuItem = new QAction(tr("Save Log View to log file"), this);
      popupMenu->addAction(menuItem);
      QObject::connect(menuItem, SIGNAL(triggered(bool)), &LogModel, SLOT(WriteLog2File()));

      // Add 'View or edit log file' item to menu.
      menuItem = new QAction(tr("View or edit log file"), this);
      popupMenu->addAction(menuItem);
      QObject::connect(menuItem, SIGNAL(triggered(bool)), this, SLOT(LV_Edit_LogFile()));

      // Add 'Clear log file' item to menu.
      menuItem = new QAction(tr("Clear log file"), this);
      popupMenu->addAction(menuItem);
      QObject::connect(menuItem, SIGNAL(triggered(bool)), &LogModel, SLOT(ClearLogFile()));

      // Add seperator to menu.
      popupMenu->addSeparator();

      // Add 'Always save log when SE closes' item to menu.
      menuItem = new QAction(tr("Always save log when SE closes"), this);
      menuItem->setCheckable(true);
      if (AppConf.AutoSaveLog) menuItem->setChecked(true);
      popupMenu->addAction(menuItem);
      QObject::connect(menuItem, SIGNAL(triggered(bool)), this, SLOT(LV_AutoSaveLog()));

      // Show popup menu at mouse position.
      popupMenu->show();
      popupMenu->move(QCursor::pos());
   }
}




// ********************************************************************
// This function handles the 'Edit event file' menu item.
// This function is signaled from the Log View popup menmu.
// ********************************************************************
void MainWindow::LV_Edit_Event()
{
   // Get the list of selected lines. Only one line can be selected.
   QModelIndexList ModelIndexes = ui->LogView->selectionModel()->selectedRows();

   // Get filename for this log line.
   QString FileName = LogModel.GetMsgFilename(ModelIndexes.at(0).row());

   // Open editor with this file.
   FileEditorDlg *Editor = new FileEditorDlg(this);
   Editor->setAttribute(Qt::WA_DeleteOnClose, true);
   if (Editor->LoadFile(FileName)) {
      // File was sucessfylly opened.
      Editor->show(); Editor->activateWindow();
   } else {
      // File could not be opened.
      Message = "<b>Unable to open file '";
      Message.append(FileName); Message.append("'.</b>");
      QMessageBox::critical(this, AppName, Message);
      delete Editor;
   }
}




// ********************************************************************
// This function handles the 'View or edit log file' menu item.
// This function is signaled from the Log View popup menmu.
// ********************************************************************
void MainWindow::LV_Edit_LogFile()
{
   // Open editor with this file.
   FileEditorDlg *Editor = new FileEditorDlg(this);
   Editor->setAttribute(Qt::WA_DeleteOnClose, true);
   if (Editor->LoadFile(QString("se.log"))) {
      // File was sucessfylly opened.
      Editor->show(); Editor->activateWindow();
   } else {
      // File could not be opened.
      delete Editor;
      QMessageBox::critical(this, AppName, "<b>Unable to open file 'se.log'.</b>");
   }
}




// *********************************************************************
// This function handles the 'Always save log when SE closes' menu item.
// This function is signaled from the Log View popup menmu.
// *********************************************************************
void MainWindow::LV_AutoSaveLog()
{
   // Turn on/off the Autosave log feature.
   AppConf.AutoSaveLog = !AppConf.AutoSaveLog;
}




// ********************************************************************
// This function updates the operator label in the status bar.
// This function is signaled from class 'OperatorId'.
// ********************************************************************
void MainWindow::SetStatusBarOperator()
{
   // Create operator string.
   QString Id = Operator.GetCurrentId();
   Message = "OPERATOR: ";
   if (Id.size()) {
      Message.append(Id);
   } else {
      Message.append("Unknown");
   }
   // Update operator label.
   LblOperator.setText(Message);
}




// ********************************************************************
// This function updates the interval label in the status bar.
// ********************************************************************
void MainWindow::SetStatusBarTimeInterval()
{
   // Create operator string.
   Message = "TIME INTERVAL: ";
   Message.append(AppConf.TimeIntDates.StartDate.toString("yyyy.MM.dd"));
   Message.append(" - ");
   Message.append(AppConf.TimeIntDates.EndDate.toString("yyyy.MM.dd  "));

   // Update operator label.
   LblInterval.setText(Message);
}




// ********************************************************************
// This function is used to set focus for the tab widget's children.
// when user switches tab. Function is signaled from the tab widget.
// ********************************************************************
void MainWindow::CurrentTabChanged(int index)
{
   // Set focus to a view in the new tab.
   if (index == 0) {
      ui->LogView->setFocus(Qt::OtherFocusReason);
      ui->LogView->setVerticalScrollBarPolicy(Qt::ScrollBarAsNeeded);
      ui->LogView->setHorizontalScrollBarPolicy(Qt::ScrollBarAsNeeded);
   }
   if (index > 0) {
      if (SEDB) SEDB->SetKeyboardFocus();
   }
}




// *********************************************************
// Loads program settings from registry or file into .
// *********************************************************
void MainWindow::LoadProgramSettings()
{
   QSettings settings;

   // Load settings for the event list.
   settings.beginGroup("EventList");
   AppConf.EvtListColStat[0] = settings.value("ShowRowNumbers", true).toBool();
   AppConf.EvtListColStat[1] = settings.value("ShowAction", true).toBool();
   AppConf.EvtListColStat[2] = settings.value("ShowModel", true).toBool();
   AppConf.EvtListColStat[3] = settings.value("ShowAgency", true).toBool();
   AppConf.EvtListColStat[4] = settings.value("ShowRMS", true).toBool();
   AppConf.EvtListColStat[5] = settings.value("ShowGap", true).toBool();
   AppConf.EvtListColStat[6] = settings.value("ShowErrLat", true).toBool();
   AppConf.EvtListColStat[7] = settings.value("ShowErrLon", true).toBool();
   AppConf.EvtListColStat[8] = settings.value("ShowErrDep", true).toBool();
   AppConf.EvtListColStat[9] = settings.value("ShowDist", true).toBool();
   AppConf.EvtListColStat[10] = settings.value("ShowType", true).toBool();
   AppConf.EvtListColStat[11] = settings.value("ShowMInt", true).toBool();
   AppConf.EvtListColStat[12] = settings.value("ShowNrSta", true).toBool();
   AppConf.EvtListColStat[13] = settings.value("ShowM", true).toBool();
   AppConf.EvtListColStat[14] = settings.value("ShowMW", true).toBool();
   AppConf.EvtListColStat[15] = settings.value("ShowML", true).toBool();
   AppConf.EvtListColStat[16] = settings.value("ShowMN", true).toBool();
   AppConf.EvtListColStat[17] = settings.value("ShowMC", false).toBool();
   AppConf.EvtListColStat[18] = settings.value("ShowMb", false).toBool();
   AppConf.EvtListColStat[19] = settings.value("Show_MB", false).toBool();
   AppConf.EvtListColStat[20] = settings.value("ShowMs", false).toBool();
   AppConf.EvtListColStat[21] = settings.value("Show_MS", false).toBool();
   AppConf.EvtListColStat[22] = settings.value("ShowLocality", false).toBool();
   AppConf.EvtListColStat[23] = settings.value("ShowSfile", false).toBool();
   settings.endGroup();

   // Load general configuration settings.
   settings.beginGroup("Configuration");
   AppConf.TimeInterval = settings.value("TimeInterval", 31).toInt();
   AppConf.UsePrevTimeInterval = settings.value("UsePrevTimeInterval", false).toBool();
   AppConf.AutoLoad = settings.value("AutoLoad", false).toBool();
   AppConf.AutoSaveLog = settings.value("AutoSaveLog", false).toBool();
   AppConf.LastUsedDatabaseType = static_cast<db_type>(settings.value("LastDbType", no_database).toInt());
   AppConf.LastUsedDatabaseName = settings.value("LastDbName").toString();
   AppConf.LastUsedDatabasePath = settings.value("LastDbPath").toString();
   AppConf.TimeIntDates.StartDate = settings.value("StartDate").toDate();
   AppConf.TimeIntDates.EndDate = settings.value("EndDate").toDate();
   AppConf.WorkDirType = settings.value("WorkDirType", 0).toInt();
   AppConf.UserWorkDir = settings.value("AlternativeWorkDir").toString();
   AppConf.StaticMapApiKey = settings.value("GoogleStaticMapApiKey").toString();
   AppConf.DefaultMapType = settings.value("GoogleDefaultMapType", "roadmap").toString();
   AppConf.DefaultZoomLevel = settings.value("GoogleDefaultZoomLevel", "Auto").toString();
   Operator.SetUnconfirmedId(settings.value("OperatorId").toString());
   settings.endGroup();

   // Restore the geometry of the mainwindow.
   settings.beginGroup("Geometry");
   restoreGeometry(settings.value("Mainwindow", QByteArray()).toByteArray());
   settings.endGroup();
}




// *******************************************
// Saves program settings to registry or file.
// *******************************************
void MainWindow::SaveProgramSettings()
{
   QSettings settings;

   // Save settings for the event list.
   settings.beginGroup("EventList");
   settings.setValue(QString("ShowRowNumbers"), AppConf.EvtListColStat[0]);
   settings.setValue(QString("ShowAction"), AppConf.EvtListColStat[1]);
   settings.setValue(QString("ShowModel"), AppConf.EvtListColStat[2]);
   settings.setValue(QString("ShowAgency"), AppConf.EvtListColStat[3]);
   settings.setValue(QString("ShowRMS"), AppConf.EvtListColStat[4]);
   settings.setValue(QString("ShowGap"), AppConf.EvtListColStat[5]);
   settings.setValue(QString("ShowErrLat"), AppConf.EvtListColStat[6]);
   settings.setValue(QString("ShowErrLon"), AppConf.EvtListColStat[7]);
   settings.setValue(QString("ShowErrDep"), AppConf.EvtListColStat[8]);
   settings.setValue(QString("ShowDist"), AppConf.EvtListColStat[9]);
   settings.setValue(QString("ShowType"), AppConf.EvtListColStat[10]);
   settings.setValue(QString("ShowMInt"), AppConf.EvtListColStat[11]);
   settings.setValue(QString("ShowNrSta"), AppConf.EvtListColStat[12]);
   settings.setValue(QString("ShowM"), AppConf.EvtListColStat[13]);
   settings.setValue(QString("ShowMW"), AppConf.EvtListColStat[14]);
   settings.setValue(QString("ShowML"), AppConf.EvtListColStat[15]);
   settings.setValue(QString("ShowMN"), AppConf.EvtListColStat[16]);
   settings.setValue(QString("ShowMC"), AppConf.EvtListColStat[17]);
   settings.setValue(QString("ShowMb"), AppConf.EvtListColStat[18]);
   settings.setValue(QString("Show_MB"), AppConf.EvtListColStat[19]);
   settings.setValue(QString("ShowMs"), AppConf.EvtListColStat[20]);
   settings.setValue(QString("Show_MS"), AppConf.EvtListColStat[21]);
   settings.setValue(QString("ShowLocality"), AppConf.EvtListColStat[22]);
   settings.setValue(QString("ShowSfile"), AppConf.EvtListColStat[23]);
   settings.endGroup();

   // Save general configuration settings.
   settings.beginGroup("Configuration");
   settings.setValue(QString("TimeInterval"), AppConf.TimeInterval);
   settings.setValue(QString("UsePrevTimeInterval"), AppConf.UsePrevTimeInterval);
   settings.setValue(QString("AutoLoad"), AppConf.AutoLoad);
   settings.setValue(QString("AutoSaveLog"), AppConf.AutoSaveLog);
   settings.setValue(QString("LastDbType"), AppConf.LastUsedDatabaseType);
   settings.setValue(QString("LastDbName"), AppConf.LastUsedDatabaseName);
   settings.setValue(QString("LastDbPath"), AppConf.LastUsedDatabasePath);
   settings.setValue(QString("StartDate"), QVariant(AppConf.TimeIntDates.StartDate));
   settings.setValue(QString("EndDate"), QVariant(AppConf.TimeIntDates.EndDate));
   settings.setValue(QString("WorkDirType"), AppConf.WorkDirType);
   settings.setValue(QString("AlternativeWorkDir"), AppConf.UserWorkDir);
   settings.setValue(QString("OperatorId"), Operator.GetCurrentId());
   settings.setValue(QString("GoogleDefaultMapType"), AppConf.DefaultMapType);
   settings.setValue(QString("GoogleDefaultZoomLevel"), AppConf.DefaultZoomLevel);
   settings.endGroup();

   // Save the geometry of the mainwindow.
   settings.beginGroup("Geometry");
   settings.setValue(QString("Mainwindow"), saveGeometry());
   settings.endGroup();
}




// *******************************************
// Sets the title of the main window.
// *******************************************
void MainWindow::SetWindowTitle()
{
   QString Title, WorkDir;

   // Create application name and version.
   Title = AppName + " " + AppVersion;

   // Create working directory text.
   WorkDir = " [" + WD.Get() + "]";

   // If no database exist, set application
   // name/version and current work directory.
   if (!SEDB) { Title.append(WorkDir); this->setWindowTitle(Title); return; }

   // If database is closed, set application
   // name/version and current work directory.
   if (SEDB->DbStatus != db::open) { Title.append(WorkDir); this->setWindowTitle(Title); return; }

   // A database is open.
   Title.append(" [");
   if (SEDB->DbInfo.Type == default_database) Title.append(AppConf.DEF_BASE + " (default) ");
   if (SEDB->DbInfo.Type == normal_database_by_name) Title.append(DbInfo.Name + " (" + DbInfo.Path + ") ");
   if (SEDB->DbInfo.Type == normal_database_by_path) Title.append(DbInfo.Name + " (" + DbInfo.Path + ") ");
   if (SEDB->DbInfo.Type == local_database)  Title.append(DbInfo.Path + " (Local Database) ");
   if (SEDB->DbInfo.Type == index_file) Title.append(DbInfo.Name + " (Index File) ");
   Title.append(QString::number(SEDB->DB->NumEvents()) + " events]");

   // Add current working directory.
   Title.append(" " + WorkDir);

   // Set window title.
   this->setWindowTitle(Title);
}




// ***************************************************
// Automatically set column widths in event list view.
// ***************************************************
void MainWindow::ResizeColumns()
{
   SEDB->AutoSizeColumns();
}




// ******************************************************
// This function is called just before application exits.
// ******************************************************
void MainWindow::CleanUpOnExit()
{
   // Delete the Locator dialog.
   delete LocateView;

   // Delete the database instance.
   delete SEDB;

   // Save the log file if requested.
   if (AppConf.AutoSaveLog) LogModel.WriteLog2File();

   // Remove the work directory lock file.
   WD.DeleteLockFile();
}




// ******************************************************
// Switch to the log view tab.
// ******************************************************
void MainWindow::ShowLogView()
{
   ActivateTab(ui->LogViewTab);
}




// ********************************************************************
// This function handles the 'Locate event' menu item.
// This function is signaled from the SEDB class.
// ********************************************************************
void MainWindow::Locate_Event()
{
   // Show the locator window if it is hidden.
   if (LocateView->isHidden()) LocateView->show();
   // Activate the window.
   LocateView->activateWindow(); LocateView->raise();
   // Send locate button signal to locator window.
   // This simulates pressing the 'Locate' button.
   LocateView->LocateButton();
}


