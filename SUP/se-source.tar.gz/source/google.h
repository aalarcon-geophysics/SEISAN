#ifndef GOOGLE_H
#define GOOGLE_H

#include <QFile>
#include <QString>
#include <QTextStream>
#include "types.h"

void CreatePriKmlFile();
void WriteKmlHeader(QFile*);
void WriteKml(event_node_*, QFile*, QString, QString, bool, float, float, float);
void WriteKmlTail(QFile*);

#endif // GOOGLE_H
