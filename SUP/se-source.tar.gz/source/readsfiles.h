#ifndef READSFILES_H
#define READSFILES_H

#include <QMutex>
#include <QThread>
#include <QString>
#include <QStringList>
#include <types.h>
#include <stdlib.h>
#include "logmodel.h"
#include "eventnode.h"

class readsfiles : public QThread
{
   Q_OBJECT

signals:
   // Signals to the database class.
   void AddDbEvent(event_node_*);
   void FileProblem(QString, QStringList, int);
   void ReadSfilesDone(char);

   // Signal to the database class.
   void WriteLog(logmodel::msg_type, QString, QString);

public:
   void run();
   void Cancel();
   void Init(QStringList*, QMutex*);

private:
   QStringList *sfilelist;
   QString Message;
   QMutex mtx_terminate;
   QMutex *mtx_common_block;
   bool terminate, terminated;
};

#endif // READSFILES_H
