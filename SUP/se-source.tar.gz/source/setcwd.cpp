#include <QDir>
#include <QFile>
#include <QMessageBox>
#include "setcwd.h"
#include "selectworkdirdlg.h"


// ************************************
// Constructor function.
// ************************************
SetCWD::SetCWD()
{
   // Initialize the class.
   LockFileCreated = false;
}




// ***************************************************************
// Returns the current work directory.
// ***************************************************************
QString SetCWD::Get()
{
   return (WorkDir);
}




// *******************************************************
// Check the directory currently selected in the 'Config'
// structure. Return any problems found. Return values are:
// 0 = No problems found.
// 1 = The directory do not exist.
// 2 = Cannot change to the directory.
// 3 = A lock-file exists in the directory.
// *******************************************************
int SetCWD::TryConfigDir(se_config* Config)
{
   // Check if directory exist.
   if (!QFile::exists(GetFromConfig(Config))) return 1;

   // Save the current working directory.
   QString CurrentDir = QDir::currentPath();

   // Try to set the directory as current directory.
   if (!QDir::setCurrent(GetFromConfig(Config))) return 2;

   // Skip checking for lock file if directory
   // is equal to current working directory.
   if (CurrentDir == QDir::currentPath()) return 0;

   // Check for presense of lock file.
   if (QFile::exists(WORKDIR_LOCK_FILE)) {
      QDir::setCurrent(CurrentDir);
      return 3;
   }

   // Restore current working directory.
   QDir::setCurrent(CurrentDir);

   return 0;
}



// *******************************************************
// Check the directory given in the 'Path' argument.
// Return any problems found. Return values are:
// 0 = No problems found.
// 1 = The directory do not exist.
// 2 = Cannot change to the directory.
// 3 = A lock-file exists in the directory.
// *******************************************************
int SetCWD::TryByPath(QString Path)
{
   // Check if directory exist.
   if (!QFile::exists(Path)) return 1;

   // Save the current working directory.
   QString CurrentDir = QDir::currentPath();

   // Set the directory as current directory.
   if (!QDir::setCurrent(Path)) return 2;

   // Skip checking for lock file if 'Path'
   // is equal to current working directory.
   if (CurrentDir == QDir::currentPath()) return 0;

   // Check for presense of lock file.
   if (QFile::exists(WORKDIR_LOCK_FILE)) {
      QDir::setCurrent(CurrentDir);
      return 3;
   }

   // Restore current working directory.
   QDir::setCurrent(CurrentDir);

   return 0;
}




// **************************************************************************
// Set the work directory given in the 'Config' structure. Will present user
// with a dialog if a problem is found. Returns a status value.
// Return values are:
// 0 = New work directory has been set.
// 1 = User requests program termination (user pressed the 'Exit' button).
// **************************************************************************
int SetCWD::Set(se_config* Config)
{
   QPushButton *selectButton, *exitButton;
   QPushButton *removeButton, *clickedButton;

   // Check for problems with the selected work directory.
   int Status = TryConfigDir(Config);

   // If problems are found, bring up a dialog box.
   while (Status) {
      selectButton = exitButton = removeButton = 0;
      QMessageBox *msgBox = new QMessageBox;
      msgBox->setIcon(QMessageBox::Warning);
      msgBox->setTextFormat(Qt::RichText);
      msgBox->setWindowTitle("Problem with work directory.");
      Message = "Current work directory is '" + GetFromConfig(Config) + "'.<br>";
      if (Status == 1) {
         // The directory do not exist.
         selectButton = msgBox->addButton(" Select another directory ", QMessageBox::ActionRole);
         exitButton = msgBox->addButton(" Exit from SE ", QMessageBox::ActionRole);
         Message.append("Directory do not exist.");
         msgBox->setText(Message);
      }
      if (Status == 2) {
         // Cannot change to the directory.
         selectButton = msgBox->addButton(" Select another directory ", QMessageBox::ActionRole);
         exitButton = msgBox->addButton(" Exit from SE ", QMessageBox::ActionRole);
         Message.append("Cannot change to work directory.");
         msgBox->setText(Message);
      }
      if (Status == 3) {
         // A lock-file exists in the directory.
         selectButton = msgBox->addButton(" Select another directory ", QMessageBox::ActionRole);
         removeButton = msgBox->addButton(" Remove lock file ", QMessageBox::ActionRole);
         exitButton = msgBox->addButton(" Exit from SE ", QMessageBox::ActionRole);
         Message.append("A lock file ("); Message.append(WORKDIR_LOCK_FILE);
         Message.append(") exists in work directory.<br>");
         Message.append("Directory may already be in use by another running instance of SE.");
         msgBox->setText(Message);
      }
      // Show the dialog box.
      msgBox->exec();

      // Get the clicked button.
      clickedButton = (QPushButton *) msgBox->clickedButton();

      // User wants to select a new directory.
      if (clickedButton == selectButton) {
         // A new directory will be set in the 'Config' structure.
         SelectWorkDirDlg *WDDialog = new SelectWorkDirDlg(Config, msgBox);
         WDDialog->setAttribute(Qt::WA_DeleteOnClose, true);
         WDDialog->exec();
      }

      // Destroy the message box.
      delete msgBox;

      // User wants to remove a lock file.
      if (clickedButton == removeButton) DeleteOldLockFile(Config);

      // User wants to exit from SE.
      if (clickedButton == exitButton) return 1;

      // Recheck the work directory.
      Status = TryConfigDir(Config);
   }

   // Delete lock-file from current work
   // directory if one has been created.
   if (LockFileCreated) DeleteLockFile();

   // Set the new work directory.
   QDir::setCurrent(GetFromConfig(Config));
   WorkDir = QDir::toNativeSeparators(QDir::currentPath());

   // Create lock file in new work directory.
   CreateLockFile();

   // Write message to log.
   Message = "Current work directory is '";
   Message.append(QDir::toNativeSeparators(QDir::currentPath()) + "'. ");
   emit WriteLog(logmodel::info, Message);

   return 0;
}




// ***************************************************************
// A simpler version of 'Set'. Does not prompt user. Set program's
// current directory based on info in 'Config'.
// This function returns a status value as follows:
// 0 = No problems found.
// 1 = The directory do not exist.
// 2 = Cannot change to the directory.
// 3 = A lock-file exists in the directory.
// ***************************************************************
int SetCWD::SetEx(se_config *Config)
{
   // Check the selected work directory.
   // Return if a problem has been found.
   int Status = TryConfigDir(Config);
   if (Status) return Status;

   // Delete lock-file from current work
   // directory if one has been created.
   if (LockFileCreated) DeleteLockFile();

   // Set the new work directory.
   QDir::setCurrent(GetFromConfig(Config));
   WorkDir = QDir::toNativeSeparators(QDir::currentPath());

   // Create lock file in new work directory.
   CreateLockFile();

   // Write message to log.
   Message = "Current work directory is '";
   Message.append(QDir::toNativeSeparators(QDir::currentPath()) + "'. ");
   emit WriteLog(logmodel::info, Message);

   return 0;
}



// ***************************************************************
// A simpler version of 'Set'. Does not prompt user.
// Set current directory based on the path in 'Path'.
// This function returns a status value as follows:
// 0 = No problems found.
// 1 = The directory do not exist.
// 2 = Cannot change to the directory.
// 3 = A lock-file exists in the directory.
// ***************************************************************
int SetCWD::SetByPath(QString Path)
{
   // Check the selected work directory.
   // Return if a problem has been found.
   int Status = TryByPath(Path);
   if (Status) return Status;

   // Delete lock-file from current work
   // directory if one has been created.
   if (LockFileCreated) DeleteLockFile();

   // Set the new work directory.
   QDir::setCurrent(Path);
   WorkDir = QDir::toNativeSeparators(QDir::currentPath());

   // Create lock file in new work directory.
   CreateLockFile();

   // Write message to log.
   Message = "Current work directory is '";
   Message.append(QDir::toNativeSeparators(QDir::currentPath()) + "'. ");
   emit WriteLog(logmodel::info, Message);

   return 0;
}




// ***************************************************************
// Returns the selected work directory in the 'Config' structure.
// ***************************************************************
QString SetCWD::GetFromConfig(se_config *Config)
{
   QString WorkDir;

   // Return the work directory.
   if (Config->WorkDirType == 0) WorkDir = Config->SeisanWorkDir;
   if (Config->WorkDirType == 1) WorkDir = Config->AppLaunchDir;
   if (Config->WorkDirType == 2) WorkDir = Config->UserWorkDir;
   WorkDir = QDir::toNativeSeparators(QDir::cleanPath(WorkDir));

   return (WorkDir);
}




// ************************************************
// Create a lock file in current working directory.
// ************************************************
void SetCWD::CreateLockFile()
{
   // Create file.
   QFile lFile(WORKDIR_LOCK_FILE);
   lFile.open(QIODevice::ReadWrite);
   lFile.close();

   // Flag that a lock file has been created.
   LockFileCreated = true;

   // Save full path to lock file.
   QFileInfo info(lFile);
   LockFile = info.absoluteFilePath();
}




// ************************************************
// Delete the current lock file.
// ************************************************
void SetCWD::DeleteLockFile()
{
   if (LockFileCreated) {
      if (QFile::exists(LockFile)) {
         QFile::remove(LockFile);
         LockFileCreated = false;
      }
   }
}




// ************************************************
// Delete a lock file that was not created by this
// program instance. Work directory is in 'Config'.
// ************************************************
void SetCWD::DeleteOldLockFile(se_config *Config)
{
   QString lFile = GetFromConfig(Config);
   lFile.append("/"); lFile.append(WORKDIR_LOCK_FILE);
   lFile = QDir::toNativeSeparators(lFile);
   QFile::remove(lFile);
}
