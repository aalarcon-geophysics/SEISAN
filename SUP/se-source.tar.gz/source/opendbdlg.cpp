#include "opendbdlg.h"
#include "library.h"
#include "ui_opendbdlg.h"
#include <QDirIterator>
#include <QFileDialog>
#include <QMessageBox>

// ******************************************
// Constructor function.
// ******************************************
OpenDbDlg::OpenDbDlg(QWidget *parent) : QDialog(parent), ui(new Ui::OpenDbDlg)
{
   // Set up the user interface.
   ui->setupUi(this);
}


// ******************************************
// Destructor function.
// ******************************************
OpenDbDlg::~OpenDbDlg()
{
    delete ui;
}



// ******************************************
// Function for initialisation of the dialog.
// ******************************************
void OpenDbDlg::InitDialog(se_config AppConf, QString *Db, int *DbType)
{
   QString ReaDir, DbDir;
   QStringList DbList;

   // Save paramter values.
   this->SeisanTop = AppConf.SEISAN_TOP;
   this->Database = Db;
   this->DbType = DbType;

   // Get a list of REA databases. We will look for
   // directories with five characters in the name.
   ReaDir = SeisanTop + "/REA";
   ReaDir = QDir::toNativeSeparators(ReaDir);
   QDirIterator it(ReaDir, QDir::Dirs | QDir::NoDotAndDotDot);
   while (it.hasNext()) {
      DbDir = GetNameFromFilePath(it.next());
      if (DbDir.size() == 5) DbList.append(DbDir);
   }

   // Populate the list widget.
   if (DbList.size()) {
      // Sort the list.
      DbList.sort(Qt::CaseInsensitive);
      // Insert all database names into the list.
      for (int index=0; index<DbList.size(); index++) {
         QString Line = DbList.at(index);
         ui->DbList->insertItem(index, Line);
      }

      // Select the first line.
      ui->DbList->setCurrentRow(0);
      // User should only be allowed to select one line.
      ui->DbList->setSelectionMode(QAbstractItemView::SingleSelection);
      // Give input focus to the list widget.
      ui->DbList->setFocus();
    }
}




// *****************************************************
// User has pressed the 'Select' button.
// *****************************************************
void OpenDbDlg::Select()
{
   // Bring up folder selection dialog box. User
   // must select a folder with year/month subfolders.
   QString Message = "Please select a folder containing a Seisan database:";
   QString Folder = QFileDialog::getExistingDirectory(this, Message, SeisanTop, QFileDialog::ShowDirsOnly);
   Folder = QDir::toNativeSeparators(Folder);

   // Write the folder path to the 'OtherFolder' widget.
   ui->OtherFolder->setText(Folder);

   // Set keyboard focus to the 'Save' button.
   ui->buttonBox->setFocus();
}



// ************************************
// User has pressed the 'Open' button.
// ************************************
void OpenDbDlg::accept()
{
   // Return the selected database.
   QString Folder = ui->OtherFolder->text();
   if (Folder.size()) {
      // Check that path is no longer then 40 characters.
      if (Folder.size() > 40) {
         Message = "The given database path cannot exceed 40 characters.";
         QMessageBox::critical(this, "", Message);
         ui->OtherFolder->setFocus();
         ui->OtherFolder->selectAll();
         return;
      }
      // Return the folder path if it exists.
      if (!QFile::exists(Folder)) {
         Message = "The given database folder do not exist!";
         QMessageBox::critical(this, "", Message);
         ui->OtherFolder->setFocus();
         ui->OtherFolder->selectAll();
         return;
      }
      // Return the database folder.
      *DbType = 1;
      *Database = Folder;
   } else {
      // Return the base name from DbList.
      *DbType = 0;
      *Database = ui->DbList->currentItem()->text();
   }

   // Close the dialog and return 'Accepted' signal.
   QDialog::done(QDialog::Accepted);
}




// **************************************
// User has pressed the 'Cancel' button.
// **************************************
void OpenDbDlg::reject()
{
   // Close the dialog and return 'Rejected' signal.
   QDialog::done(QDialog::Rejected);
}
