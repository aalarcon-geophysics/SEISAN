#include <cmath>
#include <stdio.h>
#include <stdlib.h>
#include <QDir>
#include <QChar>
#include <QFile>
#include <QDate>
#include <QDebug>
#include <QString>
#include <QIODevice>
#include <QByteArray>
#include <QMainWindow>
#include <QMessageBox>
#include <QStringList>
#include <QNetworkRequest>
#include <QNetworkAccessManager>
#include "fortran.h"
#include "library.h"
#include "database.h"
#include "mainwindow.h"


// *******************************************
// Check if 'FileName' is a valid S-file name.
// *******************************************
bool IsSfileNameOk(QString FileName)
{
   // Check length of filename.
   if (FileName.size() != 19) return false;

   // Check all numbers in the name.
   if (!FileName.at(0).isDigit()) return false;
   if (!FileName.at(1).isDigit()) return false;
   if (!FileName.at(3).isDigit()) return false;
   if (!FileName.at(4).isDigit()) return false;
   if (!FileName.at(5).isDigit()) return false;
   if (!FileName.at(6).isDigit()) return false;
   if (!FileName.at(8).isDigit()) return false;
   if (!FileName.at(9).isDigit()) return false;
   if (!FileName.at(13).isDigit()) return false;
   if (!FileName.at(14).isDigit()) return false;
   if (!FileName.at(15).isDigit()) return false;
   if (!FileName.at(16).isDigit()) return false;
   if (!FileName.at(17).isDigit()) return false;
   if (!FileName.at(18).isDigit()) return false;

   // Check all fixed characters in the name.
   if (FileName.at(2) != '-') return false;
   if (FileName.at(7) != '-') return false;
   if (FileName.at(11)!= '.') return false;
   if (FileName.at(12)!= 'S') return false;

   // Check the distance id in the name.
   if (FileName.at(10) == 'L') return true;
   if (FileName.at(10) == 'R') return true;
   if (FileName.at(10) == 'D') return true;

   return false;
}




// *********************************************************
// Check if 'FileName' is a valid name for a wave form file.
// *********************************************************
bool IsWaveformFileNameOk(QString FileName)
{
   // Check length of filename.
   if (FileName.size() != 29) return false;

   // Check all number-characters in the name.
   if (!FileName.at(0).isDigit()) return false;
   if (!FileName.at(1).isDigit()) return false;
   if (!FileName.at(2).isDigit()) return false;
   if (!FileName.at(3).isDigit()) return false;
   if (!FileName.at(5).isDigit()) return false;
   if (!FileName.at(6).isDigit()) return false;
   if (!FileName.at(8).isDigit()) return false;
   if (!FileName.at(9).isDigit()) return false;
   if (!FileName.at(11).isDigit()) return false;
   if (!FileName.at(12).isDigit()) return false;
   if (!FileName.at(13).isDigit()) return false;
   if (!FileName.at(14).isDigit()) return false;
   if (!FileName.at(16).isDigit()) return false;
   if (!FileName.at(17).isDigit()) return false;

   // Check all fixed characters in the name.
   if (FileName.at(4) != '-') return false;
   if (FileName.at(7) != '-') return false;
   if (FileName.at(10)!= '-') return false;
   if (FileName.at(18)!= 'S') return false;

   return true;
}





// *************************************************************
// This functions checks for problems with an operator identity.
// *************************************************************
bool IsOperatorIdentityOK(QString Id)
{
   // Check identity.
   if (Id.isEmpty()) return false;
   if (Id.size() > 4) return false;
   if (Id.contains(QRegExp("\\W"))) return false;

   // Identity is OK.
   return true;
}




// *********************************************************
// This function converts a char string to a fortran string
// by filling free space in a string with spaces. The string
// terminator (\0) is also overwritten with a space.
// *********************************************************
void PadString(char *string, int strsize)
{
   for (int i=static_cast<int>(strlen(string));i<=strsize-1;i++) string[i]=32;
}




// *********************************************************
// This function extends the length of the string up to
// 'strsize' by adding a number of spaces to the string.
// *********************************************************
void PadQString(QString *string, int strsize)
{
   while (string->size() < strsize) string->append(" ");
}




// ********************************************************
// This functions converts a fortran string to a C++ string
// by adding a \0 terminator after the last used character
// in the string
// ********************************************************
void UnPadString(char *string, int strsize)
{
   // Start at end of string and find first
   // character that is not a space. Replace
   // the last space with a NULL terminator.
   bool done = false;
   int index = strsize-1;

   while (!done) {
      if (string[index] != 32 && string[index] != 0) {
         if (index == strsize-1) {
            string[index] = 0;
         } else {
            string[index+1] = 0;
         }
         done = true;
      }
      // Check if we have processed the whole string and string is empty.
      if (!done && !index) { string[index] = 0; done = true; }
      index --;
   }
}




// *********************************************************
// This function removes all spaces at the end of a QString.
// *********************************************************
void UnPadQString(QString *string)
{
   int StrLength;
   while (true) {
      StrLength = string->size();
      if (!StrLength) return;
      if (string->at(StrLength-1) == QChar(32)) {
         string->remove(StrLength-1, 1);
      } else {
         return;
      }
   }
}




// **********************************************************
// Deletes a charater from a string.
// Delets the character pointed to by the zero based index
// pointer 'strptr'. Characters to the right of the deleted
// character are shifted left.
// **********************************************************
void StrDelete(char *string, int strptr)
{
   int i, strlngth;

   // Get the length of the string.
   strlngth=static_cast<int>(strlen(string));

   // Return if string is empty.
   if (!strlngth) return;

   // Return if strptr is larger then length of string.
   if (strptr>=strlngth) return;

   // Delete character pointed to by strptr.
   for (i=strptr;i<=strlngth-1;i++) string[i]=string[i+1];

   return;
}




// ************************************************
// Removes all spaces in the start of a string.
// ************************************************
void StrRmvTrailingSpaces(char *string)
{
   while (string[0] == 32) StrDelete(string, 0);
}



// ************************************************
// Removes all double, trple etc spaces from string
// leaving only a single space.
// ************************************************
void TrimSpaces(QString *String)
{
   while (String->contains("  ")) *String = String->replace("  ", " ");
}




// ************************************************
// Returns true is string only has spaces.
// ************************************************
bool IsQStrAllSpace(QString String)
{
   // Get the length of the string.
   int Length = String.size();

   // Return true if string is empty.
   if (!Length) return true;

   // Search for characters other than space in string.
   for (int Index=0;Index<Length;Index++) {
      if(String.at(Index) != QChar(32)) return false;
   }

   // Only space characters was found.
   return true;
}




// ************************************************
// Returns true is string only has spaces.
// ************************************************
bool IsQStrInteger(QString String, int *Value)
{
   bool OK;

   // Return true if string is empty.
   if (!String.size()) return false;

   // Check if string contains an integer.
   *Value = String.toInt(&OK);

   return OK;
}




// *************************************************
// This functions copies a QString to a char array.
// *************************************************
void qstr2char(char* dest, QString source)
{
   strcpy(dest, source.toLocal8Bit().data());
}




// ********************************************************
// This function copies a source string into a dest string,
// and then converts the dest string to a fortran string.
// ********************************************************
void char2fstr(char *dest, char *source, int dest_size)
{
   // Get the length of the source string.
   int length = static_cast<int>(strlen(source));

   // Return empty dest string if source string is empty.
   if (!length) { dest[0] = 0; return; }

   // Return empty dest string if source string is longer then dest_size.
   if (length > dest_size) { dest[0] = 0; return; }

   // Create and return the destination string.
   memset(static_cast<void*>(dest), 32, static_cast<size_t>(dest_size));
   strncpy(dest, source, static_cast<size_t>(length));
}




// *****************************************************
// This function copies a source QString into a char[]
// destination string string that will be padded with
// spaces for use with a Fortran function.
// *****************************************************
void qstr2fstr(char *dest, QString source, int dest_size)
{
   // Get the length of the source string.
   int length = source.size();

   // Return empty dest string if source string is empty.
   if (!length) { dest[0] = 0; return; }

   // Return empty dest string if source string is longer then dest_size.
   if (length > dest_size) { dest[0] = 0; return; }

   // Create and return the destination string.
   memset(static_cast<void*>(dest), 32, static_cast<size_t>(dest_size));
   strncpy(dest, source.toLocal8Bit().data(), static_cast<size_t>(length));
}




// *********************************************************
// This function copies a fortran string to a char string.
// *********************************************************
void fstr2char(char* dest, char* source, int source_size)
{
   memcpy(dest, source, static_cast<size_t>(source_size));
   UnPadString(dest, source_size + 1);
}




// *********************************************************
// This function copies a fortran string to a QString.
// *********************************************************
void fstr2qstr(QString* dest, char* source, int source_size)
{
   char str1[source_size+1];
   memcpy(str1, source, static_cast<size_t>(source_size));
   UnPadString(str1, source_size+1);
   *dest = QString(str1);
}




// ***********************************************
// The function will create a multilevel path.
// Returns 'true' if path already exists. Returns
// 'false' if path cannot be created.
// ***********************************************
bool CreatePath(QString Path)
{
    return QDir().mkpath(Path);
}




// ************************************************************************************************
// The function builds a new path by adding folders and/or files to an existing path.
// The new path is cleaned up and slashes are corrected match the current operating system.
// ************************************************************************************************
QString BuildPath(QString Path, QString Item1, QString Item2, QString Item3)
{
   return QDir::toNativeSeparators(QDir::cleanPath(Path + "/" +Item1 + "/" + Item2 + "/" + Item3));
}




// ***********************************************************
// This function deletes all files and folders in a directory.
// ***********************************************************
bool CleanDir(QString Directory)
{
   // Create a QDir instance for the directory.
   QDir dir(Directory);

   // Exit here if directory do not exist.
   if (!dir.exists()) return false;

   // Scan and clean the directory.
   bool Status = true;
   Q_FOREACH(QFileInfo fileInfo,
             dir.entryInfoList(QDir::NoDotAndDotDot | QDir::System | QDir::Hidden
                               | QDir::AllDirs | QDir::Files, QDir::DirsFirst))
   {
      if (fileInfo.isDir()) {
         // Delete the contents of the directory.
         if (!CleanDir(fileInfo.absoluteFilePath())) return false;
         // Delete the directory itself.
         if (!dir.rmdir(fileInfo.absoluteFilePath())) return false;
      } else {
         // Delete a file.
         if (!QFile::remove(fileInfo.absoluteFilePath())) return false;
      }
      if (!Status) return false;
   }

   return true;
}




// ********************************************************
// This function takes a valid path and removes the last
// directory from the path. Function does nothing if path
// is already at root level.
// ********************************************************
void PathCdUp(QString *Path)
{
   // Return if path is empty.
   if (!Path->size()) return;

   // Make sure the path is clean.
   *Path = QDir::cleanPath(*Path);

   // Return if path is already at root.
   if (Path->size() == 1 && Path->at(0) == QChar(47)) return;
   if (Path->size() == 1 && Path->at(0) == QChar(92)) return;
   if (Path->size() == 3 && Path->contains(":\\")) return;

   // Remove any slash at end of path.
   if (Path->endsWith(QChar(47))) Path->remove(Path->size()-1, 1);
   if (Path->endsWith(QChar(92))) Path->remove(Path->size()-1, 1);

   // Find the last slash in path.
   bool found = false; int index;
   while (!found) {
      index = Path->size() - 1;
      if (Path->at(index) == QChar(47) || Path->at(index) == QChar(92)) found = true;
      Path->remove(index, 1);
   }

   // If path is empty then add a slash.
   if (Path->size() == 0) Path->append(47);
   if (Path->size() == 2 && Path->at(1) == QChar(':')) Path->append(47);
}




// ********************************************************
// This function creates a time string suitable for
// use with the event list view. Invalid time/date values
// are replaced with question marks in the string.
// ********************************************************
void CreateElvTimeStr(db_time *time, QString *TimeStr)
{
   char str10[10];

   // Clear string.
   TimeStr->clear();

   // Add year to string.
   sprintf(str10, "%04u-", time->year);
   if (time->year <= 0) strcpy(str10, "\?\?\?\?-");
   TimeStr->append(str10);

   // Add month to string.
   sprintf(str10, "%02u-", time->month);
   if (time->month <= 0) strcpy(str10, "\?\?-");
   TimeStr->append(str10);

   // Add day to string.
   sprintf(str10, "%02u ", time->day);
   if (time->day <= 0) strcpy(str10, "\?\? ");
   TimeStr->append(str10);

   // Add hour to string.
   sprintf(str10, "%02u:", time->hour);
   if (time->hour < 0) strcpy(str10, "\?\?:");
   TimeStr->append(str10);

   // Add minute to string.
   sprintf(str10, "%02u:", time->minute);
   if (time->minute < 0) strcpy(str10, "\?\?:");
   TimeStr->append(str10);

   // Add second to string.
   sprintf(str10, "%05.2f", time->second);
   if (time->second < 0.0) strcpy(str10, "\?\?\?\?\?");
   TimeStr->append(str10);
}




// ********************************************************
// This function creates a time/date string according to
// ISO 8601 standard. Invalid time/date values
// are replaced with question marks in the string.
// ********************************************************
void CreateISO8601TimeStr(db_time *time, QString *string)
{
   char str10[10];

   // Clear string.
   string->clear();

   // Add year to string.
   sprintf(str10, "%04u-", time->year);
   if (time->year <= 0) strcpy(str10, "\?\?\?\?-");
   string->append(str10);

   // Add month to string.
   sprintf(str10, "%02u-", time->month);
   if (time->month <= 0) strcpy(str10, "\?\?-");
   string->append(str10);

   // Add day to string.
   sprintf(str10, "%02uT", time->day);
   if (time->day <= 0) strcpy(str10, "\?\?T");
   string->append(str10);

   // Add hour to string.
   sprintf(str10, "%02u:", time->hour);
   if (time->hour < 0) strcpy(str10, "\?\?:");
   string->append(str10);

   // Add minute to string.
   sprintf(str10, "%02u:", time->minute);
   if (time->minute < 0) strcpy(str10, "\?\?:");
   string->append(str10);

   // Add second to string.
   sprintf(str10, "%05.2fZ", time->second);
   if (time->second < 0.0) strcpy(str10, "\?\?\?\?\?Z");
   string->append(str10);
}




// ********************************************************
// This function creates a date string from a db_time
// structure. Invalid date values are replaced with
// question marks in the string.
// ********************************************************
void CreateDateStr(db_time time, QString *string)
{
   char str10[10];

   // Clear string.
   string->clear();

   // Add year to string.
   sprintf(str10, "%04u-", time.year);
   if (time.year <= 0) strcpy(str10, "\?\?\?\?-");
   string->append(str10);

   // Add month to string.
   sprintf(str10, "%02u-", time.month);
   if (time.month <= 0) strcpy(str10, "\?\?-");
   string->append(str10);

   // Add day to string.
   sprintf(str10, "%02u", time.day);
   if (time.day <= 0) strcpy(str10, "\?\?");
   string->append(str10);
}




// ********************************************************
// This function creates a time string from a db_time
// structure. Invalid time values are replaced with
// question marks in the string.
// ********************************************************
void CreateTimeStr(db_time time, QString *string)
{
   char str10[10];

   // Clear string.
   string->clear();

   // Add hour to string.
   sprintf(str10, "%02u:", time.hour);
   if (time.hour < 0) strcpy(str10, "\?\?:");
   string->append(str10);

   // Add minute to string.
   sprintf(str10, "%02u:", time.minute);
   if (time.minute < 0) strcpy(str10, "\?\?:");
   string->append(str10);

   // Add second to string.
   sprintf(str10, "%04.1f", time.second);
   if (time.second < 0.0) strcpy(str10, "\?\?\?\?\?");
   string->append(str10);
}




// ************************************
// Get a file's modification date/time.
// ************************************
void GetFileModTime(QString FileName, QDateTime *ModTime)
{
    QFileInfo File(FileName);
    *ModTime = File.lastModified();
}




// ****************************************
// Extracts the file name from a full path.
// ****************************************
QString GetNameFromFilePath(QString Path)
{
   QFileInfo file(Path);
   return file.fileName();
}




// ****************************************************
// Reads an s-file and returns the ID from the ID-line.
// Returns empty string if S-file could not be read.
// ****************************************************
QString GetSfileID(char File[])
{
   // Read S-file into a node.
   char Status;
   event_node_ *Node = ReadSfile(File, &Status);

   // Return here if ReadSfile fails.
   if (!Node) return QString();

   // Get the ID from the ID-line.
   QString ID = QString(Node->id_line).mid(60, 14);

   // Delete the allocated node.
   delete Node;

   // Return the ID.
   return ID;
}




// *****************************************************************
// This function is used clear information in the common blocks.
// NB: Only varables used by SE is cleared.
// *****************************************************************
void ClearCommonBlocks()
{
   // Initialize single int/float single values.
   rea4_.rea_nwav = 0;
   rea4_.rea_nmag = 0;
   rea4_.rea_nhyp = 0;
   rea4_.rea_nstat = 0;
   rea4_.rea_nspec = 0;
   rea4_.rea_nhead = 0;
   rea4_.rea_nmacro = 0;
   rea4_.rea_nfault = 0;
   rea4_.rea_nphase = 0;
   rea4_.rea_nrecord = 0;
   rea4_.rea_ncomment = 0;
   rea4_.rea_av_moment = -999.0;
   rea4_.rea_av_sdrop = -999.0;
   rea4_.rea_av_omega0 = -999.0;
   rea4_.rea_av_cornerf = -999.0;
   rea4_.rea_av_radius = -999.0;
   rea4_.rea_av_swin = -999.0;
   rea4_.rea_av_mw = -999.0;
   rea4_.rea_av_slope = -999.0;
   rea4_.rea_read_err = 0;
   rea4_.rea_write_err = 0;
   rea_new_format_.rea_sd_moment = -999.0;
   rea_new_format_.rea_sd_sdrop = -999.0;
   rea_new_format_.rea_sd_omega0 = -999.0;
   rea_new_format_.rea_sd_cornerf = -999.0;
   rea_new_format_.rea_sd_radius = -999.0;
   rea_new_format_.rea_sd_swin = -999.0;
   rea_new_format_.rea_sd_mw = -999.0;
   rea_new_format_.rea_sd_slope = -999.0;
   rea_new_format_.rea_id_line_number = 0;

   // Fill character variables with zeros.
   memset(rea1_.rea_onset, 0, MAX_DATA/2);
   memset(rea1_.rea_polarity, 0, MAX_DATA/2);
   memset(rea1_.rea_weight_in, 0, MAX_DATA/2);
   memset(rea2_.rea_co, 0, MAX_DATA/2*2);
   memset(rea2_.rea_weight_out, 0, MAX_DATA/2*2);
   memset(rea2_.rea_location, 0, MAX_DATA/2*2);
   memset(rea2_.rea_network, 0, MAX_DATA/2*2);
   memset(rea3_.rea_com, 0, MAX_DATA/2*3);
   memset(rea3_.rea_action, 0, 3);
   memset(rea4_.rea_locality, 0, 68);
   memset(rea4_.rea_id_line, 0, 80);
   memset(rea4_.rea_macro, 0, 100*80);
   memset(rea4_.rea_macro, 0, 100*80);
   memset(rea4_.rea_wav, 0, 100*80);
   memset(rea4_.rea_fault, 0, 100*80);
   memset(rea4_.rea_comment, 0, 100*80);
   memset(rea4_.rea_comment, 0, 100*80);
   memset(rea4_.rea_comp, 0, MAX_DATA/2*4);
   memset(rea4_.rea_auto, 0, MAX_DATA/2*20);
   memset(rea5_.rea_stat, 0, MAX_DATA/2*5);
   memset(rea5_.rea_agency, 0, MAX_DATA/2*5);
   memset(rea5_.rea_operator, 0, MAX_DATA/2*5);
   memset(rea8_.rea_phase, 0, MAX_DATA/2*8);
   memset(rea_new_format_.rea_spec_phase, 0, MAX_DATA/2);
   memset(hyp1_.hyp_mag_type_all, 0, 200);
   memset(hyp1_.hyp_model, 0, 100);
   memset(hyp1_.hyp_dist_id, 0, 100);
   memset(hyp1_.hyp_type, 0, 100);
   memset(hyp1_.hyp_fix_org, 0, 100);
   memset(hyp1_.hyp_depth_flag, 0, 100);
   memset(hyp1_.hyp_epi_flag, 0, 100);
   memset(hyp1_.hyp_mag_type, 0, 100*6);
   memset(hyp4_.hyp_auto, 0, 100*20);
   memset(hyp5_.hyp_mag_agency_all, 0, 200*5);
   memset(hyp5_.hyp_agency, 0, 100*5);
   memset(hyp5_.hyp_mag_agency, 0, 100*6*5);

   // Initialize int/float arrays.
   for (int index=0;index<MAX_DATA/2;index++) {
      rea4_.rea_year[index] = -999;
      rea4_.rea_month[index] = -999;
      rea4_.rea_day[index] = -999;
      rea4_.rea_hour[index] = -999;
      rea4_.rea_min[index] = -999;
      rea4_.rea_sec[index] = -999.0;
      rea4_.rea_coda[index] = -999.0;
      rea4_.rea_amp[index] = -999.0;
      rea4_.rea_per[index] = -999.0;
      rea4_.rea_baz_obs[index] = -999.0;
      rea4_.rea_baz_cal[index] = -999.0;
      rea4_.rea_vel[index] = -999.0;
      rea4_.rea_ain[index] = -999.0;
      rea4_.rea_baz_res[index] = -999.0;
      rea4_.rea_dist[index] = -999.0;
      rea4_.rea_az[index] = -999.0;
      rea4_.rea_res[index] = -999.0;
      rea4_.rea_moment[index] = -999.0;
      rea4_.rea_sdrop[index] = -999.0;
      rea4_.rea_omega0[index] = -999.0;
      rea4_.rea_cornerf[index] = -999.0;
      rea4_.rea_radius[index] = -999.0;
      rea4_.rea_swin[index] = -999.0;
      rea4_.rea_vs[index] = -999.0;
      rea4_.rea_vp[index] = -999.0;
      rea4_.rea_q_below_1hz[index] = -999.0;
      rea4_.rea_q0[index] = -999.0;
      rea4_.rea_qalpha[index] = -999.0;
      rea4_.rea_q_below_1hz[index] = -999.0;
      rea4_.rea_kappa[index] = -999.0;
      rea4_.rea_density[index] = -999.0;
      rea4_.rea_slope[index] = -999.0;
      rea4_.rea_mc[index] = -999.0;
      rea4_.rea_ml[index] = -999.0;
      rea4_.rea_mb[index] = -999.0;
      rea4_.rea_ms[index] = -999.0;
      rea4_.rea_mw[index] = -999.0;
      rea4_.rea_geo_dist[index] = -999.0;
      rea4_.rea_mag[index] = -999.0;
      rea8_.rea_abs_time[index] = -999.0;
      rea_new_format_.rea_spec_mw[index] = 0;
   }
   for (int index=0;index<100;index++) {
      hyp1_.hyp_high_accuracy[index] = 0;
      hyp1_.hyp_error[index] = 0;
      hyp4_.hyp_year[index] = -999;
      hyp4_.hyp_month[index] = -999;
      hyp4_.hyp_day[index] = -999;
      hyp4_.hyp_hour[index] = -999;
      hyp4_.hyp_min[index] = -999;
      hyp4_.hyp_nstat[index] = -999;
      hyp4_.hyp_sec[index] = -999.0;
      hyp4_.hyp_lat[index] = -999.0;
      hyp4_.hyp_lon[index] = -999.0;
      hyp4_.hyp_depth[index] = -999.0;
      hyp4_.hyp_rms[index] = -999.0;
      hyp4_.hyp_gap[index] = -999.0;
      hyp4_.hyp_sec_err[index] = -999.0;
      hyp4_.hyp_lat_err[index] = -999.0;
      hyp4_.hyp_lon_err[index] = -999.0;
      hyp4_.hyp_depth_err[index] = -999.0;
      hyp4_.hyp_cov[index][0] = -9.9e10;
      hyp4_.hyp_cov[index][1] = -9.9e10;
      hyp4_.hyp_cov[index][2] = -9.9e10;
      hyp4_.hyp_mag[index][0] = -999.0;
      hyp4_.hyp_mag[index][1] = -999.0;
      hyp4_.hyp_mag[index][2] = -999.0;
      hyp4_.hyp_mag[index][3] = -999.0;
      hyp4_.hyp_mag[index][4] = -999.0;
      hyp4_.hyp_mag[index][5] = -999.0;
   }
   for (int index=0;index<200;index++) {
      hyp4_.hyp_mag_all[index] = -999.0;
   }
}




// *****************************************************************
// This function splits a cat file into many S-files in a directory.
// No spesial checking is done on the contents of the catalog file.
// Function returns the number of S-files in the catalog (*numFound).
// Function also returns the number of S-files written (*numWritten).
// ******************************************************************
void ConvertCatFileToLocalDb(QString CatFile, QString DestFolder, int *numFound, int *numWritten)
{
   QChar distInd;
   bool IlineFound;
   QFile inFile, outFile;
   QString line, fileName;
   QStringList fileContent, sfile;

   // Initialization.
   *numFound = *numWritten = 0;

   // Set name of catalog file.
   inFile.setFileName(CatFile);

   // Open file and read everything into 'fileContent'.
   inFile.open(QIODevice::ReadOnly | QIODevice::Text);
   while(!inFile.atEnd()) fileContent.append(inFile.readLine());
   inFile.close();

   // Return here if file is empty.
   if (!fileContent.size()) return;

   // Convert to S-files.
   while (fileContent.size()) {
      // Get and remove one line from 'fileContent'.
      line = fileContent.takeFirst();
      // Remove endline character from line.
      line.remove(line.size()-1, 1);
      // Add line to 'sfile'.
      sfile.append(line);
      // Look for the end of an S-file. If line contains only
      // spaces then we have found the last line of an S-file.
      if (IsQStrAllSpace(line)) {
         // Update number of S-files in the catalog file.
         (*numFound)++;
         // Find the distance indicator.
         distInd = sfile.at(0).at(21);
         // Locate line type 'I' in sfile. Use information
         // from the 'I' line to create the S-file name.
         IlineFound = false;
         for (int line=0;line<sfile.size();line++) {
            if (sfile.at(line).size() >= 80) {
               if (sfile.at(line).at(79) == 'I') IlineFound = true;
               if (IlineFound) {
                  // Create the name of the S-file.
                  fileName = sfile.at(line).mid(66, 2) + "-";
                  fileName.append(sfile.at(line).mid(68, 4) + "-");
                  fileName.append(sfile.at(line).mid(72, 2) + distInd + ".S");
                  fileName.append(sfile.at(line).midRef(60, 6));
                  line = sfile.size();
               }
            }
         }
         // Check that line type 'I' was found.
         if (IlineFound) {
            // Write the S-file to disk.
            outFile.setFileName(DestFolder + "\\" + fileName);
            outFile.open(QIODevice::WriteOnly | QIODevice::Text);
            QTextStream out(&outFile);
            while (sfile.size()) out << sfile.takeFirst() << endl;
            outFile.close();
            // Update number of S-files written.
            (*numWritten)++;
         }
         // Clear the contents of 'sfile'.
         sfile.clear();
      }
   }
}




// *****************************************************************
// This function merges a number of S-files into a new file.
// The new file is placed in the current working directory.
// ******************************************************************
bool MergeFiles(QStringList FileList, QString OutFile)
{
   int NumFiles;
   QByteArray text;
   QFile infile, outfile;

   // Get number of files in file list Return if list is empty.
   if (!(NumFiles = FileList.size())) return false;

   // Open out file. Existing file will be overwritten. Abort if 'open' failes.
   outfile.setFileName(OutFile);
   if (!outfile.open(QIODevice::WriteOnly | QIODevice::Truncate | QIODevice::Text)) return false;

   // Copy all files in file list to out file.
   bool error = false;
   for (int index=0;index<NumFiles;index++) {
      infile.setFileName(FileList.at(index));
      if (infile.open(QIODevice::ReadOnly | QIODevice::Text)) {
         text = infile.readAll(); infile.close();
         if (outfile.write(text) == -1) error = true;
      } else {
         // The file either do not exist, or
         // it cannot be openened for reading.
         error = true;
      }
   }

   // Close the out file.
   outfile.close();

   // Return true if fuction succeded, or false otherwise.
   return !error;
}




// *****************************************************************
// This function checks if a line is empty. An empty line
// is here defined as a being a line with only spaces.
// ******************************************************************
bool IsDataLineEmpty(char Line[], qint64 LineLength)
{
   for (int i=0;i<LineLength-1;i++) if (Line[i]!=32) return false;
   return true;
}



// *****************************************************************
// This function checks if a file is in the path.
// ******************************************************************
bool IsFileInPath(QString file)
{
   QStringList PathList;
   QString Path, PathToFile;

   // Get the current path.
   Path = getenv("PATH");
   if (!Path.size()) return false;

   // Create a list of directories.
#ifdef Q_OS_WIN32
   QChar SplitChar = ';';
#endif
#ifdef Q_OS_LINUX
   QChar SplitChar = ':';
#endif
#ifdef Q_OS_OSX
   QChar SplitChar = ':';
#endif
   PathList = Path.split(SplitChar, QString::SkipEmptyParts);

   // Enumerate directories to search for file.
   for (int i=0;i<PathList.size();i++) {
      PathToFile = BuildPath(PathList.at(i), file);
      if (QFile::exists(PathToFile)) return true;
   }

   return false;
}





// ***************************************************************
// Calculates a Julian Day number.
// ***************************************************************
ulong JulianDay(db_time *Time)
{
   long a,b,c,e,f;
   ushort Year, Month;

   Year=Time->year;
   Month=Time->month;
   if (Month<=2) { Year=Year-1; Month=Month+12; }
   a=Year/100; b=a/4; c=2-a+b;
   e=(long)(double)(365.25*(Year+4716));
   f=(long)(double)(30.6001*(Month+1));
   return (c+Time->day+e+f-1525);
}




// *************************************************************
// Compares two time structures. The return value for this
// function indicates the relation between Time1 and Time2:
// -1 = Time1 is earlier (older) than Time2
//  0 = Time1 is identical to Time2
//  1 = Time1 is later than Time2
// *************************************************************
char TimeCmp(db_time *Time1, db_time *Time2)
{
   if (Time1->year<Time2->year) return -1;
   if (Time1->year>Time2->year) return 1;
   if (Time1->month<Time2->month) return -1;
   if (Time1->month>Time2->month) return 1;
   if (Time1->day<Time2->day) return -1;
   if (Time1->day>Time2->day) return 1;
   if (Time1->hour<Time2->hour) return -1;
   if (Time1->hour>Time2->hour) return 1;
   if (Time1->minute<Time2->minute) return -1;
   if (Time1->minute>Time2->minute) return 1;
   if (Time1->second<Time2->second) return -1;
   if (Time1->second>Time2->second) return 1;

   return 0;
}




// ****************************************************
// Calculates the timedifference in seconds between
// two time structures and return the absolute result.
// ****************************************************
double TimeDiff(db_time *Time1, db_time *Time2)
{
   double Diff, DaySeconds1, DaySeconds2;
   char CmpResult;
   long WholeDayDiff;

   // Compare the two times.
   CmpResult=TimeCmp(Time1, Time2);

   // Check if the times are equal.
   if (!CmpResult) return 0.0;

   // Calculate number of whole days elased between the two times.
   WholeDayDiff = (long)(JulianDay(Time1)-JulianDay(Time2));

   // Calculate number of seconds elapsed since the start of the day.
   DaySeconds1=Time1->hour*3600+Time1->minute*60+Time1->second;
   DaySeconds2=Time2->hour*3600+Time2->minute*60+Time2->second;

   // Calculate the total time-difference in seconds.
   Diff=fabs(WholeDayDiff*86400.0);
   if (CmpResult==-1 && DaySeconds1< DaySeconds2) Diff=Diff+DaySeconds2-DaySeconds1;
   if (CmpResult==-1 && DaySeconds1>=DaySeconds2) Diff=Diff+DaySeconds2-DaySeconds1;
   if (CmpResult== 1 && DaySeconds1< DaySeconds2) Diff=Diff+DaySeconds1-DaySeconds2;
   if (CmpResult== 1 && DaySeconds1>=DaySeconds2) Diff=Diff+DaySeconds1-DaySeconds2;

   return Diff;
}




// *********************************************************
// Read a line from a text file. Line number is needed.
// Returns a status value:
// 0=OK, 1=file not found, 2=open failed, 3=line not found.
// *********************************************************
int ReadFileLine(QString FileName, int LineNr, QString *Line)
{
   QFile file;
   QString line;

   // Check that the file exists.
   if (!QFile::exists(FileName)) return 1;

   // Open file.
   file.setFileName(FileName);
   if (!file.open(QIODevice::ReadOnly|QIODevice::Text)) return 2;

   // File was opened successfully. Read lines until
   // the correct line are found or we reach end of file.
   int linecount = 0;
   QTextStream ts(&file);
   while (!ts.atEnd()) {
      linecount++;
      line = ts.readLine();
      if (linecount == LineNr) {
         line.replace(QChar(0), QChar(32));
         *Line = line;
         file.close();
         return 0;
      }
   }

   // The line was not found.
   file.close();
   return 3;
}




// *********************************************************
// Read a text file into a QStringList.
// Returns a status value:
// 0=OK, 1=file not found, 2=open failed.
// *********************************************************
int ReadTextFile(QString FileName, QStringList *Lines)
{
   // Check that the file exists.
   if (!QFile::exists(FileName)) return 1;

   // Open file.
   QFile file(FileName);
   if (!file.open(QFile::ReadOnly|QFile::Text)) return 2;

   // File was opened successfully. Read all lines.
   QTextStream in(&file);
   while (!in.atEnd()) Lines->append(in.readLine());

   // Close file.
   file.close();
   return 0;
}





// *****************************************************
// Writes a number of lines to a text file.
// Returns false if something goes wrong.
// *****************************************************
bool WriteTextFile(QString FileName, QStringList Lines)
{
   // Open file.
   QFile file(FileName);
   if (!file.open(QFile::WriteOnly|QFile::Text)) return false;

   // Write to file.
   QTextStream out(&file);
   for (int i=0;i<Lines.size();i++) out << Lines.at(i) << "\n";

   // Close file.
   file.close();
   return true;
}




// *****************************************************
// Converts degrees to radians.
// *****************************************************
double Deg2Rad(double deg)
{
   return (deg * PI / 180);
}




// *****************************************************
// Converts radians to degrees.
// *****************************************************
double Rad2Deg(double rad)
{
   return (rad * 180 / PI);
}




// ********************************************************************
// Calculates the distance between two points in kilometres,
// given two coordinates. Uses the Haversine formula.
// ********************************************************************
double EarthDistance(double lat1, double lon1, double lat2, double lon2)
{
   double lat1r = Deg2Rad(lat1); double lon1r = Deg2Rad(lon1);
   double lat2r = Deg2Rad(lat2); double lon2r = Deg2Rad(lon2);
   double u = sin((lat2r - lat1r)/2); double v = sin((lon2r - lon1r)/2);
   return 2.0 * EARTHRADIUSKM * asin(sqrt(u * u + cos(lat1r) * cos(lat2r) * v * v));
}




// *********************************************************************
// Creates a Seisan database structure under a given top directory. The
// top directory is the folder that contains the REA/WAV subdirectories.
// This function will create all directories as needed. Function returns
// false if any directory cannot be created.
// *********************************************************************
bool CreateSeisanDb(QString DbName, QString DbTopDir, int StartYear, int StartMonth,
                    int EndYear, int EndMonth, bool CreateREA, bool CreateWAV)
{
   bool done;
   int Year, Month;
   QStringList FolderList;
   QString DbDir, sYear, sMonth;

   // Create the REA database.
   if (CreateREA) {
      // Make a list of REA directories to be created.
      DbDir = DbTopDir + "/REA/" + DbName;
      FolderList.append(DbDir + "/LOG");
      FolderList.append(DbDir + "/CAT");
      Year = StartYear; Month = StartMonth; done = false;
      while (!done) {
         sYear = QString().number(Year);
         sMonth = QString("%1").arg(Month, 2, 10, QChar('0'));
         FolderList.append(DbDir + "/" + sYear + "/" + sMonth);
         if (Year == EndYear && Month == EndMonth) done = true;
         Month++; if (Month == 13) { Month = 1; Year++; }
      }
      // Add DELET directories under REA to the list.
      DbDir = DbTopDir + "/REA/DELET";
      FolderList.append(DbDir + "/LOG");
      FolderList.append(DbDir + "/CAT");
      Year = StartYear; Month = StartMonth; done = false;
      while (!done) {
         sYear = QString().number(Year);
         sMonth = QString("%1").arg(Month, 2, 10, QChar('0'));
         FolderList.append(DbDir + "/" + sYear + "/" + sMonth);
         if (Year == EndYear && Month == EndMonth) done = true;
         Month++; if (Month == 13) { Month = 1; Year++; }
      }
      // Create the REA/DELET directories.
      foreach (DbDir, FolderList) if (!QDir().mkpath(DbDir)) return false;
   }

   // Create the WAV database.
   if (CreateWAV) {
      // Make a list of WAV directories to be created.
      FolderList.clear();
      DbDir = DbTopDir + "/WAV/" + DbName;
      Year = StartYear; Month = StartMonth; done = false;
      while (!done) {
         sYear = QString().number(Year);
         sMonth = QString("%1").arg(Month, 2, 10, QChar('0'));
         FolderList.append(DbDir + "/" + sYear + "/" + sMonth);
         if (Year == EndYear && Month == EndMonth) done = true;
         Month++; if (Month == 13) { Month = 1; Year++; }
      }
      // Create the WAV directories.
      foreach (DbDir, FolderList) if (!QDir().mkpath(DbDir)) return false;
   }

   return true;
}




// ***********************************************************************
// This function reads predefined comments from SEISAN.DEF. All characters
// before column 41 is removed from each comment line. If line starts
// with "B " then the B will be moved to column 79.
// ***********************************************************************
bool LoadPredefComments(QString File, QStringList* Comments)
{
   QString line;

   // Clear the comment list.
   Comments->clear();

   // Read seisan.def into the comment list.
   if (ReadTextFile(File, Comments)) return false;

   // Return if no lines where read.
   if (!Comments->size()) return false;

   // Remove all lines that are not comment lines.
   // Remove all characters before column 41 from comment lines.
   for (int i=Comments->size()-1;i>=0;i--) {
      line = Comments->at(i);
      if (line.startsWith("EEV_COMMENT")) {
         // This is a comment line.
         // Delete 40 characters from start of line.
         line.remove(0, 40);
         // If line starts with "B " then move 'B' to column 77.
         if (line.startsWith("B ")) { line.remove(0, 2); line.insert(77, "B"); }
         // Replace with modified line.
         Comments->replace(i, line);
      } else {
         // Not a comment line, remove it.
         Comments->removeAt(i);
      }
   }

   return (bool)Comments->size();
}




// **************************************************************************
// This function reads a list of predefined virtual networks from SEISAN.DEF.
// **************************************************************************
bool LoadPredefNetworks(QString File, QStringList* Networks)
{
   QString Line;
   QStringList SeisanDef;

   // Clear the comment list.
   Networks->clear();

   // Read seisan.def into the comment list.
   if (ReadTextFile(File, &SeisanDef)) return false;

   // Return if no lines where read.
   if (!SeisanDef.size()) return false;

   // Enumerate all lines, and get the list of networks.
   for (int i=SeisanDef.size()-1;i>=0;i--) {
      Line = SeisanDef.at(i);
      if (Line.startsWith("SE_VIRTUAL_NETWORKS")) {
         // This line holds a comma seperated list of networks.
         // Delete 20 characters from start of line.
         Line.remove(0, 20);
         // Remove all spaces.
         Line = Line.remove(' ');
         // Get the list of networks.
         *Networks = Line.split(',', QString::SkipEmptyParts);
      }
   }

   return (bool)Networks->size();
}




// **************************************************************************
// This function reads the NORDIC_FORMAT value from SEISAN.DEF.
// **************************************************************************
bool LoadNewNordicFormat(QString File)
{
   QString Line;
   QStringList SeisanDef;

   comblck_new_nordic *new_nordic = &new_nordic_;
   comblck_rea_new_format *rea_new_format = &rea_new_format_;

   // Initialize a value in rea_new_format to zero.
   rea_new_format->rea_old_format_required = 0;

   // Set format value to zero.
   int Format = 0;
   new_nordic->new_nordic_format = 0;
   new_nordic->new_nordic_format_only = 0;

   // Read seisan.def into the list.
   if (ReadTextFile(File, &SeisanDef)) return false;

   // Return if no lines where read.
   if (!SeisanDef.size()) return false;

   // Enumerate all lines, and get the NORDIC_FORMAT line.
   for (int i=SeisanDef.size()-1;i>=0;i--) {
      Line = SeisanDef.at(i);
      if (Line.startsWith("NORDIC_FORMAT")) {
         // This line holds a float with a single value.
         // Delete 14 characters from start of line.
         Line.remove(0, 14);
         // Remove all spaces.
         Line = Line.remove(' ');
         // Get the format value.
         Format = static_cast<int>(Line.toFloat());
         // Update the common block value.
         if (Format == 1) {
            new_nordic->new_nordic_format = 1;
            new_nordic->new_nordic_format_only = 0;
         }
         if (Format == 2) {
            new_nordic->new_nordic_format = 1;
            new_nordic->new_nordic_format_only = 1;
         }
         return true;
      }
   }

   return false;
}




// *************************************************************************************
// This function processes the command line arguments for SE. User may use the command
// line to open a database from $SEISAN_TOP/REA when SE is started.
// Valid command line syntaxes:
// se ,,                                    Opens a local database from launch folder.
// se <start date>                          Opens DEFA_BASE, 30 days interval.
// se <start date> <interval>               Opens DEFA_BASE with given interval.
// se <start date> <database>               Opens given database, 30 days interval.
// se <start date> <database> <interval>    Opens given database, with given interval.
// Valid start date formats: yyyy, yyyymm, yyyymmdd
// *************************************************************************************
bool ProcessCmdLine(se_config *Config)
{
   int Interval = 30;
   QDate StartDate, EndDate;
   QString DbPath, DbName, Date;

   // Get the command line arguments.
   QStringList Args = QCoreApplication::arguments();

   // At least 2 arguments must be given.
   if (Args.size() < 2) return false;

   // Show the help screen if requested.
   if (Args.at(1) == "help") {
      QString Message = "Valid command line syntax:\n\n";
      Message.append("Open a local database from the startup folder: se ,,\n");
      Message.append("Open DEF_BASE with 31 days interval: se <start date>\n");
      Message.append("Open DEF_BASE with given interval: se <start date> <interval/number of days>\n");
      Message.append("Open database with 31 days interval: se <start date> <database>\n");
      Message.append("Open database with given interval: se <start date> <database> <interval/number of days>");
      QMessageBox::information(0, "Seisan Explorer", Message);
      return false;
   }

   // If first argument is ",," then we are opening a local database.
   if (Args.at(1) == ",,") {
      // This is a local database.
      // Time interval is not used.
      // Return database information.
      Config->LastUsedDatabaseName = Args.at(1);
      Config->LastUsedDatabaseType = local_database;
      Config->LastUsedDatabasePath = Config->AppLaunchDir;
      return true;
   }

   // We will open a normal REA database. A start date should
   // be given as first argument. Get and check the start date.
   Date = Args.at(1);
   // Check length of date string.
   if (Date.size() != 4 && Date.size() != 6 && Date.size() != 8) return false;
   // Append month and date if needed.
   while (Date.size() < 8) Date.append("01");
   // Convert the date string to a QDate object.
   StartDate = QDate::fromString(Date, "yyyyMMdd");
   // Check date. Abort if date is invalid.
   if (!StartDate.isValid()) return false;

   // Proccess the second argument if it has been given.
   // It should be a database name, or an interval value.
   // If no database is given, try to use default database.
   if (Args.size() >= 3) {
      // A second argument has been given.
      if (IsQStrInteger(Args.at(2), &Interval)) {
         // The second argument is an interval value.
         // Check interval value. Set default value if needed.
         if (Interval <= 0) Interval = 29;
         // Use default database. Abort if DEF_BASE is not set.
         if (!Config->DEF_BASE.size()) return false;
         DbName = Config->DEF_BASE;
         // Set an end date.
         EndDate = StartDate.addDays(Interval);
      } else {
         // The second argument is a database name.
         DbName = Args.at(2);
         DbName = DbName.toUpper();
         // Set an end date. Use interval value if it has been given.
         EndDate = StartDate.addDays(30);
         if (Args.size() >= 4) {
            // User has given a forth argument. This should be a valid interval value. Set new end date.
            if (IsQStrInteger(Args.at(3), &Interval)) if (Interval > 0) EndDate = StartDate.addDays(Interval);
         }
      }
   } else {
      // No second argument has been given.
      // Use default database. Abort if DEF_BASE is not set.
      if (!Config->DEF_BASE.size()) return false;
      DbName = Config->DEF_BASE;
      // Set a default  end date.
      EndDate = StartDate.addDays(30);
   }

   // Make sure database name is 5 characters long.
   while (DbName.size() < 5) DbName.append("_");

   // Build a full path to the database directory.
   DbPath = BuildPath(Config->SEISAN_TOP, "REA", DbName);

   // Abort if database folder do not exist.
   if (!QDir(DbPath).exists()) return false;

   // Set return values.
   Config->TimeIntDates.StartDate = StartDate;
   Config->TimeIntDates.EndDate = EndDate;
   Config->TimeIntDates.EndDateType = 3;
   Config->LastUsedDatabaseName = DbName;
   Config->LastUsedDatabaseType = normal_database_by_path;
   Config->LastUsedDatabasePath = DbPath;

   return true;
}




// **************************************************************************
// Returns messages from common block 'rea_mes'.
// Function returns false if there are no messages.
// **************************************************************************
bool GetReaMesMessages(QStringList *ReaMessages)
{
   char message[81];

   // Check if there are no messages.
   if (!rea_mes_.rea_n_message) return false;

   // Get messages.
   for (int index=0; index<rea_mes_.rea_n_message; index++)
   {
      fstr2char(message, rea_mes_.rea_message[index], 80);
      StrRmvTrailingSpaces(message);
      ReaMessages->append(message);
   }

   return true;
}




// **************************************************************************
// Copies a line of text to the clipboard.
// **************************************************************************
void CopyTextToClipboard(QString Text)
{
   QClipboard *CB = QGuiApplication::clipboard();

#ifdef Q_OS_WIN32
   CB->setText(Text);
#endif
#ifdef Q_OS_LINUX
   CB->setText(Text, QClipboard::Selection);
#endif
#ifdef Q_OS_OSX
   CB->setText(Text);
#endif
}




// ****************************************************
// Set the path to SEISAN.DEF in AppConf structure.
// ****************************************************
void SetSeisanDef(se_config *AppConf, SetCWD *WD)
{
   // Use the file in the work directory if it exists.
   QString workDir = WD->Get();
   workDir.append("/SEISAN.DEF");
   if (QFile::exists(workDir)) {
      AppConf->SEISAN_DEF = QDir().toNativeSeparators(workDir);
      return;
   }

   // Otherwise use the file in SEISAN_TOP/DAT folder.
   AppConf->SEISAN_DEF = QDir().toNativeSeparators(BuildPath(AppConf->SEISAN_TOP, "DAT/SEISAN.DEF"));
}
