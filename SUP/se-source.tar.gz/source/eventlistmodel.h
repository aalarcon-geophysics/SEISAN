#ifndef EVENTLISTMODEL_H
#define EVENTLISTMODEL_H

#include <QList>
#include <QBitArray>
#include <QTableView>
#include <QStringList>
#include <QAbstractTableModel>
#include <QItemSelectionModel>

#include "types.h"
#include "database.h"
#include "speedsearchdlg.h"


struct selection {
   int row;
   bool setascurrent;
   bool ensurevisible;
   bool clearselection;
};


class eventlistmodel : public QAbstractTableModel
{
   Q_OBJECT

   public:
   void Reset();
   void FetchMoreData();
   void SetView(QTableView*);
   void SelectRow(int, bool, bool, bool);
   void UnselectRow(int);
   void ClearSelection();
   void TagRow(int);
   void UntagRow();
   void GetSelection(QListEventID*);
   void ScrollRowIntoView(int, bool);
   void SelectRows(QList<int>*, bool);
   int GetNumModelEvents() const;
   int CurrentRow();
   eventlistmodel(db *database, QObject *parent = 0);
   int rowCount(const QModelIndex &parent = QModelIndex()) const;
   int columnCount(const QModelIndex &parent = QModelIndex()) const;
   QVariant data(const QModelIndex &index, int role = Qt::DisplayRole) const;
   QVariant headerData(int section, Qt::Orientation orientation, int role) const;
   QStringList mimeTypes() const;
   QMimeData* mimeData(const QModelIndexList&) const;
   Qt::ItemFlags flags(const QModelIndex&) const;
   bool dropMimeData(const QMimeData*, Qt::DropAction, int, int, const QModelIndex&);
   bool insertRows(int position, int rows, const QModelIndex &index=QModelIndex());

   signals:
   // Signals for the main window.
   void EventsDropped(QStringList);
   int RowChanged(int);

   public slots:
   void ActivateSpeedSearch(char);
   void InsertRow(int);
   void RefreshRow(int);
   void RemoveRow(int);
   void SpeedSearchReply(int);
   void ScrollToNextSelection();
   void ScrollToPrevSelection();
   void MarkUnmarkSelectedRows();
   void UnmarkAllRows();
   void ScrollToNextMarkedEvent();
   void ScrollToPrevMarkedEvent();
   void selectionChanged(const QItemSelection&, const QItemSelection&);
   void currentRowChanged(const QModelIndex&, const QModelIndex&);

   protected:
   bool canFetchMore(const QModelIndex &parent) const;
   void fetchMore(const QModelIndex &parent);

   private:
   db *DataBase;                       // Pointer to instance of database class.
   QTableView *ModelView;              // Pointer to model's Event List View.
   QItemSelectionModel *SelModel;      // Pointer to Event List View's selection model.
   QList<selection>DelayedSelections;  // List of delayed selections.
   int NumEventsInModel;               // Number of events currently in the model.
   int TaggedRow;                      // Row number of tagged row (marked with a '+' sign).
   mutable QMutex mtx_num_events;      // Used to control access to the 'NumEventsInModel' variable.
   int NumSelectedRows;                // Number of selected events.
   QBitArray SelectedRows;             // Holds selection status for all events.
   QStringList HeaderTexts;            // List of column header names.
   QStringList DroppedEvents;          // List of events that was last dropped in event list view.
   QVariant GetItemData(event_node_*, int, int) const;
   QVariant GetItemToolTip(event_node_*, int) const;
   void SetNumModelEvents(int);
};

#endif // EVENTLIST_MODEL_H
