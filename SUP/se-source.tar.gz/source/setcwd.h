#ifndef SETCWD_H
#define SETCWD_H

#include <QObject>
#include "types.h"
#include "logmodel.h"

class SetCWD : public QObject
{
   Q_OBJECT

signals:
   // Signals for the log view.
   void WriteLog(logmodel::msg_type, QString);

public:
   SetCWD();
   QString Get();
   int Set(se_config*);
   int SetEx(se_config*);
   int SetByPath(QString);
   void DeleteLockFile();

private:
   QString Message;
   QString WorkDir;
   QString LockFile;
   bool LockFileCreated;
   QString GetFromConfig(se_config*);
   int TryByPath(QString);
   int TryConfigDir(se_config*);
   void CreateLockFile();
   void DeleteOldLockFile(se_config*);
};

#endif // SETCWD_H
