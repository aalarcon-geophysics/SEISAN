#include "numberedtxtlistdlg.h"
#include "ui_numberedtxtlistdlg.h"


// *****************************************
// Contructor function the class/dialog box.
// *****************************************
NumberedTxtListDlg::NumberedTxtListDlg(QWidget *parent) : QDialog(parent), ui(new Ui::NumberedTxtListDlg)
{
    // Set up the user interface.
    ui->setupUi(this);
}


// *****************************************
// Destructor function the class/dialog box.
// *****************************************
NumberedTxtListDlg::~NumberedTxtListDlg()
{
    delete ui;
}




// *****************************************
// Initializes the class/dialog box.
// *****************************************
void NumberedTxtListDlg::Init(QString WindowTitle, QStringList TextList, QString CheckBoxTitle, QString *Selection, bool *CheckStatus)
{
   // Save variables.
   this->Selection = Selection;
   this->CheckStatus = CheckStatus;
   ReturnValue = false;

   // Set the window title.
   this->setWindowTitle(WindowTitle);

   // Set up the list widget.
   if (TextList.size()) {
      // Insert all text lines into the list. A line
      // number will be added to the front of each line.
      for (int index=0; index<TextList.size(); index++) {
         QString Line = TextList.at(index);
         Line.insert(0, " - ");
         Line.insert(0, QString::number(index+1));
         ui->TextList->insertItem(index, Line);
      }

      // Select the first line.
      ui->TextList->setCurrentRow(0);
      // User should only be allowed to select one line.
      ui->TextList->setSelectionMode(QAbstractItemView::SingleSelection);
      // Give input focus to the list widget.
      ui->TextList->setFocus();
   }


   // Set up the checkbox widget. If no title if given
   // then the checkbox is not used, and will be hidden.
   if (CheckBoxTitle.size()) {
      ui->CheckBox->setText(CheckBoxTitle);
      ui->CheckBox->setChecked(CheckStatus);
   } else {
      ui->CheckBox->hide();
   }
}

// This function adds an additional hidden string with each item. The hidden strings are given in 'ValueList'.
// IMPORTANT: Number of string in 'ValueList' must be equal to number of strings in 'TextList'.
void NumberedTxtListDlg::Init(QString WindowTitle, QStringList TextList, QStringList ValueList, QString CheckBoxTitle, QString *Selection, QString *Value, bool *CheckStatus)
{
   // Save variables.
   this->Value = Value;
   this->Selection = Selection;
   this->CheckStatus = CheckStatus;
   ReturnValue = true;

   // Set the window title.
   this->setWindowTitle(WindowTitle);

   // Set up the list widget.
   if (TextList.size()) {
      // Insert all text lines into the list. A line
      // number will be added to the front of each line.
      for (int index=0; index<TextList.size(); index++) {
         QString Line = TextList.at(index);
         Line.insert(0, " - ");
         Line.insert(0, QString::number(index+1));
         QListWidgetItem *item = new QListWidgetItem;
         item->setText(Line);
         item->setData(Qt::UserRole, ValueList.at(index));
         ui->TextList->insertItem(index, item);
      }

      // Select the first line.
      ui->TextList->setCurrentRow(0);
      // User should only be allowed to select one line.
      ui->TextList->setSelectionMode(QAbstractItemView::SingleSelection);
      // Give input focus to the list widget.
      ui->TextList->setFocus();
   }


   // Set up the checkbox widget. If no title if given
   // then the checkbox is not used, and will be hidden.
   if (CheckBoxTitle.size()) {
      ui->CheckBox->setText(CheckBoxTitle);
      ui->CheckBox->setChecked(CheckStatus);
   } else {
      ui->CheckBox->hide();
   }
}




// *****************************************
// User has pressed the OK button.
// *****************************************
void NumberedTxtListDlg::accept()
{
   // Get the selected text line from list widget.
   TextLine = ui->TextList->currentItem()->text();
   *Selection = TextLine.remove(0,  TextLine.indexOf(" - ") + 3);
   if (ReturnValue) *Value = ui->TextList->currentItem()->data(Qt::UserRole).toString();

   // Get the checkbox status.
   if (ui->CheckBox->isVisible()) *CheckStatus = ui->CheckBox->isChecked();

   // Close the dialog and return 'accepted' signal.
   QDialog::accept();
}




// *****************************************
// User has pressed the Cancel button.
// *****************************************
void NumberedTxtListDlg::reject()
{
   // Close the dialog and return 'rejected' signal.
   QDialog::reject();
}
