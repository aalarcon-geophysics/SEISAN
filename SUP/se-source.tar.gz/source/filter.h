#ifndef FILTER_H
#define FILTER_H

#include <QString>
#include <QStringList>
#include "types.h"
#include "eventnode.h"

// Define expression token types.
#define TTUNKNOWN    0
#define TTLEFTPAR    1
#define TTRIGHTPAR   2
#define TTRELATOPER  3
#define TTLOGICOPER  4
#define TTVARIABLE   5
#define TTINTEGER    6
#define TTFLOAT      7
#define TTSTRING     8
#define TTBFUNCTION  9
#define TTVFUNCTION  10


struct stack_item {
   int valueType;    // 0=float, 1=string, 3=logical.
   prop_value value;
   bool logicalValue;
};


bool TrimAndCheckInfix(QString *infix, QString *ErrMesg, char);
void TrimInfix(QString*);
bool CheckInfix(QString, QString*, bool, bool, bool);
void Infix2TokenList(QString, QStringList*);
bool Infix2Postfix(QString, QStringList*, QString*);
bool CheckFunction(QString, QString*);
bool ExecuteBoolFunction(event_node_*, QString, QStringList);
float ExecuteValueFunction(event_node_*, QString, QStringList);
bool EvaluatePostfix(QStringList, event_node_*);
int GetTokenType(QString);
QString GetVarType(QString);
void GetFunctionArgs(QString, QStringList*);
bool isOperator(QString);
bool isOperand(QString);
bool isValidHasStationProperty(QString);
bool isValidHasMagnitudeProperty(QString);
bool isReservedHasMagnitudeProperty(QString);
bool isValidHasFPSProperty(QString);
bool isReservedHasFPSProperty(QString);
bool OperCmp(QString, QString);

#endif // FILTER_H
