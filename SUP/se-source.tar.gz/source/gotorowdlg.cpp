#include "gotorowdlg.h"
#include "ui_gotorowdlg.h"


// ******************************************
// Constructor function.
// ******************************************
GoToRowDlg::GoToRowDlg(QWidget *parent) : QDialog(parent), ui(new Ui::GoToRowDlg)
{
    ui->setupUi(this);
    setWindowFlags(Qt::Popup);

    // Set focus to lineedit widget.
    ui->lineEdit->setFocus(Qt::PopupFocusReason);

}



// ******************************************
// Destructor function.
// ******************************************
GoToRowDlg::~GoToRowDlg()
{
    delete ui;
}



// *********************************************
// User have pressed 'Enter' or the 'OK' button.
// *********************************************
void GoToRowDlg::GoToRow()
{
   // Get the text from the lineedit widget.
   // Convert the text to an integer which
   // is returned to done().
   bool Ok;
   done(ui->lineEdit->text().toInt(&Ok));
}



