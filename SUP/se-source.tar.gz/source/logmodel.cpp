#include <QFile>
#include <QDateTime>
#include <QTextStream>
#include "logmodel.h"

// *****************************************************
// Constructor fuction for the class.
// *****************************************************
logmodel::logmodel(QObject *parent) : QAbstractListModel(parent)
{
   // Clear the log model/view.
   ClearLog();
}




// *****************************************************
// This function is used to set pointer to the Log View.
// *****************************************************
void logmodel::SetView(QListView *View)
{
   // Save pointer to the view.
   ModelView = View;
}




// *****************************************************
// This fuction is called from the log view to get
// the number of rows to present in the view.
// *****************************************************
int logmodel::rowCount(const QModelIndex &parent) const
{
   Q_UNUSED(parent)

   // Return current number of events in log.
   return MsgList.size();
}




// *****************************************************
// This fuction is called from log view to get the
// item texts in the view. One call for each item (row).
// *****************************************************
QVariant logmodel::data(const QModelIndex &index, int role) const
{
   // Get row and column numbers.
   int row = index.row();

   // Return string for current index.
   if (role == Qt::DisplayRole) {
      // Return log data for this row.
      return MsgList.at(row);
   }

   // Set text color.
   if (role == Qt::ForegroundRole) {
      if (MsgTypeList.at(row) == warning) return QColor(Qt::blue);
      if (MsgTypeList.at(row) == error) return QColor(Qt::red);
   }

   // Return an invalid QVariant.
   return QVariant();
}




// ********************************************************
// This fuction is signaled to write a message to the log.
// ********************************************************
void logmodel::WriteLog(logmodel::msg_type MsgType, QString Msg, bool NoTime)
{
   // Add date and time to start of message.
   if (!NoTime) {
      QDateTime Time = QDateTime::currentDateTime();
      Msg.prepend(Time.toString("yyyy-MM-dd@hh:mm:ss") + " ");
   }

   // Save message to lists and display in log view.
   beginInsertRows(QModelIndex(), MsgList.size(), MsgList.size());
   MsgList.append(Msg);
   MsgTypeList.append(MsgType);
   MsgFileList.append("none");
   endInsertRows();
}




// ********************************************************
// This fuction is signaled to write a message to the log.
// A filename attached to the message will also be saved.
// ********************************************************
void logmodel::WriteLog(logmodel::msg_type MsgType, QString Msg, QString FileName, bool NoTime)
{
   // Add date and time to start of message.
   if (!NoTime) {
      QDateTime Time = QDateTime::currentDateTime();
      Msg.prepend(Time.toString("yyyy-MM-dd@hh:mm:ss") + " ");
   }

   // Save message to lists and display in log view.
   beginInsertRows(QModelIndex(), MsgList.size(), MsgList.size());
   MsgList.append(Msg);
   MsgTypeList.append(MsgType);
   MsgFileList.append(FileName);
   endInsertRows();
}




// ******************************************************************
// This fuction is signaled to write the log to file 'se.log'.
// ******************************************************************
void logmodel::WriteLog2File()
{
   // Write all lines to the log file.
   QFile *LogFile = new QFile("se.log");
   if (LogFile->open(QIODevice::WriteOnly | QIODevice::Append | QIODevice::Text)) {
      QTextStream out(LogFile);
      for (int l=0;l<MsgList.size();l++) out << MsgList.at(l) << '\n';
      LogFile->close();
   }
   delete LogFile;
}




// ******************************************************************
// This fuction is signaled to clear the log file 'se.log'.
// ******************************************************************
void logmodel::ClearLogFile()
{
   QFile *LogFile = new QFile("se.log");
   if (LogFile->open(QIODevice::WriteOnly | QIODevice::Truncate)) LogFile->close();
   delete LogFile;
}




// *****************************************
// This fuction returns the file name
// associated with the given log line.
// *****************************************
QString logmodel::GetMsgFilename(int LogLine)
{
   return MsgFileList.at(LogLine);
}




// ********************************************************
// This fuction is signaled to clear the log.
// ********************************************************
void logmodel::ClearLog()
{
   // Clear the log model/view.
   beginResetModel();
   MsgList.clear();
   MsgTypeList.clear();
   MsgFileList.clear();
   endResetModel();
}




// ********************************************************
// This fuction is signaled to show the log view.
// ********************************************************
void logmodel::ShowLogView()
{
   emit show_log_view();
}




// ********************************************************
// This fuction the number of lines in the model.
// ********************************************************
int logmodel::GetNumberOfLines()
{
   return MsgList.size();
}
