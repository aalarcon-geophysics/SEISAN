#ifndef OPENDBDLG_H
#define OPENDBDLG_H

#include <QDialog>
#include "types.h"

namespace Ui {
   class OpenDbDlg;
}

class OpenDbDlg : public QDialog
{
   Q_OBJECT

public slots:
   void accept();           // 'OK' button is pressed.
   void reject();           // 'Cancel' button is pressed.
   void Select();           // 'Select' button is pressed.

public:
   explicit OpenDbDlg(QWidget *parent = nullptr);
   ~OpenDbDlg();
   void InitDialog(se_config, QString*, int*);

private:
   Ui::OpenDbDlg *ui;
   QString Message;
   QString SeisanTop;
   int *DbType;
   QString *Database;
};

#endif // OPENDBDLG_H
