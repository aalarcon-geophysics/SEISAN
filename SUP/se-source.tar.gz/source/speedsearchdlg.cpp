#include "speedsearchdlg.h"
#include "ui_speedsearchdlg.h"


// ******************************************
// Constructor function.
// ******************************************
SpeedSearchDlg::SpeedSearchDlg(QWidget *parent) : QDialog(parent), ui(new Ui::SpeedSearchDlg)
{
    ui->setupUi(this);
    setWindowFlags(Qt::Popup);
}


// ******************************************
// Destructor function.
// ******************************************
SpeedSearchDlg::~SpeedSearchDlg()
{
    delete ui;
}


void SpeedSearchDlg::InitDialog(db *pDataBase, char Key)
{
   // Indicate start of new search.
   start = true;

   // Save pointer to database object.
   database = pDataBase;

   // Connect signal between dialog and database.
   connect(this, SIGNAL(SpeedSearch(QString, bool)), pDataBase, SLOT(SpeedSearch(QString, bool)));

   // Insert incoming character in lineedit widget.
   ui->lineEdit->setText(QString(Key));

   // Set focus to lineedit widget.
   ui->lineEdit->setFocus(Qt::PopupFocusReason);
}


void SpeedSearchDlg::LineChanged()
{
    // Get new line from widget.
    Line = ui->lineEdit->text();

    // Check that last character in the line is a number.
    // If not then remove the invalid character end return.
    QChar Char;
    if (Line.size()) {
       Char = Line.at(Line.size()-1);
       if (Char.digitValue() == -1) {
          Line.chop(1);
          ui->lineEdit->setText(Line);
          return;
       }
    }

    // Emit line to database. Database will find first match
    // and return an index using signal SpeedSearchReply().
    emit SpeedSearch(Line, start); start = false;
}
