#ifndef LOCATEDLG_H
#define LOCATEDLG_H

#include <QSettings>
#include <QMainWindow>
#include <QTableWidget>
#include "sebase.h"
#include "eventnode.h"
#include "fortran.h"
#include "operatorid.h"

// Define row numbers for the Settings table.


// Define row numbers for the Settings table.
#define SET_MODIND_ROW      0
#define SET_FIXORT_ROW      1
#define SET_EPIFLAG_ROW     2
#define SET_DEPTHFLAG_ROW   3
#define SET_XNEAR_ROW       4
#define SET_XFAR_ROW        5
#define SET_SDEP_ROW        6

// Define column numbers for the Phase table.
#define PHASE_NUM_COL       0
#define PHASE_STAT_COL      1
#define PHASE_COMP_COL      2
#define PHASE_NETW_COL      3
#define PHASE_LOC_COL       4
#define PHASE_DATETIME_COL  5
#define PHASE_DIST_COL      6
#define PHASE_AZM_COL       7
#define PHASE_O_COL         8
#define PHASE_PHOBS_COL     9
#define PHASE_WTOBS_COL     10
#define PHASE_TOBS_COL      11
#define PHASE_PHCAL_COL     12
#define PHASE_AIN_COL       13
#define PHASE_WTCAL_COL     14
#define PHASE_TCAL_COL      15
#define PHASE_RES_COL       16
#define PHASE_IMP_COL       17

// Define column numbers for the Azimuth table.
#define AZM_NUM_COL         0
#define AZM_STAT_COL        1
#define AZM_COMP_COL        2
#define AZM_NETW_COL        3
#define AZM_LOC_COL         4
#define AZM_DATETIME_COL    5
#define AZM_DIST_COL        6
#define AZM_O_COL           7
#define AZM_PHOBS_COL       8
#define AZM_BAZOBS_COL      9
#define AZM_APPVEL_COL      10
#define AZM_WTOBS_COL       11
#define AZM_BAZCAL_COL      12
#define AZM_WTCAL_COL       13
#define AZM_RES_COL         14
#define AZM_IMP_COL         15

// Define column numbers for the Magnitude table.
#define MAG_NUM_COL         0
#define MAG_STAT_COL        1
#define MAG_COMP_COL        2
#define MAG_NETW_COL        3
#define MAG_LOC_COL         4
#define MAG_DATETIME_COL    5
#define MAG_DIST_COL        6
#define MAG_AZM_COL         7
#define MAG_PHOBS_COL       8
#define MAG_MAGTYPE_COL     9
#define MAG_AMP_COL         10
#define MAG_PER_COL         11
#define MAG_CODA_COL        12
#define MAG_MOMENT_COL      13
#define MAG_MAG_COL         14
#define MAG_RES_COL         15

// Define color limits for the tables.
const float PhaseColLimits[3] = {1.0,2.0,3.0};
const float AzimColLimits[3] = {5.0,10.0,20.0};
const float MagnColLimits[3] = {0.2,0.4,0.8};


namespace Ui { class LocateDlg; }

class LocateDlg : public QMainWindow
{
   Q_OBJECT

public slots:
   void PrevEventButton();    // The 'Prev event' button is pressed.
   void NextEventButton();    // The 'Next event' button is pressed.
   void LocateButton();       // The 'Locate' button is pressed.
   void RowChanged(SEBASE*);  // The current row has changed for the given database.
   void SaveButton();         // The 'Save' button is pressed.
   void SaveAndRename();      // The 'Save and Rename' item from 'File' menu is pressed.
   void CopyCoordinates();    // The 'Copy Coordinates' item from the 'Edit' menu is pressed.

public:
   explicit LocateDlg(OperatorId*);
   ~LocateDlg();

private slots:
   void EpicFlagChanged(int);
   void DepthFlagChanged(int);
   void SettingsTableChanged(QTableWidgetItem*);
   void PhaseTableItemChanged(QTableWidgetItem*);
   void AzimuthTableItemChanged(QTableWidgetItem*);
   bool eventFilter(QObject*, QEvent*);

private:
   Ui::LocateDlg *ui;
   int CurRowNr;
   char TmpFile[80];
   SEBASE *SEDB;
   QListPhase Phases;
   event_node_ *Node, *LocatedNode;
   OperatorId *Operator;
   QSettings settings;
   QStringList HypMesg;
   QTableWidgetItem *OrtFlagItem, *DepthFlagItem, *EpiFlagItem, *Item;
   QColor EditableCellColor, GrayTextColor;
   QColor GreenCellColor, YellowCellColor, OrangeCellColor, RedCellColor;
   QString Message, FileName, GreenColor, YellowColor, OrangeColor, RedColor;

   // Private functions.
   void DeletePhases();
   void DeleteMagnitudes();
   void SaveSfile(bool);
   void PopulateWidgets(event_node_*);
   void PopulatePhaseTable(bool);
   void PopulateAzimuthTable(bool);
   void PopulateMagnitudeTable(bool);
   bool ValidateUserInput(bool = false);
   void CopyBasicValuesToNode(event_node_*);
   void CopySettingsTableValuesToNode(event_node_*);
   void SavePhaseTableValues();
   void SaveAzimuthTableValues();
   void showEvent(QShowEvent *);
};

#endif // LOCATEDLG_H
