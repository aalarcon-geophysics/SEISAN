#ifndef EVENTNODE_H
#define EVENTNODE_H

#include <QChar>
#include <QFile>
#include "types.h"
#include "seisandb.h"

struct prop_value {
   int valueType;    // Property type. 0=float, 1=string.
   bool novalue;     // If true then there is no data for this property.
   float number;
   QString string;
};

struct agency_mags {
   QString agency;
   float MW;
   float ML;
   float MN;
   float MC;
   float Mb;
   float MB;
   float Ms;
   float MS;
};

struct agency_fps {
   QString agency;
   QString quality;
};


event_node_* NodeLocate(event_node_*, QStringList*);
void NodeGetWaveFiles(event_node_*, QStringList*);
void NodeGetComments(event_node_*, QStringList*);
bool NodeIsRegistered(event_node_*);
void NodeSetComments(event_node_*, QStringList);
void NodeAddComment(event_node_*, QString);
bool NodeAddHypocenter(event_node_*, hypocenter_*);
void AddTextLine(text_lines*, QString, QChar);
void GetTextLines(text_lines*, QStringList*);
int HypGetNumberOfMagnitudes(hypocenter_*);
void HypInitialize(hypocenter_*);
void SetTextLines(text_lines*, QStringList, QChar);
void NodeGetIdlineAction(event_node_*, QString*);
void NodeSetIdlineAction(event_node_*, QString);
void NodeSetIdlineUpdatetime(event_node_*);
void NodeSetIdlineOperator(event_node_*, QString);
void NodeSetIdlineID(event_node_ *, QString ID = QString());
QString NodeGetIdlineID(event_node_ *Node);
bool NodeSetFileNameFromHypo(event_node_*);
void NodeSetUniqueFileName(event_node_*);
void NodeGetProperty(event_node_*, QString, prop_value*);
void NodeGetStationProperty(phase_*, QString, prop_value*);
bool NodeHasFpsQuality(event_node_*, QString);
void NodeGetAllFPS(event_node_*, QList<agency_fps>*);
void NodeGetAllHypocenterMags(event_node_*, QList<agency_mags>*);
void NodeGetPriHypocenterMags(event_node_*, QList<agency_mags>*);
void NodeGetPhases(event_node_*, QListPhase*);
bool NodeSetPhases(event_node_*, QListPhase*);
void NodeGetPriHypocenterDateTime(event_node_*, QString*, QString*);
bool NodeHasMagType(event_node_*, QString);
event_node_* ReadSfile(char*, char*, QStringList* = nullptr);
event_node_* CreateNodeFromCommonBlocks();
bool WriteSfile(event_node_*, char*);
event_node_* CopyNode(event_node_*);
void FreeNode(event_node_*);
QChar NodeGetDistanceIndicator(event_node_*);
QChar NodeGetEventIndicator(event_node_*);
QChar NodeGetModelIndicator(event_node_*);
void NodeSetDistanceIndicator(event_node_*, QChar);
void NodeSetEventIndicator(event_node_*, QChar);
void NodeSetModelIndicator(event_node_*, QChar);
char NodeCmp(event_node_*, event_node_*, sortCol);
bool LessThan_DateTime(event_node_*, event_node_*);
bool LessThan_Action(event_node_*, event_node_*);
bool LessThan_Latitude(event_node_*, event_node_*);
bool LessThan_Longitude(event_node_*, event_node_*);
bool LessThan_Depth(event_node_*, event_node_*);
bool LessThan_Model(event_node_*, event_node_*);
bool LessThan_Agency(event_node_*, event_node_*);
bool LessThan_RMS(event_node_*, event_node_*);
bool LessThan_Gap(event_node_*, event_node_*);
bool LessThan_ErrLat(event_node_*, event_node_*);
bool LessThan_ErrLon(event_node_*, event_node_*);
bool LessThan_ErrDep(event_node_*, event_node_*);
bool LessThan_Dist(event_node_*, event_node_*);
bool LessThan_Type(event_node_*, event_node_*);
bool LessThan_MInt(event_node_*, event_node_*);
bool LessThan_NSta(event_node_*, event_node_*);
bool LessThan_M(event_node_*, event_node_*);
bool LessThan_MW(event_node_*, event_node_*);
bool LessThan_ML(event_node_*, event_node_*);
bool LessThan_MN(event_node_*, event_node_*);
bool LessThan_MC(event_node_*, event_node_*);
bool LessThan_Mb(event_node_*, event_node_*);
bool LessThan_MB(event_node_*, event_node_*);
bool LessThan_Ms(event_node_*, event_node_*);
bool LessThan_MS(event_node_*, event_node_*);
bool LessThan_Locality(event_node_*, event_node_*);
bool LessThan_SFile(event_node_*, event_node_*);

#endif // EVENTNODE_H
