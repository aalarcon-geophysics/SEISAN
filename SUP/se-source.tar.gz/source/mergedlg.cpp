#include "mergedlg.h"
#include "ui_mergedlg.h"

// ******************************************
// Constructor function.
// ******************************************
MergeDlg::MergeDlg(QString Label, QWidget *parent) : QDialog(parent), ui(new Ui::MergeDlg)
{
   ui->setupUi(this);
   ui->label->setText(Label);
   ui->label->setWordWrap(true);
}


// ******************************************
// Destructor function.
// ******************************************
MergeDlg::~MergeDlg()
{
   delete ui;
}

// ************************************************
// User have pressed the 'Merge and delete' button.
// ************************************************
void MergeDlg::CancelButton()
{
   done(0);
}


// ******************************************
// User have pressed the 'Merge' button.
// ******************************************
void MergeDlg::MergeButton()
{
   done(1);
}


// ************************************************
// User have pressed the 'Merge and delete' button.
// ************************************************
void MergeDlg::MergeDelButton()
{
   done(2);
}
