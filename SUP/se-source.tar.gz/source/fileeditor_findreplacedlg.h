#ifndef FILEEDITOR_FINDREPLACEDLG_H
#define FILEEDITOR_FINDREPLACEDLG_H

#include <QDialog>
#include "types.h"

namespace Ui {
   class fileeditor_findreplacedlg;
}

class fileeditor_findreplacedlg : public QDialog
{
   Q_OBJECT

public slots:
   void accept();
   void reject();

public:
   explicit fileeditor_findreplacedlg(QWidget *parent = 0, frdata *data = 0);
   ~fileeditor_findreplacedlg();

private:
   Ui::fileeditor_findreplacedlg *ui;
   frdata *pdata;
   frdata dlgdata;
};

#endif // FILEEDITOR_FINDREPLACEDLG_H
